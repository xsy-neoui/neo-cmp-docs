package other.xsy.proxy.utils;

import com.alibaba.fastjson.JSONObject;

/**
 * className:  Result
 * Package:  other.xsy.query.utils.Result
 * Description:
 *
 * @Date: 2025/11/14 13:18
 * @Author: wibetter
 */
public class Result {
    public static final Long SUCCESS = 200L;
    private Long code;
    private JSONObject result;
    private String errorMessage;
    private Boolean success;

    public Result(Long code, JSONObject result, String errorMessage, Boolean success) {
        this.code = code;
        this.result = result;
        this.errorMessage = errorMessage;
        this.success = success;
    }

    public Result() {
    }

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public JSONObject getResult() {
        return result;
    }

    public void setResult(JSONObject result) {
        this.result = result;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public static <T> Result resultSuccessWrapper(T data) {
        JSONObject o = new JSONObject();
        o.put("data", data);
        return new Result(Result.SUCCESS, o, null, true);
    }

    public static <T> Result resultFailWrapper(Long code, String msg) {
        return new Result(code, null, msg, false);
    }
}
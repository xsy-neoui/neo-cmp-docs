package other.xsy.proxy.api;

import com.alibaba.fastjson.JSONObject;
import com.rkhd.platform.sdk.api.annotations.RequestMethod;
import com.rkhd.platform.sdk.api.annotations.RestApi;
import com.rkhd.platform.sdk.api.annotations.RestBeanParam;
import com.rkhd.platform.sdk.api.annotations.RestMapping;
import com.rkhd.platform.sdk.http.CommonData;
import com.rkhd.platform.sdk.http.CommonHttpClient;
import com.rkhd.platform.sdk.http.HttpResult;
import com.rkhd.platform.sdk.log.Logger;
import com.rkhd.platform.sdk.log.LoggerFactory;
import other.xsy.proxy.utils.Result;

import java.util.Map;

/**
 * className:  ProxyApi
 * Package:  other.xsy.proxy.api.ProxyApi
 * Description: 通用接口转发API，接收所有类型的请求并自动转发到请求参数中的url
 *
 * @Date: 2025/11/14 13:18
 * @Author: wibetter
 */
@RestApi(baseUrl = "/proxy")
public class ProxyApi {
    private final static Logger LOG = LoggerFactory.getLogger();

    /**
     * 通用转发接口
     * 接收请求参数，提取url和method字段，将请求转发到指定URL
     * 
     * @param data 包含以下字段的JSON对象：
     *             - url: 目标转发地址（必需）
     *             - method: HTTP方法，如GET、POST等（可选，默认为POST）
     *             - data: 其他请求参数（可选）
     * @return 直接返回转发后的响应数据，如果转发失败则返回错误信息
     */
    @RestMapping(value = "/forward", method = RequestMethod.POST)
    public Object forward(@RestBeanParam(name = "data") JSONObject data) {
        try {
            // 1. 从请求参数中提取目标URL和HTTP方法
            String targetUrl = data.getString("url");
            if (targetUrl == null || targetUrl.trim().isEmpty()) {
                LOG.error("转发URL为空");
                return Result.resultFailWrapper(5000001L, "转发URL(url)不能为空");
            }

            String method = data.getString("method");
            if (method == null || method.trim().isEmpty()) {
                method = "POST"; // 默认使用POST方法
            }
            method = method.toUpperCase().trim();

            // 2. 从data.data中获取其他请求参数
            JSONObject requestParams = data.getJSONObject("data");
            if (requestParams == null) {
                requestParams = new JSONObject(); // 如果没有data字段，使用空对象
            }

            LOG.info("开始转发请求,目标URL:" + targetUrl + ",方法:" + method);

            // 3. 根据method类型处理参数
            CommonHttpClient commonHttpClient = CommonHttpClient.instance();
            CommonData commonData = new CommonData();
            commonData.setCall_type(method);
            commonData.setCallString(targetUrl);

            // 4. 如果是GET请求，将参数追加到URL查询字符串
            if ("GET".equals(method)) {
                // 构建查询参数字符串
                StringBuilder queryString = new StringBuilder();
                boolean first = true;
                for (Map.Entry<String, Object> entry : requestParams.entrySet()) {
                    String key = entry.getKey();
                    if (entry.getValue() != null) {
                        if (!first) {
                            queryString.append("&");
                        }
                        queryString.append(key).append("=").append(entry.getValue());
                        first = false;
                    }
                }

                // 如果有查询参数，追加到URL
                if (queryString.length() > 0) {
                    if (targetUrl.contains("?")) {
                        targetUrl += "&" + queryString.toString();
                    } else {
                        targetUrl += "?" + queryString.toString();
                    }
                    commonData.setCallString(targetUrl);
                }
            } else {
                // POST/PUT/PATCH等请求，将参数作为请求体
                commonData.putHeader("Content-Type", "application/json");
                commonData.setBody(requestParams.toJSONString());
            }

            // 5. 发送HTTP请求
            HttpResult httpResult = commonHttpClient.execute(commonData);
            
            // 6. 获取响应结果，如果execute()成功返回（没有抛异常），表示请求成功，直接返回响应数据
            String responseBody = httpResult.getResult();
            
            try {
                // 尝试解析为JSON对象
                Object responseJson = JSONObject.parse(responseBody);
                LOG.info("转发请求成功,目标URL:" + targetUrl + ",方法:" + method + ",响应:" + responseBody);
                return responseJson;
            } catch (Exception e) {
                // 如果响应不是JSON格式，直接返回原始字符串
                LOG.info("转发请求成功,目标URL:" + targetUrl + ",方法:" + method + ",响应:" + responseBody);
                return responseBody;
            }

        } catch (Exception e) {
            LOG.error("转发请求失败,错误信息:" + e.getMessage(), e);
            return Result.resultFailWrapper(5000002L, "转发请求失败:" + e.getMessage());
        }
    }

}


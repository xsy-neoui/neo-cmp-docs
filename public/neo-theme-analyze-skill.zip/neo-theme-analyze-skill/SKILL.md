---
name: neo-theme-analyze-skill
description: 当用户要求分析 / 梳理 / 盘点当前项目的 Neo 主题换肤支持情况（只读分析，不做改动）时触发。对项目源码扫描已使用的 Neo 主题 CSS 变量及尚未替换的硬编码品牌色，并分析每个组件的功能说明（50 字内）、组件类型与项目内使用位置：通过 NeoRegister 注册且 name 作为 type 的判定为 amis 组件；通过 XRegister.CmpDefine 注册且 cmpType 作为标识的判定为 Neo 2.0 组件；其余为未知。最终输出《当前项目主题换肤支持情况.md》，包含项目名称、仓库地址、所在分支、组件名称、页面、文件位置、功能、类型、使用位置、主题变量与硬编码色明细。本技能只读分析、绝不修改源码。触发关键词：分析项目主题换肤支持情况、梳理主题换肤支持情况、盘点主题换肤、主题换肤支持情况分析、项目换肤情况分析、分析已支持换肤的组件、分析还有哪些硬编码色、当前项目主题换肤支持情况、主题换肤现状分析、换肤兼容性分析。
---

# Neo 平台主题换肤支持情况分析技能

对 Neo 平台项目做**只读**扫描与梳理，产出一份《当前项目主题换肤支持情况.md》报告，回答两个问题：

1. **哪些页面 / 组件已经支持换肤**（已使用 Neo 主题 CSS 变量），分别用到了哪些 CSS 变量。
2. **哪些页面 / 组件尚存硬编码色值**（仍在使用未替换为 CSS 变量的硬编码品牌色），分别残留了哪些硬编码色值。

> 🔒 **本技能是纯分析工具，全程只读，绝不修改任何源码**。本技能**独立自包含**，所需的「CSS 变量清单 + 硬编码色值 / 近似色匹配规则 + 忽略规则」已全部内置于本技能 `references/` 目录，无需依赖任何其他技能，只做识别与归纳，不做替换。若需真正改造（把硬编码色值替换为 CSS 变量），请另行使用改造类技能。

---

## 一、触发条件

当用户提出以下需求时启动本技能：

- **"分析 / 梳理当前项目的主题换肤支持情况"**
- "盘点一下项目里哪些组件已经支持换肤 / 还有哪些尚存硬编码色值"
- "项目换肤现状分析"、"主题换肤兼容性分析"
- "看看还有哪些页面 / 组件在用硬编码色"

若用户的真实意图是**改造 / 替换**（让项目支持换肤、升级换肤功能），本技能不负责改造，仅负责只读分析与报告，请另行使用改造类技能。

---

## 二、执行总览

本技能按顺序执行五个步骤，最终产出一份报告：

| 步骤 | 任务 | 产出 |
|:--|:--|:--|
| **0** | 采集项目关键信息 | 项目名称、仓库地址、所在分支 |
| **1** | 扫描「已支持换肤」 | 已用 CSS 变量的组件清单 + 变量分类与明细 |
| **2** | 扫描「尚存硬编码色值」 | 残留硬编码色值的组件清单 + 具体色值 |
| **3** | 分析组件元数据与使用位置 | 50 字内功能说明、组件类型、type/cmpType、项目内引用位置 |
| **4** | 生成报告 | 项目根目录 `当前项目主题换肤支持情况.md` |

> **必须**先运行 `scripts/neoThemeAnalyzer.js`（内置扫描器）一次性完成步骤 1~3 的数据采集，再由你**逐个**读取组件入口、判定注册类型与引用位置并撰写报告。脚本用法见 [scripts/README.md](scripts/README.md)。也可按下文规则手动扫描，但无论采用哪种方式，**报告中的每个字段都必须由你自行完成并填满，不得留空、不得标注「待人工复核」「待确认」等占位内容**（详见 §七「硬性输出规范」）。

> ⚠️ **本技能全程由你（agent）自主完成，不存在任何交由外部人工复核的环节。** 所有"复核 / 确认 / 核实"动作都是**你自己必须执行**的步骤：脚本产出的功能说明、组件类型、使用位置等都只是**初筛线索**，你必须读取源码把它们**核实并定稿**后写入报告，而不是把不确定项遗留给他人。

---

## 三、步骤 0：采集项目关键信息（报告头必填）

报告开头必须标注项目关键信息，通过以下命令采集（**只读**，不修改仓库）：

```bash
# 项目名称：优先取 package.json 的 name 字段
node -e "try{console.log(require('./package.json').name||'未知')}catch(e){console.log('未知')}"

# 仓库地址：远程 origin 的 URL
git config --get remote.origin.url || echo "未知"

# 所在分支：当前分支名
git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "未知"

# （可选）当前 commit，便于报告溯源
git rev-parse --short HEAD 2>/dev/null || echo "未知"
```

任一信息取不到时，在报告中如实填写「未知」。

---

## 四、步骤 1：扫描「已支持换肤」的页面与组件

### 4.1 扫描目标

在项目源码（`*.scss` / `*.css` / `*.less` / `*.tsx` / `*.ts` / `*.jsx` / `*.js`，排除 `node_modules`、`__tests__`、`*.test.*`、`*.spec.*`、构建产物目录）中，查找所有对 **Neo 主题 CSS 变量**的引用，即 `var(--xxx)` 形式（含 `rgba(var(--xxx-rgb), a)`）。

**Neo 主题 CSS 变量的完整清单与分类**见 [references/css-variables-catalog.md](references/css-variables-catalog.md)。分为 7 大类：

| 分类 | 变量前缀 / 代表变量 |
|:--|:--|
| 品牌色 | `--brand-color`、`--brand-color-hover`、`--brand-color-shade` … |
| 背景色 | `--color-bg-brand*` |
| 边框色 | `--color-border-brand*` |
| 图标色 | `--color-icon-brand*`、`--color-icon-fill-brand-link` |
| 文本色 | `--color-text-brand*`、`--color-text-brand-link` |
| 按钮色 | `--color-button-filled-primary*`（含 -color / -secondary 系列） |
| 导航色 | `--brand-nav-header-*` |

> 只统计上述**主题变量**；项目自定义的非主题 `var(--xxx)`（如 `--gap`、`--radius`）不计入。判定方式见 [references/analysis-rules.md](references/analysis-rules.md) §1。

### 4.2 搜索命令（手动方式）

```bash
# 搜索所有 Neo 主题 CSS 变量引用
grep -rnoE "var\(--(brand-color|color-bg-brand|color-border-brand|color-icon-brand|color-icon-fill-brand|color-text-brand|color-button-filled-primary|brand-nav-header)[a-z0-9-]*" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="node_modules" --exclude-dir="__tests__" --exclude-dir="dist" --exclude-dir="build"
```

### 4.3 组件 / 页面归属判定

每个命中都要归属到「组件」与「所在页面」，判定规则见 [references/analysis-rules.md](references/analysis-rules.md) §3。要点：

- **组件名称**：优先取同目录 / 同名的组件文件名（如 `UserCard.tsx` → `UserCard`）；样式文件（`.scss`/`.less`）优先关联同名或 `index` 组件；再退化到就近的类名 / 函数组件名；实在无法判定时用文件名。
- **所在页面**：根据目录结构推断（如 `src/pages/Dashboard/...` → `Dashboard 页`、`src/views/order/...` → `订单页`）；无法判定时填「未知」。
- **文件位置**：相对项目根目录的路径 + 行号。

### 4.4 汇总维度

对每个组件，汇总：

1. **用到的 CSS 变量分类**（先列大类：品牌色 / 按钮色 / 边框色 / 背景色 / 图标色 / 文本色 / 导航色）；
2. **具体的 CSS 变量列表**（去重后列出该组件用到的每一个变量名）。

---

## 五、步骤 2：扫描尚存硬编码色值

### 5.1 扫描目标

按本技能内置的**硬编码品牌色识别规则**，找出仍以硬编码色值（未替换为 CSS 变量）出现的品牌色，即「应替换但尚未替换」的残留项，统称为**尚存硬编码色值**。

- **完全匹配色值表（32 色）**、**近似色匹配规则（仅以 `#0564f5` 为基准，1-2 色阶差）**、**8 位 hex / rgb / rgba 处理**：完整规则见本技能 [references/color-matching-rules.md](references/color-matching-rules.md)（规则已内置于本技能，自包含无外部依赖）。
- 可编程判定引擎：[scripts/neoThemeColorMatcher.js](scripts/neoThemeColorMatcher.js) 的 `matchBrandColor()`，`matchType` 为 `exact*` / `approximate*` 者视为「命中的硬编码品牌色」。

#### Primary 按钮语义 class 识别（强制）

扫描硬编码色值时，以下 class 模式必须识别为 Primary 按钮：`button-primary`、`ant-btn-primary`、`btn-primary`、`a-Button--primary`、**class 名称或 class token 中含 `btn-conform`**、**class 名称或 class token 中含 `add_button`、`confirm_button`、`cancel_button`**，以及其他包含 `primary` 关键词的按钮类名。

> ⚠️ `btn-conform` 虽然不含 `primary` 关键词，但属于 Primary 按钮语义。分析其样式块及 `hover` / `active` 状态时，必须按 Primary 按钮处理，不得因缺少 `primary` 字样而漏掉。命中的按钮背景、文字或边框硬编码色需在报告中保留其按钮语义，并优先建议对应的 `--color-button-filled-primary*` 变量，而不是只按普通品牌色给出建议。

> ⚠️ **业务语义按钮（`add_button` / `confirm_button` / `cancel_button`）**：这三类均不含 `primary` 关键词，但都属于 Primary 按钮语义，必须一并识别、不得漏判。其中 **`add_button`（新增）、`confirm_button`（确认）** 为实心 Primary 按钮，按背景白 / 非白正常给出按钮变量建议；**`cancel_button`（取消）** 为空心（轮廓）按钮，一律按白底轮廓规则给建议——只对其 `color` / `border-color` 建议 `--color-button-filled-primary` 状态系列，背景保持原样不建议改。

具体建议变量按背景与状态确定：非白色背景的 `background` / `background-color` 使用 `--color-button-filled-primary`、`-hover`、`-active`；其 `color` 使用 `--color-button-filled-primary-color` 或 `-color-hover`（字体色变量）；其 `border-color` / `border` 中色值使用**与 background 相同的按钮背景色变量** `--color-button-filled-primary`、`-hover`、`-active`（**非字体色变量**）；白色背景按钮及空心按钮（含 `cancel_button`）的 `color` / `border-color` 使用 `--color-button-filled-primary` 状态系列。

### 5.2 忽略规则（命中即不计入尚存硬编码色值）

> ⚠️ **强制要求**：扫描尚存硬编码色值时，**必须严格按以下忽略规则逐项判定并跳过处理**。这套忽略规则完整内置于本技能，不依赖任何其他技能。对每个命中的硬编码色值，命中任一规则即判为「合法跳过」，**不计入**「尚存硬编码色值」，但可在报告「合法跳过」区单独记录。判定顺序固定、不可打乱、不可跳步：

1. 类名 / 变量名中含色值（如 `text-[#0564f5]`、`bg-[#4e80f5]`）
2. 测试文件（`*.test.*`、`*.spec.*`、`__tests__/`）
3. **已注释代码**（强制铁律）：**必须**排除掉所有位于任何形式注释内的色值，覆盖 5 类形态：① 单行 `//`；② 行内 `//` 之后（`// fallback #0564f5`）；③ 单行块注释 `/* ... */`；④ **多行块注释 `/* ... */` 中间行**（含以 `*` 起首的续行，须用状态机跟踪 `/*` / `*/` 开合）；⑤ JSX 注释 `{/* ... */}`。凡命中任一形态即视为已注释，一律跳过、不计入残留。详细判定见 [analysis-rules.md](references/analysis-rules.md) §2 补充「已注释行识别」
4. 所属 CSS 选择器（含多行、SCSS/Less 嵌套、`&` 拼接）向上回溯后 class 名含 `blue`
5. ECharts option 属性值（**须读取完整文件上下文，向上回溯到最外层 option 对象确认**：① 任意层级命中 `series: [{ type: 'bar' }]`、`xAxis`、`yAxis`、`legend`、`grid`、`dataZoom`、`visualMap` 等专有属性；② 祖先 key 链含 ECharts 专有 key（如 `legend.pageIconColor`）；③ 经 `define()` / `export default` / `module.exports` / `return` 导出且顶层含 ≥2 个 ECharts 顶层 option 键的独立配置模块，**即使不 import echarts、不用 `<ReactECharts>`、变量不叫 option 也算**——三者任一命中即成立，不能只看 `color:` / `itemStyle:` 等单行属性名，细则见 [analysis-rules.md](references/analysis-rules.md) §2 补充「ECharts 判定」） / 颜色数组字面量 / `var(--x, #xxx)` 回退值 / 取色器（调色板）对象
6. SASS / Less 变量名含 `blue`（如 `$blue-base`、`@blue-6`）
7. 与基准色 `#0564f5` 差异超阈值（Δ_ch > 32 或 d > 50）的其他蓝色 / 非品牌色

完整判定细则见本技能 [references/analysis-rules.md](references/analysis-rules.md) §2。

### 5.3 搜索命令（手动方式）

```bash
# 6 位 hex 品牌色（主品牌色 21 组 + 次品牌色 11 组，含大小写），排除已注释、var() 回退、测试、node_modules
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#3399cc|#3399CC|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC|#4b87f1|#4B87F1" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" --exclude-dir="dist" --exclude-dir="build" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# 8 位 hex（含透明度），前 6 位命中表中任一色值
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|3399cc|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc|4b87f1)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" --exclude-dir="dist" --exclude-dir="build" \
  -i | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# rgb / rgba 数值格式
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|26,\s*122,\s*255|37,\s*124,\s*255|6,\s*86,\s*213|0,\s*123,\s*255|36,\s*104,\s*242|28,\s*97,\s*218|24,\s*101,\s*217|37,\s*99,\s*235|29,\s*78,\s*216|4,\s*123,\s*219|23,\s*88,\s*231|0,\s*126,\s*255|51,\s*153,\s*204|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255|76,\s*161,\s*220|75,\s*135,\s*241)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" --exclude-dir="dist" --exclude-dir="build" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("
```

> 📌 **注释行过滤增强**：以上 3 条 grep 命令均使用 `grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)"` 排除各类注释行（含多行块注释中间以 `*` 起始的续行），配合 §5.2 忽略规则第 3 项「已注释行」共同确保**已注释代码中的硬编码色值不会被误判为「尚存硬编码色值」的残留项**。多行块注释（跨行 `/* ... */`）内嵌的色值须借助脚本状态机识别（详见 [analysis-rules.md](references/analysis-rules.md) §2 补充「已注释行识别」）。

> ⚠️ grep 命令只是初筛，**近似色（未在完全匹配表中但与 `#0564f5` 差 1-2 色阶）**无法用固定 grep 命中，须借助 `scripts/neoThemeAnalyzer.js` / `matchBrandColor()` 判定，或对可疑蓝色逐一按 [references/color-matching-rules.md](references/color-matching-rules.md) 计算 Δ_ch / d。

### 5.4 汇总维度

对每个仍有尚存硬编码色值的组件，汇总：组件名称、所在页面（未知则填「未知」）、文件位置（含行号）、残留的具体硬编码色值列表（标注完全匹配 / 近似匹配，以及建议替换的目标变量）。

---

## 六、步骤 3：分析组件功能、类型与使用位置

步骤 1、2 命中的**每个组件**都必须补充以下信息，完整判定细则见 [references/analysis-rules.md](references/analysis-rules.md) §4：

### 6.1 功能说明（50 字内）

1. 找到组件实现入口（优先注册文件、同名 `.tsx/.jsx/.ts/.js`、同目录 `index.*`）。
2. 阅读组件的渲染结构、核心 props、事件处理、数据请求 / 状态逻辑，不得仅凭文件名臆测。
3. 用一句中文概括组件当前功能，**总长度不得超过 50 个字符**；不要写技术实现细节或换肤结论。
4. 脚本的 `featureDescription` 只是依据注释 / `description` / `label` / `title` 提取的**初筛线索**；你**必须**结合已读取的组件代码把它改写成准确的功能说明后写入报告，**不得**直接照抄脚本候选值，也**不得**留空或写「待复核」。

### 6.2 组件类型与注册标识

按以下固定优先级判定：

| 注册方式 | 组件类型 | 注册标识 |
|:--|:--|:--|
| `NeoRegister(...)` | `amis 组件` | 注册配置中的 `name`，即组件 `type` |
| `XRegister.CmpDefine(...)` | `Neo 2.0 组件` | 注册配置中的 `cmpType` |
| 两者均未发现 | `未知` | `未知` |

- 支持装饰器、函数调用、对象参数和字符串参数等常见写法；不要因目录名含 `__c` 就直接判定类型。
- 若同一组件同时命中两类注册，你**必须**在报告中**同时列出两种注册标识**并注明「注册冲突」，不得擅自只选一种、也不得因此留空。

### 6.3 查找项目内使用位置

- amis 组件：用注册 `name` 的值精确搜索 `type: '<name>'` / `"type": "<name>"`。
- Neo 2.0 组件：用注册 `cmpType` 的值精确搜索 `cmpType: '<value>'` / `"cmpType": "<value>"`。
- 搜索当前项目全部源码与配置，排除 `node_modules`、测试文件、构建产物和组件自身的注册声明。
- 报告中列出相对路径 + 行号；同一行去重。未找到引用写「未发现」，类型未知或无标识时写「无法按注册标识检索」。
- 脚本输出的 `usedAt` 为精确属性值初筛结果，你**必须**逐条核实其是否为真实组件引用（剔除示例、注释、类型声明与无关配置）后再写入报告，核实由你自己完成。

---

## 七、步骤 4：生成《当前项目主题换肤支持情况.md》

在**项目根目录**生成报告文件 `当前项目主题换肤支持情况.md`，结构与模板见 [references/report-template.md](references/report-template.md)。报告须包含：

1. **项目关键信息**（步骤 0）：项目名称、仓库地址、所在分支（+ 可选 commit、分析日期）。
2. **总体汇总**：扫描文件数、已支持换肤组件数、尚存硬编码色值的组件数、命中的主题变量总数、残留硬编码色值总数。
3. **一、已支持换肤的页面与组件**：每个组件一行，含组件名称、功能说明（≤50 字）、组件类型、注册标识、所在页面、文件位置、用到的地方、CSS 变量分类与具体变量列表。
4. **二、尚存硬编码色值**：每个组件一行，含组件名称、功能说明（≤50 字）、组件类型、注册标识、所在页面、文件位置、用到的地方、残留硬编码色值（+ 建议目标变量、匹配类型）。
5. **三、合法跳过项**（可选）：因忽略规则跳过的硬编码色值及原因。

### 7.1 硬性输出规范（必须严格遵守，不得偏离）

以下为**强制约束**，生成报告时逐条满足，任一不满足即视为未完成本技能：

1. **必须以「组件」为最小粒度逐行输出，严禁用目录 / 文件计数聚合替代组件明细。** 「一、已支持换肤」和「二、尚存硬编码色值」都必须是**逐组件的表格**（组件多时可按页面 / 目录分组小节，但每个组件仍占独立行）。**禁止**出现「`components/` 目录 120 个文件」这类以目录文件数代替组件清单的写法。
2. **每一行的每一个字段都必须填满真实值。** 已支持换肤表必含：组件名称、功能说明（≤50 字）、组件类型、注册标识、所在页面、文件位置、用到的地方、CSS 变量分类。尚存硬编码表必含：组件名称、功能说明（≤50 字）、组件类型、注册标识、所在页面、文件位置、用到的地方、残留硬编码色值、匹配类型、建议目标变量。
3. **不得留空、不得使用占位符。** 任何字段都不允许出现空白、`-`、`TODO`、「待补充」「待人工复核」「待确认」等占位内容。确实无法判定的字段，只能按规定填写约定值：所在页面填「未知」、功能说明填「未知（未找到组件实现入口）」、组件类型 / 注册标识填「未知」、使用位置填「未发现」或「无法按注册标识检索」。
4. **必须包含「一、已支持换肤」的逐组件 CSS 变量明细区（1.x）**：概览表之外，每个已支持组件都要有一个明细小节，列出去重后的具体变量列表并按大类归组。只给大类聚合统计、不给逐组件具体变量列表的，视为不合规。
5. **功能说明必须来自对组件实现的实际阅读**（渲染结构 / props / 交互 / 数据逻辑），不得仅凭文件名或脚本候选值臆测，长度 ≤50 字。
6. **组件类型与注册标识必须来自注册代码证据**：`NeoRegister.name` → amis 组件 + `type`；`XRegister.CmpDefine.cmpType` → Neo 2.0 组件 + `cmpType`；无证据填「未知」。
7. **报告内容必须与实际扫描 / 阅读结果一致**，不得编造组件、色值或引用位置。

> 报告内容须与实际扫描结果一致。**本技能不修改任何源码**，只生成这一份 md 报告。生成后必须对照 §八「执行检查清单」逐项自检，全部通过方可交付。

---

## 八、执行检查清单

- [ ] **全程只读**，未修改任何源码文件
- [ ] 已采集项目关键信息（名称 / 仓库地址 / 分支），缺失项填「未知」
- [ ] 步骤 1 已扫描全部 7 类 Neo 主题 CSS 变量的引用
- [ ] 已支持换肤的每个组件均含：名称、功能说明（≤50 字）、组件类型、注册标识、所在页面（未知填「未知」）、文件位置、用到的地方、变量分类、具体变量列表
- [ ] 步骤 2 已按完全匹配（含 `#3399cc` 等经典 Web 蓝）+ 近似匹配（仅基准 `#0564f5`）规则识别硬编码品牌色
- [ ] Primary 按钮语义 class 已完整识别：`button-primary`、`ant-btn-primary`、`btn-primary`、`a-Button--primary`、class 含 `btn-conform`、`add_button`、`confirm_button`、`cancel_button` 及其他含 `primary` 的按钮类；其中 `btn-conform`、`add_button`、`confirm_button`、`cancel_button` 未因缺少 `primary` 字样而漏判；`add_button` / `confirm_button` 按实心按钮、`cancel_button` 按空心（轮廓）按钮给出 `--color-button-filled-primary*` 建议
- [ ] 扫描尚存硬编码色值时已严格按 7 类忽略规则逐项判定并跳过（类名含色值 / 测试 / 注释 / blue 选择器回溯 / ECharts / 数组 / 取色器对象 / var 回退 / SASS blue 变量 / 超阈值）
- [ ] **所有形式的注释代码内的硬编码色值已一律排除**（单行 `//`、行内 `//`、单行块注释 `/* ... */`、多行块注释含 `*` 起首续行、JSX `{/* ... */}` 全部跳过；块注释状态机识别已生效）
- [ ] 尚存硬编码色值的每个组件均含：名称、功能说明（≤50 字）、组件类型、注册标识、所在页面、文件位置、用到的地方、残留硬编码色值列表
- [ ] 每个功能说明均基于组件入口的渲染、props、交互及数据逻辑总结，未仅凭名称臆测
- [ ] `NeoRegister` 组件已判定为 amis 组件并提取 `name` 作为 `type`
- [ ] `XRegister.CmpDefine` 组件已判定为 Neo 2.0 组件并提取 `cmpType`
- [ ] 已按 `type` / `cmpType` 精确搜索项目内引用，排除注册声明自身并记录相对路径与行号
- [ ] 未注册组件类型填「未知」，无引用填「未发现」或「无法按注册标识检索」
- [ ] 报告 `当前项目主题换肤支持情况.md` 已生成在项目根目录，结构符合模板
- [ ] **两张主表均以组件为最小粒度逐行输出，未用目录 / 文件计数聚合替代组件明细**
- [ ] **每行的每个字段都已填满，无空白 / `-` / `TODO` / 「待人工复核」「待确认」等占位内容**
- [ ] **已支持换肤部分含逐组件 CSS 变量明细区（1.x），非仅大类聚合统计**
- [ ] 无法判定的字段已按约定值填写（页面「未知」、功能「未知（未找到组件实现入口）」、类型 / 标识「未知」、引用「未发现」/「无法按注册标识检索」）
- [ ] 报告内容与实际扫描 / 阅读结果一致，未编造组件、色值或引用位置

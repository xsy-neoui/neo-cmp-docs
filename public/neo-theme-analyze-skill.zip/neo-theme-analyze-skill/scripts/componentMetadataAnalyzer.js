'use strict';

const fs = require('fs');
const path = require('path');

const CODE_EXTENSIONS = ['.tsx', '.jsx', '.ts', '.js'];

function lineNumberAt(content, index) {
  return content.slice(0, index).split(/\r?\n/).length;
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function truncateDescription(value) {
  const normalized = String(value || '')
    .replace(/\s+/g, ' ')
    .replace(/^[：:，,。；;\s]+|[\s]+$/g, '')
    .trim();
  if (!normalized) return '';
  return normalized.length <= 50 ? normalized : `${normalized.slice(0, 49)}…`;
}

function extractObjectField(body, field) {
  const re = new RegExp(`(?:['"]?${field}['"]?)\\s*:\\s*['"]([^'"]+)['"]`);
  const match = body.match(re);
  return match ? match[1] : '';
}

// 从 `{` 起始位置出发，做括号配平，返回匹配的对象体（含首尾大括号内的内容）与结束下标。
// 能正确跳过嵌套对象 / 数组、字符串字面量与模板串，避免在第一个内层 `}` 处提前截断。
function readBalancedObject(content, openBraceIndex) {
  let depth = 0;
  let quote = null; // 当前所处字符串引号：' " `
  for (let i = openBraceIndex; i < content.length; i++) {
    const ch = content[i];
    const prev = content[i - 1];
    if (quote) {
      if (ch === quote && prev !== '\\') quote = null;
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        return { body: content.slice(openBraceIndex + 1, i), endIndex: i };
      }
    }
  }
  return null;
}

function detectRegistrations(content, file) {
  const registrations = [];
  const patterns = [
    { type: 'amis 组件', api: 'NeoRegister', key: 'name', idKey: 'type' },
    { type: 'Neo 2.0 组件', api: 'XRegister.CmpDefine', key: 'cmpType', idKey: 'cmpType' },
  ];

  patterns.forEach((definition) => {
    const escapedApi = definition.api.replace('.', '\\.');
    // 定位 `api(` 后的第一个 `{`，再做括号配平取完整对象体，避免嵌套对象截断导致漏检
    const openRe = new RegExp(`${escapedApi}\\s*\\(\\s*\\{`, 'g');
    let match;
    while ((match = openRe.exec(content)) !== null) {
      const braceIndex = content.indexOf('{', match.index);
      const balanced = readBalancedObject(content, braceIndex);
      if (!balanced) continue;
      const value = extractObjectField(balanced.body, definition.key);
      if (!value) continue;
      registrations.push({
        ...definition,
        value,
        file,
        line: lineNumberAt(content, match.index),
        endLine: lineNumberAt(content, balanced.endIndex),
      });
    }
    const directRe = new RegExp(`${escapedApi}\\s*\\(\\s*['"]([^'"]+)['"]`, 'g');
    while ((match = directRe.exec(content)) !== null) {
      registrations.push({
        ...definition,
        value: match[1],
        file,
        line: lineNumberAt(content, match.index),
        endLine: lineNumberAt(content, match.index + match[0].length),
      });
    }
  });

  return registrations.filter((item, index, all) =>
    all.findIndex((candidate) => candidate.type === item.type && candidate.value === item.value &&
      candidate.file === item.file && candidate.line === item.line) === index);
}

function extractFeatureDescription(content, componentName) {
  const candidates = [];
  const descriptionFields = [
    /(?:description|desc|label|title)\s*[:=]\s*['"`]([^'"`\n]{2,100})['"`]/gi,
    /\/\*\*[\s\S]*?(?:功能|用途|说明)\s*[：:]\s*([^\n*]{2,100})[\s\S]*?\*\//gi,
    /\/\/\s*(?:功能|用途|说明)\s*[：:]\s*([^\n]{2,100})/gi,
  ];
  descriptionFields.forEach((re) => {
    let match;
    while ((match = re.exec(content)) !== null) candidates.push(match[1]);
  });
  const preferred = candidates.find((value) => !/组件名称|属性|配置|schema/i.test(value));
  if (preferred) return truncateDescription(preferred);

  const readableName = String(componentName || '当前')
    .replace(/__c$/, '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[-_]+/g, ' ')
    .trim();
  // 注：此处仅返回初筛线索，agent 必须读取组件实现后重写为准确功能说明（≤50 字），不得照抄。
  return truncateDescription(`${readableName || '当前'}组件（初筛线索，待 agent 依据实现改写）`);
}

function resolveImplementationFile(file, files, registration) {
  const dir = path.dirname(file);
  const base = path.basename(file, path.extname(file));
  const candidates = [];
  if (registration) candidates.push(registration.file);
  CODE_EXTENSIONS.forEach((ext) => candidates.push(path.join(dir, `${base}${ext}`)));
  CODE_EXTENSIONS.forEach((ext) => candidates.push(path.join(dir, `index${ext}`)));
  return candidates.find((candidate) => files.includes(candidate)) || file;
}

function findRegistrations(file, componentName, registrations) {
  const sameFile = registrations.filter((item) => item.file === file);
  if (sameFile.length) return sameFile;
  const sameDir = registrations.filter((item) => path.dirname(item.file) === path.dirname(file));
  if (sameDir.length) return sameDir;
  const normalized = String(componentName).toLowerCase().replace(/[^a-z0-9]/g, '');
  return registrations.filter((item) =>
    item.value.toLowerCase().replace(/[^a-z0-9]/g, '') === normalized);
}
function findUsages(registration, files, contents, root) {
  if (!registration) return [];
  const key = escapeRegExp(registration.idKey);
  const value = escapeRegExp(registration.value);
  // 同时兼容对象属性写法（type: 'x' / "type": "x"）与 JSX 属性写法（type="x"）
  const usageRe = new RegExp(
    `(?:['"]?${key}['"]?)\\s*[:=]\\s*(?:['"]${value}['"]|${value}(?=\\s*(?:[,}\\]\\n#>/]|$)))`,
    'g',
  );
  const results = [];

  files.forEach((file) => {
    const content = contents.get(file) || '';
    const lines = content.split(/\r?\n/);
    let match;
    while ((match = usageRe.exec(content)) !== null) {
      const line = lineNumberAt(content, match.index);
      const trimmed = (lines[line - 1] || '').trim();
      if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) continue;
      if (file === registration.file && line >= registration.line &&
        line <= (registration.endLine || registration.line)) continue;
      const context = trimmed.replace(/\|/g, '\\|').slice(0, 120);
      results.push({ file: path.relative(root, file), line, context });
    }
  });

  return results.filter((item, index, all) =>
    all.findIndex((candidate) => candidate.file === item.file && candidate.line === item.line) === index);
}

function buildComponentMetadata(root, files, inferComponent) {
  const contents = new Map();
  files.forEach((file) => {
    try { contents.set(file, fs.readFileSync(file, 'utf8')); } catch (error) { contents.set(file, ''); }
  });

  const registrations = [];
  files.forEach((file) => {
    if (!CODE_EXTENSIONS.includes(path.extname(file).toLowerCase())) return;
    registrations.push(...detectRegistrations(contents.get(file), file));
  });

  const usageCache = new Map();
  const byFile = new Map();
  files.forEach((file) => {
    const component = inferComponent(file);
    const matchedRegistrations = findRegistrations(file, component, registrations);
    const registration = matchedRegistrations[0] || null;
    const hasConflict = new Set(matchedRegistrations.map((item) => item.type)).size > 1;
    const implementationFile = resolveImplementationFile(file, files, registration);
    const implementation = contents.get(implementationFile) || '';
    const usedAt = [];
    matchedRegistrations.forEach((item) => {
      const cacheKey = `${item.type}:${item.value}`;
      if (!usageCache.has(cacheKey)) {
        usageCache.set(cacheKey, findUsages(item, files, contents, root));
      }
      usedAt.push(...usageCache.get(cacheKey));
    });
    const uniqueUsages = usedAt.filter((item, index, all) =>
      all.findIndex((candidate) => candidate.file === item.file && candidate.line === item.line) === index);
    byFile.set(file, {
      featureDescription: extractFeatureDescription(implementation, component),
      componentType: hasConflict
        ? '注册冲突'
        : (registration ? registration.type : '未知'),
      registrationKey: matchedRegistrations.map((item) => item.idKey).join(' / '),
      registrationValue: matchedRegistrations.map((item) => item.value).join(' / '),
      registrationFile: registration ? path.relative(root, registration.file) : '',
      registrationLine: registration ? registration.line : null,
      usedAt: uniqueUsages,
    });
  });

  return { byFile, registrations };
}
module.exports = {
  buildComponentMetadata,
  detectRegistrations,
  extractFeatureDescription,
  findUsages,
  truncateDescription,
};

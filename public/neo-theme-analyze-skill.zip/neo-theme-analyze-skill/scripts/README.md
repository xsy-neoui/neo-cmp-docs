# neo-theme-analyze-skill · 工具脚本

本目录提供主题换肤支持情况**只读分析**的可执行脚本。脚本全程只读，不修改任何源码。

## 文件说明

| 文件 | 说明 |
|:--|:--|
| `neoThemeColorMatcher.js` | 硬编码色值 → Neo CSS 变量匹配决策引擎（本技能内置） |
| `componentMetadataAnalyzer.js` | 功能说明候选、amis / Neo 2.0 注册类型及项目内引用分析 |
| `neoThemeAnalyzer.js` | 项目扫描器：汇总换肤状态与组件元数据 |

## `neoThemeAnalyzer.js`

**功能**：扫描项目源码与常见配置（`*.scss/css/less/tsx/ts/jsx/js/json/json5/yaml/yml`，排除 `node_modules`、测试文件、构建目录），产出：

1. **已支持换肤**：使用了 Neo 主题 CSS 变量的文件 / 组件，及变量分类（品牌色 / 背景色 / 边框色 / 图标色 / 文本色 / 按钮色 / 导航色）与去重后的具体变量列表。
2. **尚存硬编码色值**：仍使用硬编码品牌色（完全匹配 + 仅以 `#0564f5` 为基准的近似匹配）的文件 / 组件，及残留色值、匹配类型、建议目标变量。扫描时严格按内置忽略规则跳过处理。
3. **组件元数据**：从组件实现提取功能说明候选（≤50 字），识别 `NeoRegister.name`（amis 组件）与 `XRegister.CmpDefine.cmpType`（Neo 2.0 组件），并按 `type` / `cmpType` 精确扫描项目内引用位置。

### 用法

```bash
# 在项目根目录执行（默认扫描当前工作目录）
node /path/to/neo-theme-analyze-skill/scripts/neoThemeAnalyzer.js

# 指定项目根目录
node neoThemeAnalyzer.js --root ./my-app

# 输出 JSON（便于二次加工 / 生成报告）
node neoThemeAnalyzer.js --root . --json
```

> `neoThemeColorMatcher.js` 必须与 `neoThemeAnalyzer.js` 位于同一目录（脚本通过相对路径 `require`）。

### 输出字段（JSON 模式）

```jsonc
{
  "scannedFiles": 128,
  "supported": [
    {
      "file": "src/pages/Dashboard/UserCard.tsx",
      "component": "UserCard",
      "page": "Dashboard 页",
      "featureDescription": "展示用户摘要并支持进入详情",
      "componentType": "amis 组件",
      "registrationKey": "type",
      "registrationValue": "user-card",
      "usedAt": [{ "file": "src/pages/Home/schema.ts", "line": 32, "context": "type: 'user-card'" }],
      "usedVars": ["--brand-color", "--color-text-brand"],
      "varCategories": ["品牌色", "文本色"],
      "hardcoded": []
    }
  ],
  "notSupported": [
    {
      "file": "src/pages/Login/LoginForm.scss",
      "component": "LoginForm",
      "page": "Login 页",
      "hardcoded": [
        { "line": 22, "color": "#0564f5", "matchType": "exact", "target": "var(--brand-color)" }
      ]
    }
  ],
  "summary": { "supportedComponents": 1, "notSupportedComponents": 1, "totalHardcoded": 1, "approximateHardcoded": 0 }
}
```

### 启发式与人工复核

脚本对忽略规则（注释行、`var()` 回退、类名含色值、SASS `blue` 变量、颜色数组 / 取色器对象、blue 选择器就近回溯、ECharts 文件、超阈值近似）做了**尽力而为**的实现，覆盖绝大多数常见场景。个别复杂多行嵌套结构，你（agent）**必须**对照 [../references/analysis-rules.md](../references/analysis-rules.md) §2 核对脚本输出并自行定稿，此核对由你完成，不遗留给外部人工。

- **ECharts 判定**：脚本读取**完整文件内容**判定，除辅助特征（`echarts` / `ReactECharts` / `setOption` 引用）外，还检测 ECharts option 专有的**强特征**——`series: [{ type: 'bar'|'line'|'pie'... }]`、`xAxis` / `yAxis` / `legend` / `grid` / `dataZoom` / `visualMap` / `polar` / `radar` / `geo` / `toolbox` 等。命中强特征即视为图表上下文，整文件硬编码色值不计入残留（需走 `getCssVarHex()` 方案）。判定细则见 [../references/analysis-rules.md](../references/analysis-rules.md) §2 补充「ECharts 判定」。

- 组件名 / 页面名为**目录结构启发式推断**，判定不了时脚本会给出 `未知` 或目录名；你（agent）**必须**自行确认并定稿，无法判定的填约定值「未知」，不得留空。
- `featureDescription` 是从注释和 `description` / `label` / `title` 提取或生成的**初筛线索**；最终功能说明**必须**由你（agent）阅读渲染、props、交互和数据逻辑后重写，并控制在 50 字内，不得直接照抄或留空。
- 组件类型以静态注册代码为准：`NeoRegister.name` → amis 组件 / `type`；`XRegister.CmpDefine.cmpType` → Neo 2.0 组件。动态注册须由你（agent）自行追踪变量定义并定稿，仍无法确定时按约定填「未知」。
- 注册对象体采用**括号配平**解析，`name` / `cmpType` 位于 `editor`、`props` 等嵌套对象之后也能正确提取；同时兼容 `NeoRegister('name', ...)` 直接字符串写法。
- `usedAt` 同时匹配对象属性写法（`type: 'x'` / `"type": "x"`）与 JSX 属性写法（`cmpType="x"`），你**必须**自行剔除示例、注释、类型声明和无关配置后定稿。
- 脚本产出的是**初筛数据**，最终《当前项目主题换肤支持情况.md》报告由你（agent）依据 [../references/report-template.md](../references/report-template.md) 组织生成，**必须严格满足该模板「硬性输出要求」的全部约束**：以组件为最小粒度逐行输出、字段填满不留占位、含逐组件变量明细区。

## 相关文档

- [../SKILL.md](../SKILL.md) — 分析技能完整流程
- [../references/css-variables-catalog.md](../references/css-variables-catalog.md) — 主题变量清单与分类
- [../references/color-matching-rules.md](../references/color-matching-rules.md) — 硬编码色值匹配规则
- [../references/analysis-rules.md](../references/analysis-rules.md) — 忽略规则 + 组件归属判定
- [../references/report-template.md](../references/report-template.md) — 报告模板

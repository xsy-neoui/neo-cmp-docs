/**
 * Neo 主题换肤支持情况分析器（只读扫描）
 *
 * 用途：扫描项目源码，产出两类数据供生成《当前项目主题换肤支持情况.md》：
 *   1) 已支持换肤：使用了 Neo 主题 CSS 变量的文件 / 组件，及其变量分类与具体变量列表。
 *   2) 尚存硬编码色值：仍使用硬编码品牌色（未替换为 CSS 变量）的文件 / 组件，及残留色值。
 *
 * 🔒 本脚本全程只读，不修改任何源码。
 *
 * 用法：
 *   node neoThemeAnalyzer.js [项目根目录]           # 默认当前工作目录
 *   node neoThemeAnalyzer.js --root . --json        # 输出 JSON（默认输出可读文本）
 *   node neoThemeAnalyzer.js --root ./my-app        # 指定项目根目录
 *
 * 说明：脚本的忽略规则做了「尽力而为」的启发式实现（注释行、var() 中备用的硬编码色值、类名含色值、
 *      测试文件、SASS blue 变量、颜色数组、取色器对象、blue 选择器就近回溯、超阈值近似），
 *      与 references/analysis-rules.md §2 对齐。个别复杂多行结构须由 agent 对照 §2 自行核对脚本输出并定稿。
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { matchBrandColor, matchLightBlueTint } = require('./neoThemeColorMatcher');
const { buildComponentMetadata } = require('./componentMetadataAnalyzer');

// ===== 配置 =====
const SRC_EXT = new Set([
  '.scss', '.css', '.less', '.tsx', '.ts', '.jsx', '.js', '.json', '.json5', '.yaml', '.yml',
]);
const EXCLUDE_DIRS = new Set([
  'node_modules', '.git', 'dist', 'build', 'output', '.next', '.nuxt',
  'coverage', '.cache', '.vitepress', 'lib', 'es',
]);

// 主题变量前缀 → 分类（注意：更长前缀在前，避免 --brand-nav-header 被 --brand-color 抢先）
const VAR_CATEGORIES = [
  { prefix: '--brand-nav-header', category: '导航色' },
  { prefix: '--brand-color', category: '品牌色' },
  { prefix: '--color-bg-brand', category: '背景色' },
  { prefix: '--color-border-brand', category: '边框色' },
  { prefix: '--color-icon-fill-brand', category: '图标色' },
  { prefix: '--color-icon-brand', category: '图标色' },
  { prefix: '--color-text-brand', category: '文本色' },
  { prefix: '--color-button-filled-primary', category: '按钮色' },
];

function classifyVar(varName) {
  for (const { prefix, category } of VAR_CATEGORIES) {
    if (varName.startsWith(prefix)) return category;
  }
  return null;
}

// ===== 文件遍历 =====
function walk(dir, files = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return files;
  }
  for (const entry of entries) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (EXCLUDE_DIRS.has(entry.name)) continue;
      walk(abs, files);
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (!SRC_EXT.has(ext)) continue;
      if (/\.(test|spec)\.[jt]sx?$/.test(entry.name)) continue; // 测试文件
      files.push(abs);
    }
  }
  return files;
}

// ===== 组件名推断（启发式） =====
function inferComponent(filePath) {
  const base = path.basename(filePath).replace(/\.[^.]+$/, '');
  if (base.toLowerCase() === 'index') {
    // 用父目录名作为组件名
    return path.basename(path.dirname(filePath));
  }
  return base;
}

// ===== 页面推断（启发式） =====
function inferPage(relPath) {
  const parts = relPath.split(path.sep);
  const idx = parts.findIndex((p) => /^(pages|views|page|views?)$/i.test(p));
  if (idx >= 0 && parts[idx + 1]) return `${parts[idx + 1]} 页`;
  if (parts.some((p) => /^(components|common|shared|widgets|ui)$/i.test(p))) {
    return '通用组件 / 多页面复用';
  }
  return '未知';
}

// ===== 行级忽略判定（启发式） =====
function isCommentLine(line) {
  const t = line.trim();
  return t.startsWith('//') || t.startsWith('/*') || t.startsWith('*');
}

// 预计算每一行内的「块注释区间列表」：blockCommentRanges[i] 为 [start, end) 区间数组，
// 表示第 i 行内哪些字符段处于 /* ... */ 内（含跨行的续行整行、以及行首至 */、/* 至行尾）。
// 状态机跟踪 /* ... */ 开合；不解析字符串字面量内的 /* */（对分析场景足够）。
// entering === true 表示该行开始时已处于块注释内。
function computeBlockCommentRanges(lines) {
  const ranges = lines.map(() => []);
  let inBlock = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let j = 0;
    // 若行首已处于块注释：从 0 开始记录本行的注释起点
    let openAt = inBlock ? 0 : -1;
    while (j <= line.length) {
      if (inBlock) {
        const close = line.indexOf('*/', j);
        if (close === -1) {
          // 块注释延续到行尾
          ranges[i].push([openAt, line.length]);
          break;
        }
        // 收尾：将 [openAt, close+2) 作为一段
        ranges[i].push([openAt, close + 2]);
        inBlock = false;
        openAt = -1;
        j = close + 2;
      } else {
        const open = line.indexOf('/*', j);
        if (open === -1) break;
        inBlock = true;
        openAt = open;
        j = open + 2;
      }
    }
  }
  return ranges;
}

function positionInAnyRange(ranges, pos) {
  for (const [s, e] of ranges) {
    if (pos >= s && pos < e) return true;
  }
  return false;
}

// 行内 // 之后的部分视为注释；如果色值起始位置在 // 之后 → 视为注释内
// 注意：需先剔除位于块注释区间内的 //（避免 /* http:// */ 之类误伤）
function isAfterLineComment(line, colorIndex, blockRanges) {
  // 找到第一个不在块注释区间内的 //
  let from = 0;
  while (from < line.length) {
    const idx = line.indexOf('//', from);
    if (idx === -1) return false;
    if (!positionInAnyRange(blockRanges, idx)) {
      return colorIndex > idx;
    }
    from = idx + 2;
  }
  return false;
}

// 色值是否位于「类名/变量名含色值」写法内，如 text-[#0564f5]
function isInClassToken(line, index) {
  const before = line.slice(Math.max(0, index - 2), index);
  return before.includes('[');
}

// 行内色值是否作为 var() 回退值，如 var(--x, #0564f5)
function isVarFallback(line, index) {
  const before = line.slice(0, index);
  const lastVar = before.lastIndexOf('var(');
  if (lastVar === -1) return false;
  const between = before.slice(lastVar);
  // var( 之后、色值之前若已出现逗号，则为回退值
  return between.includes(',') && !between.includes(')');
}

// 色值是否位于 background / background-color / backgroundColor 属性值上
// （浅蓝色值只在背景属性上才计入残留，见 references/color-matching-rules.md 第五节）
const BG_PROP_RE = /(background|background-color|backgroundColor)\s*:\s*[^;]*$/i;
function isOnBackgroundProp(line, index) {
  return BG_PROP_RE.test(line.slice(0, index));
}

// SASS/Less 变量名含 blue，如 $blue-base: #096dd9  /  @blue-6: #1890ff
function isBlueSassVar(line) {
  return /(\$|@)[a-z0-9_-]*blue[a-z0-9_-]*\s*:/i.test(line);
}

// 行内含 blue 关键字（class 名 / 选择器同一行）
function lineHasBlue(line) {
  return /blue/i.test(line);
}

// 向上回溯最近的选择器行是否含 blue（就近启发式，覆盖多行/嵌套的常见场景）
function ancestorSelectorHasBlue(lines, lineIdx) {
  let depth = 0;
  for (let i = lineIdx; i >= 0 && lineIdx - i < 40; i--) {
    const l = lines[i];
    // 简单括号配平：遇到选择器块起始 { 时检查其选择器
    const opens = (l.match(/\{/g) || []).length;
    const closes = (l.match(/\}/g) || []).length;
    depth += closes - opens;
    if (opens > 0 && depth <= 0) {
      // 该行（或其上一行）为选择器
      const selector = l.split('{')[0].trim() || (lines[i - 1] || '').trim();
      if (/blue/i.test(selector)) return true;
      if (depth < 0) depth = 0;
    }
  }
  return false;
}

// 判定一行是否属于「纯色值数组 / 取色器对象」上下文（就近启发式）
function isPaletteContext(line) {
  // 颜色数组字面量：['#xxx', '#yyy'] 或 ["#xxx", ...]
  const arrLike = /\[\s*['"]?#?[0-9a-fA-F]{3,8}['"]?(\s*,\s*['"]?(#?[0-9a-fA-F]{3,8}|rgba?\([^)]*\))['"]?)*\s*\]?/;
  // 取色器对象：整行去掉 key 后，值几乎都是色值（粗略：本行仅含色值/逗号/引号/括号/键名）
  const stripped = line.replace(/['"]?[a-zA-Z_$][\w$]*['"]?\s*:/g, '') // 去 key:
    .replace(/[{}\[\],\s'"]/g, '');
  const onlyColors = stripped.length > 0 &&
    /^((#?[0-9a-fA-F]{3,8})|(rgba?\([\d.,]+\)))+$/i.test(
      stripped.replace(/rgba?\(([\d.,]+)\)/gi, 'rgba($1)'),
    );
  return arrLike.test(line) && onlyColors;
}

// 判定是否 ECharts 上下文（须读取完整文件上下文）：
// 1) 辅助特征：文件引用 echarts / ReactECharts / setOption / getCssVarHex；
// 2) 强特征：出现 ECharts option 专有属性（series[].type、xAxis、yAxis、legend、grid、
//    dataZoom、visualMap、polar、radar、geo、toolbox、tooltip 等）。
// 仅辅助特征而无强特征时不足以判定，避免把普通样式文件误判为图表文件。
const ECHARTS_STRONG_FEATURE_RE = new RegExp(
  [
    // series: [{ ... type: 'bar' | 'line' | ... }]
    'series\\s*:\\s*\\[[\\s\\S]{0,400}?type\\s*:\\s*[\'"](?:bar|line|pie|scatter|effectScatter|radar|tree|treemap|sunburst|boxplot|candlestick|heatmap|map|parallel|lines|graph|sankey|funnel|gauge|pictorialBar|themeRiver|custom)[\'"]',
    // 坐标轴 / 图例 / 网格等专有顶层属性（后接对象或数组）
    '\\b(?:xAxis|yAxis|radiusAxis|angleAxis|legend|grid|dataZoom|visualMap|polar|radar|geo|parallel|toolbox|brush|graphic)\\s*:\\s*[\\[{]',
  ].join('|'),
);

function fileHasEchartsStrongFeature(content) {
  return ECHARTS_STRONG_FEATURE_RE.test(content);
}

function fileLooksLikeChart(content) {
  const hasHelper = /echarts|ReactECharts|setOption/i.test(content);
  const hasStrong = fileHasEchartsStrongFeature(content);
  // 强特征命中即判定；仅辅助特征（如 import echarts）时也保守跳过整文件的硬编码统计，
  // 因这类文件的色值基本服务于图表，需走 getCssVarHex 方案。
  return hasStrong || hasHelper;
}

// ===== 单文件扫描 =====
const COLOR_RE = /#[0-9a-fA-F]{3,8}\b|rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(?:,\s*[\d.]+\s*)?\)/g;
const VAR_RE = /var\(\s*(--[a-z0-9-]+)/gi;
const GETCSSVAR_RE = /getCssVarHex\(\s*['"](--[a-z0-9-]+)['"]/gi;

function scanFile(absPath, root) {
  const content = fs.readFileSync(absPath, 'utf8');
  const lines = content.split(/\r?\n/);
  const relPath = path.relative(root, absPath);
  const ext = path.extname(absPath).toLowerCase();
  const isStyle = ['.scss', '.css', '.less'].includes(ext);
  const chartFile = !isStyle && fileLooksLikeChart(content);

  // 预计算跨行块注释区间：处于 /* ... */ 段内的字符范围，色值起始若落入此段则跳过
  const blockCommentRanges = computeBlockCommentRanges(lines);

  const usedVars = new Set();
  const varCategories = new Set();
  const hardcoded = []; // { line, color, matchType, target, shade, delta, distance }

  lines.forEach((line, i) => {
    // --- 主题变量引用 ---
    let m;
    VAR_RE.lastIndex = 0;
    while ((m = VAR_RE.exec(line)) !== null) {
      let name = m[1].replace(/-rgb$/, ''); // 归并 -rgb 伴侣到主变量
      const cat = classifyVar(name);
      if (cat) {
        usedVars.add(name);
        varCategories.add(cat);
      }
    }
    // getCssVarHex('--brand-color') 也算已支持
    GETCSSVAR_RE.lastIndex = 0;
    while ((m = GETCSSVAR_RE.exec(line)) !== null) {
      const name = m[1].replace(/-rgb$/, '');
      const cat = classifyVar(name);
      if (cat) {
        usedVars.add(name);
        varCategories.add(cat);
      }
    }

    // --- 硬编码色值 ---
    // 硬性铁律：一切被注释的代码内的色值必须排除。
    // 由 blockCommentRanges + isAfterLineComment 精确到「色值起始位置」，而非整行判定，
    // 以正确处理同行内注释与代码混合的场景（如 `/* ... */ .a { color: #xxx; }` 或
    // `.a { color: /* ... */ #xxx; }`）。
    const lineBlockRanges = blockCommentRanges[i];
    const trimmedForCommentCheck = line.trim();
    // 整行以 // 起首（单行 // 注释）→ 跳过整行
    if (trimmedForCommentCheck.startsWith('//')) return;
    if (isBlueSassVar(line)) return;
    if (lineHasBlue(line)) return;
    if (chartFile) return; // ECharts 文件整体跳过硬编码色统计（需 getCssVarHex 方案）
    if (isPaletteContext(line)) return;
    if (ancestorSelectorHasBlue(lines, i)) return;

    let cm;
    COLOR_RE.lastIndex = 0;
    while ((cm = COLOR_RE.exec(line)) !== null) {
      const color = cm[0];
      const idx = cm.index;
      // 色值起始位置若落在 /* ... */ 块注释区间内（含跨行块注释续行）→ 视为注释内，跳过
      if (positionInAnyRange(lineBlockRanges, idx)) continue;
      // 色值起始位置若在同一行 // 之后（且 // 不在块注释内）→ 视为注释内，跳过
      if (isAfterLineComment(line, idx, lineBlockRanges)) continue;
      if (isInClassToken(line, idx)) continue;
      // var() 中备用（回退）的硬编码色值不需要替换 → 不计入残留（蓝色 / 浅蓝通用）
      if (isVarFallback(line, idx)) continue;
      let r = matchBrandColor(color);
      if (r.matchType === 'none' || r.matchType === 'invalid') {
        // 浅蓝色值：仅 background / background-color / backgroundColor 属性上的命中计入残留
        if (!isOnBackgroundProp(line, idx)) continue;
        const tint = matchLightBlueTint(color);
        if (tint.matchType === 'none' || tint.matchType === 'invalid') continue;
        r = tint;
      }
      hardcoded.push({
        line: i + 1,
        color,
        kind: r.kind || 'blue',
        matchType: r.matchType,
        target: r.output,
        shade: r.shade,
        delta: r.delta,
        distance: r.distance,
        baseHex: r.baseHex,
      });
    }
  });

  return {
    file: relPath,
    component: inferComponent(absPath),
    page: inferPage(relPath),
    usedVars: [...usedVars].sort(),
    varCategories: [...varCategories],
    hardcoded,
  };
}

// ===== 主流程 =====
function analyze(root) {
  const files = walk(root);
  const { byFile, registrations } = buildComponentMetadata(root, files, inferComponent);
  const supported = [];
  const notSupported = [];
  let varCount = 0;
  let hardcodedCount = 0;
  let approxCount = 0;

  for (const f of files) {
    let res;
    try {
      res = { ...scanFile(f, root), ...byFile.get(f) };
    } catch (e) {
      continue;
    }
    if (res.usedVars.length > 0) {
      supported.push(res);
      varCount += res.usedVars.length;
    }
    if (res.hardcoded.length > 0) {
      notSupported.push(res);
      hardcodedCount += res.hardcoded.length;
      approxCount += res.hardcoded.filter((h) => String(h.matchType).startsWith('approximate')).length;
    }
  }

  return {
    scannedFiles: files.length,
    supported,
    notSupported,
    registrations: registrations.map((item) => ({
      componentType: item.type,
      registrationKey: item.idKey,
      registrationValue: item.value,
      file: path.relative(root, item.file),
      line: item.line,
    })),
    summary: {
      scannedFiles: files.length,
      supportedComponents: supported.length,
      notSupportedComponents: notSupported.length,
      totalVarsUsed: varCount,
      totalHardcoded: hardcodedCount,
      approximateHardcoded: approxCount,
    },
  };
}

// ===== 文本输出 =====
function printComponentMetadata(item) {
  console.log(`      功能：${item.featureDescription || '未知'}`);
  const id = item.registrationValue
    ? `（${item.registrationKey}=${item.registrationValue}）`
    : '';
  console.log(`      组件类型：${item.componentType || '未知'}${id}`);
  console.log(`      用到的地方：${item.usedAt && item.usedAt.length
    ? item.usedAt.map((usage) => `${usage.file}:${usage.line}`).join('、')
    : '未发现'}`);
}

function printText(result) {
  const { summary, supported, notSupported } = result;
  console.log('==== Neo 主题换肤支持情况分析（只读） ====\n');
  console.log('【总体汇总】');
  console.log(`  扫描文件总数：${summary.scannedFiles}`);
  console.log(`  已支持换肤组件数：${summary.supportedComponents}`);
  console.log(`  尚存硬编码色值的组件数：${summary.notSupportedComponents}`);
  console.log(`  命中主题变量总数（含重复文件）：${summary.totalVarsUsed}`);
  console.log(`  残留硬编码色值总数：${summary.totalHardcoded}（其中近似匹配 ${summary.approximateHardcoded}）\n`);

  console.log('【一、已支持换肤的页面与组件】');
  supported.forEach((s) => {
    console.log(`  - ${s.component}（${s.page}）  ${s.file}`);
    printComponentMetadata(s);
    console.log(`      分类：${s.varCategories.join('、') || '-'}`);
    console.log(`      变量：${s.usedVars.join(', ')}`);
  });

  console.log('\n【二、尚存硬编码色值】');
  notSupported.forEach((n) => {
    console.log(`  - ${n.component}（${n.page}）  ${n.file}`);
    printComponentMetadata(n);
    n.hardcoded.forEach((h) => {
      const tag = String(h.matchType).startsWith('approximate')
        ? `近似匹配·${h.shade}色阶(基准${h.baseHex},Δ=${h.delta},d≈${h.distance})`
        : '完全匹配';
      const kindTag = h.kind === 'light-blue-tint' ? '浅蓝' : '蓝色';
      console.log(`      L${h.line}: ${h.color}  [${kindTag}·${tag}]  建议 → ${h.target}`);
    });
  });
}

function main() {
  const argv = process.argv.slice(2);
  let root = process.cwd();
  let asJson = false;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--root' && argv[i + 1]) { root = path.resolve(argv[++i]); }
    else if (argv[i] === '--json') { asJson = true; }
    else if (!argv[i].startsWith('--')) { root = path.resolve(argv[i]); }
  }
  const result = analyze(root);
  if (asJson) {
    console.log(JSON.stringify(result, null, 2));
  } else {
    printText(result);
  }
}

if (require.main === module) {
  main();
}

module.exports = { analyze, scanFile, classifyVar, walk };

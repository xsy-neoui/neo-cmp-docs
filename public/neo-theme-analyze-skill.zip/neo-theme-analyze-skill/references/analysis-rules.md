# 分析规则细则

本文件是 `SKILL.md` 步骤 1 / 步骤 2 的配套细则，含：主题变量识别（§1）、硬编码色值忽略规则（§2）、组件与页面归属判定（§3）。

---

## §1 主题变量识别（步骤 1）

### 1.1 判定「是否为 Neo 主题变量」

一个 `var(--xxx)` 引用是否计入换肤支持统计，取决于 `--xxx` 是否命中 [css-variables-catalog.md](css-variables-catalog.md) 的 7 类前缀之一：

- `--brand-color` / `--color-bg-brand` / `--color-border-brand` / `--color-icon-brand` / `--color-icon-fill-brand` / `--color-text-brand` / `--color-button-filled-primary` / `--brand-nav-header`

命中 → 计入，并按前缀归类；未命中（如 `--gap`、`--primary-radius`、`--custom-x`）→ 不计入。

### 1.2 同时统计的写法

以下写法都算「使用了主题变量」：

- `color: var(--brand-color);`
- `background: var(--color-bg-brand-tint);`
- `box-shadow: 0 0 0 2px rgba(var(--color-border-brand-rgb), 0.15);`（`-rgb` 伴侣变量与主变量同类）
- TSX 内联 `style` 属性中的 `color: 'var(--brand-color)'`
- `getCssVarHex('--brand-color')`（ECharts 场景，读取主题变量的 hex 值 —— **也应计入**「已支持换肤」，归入对应大类）

### 1.3 去重

同一组件内同一变量多次使用，具体变量列表**去重**后只列一次；但可在明细中标注出现次数（可选）。

---

## §2 硬编码色值忽略规则（步骤 2）

> ⚠️ 本节忽略规则完整内置于本技能，自包含、不依赖任何其他技能。**扫描尚存硬编码色值时必须严格按本节逐项判定并跳过处理**。

对每个命中的硬编码色值，按固定顺序逐项判定，命中任一即判为「合法跳过」，**不计入**「尚存硬编码色值」的残留项（可记入报告「合法跳过」区供复核）。判定顺序如下：

```
命中行
  ↓
① 类名 / 变量名含色值？ 如 text-[#0564f5]、bg-[#4e80f5] → 跳过
  ↓ 否
② 测试文件？ *.test.*、*.spec.*、__tests__/ → 跳过
  ↓ 否
③ 已注释行？ 以 // 或 /* 开头、或被 /* */ 包裹 → 跳过
  ↓ 否
④ blue 选择器回溯？ 向上回溯所属 CSS 规则块（含多行、SCSS/Less 嵌套、& 拼接），
    任一层祖先选择器 class 名含 blue（大小写不敏感）→ 跳过
  ↓ 否
⑤ var() 中备用（回退）的硬编码色值 —— var(--x, #0564f5)、var(--card-bg, #e6f0fe)、
    rgba(var(--brand-color-rgb, 5, 100, 245), 0.2) → 跳过（不需要替换，蓝色 / 浅蓝同等适用）
  ↓ 否
⑥ ECharts option 属性值（须读取完整文件上下文向上回溯确认，命中 series:[{type:...}]、
    xAxis、yAxis、legend、grid、dataZoom 等专有属性才成立，判定细则见 §2 补充「ECharts 判定」） /
    颜色数组字面量（['#0564f5', ...]） /
    取色器对象（对象内所有属性值均为 hex/rgb/rgba）→ 跳过
  ↓ 否
⑦ SASS / Less 变量名含 blue（$blue-base、@blue-6 …）→ 跳过
  ↓ 否
⑧ 与基准色 #0564f5 差异超阈值（Δ_ch > 32 或 d > 50）的蓝色 / 非品牌色 → 跳过（保留原样）
  ↓ 否
⑨ 浅蓝色值出现在非背景属性上（color / border-color / box-shadow / fill / stroke …）
    或不在浅蓝 11 色清单内（浅蓝不做近似匹配）→ 跳过
  ↓ 全部未命中
✅ 判定为「尚存硬编码色值」的残留项 → 计入报告（标注色系：蓝色 / 浅蓝）
```

### §2 补充：var() 备用值忽略规则（规则 ⑤，蓝色 / 浅蓝通用）

**`var()` 括号内逗号后的备用（回退）硬编码色值不需要替换**，一律判为「合法跳过」、不计入残留：

```scss
color: var(--brand-color, #0564f5);                          // 备用值 → 跳过
background: var(--card-bg, #e6f0fe);                         // 浅蓝备用值 → 跳过
background: rgba(var(--brand-color-rgb, 5, 100, 245), 0.2);  // var() 内备用 rgb 数值 → 跳过
```

原因：备用值只在 CSS 变量未定义时兜底，不是运行时实际生效的主题色，替换它无换肤收益且会破坏 `var()` 语法。固定 grep 命令末尾的 `grep -v "var("` 即服务于此规则；脚本中由 `isVarFallback()` 实现。

### §2 补充：浅蓝色值的属性限定（规则 ⑨）

浅蓝 11 色（见 [color-matching-rules.md](color-matching-rules.md) 第四节）**只在 `background` / `background-color`（JSX `backgroundColor`）属性上计入残留**，建议目标变量 `var(--brand-color-tint)`；出现在其他属性上、或不在清单内的浅色（浅蓝不做近似匹配）一律不计入。脚本中由 `isOnBackgroundProp()` + `matchLightBlueTint()` 实现。

> 分析场景下「跳过」= 不计入残留项，绝不修改任何源码。

### §2 补充：Primary 按钮语义 class 识别

扫描命中硬编码色值的 CSS / SCSS / Less 规则块时，必须向上回溯所属选择器，并将以下 class 模式识别为 Primary 按钮：

- `button-primary`
- `ant-btn-primary`
- `btn-primary`
- `a-Button--primary`
- **class 名称或 class token 中含 `btn-conform`**
- **class 名称或 class token 中含 `add_button`、`confirm_button`、`cancel_button`**
- 其他包含 `primary` 关键词的按钮类名

`btn-conform`、`add_button`、`confirm_button`、`cancel_button` 即使不含 `primary` 关键词，也必须按 Primary 按钮语义处理，并覆盖其 `hover` / `active` 嵌套状态。其中 **`add_button`（新增）、`confirm_button`（确认）** 为实心 Primary 按钮，按下表背景白 / 非白正常归类；**`cancel_button`（取消）** 为空心（轮廓）按钮，无论背景为何色，一律按下表「白色背景 / 空心按钮」行归类（只对 `color` / `border-color` 建议按钮色变量，背景保持原样）。报告中的建议目标变量按属性与状态确定：

| 背景类型 / 状态 | 属性 | 建议目标变量 |
|:--|:--|:--|
| 白色背景 / 空心按钮（含 `cancel_button`），默认 / hover / active | `color`、`border-color` | `--color-button-filled-primary` / `-hover` / `-active` |
| 非白色背景，默认 / hover / active | `background`、`background-color`、`border-color`、`border` 中色值 | `--color-button-filled-primary` / `-hover` / `-active`（边框与背景同一变量） |
| 非白色背景，默认 | `color` | `--color-button-filled-primary-color` |
| 非白色背景，hover / active | `color` | `--color-button-filled-primary-color-hover` |

> 该规则只改变分析归类和建议变量，不修改源码；`border` 简写只针对其中色值给出建议，宽度与样式保持不变。
> ⚠️ 非白色背景填充按钮的 `border-color` / `border` 中色值必须建议**与 background 相同的按钮背景色变量**（`--color-button-filled-primary` 系列），**不要建议字体色变量**（`--color-button-filled-primary-color` 系列）；字体色变量仅用于 `color`。

### §2 补充：ECharts 判定（规则 ⑤ 之 ECharts 细则）

> 🚫 **失效根因**：ECharts option 常见属性名（`color`、`borderColor`、`backgroundColor`、`itemStyle`、`lineStyle`、`textStyle` 等）与普通 CSS-in-JS / 内联样式高度重合。只看色值所在**单行/就近几行**会漏判（该跳过却计入残留）或误判。因此**不允许仅凭单行属性名**判定 ECharts。

**判定铁律：必须读取完整文件上下文，向上回溯到「最外层」option 对象再判定。**

> 🔑 **回溯不能只看色值所在的最近一层 `{}`**。ECharts 色值常深埋于嵌套结构（`legend.pageIconColor`、`xAxis.axisLabel.color`、`series[].itemStyle.color`）。若只检查最近一层对象的同级属性，很可能因该层同级属性（如 `legend` 内的 `show`/`data`）都不是强特征而漏判（该跳过却计入残留）。因此**回溯必须一路向上到最外层对象字面量**（被 `return {...}` / `export default {...}` / `module.exports = {...}` / `const option = {...}` / 传入图表 API 的根对象），并记录**祖先 key 链**。

从命中色值行执行结构回溯，做三类匹配，**命中任一即判定 ECharts，其内色值一律跳过 / 不计入残留**：

- **匹配 A — 强特征属性（任意层级出现任一即成立）**：
  - `series: [{ type: 'bar' | 'line' | 'pie' | 'scatter' | 'radar' | 'gauge' | 'funnel' | 'map' | 'heatmap' | 'effectScatter' | ... }]`
  - `xAxis` / `yAxis` / `radiusAxis` / `angleAxis`（含 `axisLine` / `axisLabel` / `axisTick` / `axisPointer` / `splitLine` / `splitArea` / `nameTextStyle` / `boundaryGap`）
  - `legend`（含 ECharts 专有子属性 `pageIconColor` / `pageIconInactiveColor` / `pageTextStyle` / `inactiveColor`）、`grid`、`tooltip`（与 series/坐标轴同级，含 `confine` / `extraCssText` / `axisPointer`）、`dataZoom`、`visualMap`（含 `inRange` / `outOfRange` / `calculable` / `pieces`）、`polar`、`radar`、`geo`、`toolbox`、`brush`、`graphic`、`timeline`、`calendar`、`dataset`
- **匹配 B — 祖先 key 链**：沿祖先 key 链，只要某层 key 名属于上述 ECharts 专有 key（`series` / `xAxis` / `yAxis` / `legend` / `grid` / `tooltip` / `visualMap` / `dataZoom` / `itemStyle` / `lineStyle` / `areaStyle` / `nameTextStyle` / `emphasis` 等）即成立。如 `#4E80F5` 位于 `legend.pageIconColor`，祖先 key 链含 `legend` → 命中。
- **匹配 C — 独立 ECharts 配置模块（整对象识别）**：某对象字面量经 `define()` / `export default` / `module.exports` / `return` 导出或返回，且其**顶层键中同时出现 ≥ 2 个 ECharts 顶层 option 键**（`title` / `grid` / `legend` / `xAxis` / `yAxis` / `series` / `tooltip` / `visualMap` / `dataZoom` / `polar` / `radar` / `geo` / `toolbox` 等）→ 整个对象判定为 ECharts option，内部所有色值全部跳过。**不依赖**是否 `import echarts`、是否用 `<ReactECharts>`、变量是否叫 `option`。
- **辅助特征（佐证，不单独判定）**：变量名为 `option`/`chartOption`/`echartsOption`；传入 `<ReactECharts option={...}/>`、`echarts.init().setOption(...)`、`chart.setOption(...)`；文件 `import` 了 `echarts` / `echarts-for-react`；文件名/路径含 `chart`/`echart`/`option`/`bi`。

```
命中色值行（属性名疑似图表色）
  ↓ 向上回溯到「最外层」option 对象 + 记录祖先 key 链 + 声明/导出位置
匹配 A（强特征属性）/ B（祖先 key 链含 ECharts key）/ C（导出对象含 ≥2 个 ECharts 顶层键）任一命中？
  ├─ 是 → 判定 ECharts → 跳过（不计入残留）
  └─ 否 → 不判定 ECharts，回到 §2 其余检查（取色器对象 / 数组 / var 回退 …）
```

```js
// ✅ 匹配 C：AMD 模块 return 含 title/grid/legend/xAxis/yAxis/series 等多顶层键的对象
//    → 整体 ECharts option → #4E80F5、#182437、#6A7280 全部跳过（不计入残留）
define(function (require, exports, module) {
  return {
    title: { text: '气泡图' },
    grid: { top: '10%' },
    legend: { show: true, pageIconColor: '#4E80F5' },  // 跳过（匹配 B/C）
    tooltip: { textStyle: { color: '#182437' } },       // 跳过
    xAxis: { nameTextStyle: { color: '#6A7280' } },     // 跳过
    yAxis: { nameTextStyle: { color: '#6A7280' } },     // 跳过
    series: [{ type: 'scatter', data: [] }],
  };
});

// ✅ 匹配 A/B：回溯命中 series[].type + xAxis + legend → ECharts → 全部色值跳过
const option = {
  legend: { textStyle: { color: '#0564f5' } },
  xAxis: { axisLine: { lineStyle: { color: '#4e80f5' } } },
  yAxis: {},
  series: [{ type: 'bar', itemStyle: { color: '#0564f5' } }],
};
// ❌ 无 ECharts 强特征 / 祖先 key / 多顶层键，普通内联样式 → 不按 ECharts 跳过，回到其余检查
const style = { color: '#0564f5', padding: 8 };
```

### §2 补充：取色器对象判定

色值是某对象字面量 `{ ... }` 的属性值，且该对象**每一个属性值都是色值**（hex / `rgb(...)` / `rgba(...)`，允许引号），对象内无任何非色值属性值（数字 / 布尔 / 文案 / 嵌套对象 / 函数 / `var(...)`）→ 认定为取色器（调色板）对象，其中所有色值一律跳过。

```ts
// ✅ 取色器（属性值全为色值）→ 跳过
const palette = { primary: '#0564f5', hover: '#4e80f5', mask: 'rgba(5, 100, 245, 0.2)' };
// ❌ 含非色值属性（title/fontSize）→ 不是取色器，#0564f5 回到 §2 其余检查判定
const theme = { title: '主色', fontSize: 14, primary: '#0564f5' };
```

### §2 补充：已注释行识别（规则 ③ 之细则）

> 🚨 **强制铁律**：扫描尚存硬编码色值时，**必须严格排除掉所有被注释的代码**——凡是位于任何形式注释内的色值，一律不得计入「尚存硬编码色值」的残留项。

「已注释行」覆盖 5 类形态，命中任一即视为已注释、一律跳过：

| 形态 | 示例 | 判定要点 |
|:--|:--|:--|
| ① 单行 `//` 注释 | `// color: #0564f5;` | 行首（允许前置空白）以 `//` 起始 |
| ② 行内 `//` 之后 | `color: red; // fallback #0564f5` | 色值出现在同一行 `//` 之后（`//` 之前的代码不视为注释） |
| ③ 单行块注释 `/* ... */` | `/* color: #0564f5; */` | 行首（允许前置空白）以 `/*` 起始且同行含 `*/` |
| ④ 多行块注释 `/* ... */` 中间行 | `* color: #0564f5;`（前一行为 `/*`、后一行为 `*/`） | 逐文件用**状态机**跟踪 `/*` 与 `*/` 的开合状态，处于 open 状态期间的所有行（含以 `*` 起首的续行）一律视为注释 |
| ⑤ JSX 注释 `{/* ... */}` | `{/* <div style={{ color: '#0564f5' }} /> */}` | `.tsx` / `.jsx` 文件中被 `{/*` 与 `*/}` 包裹的整段 |

**块注释状态机判定要点**：对每个 `.scss` / `.css` / `.less` / `.ts` / `.tsx` / `.js` / `.jsx` 文件，从头到尾逐行扫描时维护一个 `inBlockComment` 布尔标志：

- 行内出现 `/*` 且其后未出现 `*/` → 进入块注释状态（`inBlockComment = true`）；
- 行内出现 `*/` → 退出块注释状态（`inBlockComment = false`）；
- `inBlockComment` 为 `true` 时，**该行整行**（含以 `*` 起首的续行、含开合 `/*` `*/` 所在行本身）**一律视为注释**，其内色值一律跳过。
- 字符串字面量内的 `/*` / `*/` 不计入注释状态切换（避免把字符串里的 `/*` 误判为注释起始）。

> 💡 固定 grep 命令通过 `grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)"` 排除单行注释与块注释续行，但**无法可靠识别跨行块注释开合**；若担心遗漏（例如色值行紧邻 `/*` 但不以 `*` 起首），须借助 `scripts/neoThemeAnalyzer.js` 中的块注释状态机预处理，或人工回溯确认，绝不允许把注释中的色值当作残留计入报告。

### §2 补充：blue 选择器向上回溯

- 从命中行向上找到所属 CSS 规则块；SCSS/Less 嵌套须逐层向上拼接所有祖先选择器，`&.blue`、`&-blue`、`.icon-blue &` 等一并拼接。
- 拼接后选择器任一 class / 标签名含 `blue`（大小写不敏感）→ 跳过。

```scss
.blue-badge { color: #0564f5; }              // 回溯 .blue-badge → 跳过
.card { .blue-tag { background: #4e80f5; } }  // 逐层回溯命中 .blue-tag → 跳过
.btn { &.blue { border-color: #096dd9; } }    // & 拼接为 .btn.blue → 跳过
```

---

## §3 组件与页面归属判定（步骤 1 与步骤 2 通用）

每个命中（无论是 CSS 变量还是残留硬编码色）都要归属到「组件名称」「所在页面」「文件位置」。

### 3.1 组件名称

按以下优先级判定：

1. **组件文件**：文件本身是组件（`.tsx` / `.jsx`，或包含 `export default function/class`、`const X = () => {}` 组件定义）→ 取组件名（导出的组件名 / 文件名）。
2. **样式文件关联组件**：`.scss` / `.less` / `.css` 文件 → 关联同目录同名组件文件（`UserCard.scss` ↔ `UserCard.tsx`）或同目录 `index.tsx`；关联不到时，取样式文件所属目录名作为组件名。
3. **就近符号**：一个文件含多个组件时，按命中行就近向上的组件定义（函数 / 类）归属。
4. **兜底**：以上都无法判定时，用**文件名**（去扩展名）作为组件名，并在报告中不额外标注推断依据。

### 3.2 所在页面

按目录结构推断，判定不了就填「未知」：

- `src/pages/<Page>/...`、`src/views/<Page>/...` → `<Page>` 页（可结合目录中文名 / 路由配置）。
- 组件位于通用目录（`src/components/`、`src/common/`、`packages/ui/` 等）且被多处复用 → 页面填「通用组件 / 多页面复用」或「未知」。
- 有路由表（`router`、`routes`）时可结合路由 path/title 提升页面名准确度（可选增强）。
- **判定不了一律填「未知」**，不要臆测。

### 3.3 文件位置

统一使用**相对项目根目录**的路径；明细行附**行号**。同一组件多处命中时，文件位置列可合并写路径、行号在明细中逐条列出。

---

## §4 组件功能、注册类型与使用位置判定（步骤 3）

### 4.1 功能说明

- 必须读取组件实现入口，综合 JSX / render 结构、核心 props、事件方法、状态与数据请求，概括组件对用户提供的能力。
- 一句话中文说明，**最多 50 个字符**；不得仅复述文件名，不写“该组件是一个组件”等无信息内容。
- 优先分析注册文件；样式命中时关联同名组件或同目录 `index.tsx/jsx/ts/js`。无法找到实现时填「未知（未找到组件实现入口）」。
- 脚本从 `description` / `desc` / `label` / `title` 与“功能/用途/说明”注释中生成的只是**初筛线索**；你（agent）**必须**结合代码把功能说明核实并改写后写入报告，此环节由你自己完成，不存在交由外部人工复核的步骤，也不得留空。

### 4.2 组件类型与注册标识

| 代码证据 | 组件类型 | 标识提取 |
|:--|:--|:--|
| `NeoRegister({ name: 'xxx', ... })` 或等价调用 | amis 组件 | `type = name = xxx` |
| `XRegister.CmpDefine({ cmpType: 'xxx', ... })` 或等价调用 | Neo 2.0 组件 | `cmpType = xxx` |
| 未找到以上注册 | 未知 | 未知 |

- 目录名、类名、`__c` 后缀只能辅助定位，**不能替代注册代码证据**。
- 同一组件同时出现两种注册方式时，**必须同时列出两种注册标识**并注明「注册冲突」，由你自行判定并如实记录，不得只选其一、不得留空。
- 注册配置跨变量传入、动态表达式或封装调用导致无法静态提取时，你（agent）**必须**自行追踪变量定义以判定类型与标识；类型可按调用判定，追踪后仍无法确定标识时填「未知（动态注册）」，不得留空。

### 4.3 使用位置检索

1. amis 组件：取 `NeoRegister.name`，精确搜索属性值 `type: '<name>'`、`"type": "<name>"`。
2. Neo 2.0 组件：取 `XRegister.CmpDefine.cmpType`，精确搜索 `cmpType: '<value>'`、`"cmpType": "<value>"`。
3. 范围为当前项目源码与配置；排除 `node_modules`、`dist`、`build`、测试文件、注释与组件自身注册声明。
4. 每条结果记录相对路径、行号与必要的短上下文；同文件同一行去重。
5. 无引用时填「未发现」；组件类型或注册标识未知时填「无法按注册标识检索」。
6. 你**必须**自行确认每条搜索结果是组件实例 / 页面 Schema / 组件配置引用，示例文档、类型声明、注册清单等非运行时使用须剔除或单独说明；该确认由你完成并直接定稿，不遗留给外部人工。

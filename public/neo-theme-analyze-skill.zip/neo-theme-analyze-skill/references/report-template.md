# 报告模板：当前项目主题换肤支持情况.md

步骤 3 在**项目根目录**生成 `当前项目主题换肤支持情况.md`，按以下结构填充实际扫描数据。

---

```markdown
# 当前项目主题换肤支持情况

## 项目关键信息

| 项 | 值 |
|:--|:--|
| 项目名称 | <package.json name，未知则填"未知"> |
| 仓库地址 | <git remote.origin.url，未知则填"未知"> |
| 所在分支 | <当前分支名，未知则填"未知"> |
| 当前 commit | <短 commit，可选> |
| 分析日期 | YYYY-MM-DD |

## 总体汇总

| 指标 | 数值 |
|:--|:--|
| 扫描文件总数 | XXX |
| 已支持换肤的组件数 | XXX |
| 尚存硬编码色值的组件数 | XXX |
| 命中的主题 CSS 变量总数（去重） | XXX |
| 残留硬编码色值总数 | XXX |
| 其中蓝色残留数 | XXX |
| 其中浅蓝残留数（`background` / `background-color`） | XXX |
| 其中近似匹配数 | XXX |
| 合法跳过项数 | XXX |

---

## 一、已支持换肤的页面与组件

> 已使用 Neo 主题 CSS 变量（品牌色 / 按钮色 / 边框色 / 背景色 / 图标色 / 文本色 / 导航色）的组件。

| 组件名称 | 功能说明（≤50字） | 组件类型 | 注册标识 | 所在页面 | 文件位置 | 用到的地方 | CSS 变量分类 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| UserCard | 展示用户摘要并支持进入详情 | amis 组件 | `type=user-card` | Dashboard 页 | src/pages/Dashboard/UserCard.tsx | src/pages/Home/schema.ts:32 | 品牌色、文本色、边框色 |
| NavBar | 提供全局导航、选中与返回交互 | Neo 2.0 组件 | `cmpType=navBar` | 通用组件 / 多页面复用 | src/components/NavBar/index.scss | src/pages/Layout/config.ts:18 | 导航色、按钮色 |
| ChartPanel | 展示业务指标趋势图表 | 未知 | 未知 | 未知 | src/widgets/ChartPanel.tsx | 无法按注册标识检索 | 品牌色（ECharts getCssVarHex） |
| ... | ... | ... | ... | ... | ... | ... | ... |

### 1.x 明细：各组件用到的具体 CSS 变量

#### UserCard（src/pages/Dashboard/UserCard.tsx）
- 功能说明：展示用户摘要并支持进入详情
- 组件类型：amis 组件
- 注册标识：`type=user-card`（来自 `NeoRegister.name`）
- 用到的地方：`src/pages/Home/schema.ts:32`
- 品牌色：`var(--brand-color)`、`var(--brand-color-hover)`
- 文本色：`var(--color-text-brand)`、`var(--color-text-brand-link)`
- 边框色：`var(--color-border-brand)`

#### NavBar（src/components/NavBar/index.scss）
- 功能说明：提供全局导航、选中与返回交互
- 组件类型：Neo 2.0 组件
- 注册标识：`cmpType=navBar`（来自 `XRegister.CmpDefine.cmpType`）
- 用到的地方：`src/pages/Layout/config.ts:18`
- 导航色：`var(--brand-nav-header-bg)`、`var(--brand-nav-header-font)`、`var(--brand-nav-header-select-bg)`
- 按钮色：`var(--color-button-filled-primary)`

（… 逐组件列出去重后的具体变量列表 …）

---

## 二、尚存硬编码色值

> 仍在使用硬编码品牌色（未替换为 CSS 变量）的组件。近似匹配项须由你（agent）核实基准差异后如实标注匹配类型，不得留空。

| 组件名称 | 功能说明（≤50字） | 组件类型 | 注册标识 | 所在页面 | 文件位置 | 用到的地方 | 残留硬编码色值 | 色系 | 匹配类型 | 建议目标变量 |
|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|
| LoginForm | 提供账号输入、校验与登录提交 | amis 组件 | `type=login-form` | 登录页 | src/pages/Login/LoginForm.scss:22 | src/pages/Login/schema.ts:8 | `#0564f5` | 蓝色 | 完全匹配 | `var(--brand-color)` |
| OrderTag | 展示订单状态并支持筛选 | Neo 2.0 组件 | `cmpType=orderTag` | 订单页 | src/pages/Order/OrderTag.less:14 | src/pages/Order/config.ts:41 | `#4e80f5` | 蓝色 | 完全匹配 | `var(--brand-color-hover)` |
| Badge | 展示带状态语义的徽标信息 | 未知 | 未知 | 未知 | src/components/Badge/index.tsx:31 | 无法按注册标识检索 | `#0968f5` | 蓝色 | 近似匹配·1色阶（基准#0564f5, Δ=4, d≈5.7） | `var(--brand-color)` |
| Overlay | 提供页面遮罩与交互阻断 | 未知 | 未知 | 未知 | src/components/Overlay.scss:8 | 无法按注册标识检索 | `#0564f533` | 蓝色 | 完全匹配·含透明度 | `rgba(var(--brand-color-rgb), 0.2)` |
| Panel | 展示分组信息与浅底卡片区块 | 未知 | 未知 | 未知 | src/components/Panel/index.scss:12（`background`） | 无法按注册标识检索 | `#e6f0fe` | 浅蓝 | 完全匹配 | `var(--brand-color-tint)` |
| Mask | 提供浅蓝半透明蒙层背景 | 未知 | 未知 | 未知 | src/components/Mask.scss:41（`background`） | 无法按注册标识检索 | `rgba(230, 247, 255, 0.2)` | 浅蓝 | 完全匹配·含透明度 | `rgba(var(--brand-color-tint-rgb), 0.2)` |
| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |

---

## 三、合法跳过项（按忽略规则跳过，非遗漏）

> 命中品牌色但按忽略规则跳过，不计入"尚存硬编码色值"。

| 文件 | 行号 | 色值 | 跳过原因 |
|:--|:--|:--|:--|
| src/components/Foo.scss | 12 | `#0564f5` | 类名保护：`text-[#0564f5]` |
| src/charts/Chart.tsx | 45 | `#0564f5` | ECharts option 属性 |
| src/theme/palette.ts | 3 | `#0564f5` | 取色器对象（属性值全为色值） |
| src/styles/blue.scss | 7 | `#096dd9` | blue 选择器回溯命中 |
| src/vars.scss | 2 | `#2065cf` | SCSS 变量定义 `$blue-base` |
| src/components/Bar.scss | 20 | `#3080d0` | 超阈值：与 #0564f5 差 Δ_ch=43，非品牌色 |
| src/components/Panel/index.scss | 66 | `#e6f0fe` | `var()` 中备用（回退）的硬编码色值，不需要替换 |
| src/components/Tag.less | 31 | `#e6f0fe` | 浅蓝出现在非背景属性（`color`）上，不计入残留 |
| src/components/Hero.scss | 9 | `#f0f8ff` | 不在浅蓝 11 色清单内（浅蓝不做近似匹配） |
| ... | ... | ... | ... |
```

---

## 硬性输出要求（必须严格满足，任一不满足即为不合规）

> 以下为强制约束，生成报告时逐条满足。全部由你（agent）自主完成并定稿，**不存在任何交由外部人工复核的环节**。

1. **以组件为最小粒度逐行输出**：「一、已支持换肤」「二、尚存硬编码色值」都必须是**逐组件表格**，每个组件独立占一行。**严禁**用「某目录 N 个文件」「某变量命中 N 个文件」这类目录 / 文件计数聚合替代组件明细。
2. **字段必须填满，禁止占位符**：任一字段都不得出现空白、`-`、`TODO`、「待补充」「待人工复核」「待确认」。无法判定时只能填约定值（见下）。「色系」列只能填「蓝色」或「浅蓝」。
3. **约定值**：所在页面 → 「未知」；功能说明 → 「未知（未找到组件实现入口）」；组件类型 / 注册标识 → 「未知」；使用位置 → 「未发现」或「无法按注册标识检索」。
4. **必含逐组件 CSS 变量明细区（1.x）**：概览表之外，每个已支持组件都要有明细小节，列出去重后的具体变量并按大类归组；只给大类聚合统计不合规。
5. **功能说明基于组件实现**，一句中文且 ≤50 字，不得凭文件名或脚本候选值臆测。
6. **组件类型 / 注册标识以注册代码为准**：`NeoRegister.name` → amis 组件及 `type`；`XRegister.CmpDefine.cmpType` → Neo 2.0 组件及 `cmpType`；两者均无 → 未知；两者皆有 → 同列两标识并注明「注册冲突」。
7. **用到的地方按注册标识精确检索**并记录路径 + 行号，剔除注册声明自身、测试、注释、示例和无关配置；无引用写「未发现」。
8. **匹配类型**须区分「完全匹配」与「近似匹配·N色阶」（近似附基准 `#0564f5` 与 Δ_ch / d）；**色系**须区分蓝色（建议 `--brand-color` / `--brand-color-hover`）与浅蓝（建议 `--brand-color-tint`，且必须标明命中属性为 `background` / `background-color`）。
9. **只读产物**：本报告是本技能唯一产物，不得改动任何源码。
10. 组件较多时可按页面 / 目录分组小节呈现，但每个组件仍占独立行，字段保持一致。

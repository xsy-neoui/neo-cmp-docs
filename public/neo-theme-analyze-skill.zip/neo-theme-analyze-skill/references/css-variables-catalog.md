# Neo 主题 CSS 变量清单与分类（分析用）

> 本清单用于「步骤 1：扫描已支持换肤的页面与组件」。扫描到的 `var(--xxx)` 引用须归入以下 7 大类之一并列出具体变量；不在本清单内的 `var(--xxx)`（项目自定义非主题变量，如 `--gap`、`--radius`）不计入换肤支持统计。
>
> 本清单为本技能内置、自包含的分析归类依据，不依赖任何其他技能。本文件只做**分析归类**用途。

---

## 分类判定：按变量名前缀归类

扫描器 / 人工按下表前缀，将命中的变量归入对应大类：

| 大类 | 匹配前缀（`var(` 之后） | 说明 |
|:--|:--|:--|
| **品牌色** | `--brand-color`（且**不**以 `--brand-nav-header` 开头） | 品牌核心色及其变体 |
| **背景色** | `--color-bg-brand` | 语义化品牌背景 Token |
| **边框色** | `--color-border-brand` | 语义化品牌边框 Token |
| **图标色** | `--color-icon-brand` / `--color-icon-fill-brand` | 语义化品牌图标 Token |
| **文本色** | `--color-text-brand` | 语义化品牌文本 / 链接 Token |
| **按钮色** | `--color-button-filled-primary` | 按钮背景 / 文字 / 次按钮 Token |
| **导航色** | `--brand-nav-header` | 导航 Banner 色 Token |

> 每个 Hex 主变量都有 `-rgb` 伴侣变量（如 `--brand-color-rgb`），归类时与主变量同类；`rgba(var(--xxx-rgb), a)` 与 `var(--xxx)` 一并计入。

---

## 一、品牌色（6 对，hex + -rgb）

```
--brand-color              --brand-color-rgb
--brand-color-hover        --brand-color-hover-rgb
--brand-color-shade        --brand-color-shade-rgb
--brand-color-tint         --brand-color-tint-rgb
--brand-color-tint-light   --brand-color-tint-light-rgb
--brand-color-disabled     --brand-color-disabled-rgb
```

## 二、背景色（6 个 + -rgb）

```
--color-bg-brand             --color-bg-brand-hover        --color-bg-brand-shade
--color-bg-brand-tint        --color-bg-brand-tint-light   --color-bg-brand-disabled
（均有对应 -rgb 伴侣变量）
```

## 三、边框色（6 个 + -rgb）

```
--color-border-brand             --color-border-brand-hover        --color-border-brand-shade
--color-border-brand-tint        --color-border-brand-tint-light   --color-border-brand-disabled
（均有对应 -rgb 伴侣变量）
```

## 四、图标色（7 个 + -rgb）

```
--color-icon-brand               --color-icon-brand-hover          --color-icon-brand-shade
--color-icon-brand-tint          --color-icon-brand-tint-light     --color-icon-brand-disabled
--color-icon-fill-brand-link
（均有对应 -rgb 伴侣变量）
```

## 五、文本色（7 个 + -rgb）

```
--color-text-brand               --color-text-brand-hover          --color-text-brand-shade
--color-text-brand-tint          --color-text-brand-tint-light     --color-text-brand-disabled
--color-text-brand-link
（均有对应 -rgb 伴侣变量）
```

## 六、按钮色（18 个）

背景色（5 个 + -rgb）：
```
--color-button-filled-primary            --color-button-filled-primary-hover
--color-button-filled-primary-active     --color-button-filled-primary-tint
--color-button-filled-primary-disabled
```

文字色（3 个）：
```
--color-button-filled-primary-color      --color-button-filled-primary-color-hover
--color-button-filled-primary-color-disabled
```

次按钮（3 个 + -rgb）：
```
--color-button-filled-primary-secondary            --color-button-filled-primary-secondary-hover
--color-button-filled-primary-secondary-disabled
```

## 七、导航色（11 个 + -rgb）

```
--brand-nav-header-bg              --brand-nav-header-font           --brand-nav-header-font-hover
--brand-nav-header-icon            --brand-nav-header-icon-hover     --brand-nav-header-launcher-icon
--brand-nav-header-select          --brand-nav-header-select-bg      --brand-nav-header-elem-opacity
--brand-nav-header-elem-hover      --brand-nav-header-placeholder
（均有对应 -rgb 伴侣变量）
```

---

## 归类优先级注意事项

- `--brand-nav-header-*` 必须归入**导航色**，不要因其以 `--brand-` 开头而误判为**品牌色**。判定时先匹配更长的前缀（`--brand-nav-header`），再匹配 `--brand-color`。
- `--color-icon-fill-brand-link` 归入**图标色**。
- `--color-text-brand-link` 归入**文本色**。
- 只要变量名以上述任一前缀开头即计入对应大类；未列全的新增变体（如未来新增 `--color-bg-brand-xxx`）按前缀就近归类。

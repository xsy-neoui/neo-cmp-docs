/**
 * Neo 主题换肤 · 硬编码色值匹配工具
 *
 * 用途：给定一个硬编码色值（#RRGGBB / #RRGGBBAA / rgb() / rgba()），
 *      返回其应替换的 Neo 品牌 CSS 变量。
 *
 * 匹配策略（与 SKILL.md § 3.1 ~ § 3.1.2 完全对齐）：
 *   - 完全匹配：与 BRAND_COLOR_MAP 中 48 个蓝色色值逐一比对（大小写不敏感），命中即用其目标变量。
 *   - 浅蓝（任务 2）：另用 matchLightBlueTint() 与 LIGHT_BLUE_TINT_MAP 的 11 个浅蓝色值做完全匹配，
 *     命中映射为 --brand-color-tint；浅蓝不参与近似匹配，且仅适用于 background / background-color。
 *   - 近似匹配：仅与唯一基准色 #0564f5 比较（1-2 色阶差），命中一律映射为 --brand-color；
 *     不与表中其他色值（含次品牌色、经典 Web 蓝 #3399cc）做近似比较，避免蓝色候选邻域重叠导致过度替换。
 *
 * 配套参考文档：references/theme-css-variables.md § 十一
 *
 * 用法：
 *   const { matchBrandColor } = require('./neoThemeColorMatcher');
 *   matchBrandColor('#0564f5');
 *   // → { matchType: 'exact', targetVar: '--brand-color', output: 'var(--brand-color)', ... }
 *
 *   matchBrandColor('#0968f5');
 *   // → { matchType: 'approximate', targetVar: '--brand-color', shade: 1, delta: 4, distance: 5.7, output: 'var(--brand-color)' }
 *
 *   matchBrandColor('#0564f533');
 *   // → { matchType: 'exact-with-alpha', targetVar: '--brand-color', alpha: 0.2, output: 'rgba(var(--brand-color-rgb), 0.2)' }
 */

'use strict';

// ===== 1. 硬编码色值 → CSS 变量映射表 =====
const BRAND_COLOR_MAP = {
  // 主品牌色 → var(--brand-color)
  '#0564f5': '--brand-color', // Neo 标准
  '#096dd9': '--brand-color', // Ant Design v4
  '#2065cf': '--brand-color',
  '#1d77ff': '--brand-color',
  '#1677ff': '--brand-color', // Ant Design v5
  '#0052d9': '--brand-color', // TDesign
  '#2b7fff': '--brand-color',
  '#0060df': '--brand-color',
  '#1a7aff': '--brand-color',

  // 实战补充：与基准 #0564f5 相差 1-2 色阶、在历史项目中高频出现的硬编码变体，
  // 原本应由「近似匹配」命中，但近似色无法被固定 grep 捞出而屡屡漏网，
  // 故升级为「完全匹配」以保证 grep + 替换的确定性。全部映射为主品牌色。
  '#257cff': '--brand-color', // rgb(37, 124, 255)  Δ_ch=32 d≈41.2
  '#0656d5': '--brand-color', // rgb(6, 86, 213)    Δ_ch=32 d≈34.9
  '#007bff': '--brand-color', // rgb(0, 123, 255)   Δ_ch=23 d≈25.6  Bootstrap 主蓝
  '#2468f2': '--brand-color', // rgb(36, 104, 242)  Δ_ch=31 d≈31.4
  '#1c61da': '--brand-color', // rgb(28, 97, 218)   Δ_ch=27 d≈35.6
  '#1865d9': '--brand-color', // rgb(24, 101, 217)  Δ_ch=28 d≈33.9
  '#2563eb': '--brand-color', // rgb(37, 99, 235)   Δ_ch=32 d≈33.5  Tailwind blue-600
  '#1d4ed8': '--brand-color', // rgb(29, 78, 216)   Δ_ch=29 d≈43.6  Tailwind blue-700
  '#047bdb': '--brand-color', // rgb(4, 123, 219)   Δ_ch=26 d≈34.7  amis cxd 主色
  '#1758e7': '--brand-color', // rgb(23, 88, 231)   Δ_ch=18 d≈25.8
  '#007eff': '--brand-color', // rgb(0, 126, 255)   Δ_ch=26 d≈28.3

  // 经典 Web 蓝：与基准 #0564f5 差异 > 2 色阶，业务上明确属于品牌主色系，以完全匹配方式识别
  '#3399cc': '--brand-color', // rgb(51, 153, 204)  Δ_ch=53 d≈81.3

  // 实战盘点补充（第二批）：历史项目中作为品牌主色使用的蓝色硬编码，含深蓝 / 靛蓝 / 灰蓝变体。
  // 多数与基准 #0564f5 差异超过 2 色阶，近似匹配捞不到，必须以完全匹配识别为主品牌色。
  '#3c50e0': '--brand-color', // rgb(60, 80, 224)   靛蓝变体
  '#115bdd': '--brand-color', // rgb(17, 91, 221)
  '#3a75c6': '--brand-color', // rgb(58, 117, 198)  灰蓝主色变体
  '#4378be': '--brand-color', // rgb(67, 120, 190)  灰蓝主色变体
  '#4477bc': '--brand-color', // rgb(68, 119, 188)  灰蓝主色变体
  '#5f7ab8': '--brand-color', // rgb(95, 122, 184)  灰蓝主色变体
  '#2869ff': '--brand-color', // rgb(40, 105, 255)  对应 rgba(40, 105, 255, 0.2)
  '#2a72d3': '--brand-color', // rgb(42, 114, 211)
  '#287eff': '--brand-color', // rgb(40, 126, 255)
  '#2866f2': '--brand-color', // rgb(40, 102, 242)

  // 次品牌色 → var(--brand-color-hover)
  '#4e80f5': '--brand-color-hover', // Neo 标准 hover
  '#1890ff': '--brand-color-hover', // Ant Design v4 hover
  '#40a9ff': '--brand-color-hover',
  '#3886fb': '--brand-color-hover',
  '#238dff': '--brand-color-hover',
  '#3783ff': '--brand-color-hover',
  '#4096ff': '--brand-color-hover', // Ant Design v5 hover
  '#5b8ff9': '--brand-color-hover', // AntV 常用蓝
  '#69c0ff': '--brand-color-hover', // Ant Design 极浅蓝
  '#4ca1dc': '--brand-color-hover',
  '#4b87f1': '--brand-color-hover', // rgb(75, 135, 241) 次品牌色变体

  // 实战盘点补充（第二批）：与标准 hover 色 #4e80f5 / #1890ff 高度接近的浅蓝变体
  '#5581f4': '--brand-color-hover', // rgb(85, 129, 244)  与 #4e80f5 仅差 Δ_ch=7
  '#4285f4': '--brand-color-hover', // rgb(66, 133, 244)  Google 蓝，与 #4e80f5 差 Δ_ch=12
  '#009ffe': '--brand-color-hover', // rgb(0, 159, 254)   对应 rgba(0, 159, 254, 0.2)

  // 实战盘点补充（第三批）
  '#475ffd': '--brand-color', // rgb(71, 95, 253)   靛蓝主色变体
  '#4376bb': '--brand-color', // rgb(67, 118, 187)  灰蓝主色变体（与 #4378be 近邻）
  '#457ff5': '--brand-color-hover', // rgb(69, 127, 245)  与 #4e80f5 仅差 Δ_ch=9
};

// ===== 1.1 浅蓝色值 → var(--brand-color-tint) 映射表（任务 2）=====
// 仅 background / background-color 属性上的浅蓝色值参与替换（属性判定由调用方负责）；
// 浅蓝只做「完全匹配」，不参与任何近似匹配，避免误伤中性浅灰底色。
const LIGHT_BLUE_TINT_MAP = {
  '#e6f0fe': '--brand-color-tint', // rgb(230, 240, 254) 浅蓝基准写法
  '#e6f7ff': '--brand-color-tint', // rgb(230, 247, 255) 含 rgba(230, 247, 255, 0.2)
  '#e8f0fe': '--brand-color-tint', // rgb(232, 240, 254)
  '#e8f1ff': '--brand-color-tint', // rgb(232, 241, 255)
  '#e7f7ff': '--brand-color-tint', // rgb(231, 247, 255)
  '#eff6ff': '--brand-color-tint', // rgb(239, 246, 255) Tailwind blue-50
  '#eef2ff': '--brand-color-tint', // rgb(238, 242, 255) Tailwind indigo-50
  '#dcf4ff': '--brand-color-tint', // rgb(220, 244, 255)
  '#d9f3fb': '--brand-color-tint', // rgb(217, 243, 251)
  '#eceff8': '--brand-color-tint', // rgb(236, 239, 248) 灰浅蓝
  '#edeff2': '--brand-color-tint', // rgb(237, 239, 242) 常见写法 #edeff280
};

// ===== 2. 近似色匹配阈值 =====
const THRESHOLDS = {
  SHADE_1_CH_MAX: 16, // 1 色阶差单通道最大值
  SHADE_1_D_MAX: 25, // 1 色阶差欧氏距离最大值
  SHADE_2_CH_MAX: 32, // 2 色阶差单通道最大值
  SHADE_2_D_MAX: 50, // 2 色阶差欧氏距离最大值
};

// ===== 3. 基础工具函数 =====
function normalizeHex(hex) {
  const trimmed = String(hex).trim().toLowerCase();
  return trimmed.startsWith('#') ? trimmed : `#${trimmed}`;
}

function hex6ToRgb(hex) {
  const m = normalizeHex(hex).match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const int = parseInt(m[1], 16);
  return { r: (int >> 16) & 0xff, g: (int >> 8) & 0xff, b: int & 0xff };
}

function parseHex8(hex) {
  const m = normalizeHex(hex).match(/^#([0-9a-f]{6})([0-9a-f]{2})$/i);
  if (!m) return null;
  const alphaInt = parseInt(m[2], 16);
  return {
    hex6: `#${m[1].toLowerCase()}`,
    alphaHex: m[2].toLowerCase(),
    alpha: Math.round((alphaInt / 255) * 100) / 100,
  };
}

function parseRgb(rgbStr) {
  const m = String(rgbStr).match(
    /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)$/i,
  );
  if (!m) return null;
  return {
    r: parseInt(m[1], 10),
    g: parseInt(m[2], 10),
    b: parseInt(m[3], 10),
    alpha: m[4] !== undefined ? parseFloat(m[4]) : null,
  };
}

function channelDelta(c1, c2) {
  return Math.max(Math.abs(c1.r - c2.r), Math.abs(c1.g - c2.g), Math.abs(c1.b - c2.b));
}

function euclideanDistance(c1, c2) {
  return Math.sqrt((c1.r - c2.r) ** 2 + (c1.g - c2.g) ** 2 + (c1.b - c2.b) ** 2);
}

// ===== 4. 判定色阶差 =====
function classifyShade(chDelta, distance) {
  if (chDelta === 0 && distance === 0) return 0;
  if (chDelta <= THRESHOLDS.SHADE_1_CH_MAX && distance <= THRESHOLDS.SHADE_1_D_MAX) return 1;
  if (chDelta <= THRESHOLDS.SHADE_2_CH_MAX && distance <= THRESHOLDS.SHADE_2_D_MAX) return 2;
  return -1; // 超阈值
}

// ===== 5. 近似匹配唯一基准 =====
// 近似（1-2 色阶）匹配只与 #0564f5 比较，命中一律映射为 --brand-color。
// 表中其余色值（含次品牌色）仅参与「完全匹配」，不作为近似基准。
const APPROX_BASE_HEX = '#0564f5';
const APPROX_BASE_VAR = '--brand-color';

function matchApprox(rgb, sourceLabel) {
  const baseRgb = hex6ToRgb(APPROX_BASE_HEX);
  const chDelta = channelDelta(rgb, baseRgb);
  const distance = euclideanDistance(rgb, baseRgb);
  const shade = classifyShade(chDelta, distance);
  if (shade !== 1 && shade !== 2) {
    return { matchType: 'none', input: sourceLabel || `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})` };
  }
  return {
    matchType: 'approximate',
    targetVar: APPROX_BASE_VAR,
    baseHex: APPROX_BASE_HEX,
    shade,
    delta: chDelta,
    distance: Math.round(distance * 10) / 10,
  };
}

// ===== 6. 核心匹配函数 =====
function matchBrandColor(input) {
  if (!input || typeof input !== 'string') {
    return { matchType: 'invalid', input };
  }

  const raw = String(input).trim();

  // 分支 A：rgb() / rgba() 数值格式
  const rgbParsed = parseRgb(raw);
  if (rgbParsed) {
    const inner = matchRgb(rgbParsed);
    if (inner.matchType === 'none') return { ...inner, output: null };
    if (rgbParsed.alpha !== null) {
      // alpha = 1 与不透明等价 → 直接用主变量（与 8 位 hex AA=FF 规则一致）
      if (rgbParsed.alpha === 1) {
        return { ...inner, alpha: 1, output: `var(${inner.targetVar})` };
      }
      return {
        ...inner,
        matchType:
          inner.matchType === 'exact' ? 'exact-with-alpha' : 'approximate-with-alpha',
        alpha: rgbParsed.alpha,
        output: `rgba(var(${inner.targetVar}-rgb), ${rgbParsed.alpha})`,
      };
    }
    return { ...inner, output: `var(${inner.targetVar})` };
  }

  // 分支 B：8 位 hex
  const parsed8 = parseHex8(raw);
  if (parsed8) {
    const inner = matchHex6(parsed8.hex6);
    if (inner.matchType === 'none') return { ...inner, output: null };
    // AA=FF 优先直接主变量
    if (parsed8.alphaHex === 'ff') {
      return { ...inner, output: `var(${inner.targetVar})`, alpha: 1 };
    }
    return {
      ...inner,
      matchType:
        inner.matchType === 'exact' ? 'exact-with-alpha' : 'approximate-with-alpha',
      alpha: parsed8.alpha,
      output: `rgba(var(${inner.targetVar}-rgb), ${parsed8.alpha})`,
    };
  }

  // 分支 C：6 位 hex
  const result = matchHex6(raw);
  return {
    ...result,
    output: result.targetVar ? `var(${result.targetVar})` : null,
  };
}

function matchHex6(hex) {
  const normalized = normalizeHex(hex);

  // 完全匹配（全表 48 色，大小写不敏感）
  if (BRAND_COLOR_MAP[normalized]) {
    return {
      matchType: 'exact',
      targetVar: BRAND_COLOR_MAP[normalized],
      baseHex: normalized,
      shade: 0,
      delta: 0,
      distance: 0,
    };
  }

  // 近似匹配（仅与 #0564f5 比较）
  const rgb = hex6ToRgb(normalized);
  if (!rgb) return { matchType: 'invalid', input: hex };

  return matchApprox(rgb, normalized);
}

function matchRgb(rgb, sourceLabel) {
  // 完全匹配：与全表 48 色任一 rgb 值完全相等
  for (const [baseHex, targetVar] of Object.entries(BRAND_COLOR_MAP)) {
    const baseRgb = hex6ToRgb(baseHex);
    if (baseRgb.r === rgb.r && baseRgb.g === rgb.g && baseRgb.b === rgb.b) {
      return { matchType: 'exact', targetVar, baseHex, shade: 0, delta: 0, distance: 0 };
    }
  }
  // 近似匹配：仅与 #0564f5 比较
  return matchApprox(rgb, sourceLabel);
}

// ===== 6.5 浅蓝色值匹配（任务 2，只做完全匹配）=====
/**
 * 判定浅蓝硬编码色值 → var(--brand-color-tint)
 *
 * ⚠️ 调用方须自行确认该色值位于 background / background-color（或 JSX backgroundColor）属性上；
 *    其他属性上的浅蓝色值一律不替换。浅蓝不参与近似匹配，未命中即返回 matchType: 'none'。
 *
 *   matchLightBlueTint('#e6f0fe')                 // → var(--brand-color-tint)
 *   matchLightBlueTint('#edeff280')               // → rgba(var(--brand-color-tint-rgb), 0.5)
 *   matchLightBlueTint('rgba(230,247,255,0.2)')   // → rgba(var(--brand-color-tint-rgb), 0.2)
 */
function matchLightBlueTint(input) {
  if (!input || typeof input !== 'string') return { matchType: 'invalid', input };
  const raw = String(input).trim();

  const buildOpaque = (hex6) => ({
    matchType: 'exact',
    targetVar: LIGHT_BLUE_TINT_MAP[hex6],
    baseHex: hex6,
    kind: 'light-blue-tint',
    output: `var(${LIGHT_BLUE_TINT_MAP[hex6]})`,
  });
  const buildAlpha = (hex6, alpha) =>
    alpha === 1
      ? { ...buildOpaque(hex6), alpha: 1 }
      : {
          matchType: 'exact-with-alpha',
          targetVar: LIGHT_BLUE_TINT_MAP[hex6],
          baseHex: hex6,
          kind: 'light-blue-tint',
          alpha,
          output: `rgba(var(${LIGHT_BLUE_TINT_MAP[hex6]}-rgb), ${alpha})`,
        };

  // 分支 A：rgb() / rgba()
  const rgbParsed = parseRgb(raw);
  if (rgbParsed) {
    for (const baseHex of Object.keys(LIGHT_BLUE_TINT_MAP)) {
      const baseRgb = hex6ToRgb(baseHex);
      if (baseRgb.r === rgbParsed.r && baseRgb.g === rgbParsed.g && baseRgb.b === rgbParsed.b) {
        return rgbParsed.alpha === null
          ? buildOpaque(baseHex)
          : buildAlpha(baseHex, rgbParsed.alpha);
      }
    }
    return { matchType: 'none', input: raw };
  }

  // 分支 B：8 位 hex
  const parsed8 = parseHex8(raw);
  if (parsed8) {
    if (!LIGHT_BLUE_TINT_MAP[parsed8.hex6]) return { matchType: 'none', input: raw };
    return parsed8.alphaHex === 'ff'
      ? { ...buildOpaque(parsed8.hex6), alpha: 1 }
      : buildAlpha(parsed8.hex6, parsed8.alpha);
  }

  // 分支 C：6 位 hex
  const normalized = normalizeHex(raw);
  if (!LIGHT_BLUE_TINT_MAP[normalized]) return { matchType: 'none', input: raw };
  return buildOpaque(normalized);
}

// ===== 7. 导出 =====
module.exports = {
  BRAND_COLOR_MAP,
  LIGHT_BLUE_TINT_MAP,
  THRESHOLDS,
  matchBrandColor,
  matchLightBlueTint,
  hex6ToRgb,
  parseHex8,
  parseRgb,
  channelDelta,
  euclideanDistance,
  classifyShade,
};

---
name: neo-theme-skill
description: 当用户要求项目支持 Neo 主题换肤功能时触发。将 Neo 平台历史项目中的硬编码色值、旧版 CSS 变量、按钮样式改造为支持运行时主题换肤的标准写法。覆盖四大核心任务：① 蓝色硬编码色值替换为品牌色 CSS 变量；② 浅蓝硬编码背景色（background / background-color）替换为 var(--brand-color-tint)；③ 旧版 CSS 变量迁移为新版变量名；④ primary 模式按钮色改造为按钮色 CSS 变量。每次执行需按顺序完成全部四项任务，最终生成 Neo主题换肤功能升级报告.md。触发关键词：项目支持Neo主题换肤功能、项目支持主题换肤、Neo主题换肤功能升级、Neo主题换肤升级、主题换肤功能升级、主题换肤升级、项目换肤升级。
---

# Neo 平台主题换肤功能升级技能

将 Neo 平台历史项目的硬编码色值、旧版 CSS 变量、按钮样式，改造为支持运行时主题换肤的标准写法。

## 触发条件

当用户提出以下需求时启动本技能：

- **"让项目支持 Neo 主题换肤功能"**
- "项目支持 Neo 主题换肤功能升级"
- "项目主题换肤升级"
- "Neo 主题换肤功能升级"

> 本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

---

## 一、Neo 平台主题换肤机制概述

Neo 平台基于 **CSS 变量 + TokenHelper 运行时引擎** 实现主题换肤，核心设计要点：

1. **Hex 主变量 + -rgb 伴侣变量双输出**：`--brand-color: #0564f5` + `--brand-color-rgb: 5, 100, 245`
2. **品牌色、按钮色、导航色三套独立体系**，通过 `TokenHelper.setBaseColor()` / `setButtonPrimaryColor()` / `setNavBannerColor()` 分别控制
3. **组件通过 `var(--xxx)` 消费 CSS 变量**，运行时主题切换自动生效

### 核心原则

- ✅ 所有品牌相关颜色必须使用 CSS 变量
- ❌ 禁止硬编码品牌色 hex/rgb 值
- ❌ 禁止从 `ColorsConfig` 读取颜色后以内联 `style={{}}` 写入

---

## 二、升级任务总览

每次执行本技能，**必须按顺序**完成以下五项任务：

| 步骤 | 任务 | 说明 |
|:--|:--|:--|
| **1** | 蓝色硬编码色值 → CSS 变量替换 | 遍历源码，将品牌相关蓝色硬编码色值替换为 `var(--brand-color)` / `var(--brand-color-hover)`；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有蓝色硬编码色值均已替换** |
| **2** | 浅蓝硬编码色值 → `var(--brand-color-tint)` 替换 | 将 `background` / `background-color` 上的浅蓝硬编码色值（`#e6f0fe` 等 11 组）替换为 `var(--brand-color-tint)`；**完成后须执行遗漏检测，存在遗漏则自动重试** |
| **3** | 旧 CSS 变量 → 新 CSS 变量迁移 | 包含两类：① 将带 `-bg` 后缀的旧按钮变量名替换为新变量名；② 将旧版导航色变量（`--dayone-theme-header-*`）替换为新版导航色变量（`--brand-nav-header-*`） |
| **4** | Primary 按钮色改造 | 按背景色白/非白区分规则，替换为按钮色变量；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有 primary 按钮背景色均已改造** |
| **5** | 生成主题换肤功能升级报告 | **前四项任务全部完成后**，**依据当前项目代码的实际改动**（`git diff` / `git status`）汇总所有改动，生成 `Neo主题换肤功能升级报告.md` |

> ⚠️ **报告生成时机与依据**：任务 1~4 执行过程中可临时记录改动明细，但**最终报告必须在全部任务执行完成后**、依据**当前项目代码的实际改动**统一生成，确保报告内容与仓库真实 diff 一致。

---

## 三、任务 1：蓝色硬编码色值替换

### 3.0 匹配规则总则（Task 1 强制前置条件，最高优先级）

1. **优先完全匹配**：源代码色值与 3.1 替换规则对照表**逐字符完全匹配**（大小写不敏感）时 → 直接命中并按对应规则替换，无需报告标记。
2. **允许近似色匹配（唯一基准 `#0564f5`，1-2 色阶差）**：未列在完全匹配表内、但与主品牌基准色 `#0564f5`（rgb(5, 100, 245)）差异极小（≤ 2 色阶）时 → 推断为主品牌色近似变体，统一替换为 `var(--brand-color)`（含透明度时用 `var(--brand-color-rgb)`）。**近似匹配只与 `#0564f5` 这一个基准比较**（表中其余色值仅参与完全匹配）。近似替换**必须**在报告中标记 `[近似匹配]`，供人工复核。精确阈值见 [references/color-matching-details.md](references/color-matching-details.md) 第二节。
3. **超阈值一律不替换**：与 `#0564f5` 差异超出近似阈值（Δ_ch > 32 或 d > 50）→ 保留原样。
4. **禁止基于色名自动扩展**：不得基于色名、变量名（含 `primary`、`blue`）或代码上下文推断替换目标；替换必须由色值本身的匹配结果驱动。
5. **8 位十六进制**（`#RRGGBBAA`）：**前 6 位** 命中即视为命中，详细规则与 alpha 换算见 [references/color-matching-details.md](references/color-matching-details.md) 第一节。
6. **rgb / rgba**：三个数字与表中色值完全相等（允许逗号后空格差异）→ 完全匹配；否则仅与 `#0564f5` 按双阈值判定是否近似。
7. **近似匹配必须在报告中单独标记**：所有非完全匹配的替换都要在报告「近似匹配详情」表中单列，附源色值、匹配基准、色阶差、替换目标。

> ⚠️ 违反上述总则（例如将差异超过 2 色阶的色值当作品牌色替换）属于**错误改动**，必须在报告中回滚并标记。

### 3.0.1 强制防护流程（先于所有替换动作）

对**每一个**色值匹配行，必须**先跑完全部 6 项跳过检查**，全部通过才允许替换。**顺序固定、不可跳步**：

```
匹配行
  ↓
检查 1：类名 / 变量名含色值？（如 text-[#0564f5]）→ 跳过
检查 2：测试文件？（*.test.* / *.spec.* / __tests__/）→ 跳过
检查 3：已注释行？（单行 // / 行内 // / 单/多行块注释 /* */ / JSX {/* */}）→ 跳过
检查 4：blue 类选择器回溯？（向上回溯规则块的祖先选择器含 blue）→ 跳过
检查 5：ECharts option / 颜色数组 / **var() 中备用（回退）色值** / 取色器对象？→ 跳过
检查 6：SASS / Less 变量名含 blue（$blue-base、@blue-6）？→ 跳过
  ↓
✅ 全部通过 → 才允许进入替换决策
```

**执行铁律**：
- 顺序不可乱、不可跳步；任一步命中即判为「合法跳过」，立即终止该行处理，不再执行后续检查，也不得替换。
- 命中即在报告「跳过详情」表中记录文件、行号、色值、命中的检查项与跳过原因。
- 3.3.5 遗漏检测阶段同样必须重跑这 6 项检查。

**防护补充**：块内已存在的 `// var(...)` 注释行**只在检查 3 中跳过它自身**，不构成对同块其他活跃行的替换许可；每一行的命运由它自己的 6 项检查结果独立决定。

**忽略规则强调（检查 5 之 var() 备用值）**：`var()` 括号内逗号后的**备用（回退）硬编码色值不需要替换**，例如 `color: var(--brand-color, #0564f5);`、`background: var(--card-bg, #e6f0fe);`。这类色值仅在变量未定义时兜底，替换会破坏 `var()` 语法且无换肤收益。该忽略规则对**任务 1 蓝色色值与任务 2 浅蓝色值均适用**，且在遗漏检测阶段同样按「合法跳过」处理（固定 grep 命令末尾的 `grep -v "var("` 即为此服务）。

> 📚 6 项检查的详细判定规则、注释状态机、ECharts / 取色器 / blue 选择器的完整判定细则与示例见 **[references/guards-and-detection.md](references/guards-and-detection.md)**。

### 3.1 替换规则对照表（完整 48 组，完全匹配）

> 所有色值大小写均匹配（`#0564f5` / `#0564F5`）；`rgb()` 与 hex 等价（允许逗号后空格差异）；`rgba()` 使用对应 `-rgb` 伴侣变量并保留原始 alpha（`rgba(5, 100, 245, 0.2)` → `rgba(var(--brand-color-rgb), 0.2)`）。

#### 3.1.1 主品牌色 → `var(--brand-color)`（33 组）

| Hex（小写/大写） | rgb | 说明 |
|:--|:--|:--|
| `#0564f5` / `#0564F5` | `rgb(5, 100, 245)` | **基准色** |
| `#096dd9` / `#096DD9` | `rgb(9, 109, 217)` | Ant Design v4 主色 |
| `#2065cf` / `#2065CF` | `rgb(32, 101, 207)` | |
| `#1d77ff` / `#1D77FF` | `rgb(29, 119, 255)` | |
| `#1677ff` / `#1677FF` | `rgb(22, 119, 255)` | Ant Design v5 主色 |
| `#0052d9` / `#0052D9` | `rgb(0, 82, 217)` | TDesign 主色 |
| `#2b7fff` / `#2B7FFF` | `rgb(43, 127, 255)` | |
| `#0060df` / `#0060DF` | `rgb(0, 96, 223)` | |
| `#1a7aff` / `#1A7AFF` | `rgb(26, 122, 255)` | |
| `#257cff` / `#257CFF` | `rgb(37, 124, 255)` | 实战补充 |
| `#0656d5` / `#0656D5` | `rgb(6, 86, 213)` | 实战补充 |
| `#007bff` / `#007BFF` | `rgb(0, 123, 255)` | Bootstrap 主蓝 |
| `#2468f2` / `#2468F2` | `rgb(36, 104, 242)` | 实战补充 |
| `#1c61da` / `#1C61DA` | `rgb(28, 97, 218)` | 实战补充 |
| `#1865d9` / `#1865D9` | `rgb(24, 101, 217)` | 实战补充 |
| `#2563eb` / `#2563EB` | `rgb(37, 99, 235)` | Tailwind blue-600 |
| `#1d4ed8` / `#1D4ED8` | `rgb(29, 78, 216)` | Tailwind blue-700 |
| `#047bdb` / `#047BDB` | `rgb(4, 123, 219)` | amis cxd 主色 |
| `#1758e7` / `#1758E7` | `rgb(23, 88, 231)` | 实战补充 |
| `#007eff` / `#007EFF` | `rgb(0, 126, 255)` | 实战补充 |
| `#3399cc` / `#3399CC` | `rgb(51, 153, 204)` | 经典 Web 蓝（仅完全匹配，不参与近似） |
| `#3c50e0` / `#3C50E0` | `rgb(60, 80, 224)` | 实战补充·靛蓝变体 |
| `#115bdd` / `#115BDD` | `rgb(17, 91, 221)` | 实战补充 |
| `#3a75c6` / `#3A75C6` | `rgb(58, 117, 198)` | 实战补充·灰蓝主色变体 |
| `#4378be` / `#4378BE` | `rgb(67, 120, 190)` | 实战补充·灰蓝主色变体 |
| `#4477bc` / `#4477BC` | `rgb(68, 119, 188)` | 实战补充·灰蓝主色变体 |
| `#5f7ab8` / `#5F7AB8` | `rgb(95, 122, 184)` | 实战补充·灰蓝主色变体 |
| `#2869ff` / `#2869FF` | `rgb(40, 105, 255)` | 实战补充；含 `rgba(40, 105, 255, 0.2)` |
| `#2a72d3` / `#2A72D3` | `rgb(42, 114, 211)` | 实战补充 |
| `#287eff` / `#287EFF` | `rgb(40, 126, 255)` | 实战补充 |
| `#2866f2` / `#2866F2` | `rgb(40, 102, 242)` | 实战补充 |
| `#475ffd` / `#475FFD` | `rgb(71, 95, 253)` | 实战补充（第三批）·靛蓝主色变体 |
| `#4376bb` / `#4376BB` | `rgb(67, 118, 187)` | 实战补充（第三批）·灰蓝主色变体 |

> 💡 上表末 12 色为**第二 / 第三批实战盘点补充**的蓝色硬编码色值，多数与基准 `#0564f5` 差异超过 2 色阶（近似匹配捞不到），必须以完全匹配识别为主品牌色。**已存在于表中的蓝色色值（如 `#1865d9`、`#1890ff`、`#4b87f1`）不重复列入。**

#### 3.1.2 次品牌色 → `var(--brand-color-hover)`（15 组）

| Hex（小写/大写） | rgb | 说明 |
|:--|:--|:--|
| `#4e80f5` / `#4E80F5` | `rgb(78, 128, 245)` | |
| `#1890ff` / `#1890FF` | `rgb(24, 144, 255)` | Ant Design v4 hover |
| `#40a9ff` / `#40A9FF` | `rgb(64, 169, 255)` | |
| `#3886fb` / `#3886FB` | `rgb(56, 134, 251)` | |
| `#238dff` / `#238DFF` | `rgb(35, 141, 255)` | |
| `#3783ff` / `#3783FF` | `rgb(55, 131, 255)` | |
| `#4096ff` / `#4096FF` | `rgb(64, 150, 255)` | Ant Design v5 hover |
| `#5b8ff9` / `#5B8FF9` | `rgb(91, 143, 249)` | |
| `#69c0ff` / `#69C0FF` | `rgb(105, 192, 255)` | Ant Design 浅蓝 |
| `#4ca1dc` / `#4CA1DC` | `rgb(76, 161, 220)` | |
| `#4b87f1` / `#4B87F1` | `rgb(75, 135, 241)` | 次品牌色变体 |
| `#5581f4` / `#5581F4` | `rgb(85, 129, 244)` | 实战补充（与 `#4e80f5` 仅差 Δ_ch=7） |
| `#4285f4` / `#4285F4` | `rgb(66, 133, 244)` | 实战补充·Google 蓝 |
| `#009ffe` / `#009FFE` | `rgb(0, 159, 254)` | 实战补充；含 `rgba(0, 159, 254, 0.2)` |
| `#457ff5` / `#457FF5` | `rgb(69, 127, 245)` | 实战补充（第三批），与 `#4e80f5` 仅差 Δ_ch=9 |

#### 3.1.2.1 显式列举的 rgba 硬编码写法

以下 `rgba()` 写法在历史项目中高频出现，按要求 5 使用 `-rgb` 伴侣变量并保留原始 alpha（允许逗号后有/无空格）：

| 源写法 | 对应 hex | 替换为 |
|:--|:--|:--|
| `rgba(40, 105, 255, 0.2)` / `rgba(40,105,255,0.2)` | `#2869ff`（主品牌色） | `rgba(var(--brand-color-rgb), 0.2)` |
| `rgba(0, 159, 254, 0.2)` / `rgba(0,159,254,0.2)` | `#009ffe`（次品牌色） | `rgba(var(--brand-color-hover-rgb), 0.2)` |
| `rgba(68, 119, 188, 1)` / `rgba(68,119,188,1)` | `#4477bc`（主品牌色） | `var(--brand-color)`（alpha = 1，直接用主变量，不写 rgba） |

> 其他 alpha 值（如 `rgba(40, 105, 255, 0.5)`）同样适用：色值三通道命中即完全匹配，alpha 原样保留。
>
> ⚠️ **alpha = 1 的特例**：`rgba(r, g, b, 1)` 与不透明色等价，命中后**直接替换为主变量** `var(--brand-color)` / `var(--brand-color-hover)`，不保留 `rgba(var(--xxx-rgb), 1)` 写法（与 8 位 hex `AA=FF` 规则一致）。

#### 3.1.3 8 位十六进制（含透明度）与 alpha 换算

- 取 8 位色值 `#RRGGBBAA` 的**前 6 位** `#RRGGBB` 与上表比对（大小写不敏感）：命中 → 替换为对应 `-rgb` 伴侣变量 + 换算后 alpha；未命中且非近似 → 保留原样。
- 替换格式：`#RRGGBBAA` → `rgba(var(--xxx-rgb), <alpha_decimal>)`，`alpha_decimal = round(parseInt(AA,16)/255, 2)`。
- 边界：`AA=FF` → 直接用主变量 `var(--xxx)`（不写 rgba）；`AA=00` → 保留 `rgba(var(--xxx-rgb), 0)`。

| AA | 值 | AA | 值 | AA | 值 | AA | 值 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| `00` | 0 | `33` | 0.2 | `80` | 0.5 | `CC` | 0.8 |
| `0D` | 0.05 | `40` | 0.25 | `99` | 0.6 | `E6` | 0.9 |
| `1A` | 0.1 | `4D` | 0.3 | `B3` | 0.7 | `F2` | 0.95 |
| `26` | 0.15 | `66` | 0.4 | | | `FF` | 1 |

示例：`#0564f533` → `rgba(var(--brand-color-rgb), 0.2)`；`#0564f5FF` → `var(--brand-color)`；`#4e80f5cc` → `rgba(var(--brand-color-hover-rgb), 0.8)`。

> 📚 更多 8 位 hex 示例、注释保留写法、别名出处见 **[references/color-matching-details.md](references/color-matching-details.md) 第一/三节**。

#### 3.1.4 近似匹配阈值（唯一基准 `#0564f5`，1-2 色阶差 → `var(--brand-color)`）

未在 3.1.1 / 3.1.2 完全匹配表中列出的色值，**只与唯一基准色 `#0564f5`（rgb(5, 100, 245)）比较**，差异 ≤ 2 色阶时推断为主品牌色近似变体并替换为 `var(--brand-color)`（含透明度用 `rgba(var(--brand-color-rgb), a)`）。

> 🚨 **单一基准原则**：近似匹配**只认 `#0564f5` 这一个基准**，**不与表中其他色值（含次品牌色、`#3399cc`）比较**——表中其余色值仅参与完全匹配。次品牌色 `var(--brand-color-hover)` 只能由完全匹配命中。

给定源色 `Cs=(Rs,Gs,Bs)`、基准 `Ct=(5,100,245)`：
- 单通道最大差异 `Δ_ch = max(|Rs-5|, |Gs-100|, |Bs-245|)`
- 欧氏距离 `d = √((Rs-5)² + (Gs-100)² + (Bs-245)²)`

| 相似度 | Δ_ch | d | 判定 | 处理 |
|:--|:--|:--|:--|:--|
| 完全匹配 | = 0 | = 0 | ✅ 命中 | 直接替换，无需报告标记 |
| 1 色阶差 | ≤ 16 | ≤ 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·1色阶]` |
| 2 色阶差 | ≤ 32 且 > 16 | ≤ 50 且 > 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·2色阶]` |
| 超阈值 | > 32 或 d > 50 | — | ❌ 不命中 | 保留原样，不替换 |

> **注**：`Δ_ch` 与 `d` 需**同时满足**对应区间才判定为该色阶差；任一超出即视为超阈值。近似匹配基准恒为 `#0564f5`、目标恒为 `var(--brand-color)`，不存在多候选、无需 Tiebreaker。
>
> 示例：`#0968f5`（Δ=4, d≈5.7）→ `var(--brand-color)` `[近似·1色阶]`；`#256bd8`（Δ=32, d≈43.7）→ `var(--brand-color)` `[近似·2色阶]`；`#3080d0`（Δ=43）→ 保留原样。
>
> 📚 完整近似匹配示例、8 位 hex 近似规则、注释与报告格式见 **[references/color-matching-details.md](references/color-matching-details.md) 第二节**。

### 3.1.5 近似色执行缺口修补 —— 全量色值普查（必须执行）

> 🚨 **为什么必须有这一步**：SKILL 的固定 grep 命令只枚举了完全匹配表中的确定色值；**近似色没有固定 grep 模式，永远不会被 grep 捞出，也就永远不会被送进近似判定**。

除按 3.1 完全匹配表逐色 grep 外，**必须**额外执行一次「全量蓝色普查」：抽取源码中所有 hex / rgb(a) 色值，逐一交给匹配器判定，surfacing 出所有与 `#0564f5` 差 1-2 色阶但不在完全匹配表中的近似色。

> 📚 全量普查的完整 grep + node 命令、匹配器用法见 **[references/guards-and-detection.md](references/guards-and-detection.md) § 6.4**。

对普查输出的每个近似命中：先按 3.0.1 防护 1 的 6 项跳过检查逐项判定，全部通过后按近似匹配规则（[references/color-matching-details.md](references/color-matching-details.md) 第二节）替换为 `var(--brand-color)`（含透明度用 `var(--brand-color-rgb)`），并在报告「近似匹配详情」表中单独记录。若普查过程中反复出现某个高频近似色，应考虑将其反馈补充进完全匹配表。

### 3.2 操作要求（按优先级从高到低排列）

#### 要求 1：变量名保护（跳过非硬编码色值）【最高优先级】

- 类名/变量名中包含硬编码色值（`text-[#0564f5]`、`bg-[#4e80f5]`）→ **跳过**
- SASS/Less 变量名含 `blue` 关键字（`$blue-base: #096dd9`、`@blue-6: #1890ff`）→ **跳过**

#### 要求 2：注释保留原有写法【高优先级】

| 文件类型 | 注释方式 | 操作 |
|:--|:--|:--|
| `.scss` / `.less` | `//` | 注释掉原有行，在其下方新增替换行 |
| `.css` | `/* */` | 注释掉原有行，在其下方新增替换行 |
| `.tsx` / `.jsx` / `.ts` / `.js` | 不注释 | 直接替换，不保留原有写法 |

> 📚 SCSS / CSS / TSX 三类文件的替换前后示例见 **[references/examples.md](references/examples.md) § 3.1**。

#### 要求 3：跳过测试文件和已注释行【高优先级】

> 🚨 **强制铁律**：**硬编码色值替换必须严格排除掉所有被注释的代码**——凡是位于任何形式的注释内的色值，一律不得替换、不得计入遗漏、不得计入残留。

- 跳过 `*.test.*`、`*.spec.*`、`__tests__/` 目录下的所有文件
- 跳过一切被注释的代码，覆盖以下五类形态（命中任一即视为已注释）：
  1. 单行 `//` 注释
  2. 行内 `//` 注释后的色值
  3. 单行块注释 `/* ... */`
  4. 多行块注释 `/* ... */` 中间行（含以 `*` 起首的续行，由块注释状态机跟踪 `/*` 与 `*/` 开合）
  5. JSX 注释 `{/* ... */}`

> 📚 5 类注释形态的详细判定、块注释状态机、字符串字面量豁免、代码示例见 **[references/guards-and-detection.md](references/guards-and-detection.md) 第二节**。

#### 要求 4：多类场景跳过不替换【高优先级】

| 场景 | 判定方式 |
|:--|:--|
| ① 在注释中 | 色值位于注释内容中 → 跳过（见要求 3） |
| ② ECharts 属性 | 色值作为 echarts option 的属性值 → **跳过**。⚠️ **不能只看单行属性名**，必须读取完整文件上下文、向上回溯到最外层 option 对象。判定细则见下方 📚 引用 |
| ③ 颜色数组中 | 色值位于数组字面量内（如 `['#0564f5', '#4e80f5']`）→ 跳过 |
| ④ **var() 中备用（回退）的硬编码色值** | 色值位于 `var()` 括号内、作为逗号后的**备用值 / 回退值**（如 `var(--custom-color, #0564f5)`、`var(--bg, #e6f0fe)`、`rgba(var(--brand-color-rgb, 5, 100, 245), 0.2)`）→ **一律跳过、不需要替换**。因为该色值只在 CSS 变量缺失时生效，是兜底而非实际生效的主题色；替换它会造成 `var()` 语法嵌套错误。**本规则对蓝色（任务 1）与浅蓝（任务 2）色值同等适用** |
| ⑤ class 名含 blue | class 名中包含 `blue` 关键字 → 跳过；**并向上回溯所属 CSS 规则块（含多行、嵌套、`&` 拼接）的祖先选择器** |
| ⑥ SASS/Less 变量名含 blue | 变量名中包含 `blue` 关键字，其对应的硬编码色值也 → 跳过 |
| ⑦ 取色器对象 | 色值作为对象的属性值存在，且该对象**所有其他属性值也都是色值**（hex / rgb / rgba）→ 认定为取色器（调色板）对象，其中所有硬编码色值 → **跳过** |

> 📚 ECharts 三类匹配（A 强特征属性 / B 祖先 key 链 / C 独立配置模块）判定细则、取色器对象判定条件、blue 选择器回溯规则的完整规则与示例见 **[references/guards-and-detection.md](references/guards-and-detection.md) 第三/四/五节**。ECharts 判定**必须**读取完整文件上下文向上回溯，不能只看单行属性名。

#### 要求 5：rgba 色值使用 -rgb 伴侣变量替换【高优先级】

`rgba()` 格式色值必须使用对应的 `-rgb` 伴侣变量并保留原有透明度值；`rgb()` 按常规 hex 色值方式替换。

> 📚 示例见 **[references/examples.md](references/examples.md) § 3.2**。

---

> ⚠️ **分隔线说明**：以上 5 条要求为**最高优先级**，必须优先严格执行到位。以下 3 条为常规优先级。

#### 要求 6：替换后检查代码逻辑

- CSS 变量名拼写正确
- `var()` 语法正确（括号配对、逗号位置）
- 替换后颜色语义一致：主品牌色 → `--brand-color`，次品牌色 → `--brand-color-hover`
- 不会破坏原有选择器、属性键、其他属性值

#### 要求 7：记录本任务的替换明细（供最终报告汇总）

每完成一个文件的替换，先临时记录本次改动明细（文件、原写法、替换后、匹配类型）。这些明细将在**全部任务执行完成后**，由「任务 5」依据当前项目代码的实际改动（`git diff`）统一核对并汇总进最终报告。

> 📌 临时记录仅用于辅助，**最终报告以实际代码改动为准**（见 [任务 5](#七任务-5生成-neo-主题换肤功能升级报告)）。

#### 要求 8：不修改非相关内容

- 仅替换匹配上述色值列表中的值或与列表色值差 ≤ 2 色阶的近似色
- 不修改未列出且超阈值的其他颜色值
- 不修改代码结构、逻辑或其他属性

### 3.3 安全替换执行规范

#### 3.3.1 替换策略选择

| 匹配量 | 策略 | 说明 |
|:--|:--|:--|
| 少量（< 20 个匹配） | **逐行 replace_in_file** | 每次精确替换一条 CSS 属性声明，最安全 |
| 中量（20-200 个匹配） | **逐文件逐行解析** | Python 按行解析文件，属性级精准替换 |
| 大量（> 200 个匹配） | **分区域并行** | 按目录拆分，多个 agent 并行，各自独立校验 |

#### 3.3.2 逐行 replace_in_file 方式（首选）

```
① 使用 search_content 搜索所有匹配的硬编码色值
② 对每个命中行，**必须先按 3.0.1 防护 1 的固定顺序跑完全部 6 项跳过检查**，全部通过才进入替换
③ 对需要替换的行执行 replace_in_file 替换（SCSS/CSS 保留注释；TSX/TS/JS 直接替换）
④ 每替换一个文件后按要求 6 检查逻辑
⑤ 更新 Neo主题换肤功能升级报告.md
```

#### 3.3.3 批量脚本替换安全规则（匹配量 > 200 时）

三条铁律：

1. **属性名边界锚定**：禁止裸匹配 `color: #xxx`（会误伤 `border-color`、`background-color`），必须用 `(^|\{|;)\s*color:` 之类锚定。
2. **逐行拆解属性名与值**：只替换属性值中的色值，属性名保持不变。
3. **替换后必跑完整性校验**：检测属性名撕裂（`grep -rn "[a-z]\-// [a-z]"`）、孤立 var() 行、残留品牌色。

> 📚 完整 Python 代码、误伤属性对照表、校验命令与常见错误修复见 **[references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md)**。

#### 3.3.4 完整执行流程

```
① 评估匹配量级，选择合适策略（3.3.1）
② 使用 search_content 搜索所有匹配的硬编码色值
③ 对每个命中行，先执行 3.0.1 防护 1 的 6 项跳过检查（顺序固定），全部通过才允许替换
④ 按照选择的策略执行替换
⑤ 如果使用了批量脚本，必须执行完整性校验（3.3.3 规则 3）
⑥ 更新 Neo主题换肤功能升级报告.md
⑦ 执行 3.3.5 遗漏检测 → 如有遗漏则自动重复 ①~⑥，直到无遗漏
```

#### 3.3.5 遗漏检测与自动重试（必须执行）

任务 1 第一轮替换完成后，**必须**执行遗漏检测：重新使用 `search_content` 全面搜索当前项目源码，检查是否存在遗漏的硬编码色值。

**检测范围**：主品牌色 33 组 + 次品牌色 15 组的所有大小写/格式变形（6 位 hex、8 位 hex、`rgb()`、`rgba()`）。

**遗漏检测命令（三条 grep，必须全部执行）**：

```bash
# ① 6 位 hex（主品牌色 33 组 + 次品牌色 15 组，含大小写）
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#3399cc|#3399CC|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC|#4b87f1|#4B87F1|#3c50e0|#3C50E0|#115bdd|#115BDD|#3a75c6|#3A75C6|#4378be|#4378BE|#4477bc|#4477BC|#5f7ab8|#5F7AB8|#2869ff|#2869FF|#2a72d3|#2A72D3|#287eff|#287EFF|#2866f2|#2866F2|#5581f4|#5581F4|#4285f4|#4285F4|#009ffe|#009FFE|#475ffd|#475FFD|#4376bb|#4376BB|#457ff5|#457FF5" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ② 8 位 hex（含透明度）
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|3399cc|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc|4b87f1|3c50e0|115bdd|3a75c6|4378be|4477bc|5f7ab8|2869ff|2a72d3|287eff|2866f2|5581f4|4285f4|009ffe|475ffd|4376bb|457ff5)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ③ rgb/rgba 数值格式
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|26,\s*122,\s*255|37,\s*124,\s*255|6,\s*86,\s*213|0,\s*123,\s*255|36,\s*104,\s*242|28,\s*97,\s*218|24,\s*101,\s*217|37,\s*99,\s*235|29,\s*78,\s*216|4,\s*123,\s*219|23,\s*88,\s*231|0,\s*126,\s*255|51,\s*153,\s*204|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255|76,\s*161,\s*220|75,\s*135,\s*241|60,\s*80,\s*224|17,\s*91,\s*221|58,\s*117,\s*198|67,\s*120,\s*190|68,\s*119,\s*188|95,\s*122,\s*184|40,\s*105,\s*255|42,\s*114,\s*211|40,\s*126,\s*255|40,\s*102,\s*242|85,\s*129,\s*244|66,\s*133,\s*244|0,\s*159,\s*254|71,\s*95,\s*253|67,\s*118,\s*187|69,\s*127,\s*245)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("
```

> 📌 `grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)"` 排除各类注释行（含多行块注释以 `*` 起始的续行），配合防护 1 检查 3 确保已注释代码中的色值不被误判为残留。
> 📚 近似色不会被上述固定 grep 捞出，须另按 3.1.5 全量普查（[references/guards-and-detection.md](references/guards-and-detection.md) § 6.4）处理。

**遗漏判定与重试规则**：

1. 对搜索命中行逐一判断：是否属于**合法跳过场景**（参见 3.0.1 防护 1 的 6 项检查）。
2. 若命中行**不属于**任一合法跳过场景 → 判定为**遗漏**。
3. 如存在遗漏 → **立即重新执行任务 1**（从 3.1 替换规则开始，逐项替换所有遗漏项）。
4. 替换完成后 → **再次执行遗漏检测**。
5. 重复以上过程，直到**所有命中行均为合法跳过**，方可进入任务 2。
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`。

> ⚠️ **关键原则**：遗漏检测不是可选项，是任务 1 的强制组成部分。无论第一次替换看起来多么完整，都必须执行遗漏检测并在报告中记录结果。

---

## 四、任务 2：浅蓝硬编码色值替换

> 本任务与任务 1 是**同构的两条独立规则线**：任务 1 处理蓝色（主品牌色 / 次品牌色）硬编码，本任务专门处理**浅蓝背景色**硬编码。匹配总则、6 项防护检查、注释保留、安全替换策略、报告记录方式**全部复用任务 1**（§ 3.0、§ 3.0.1、§ 3.2、§ 3.3），差异只在**色值清单**与**目标变量**。

### 4.1 适用范围（只改背景属性）

**必须同时满足以下两个条件**才允许替换：

1. 属性为 **`background`** 或 **`background-color`**（含 `background` 简写，如 `background: #e6f0fe url(...) no-repeat;` → **只替换其中的色值部分**，其余值原样保留）；
2. 色值命中 § 4.2 浅蓝色值清单（完全匹配，大小写不敏感）。

> ⚠️ 其他属性（`color`、`border-color`、`border`、`box-shadow`、`outline`、`fill`、`stroke` 等）上的浅蓝色值 → **保留原样，不替换**。TSX / JS 中的内联样式同理：仅 `background` / `backgroundColor` 属性键上的浅蓝色值参与替换。

### 4.2 浅蓝色值清单（完全匹配，11 组 → `var(--brand-color-tint)`）

| Hex（大小写均匹配） | rgb | 说明 |
|:--|:--|:--|
| `#e6f0fe` / `#E6F0FE` | `rgb(230, 240, 254)` | **浅蓝基准写法** |
| `#e6f7ff` / `#E6F7FF` | `rgb(230, 247, 255)` | 含 `rgba(230, 247, 255, 0.2)` |
| `#e8f0fe` / `#E8F0FE` | `rgb(232, 240, 254)` | |
| `#e8f1ff` / `#E8F1FF` | `rgb(232, 241, 255)` | |
| `#e7f7ff` / `#E7F7FF` | `rgb(231, 247, 255)` | |
| `#eff6ff` / `#EFF6FF` | `rgb(239, 246, 255)` | Tailwind blue-50 |
| `#eef2ff` / `#EEF2FF` | `rgb(238, 242, 255)` | Tailwind indigo-50 |
| `#dcf4ff` / `#DCF4FF` | `rgb(220, 244, 255)` | |
| `#d9f3fb` / `#D9F3FB` | `rgb(217, 243, 251)` | |
| `#eceff8` / `#ECEFF8` | `rgb(236, 239, 248)` | 灰浅蓝 |
| `#edeff2` / `#EDEFF2` | `rgb(237, 239, 242) ` | 常见写法为 8 位 `#edeff280` |

#### 4.2.1 显式列举的含透明度写法

| 源写法 | 对应基色 | 替换为 |
|:--|:--|:--|
| `#edeff280` / `#EDEFF280` | `#edeff2` | `rgba(var(--brand-color-tint-rgb), 0.5)` |
| `rgba(230, 247, 255, 0.2)` / `rgba(230,247,255,0.2)` | `#e6f7ff` | `rgba(var(--brand-color-tint-rgb), 0.2)` |

### 4.3 替换规则

| 源写法形态 | 替换为 |
|:--|:--|
| 6 位 hex（不透明），如 `#e6f0fe` | `var(--brand-color-tint)` |
| `rgb(r, g, b)`（三通道命中） | `var(--brand-color-tint)` |
| 8 位 hex `#RRGGBBAA`（前 6 位命中，`AA ≠ FF`） | `rgba(var(--brand-color-tint-rgb), <alpha>)`，alpha 换算表同 § 3.1.3 |
| 8 位 hex `AA = FF` | `var(--brand-color-tint)` |
| `rgba(r, g, b, a)`（三通道命中，`a < 1`） | `rgba(var(--brand-color-tint-rgb), a)`，alpha 原样保留 |
| `rgba(r, g, b, 1)` | `var(--brand-color-tint)` |

> 🚨 **浅蓝不参与近似匹配**：§ 3.1.4 的 1-2 色阶近似匹配**唯一基准恒为 `#0564f5`**，只服务任务 1。浅蓝一律**只做完全匹配**——清单外的浅色（`#f0f8ff`、`#fafcff` 等）**一律保留原样，不替换、不推断**，避免误伤中性浅灰底色。

### 4.4 防护与忽略规则（完全复用任务 1）

每个浅蓝命中行同样必须**先跑完 § 3.0.1 的 6 项跳过检查**（顺序固定、不可跳步），全部通过才允许替换：类名/变量名含色值、测试文件、已注释行（5 类形态）、blue 类选择器回溯、ECharts / 颜色数组 / **var() 中备用（回退）色值** / 取色器对象、SASS/Less 变量名含 blue。

> ⚠️ 特别强调：`background: var(--card-bg, #e6f0fe);` 中 `#e6f0fe` 是 `var()` 的**备用值**，属检查 5 命中项 → **跳过，不需要替换**。

### 4.5 注释保留与执行方式（同 § 3.2 要求 2 / § 3.3）

- `.scss` / `.less`：用 `//` 注释原有行，在其下方新增替换行；
- `.css`：用 `/* */` 注释原有行，在其下方新增替换行；
- `.tsx` / `.jsx` / `.ts` / `.js`：直接替换，不保留原有写法。

替换策略按匹配量选择（§ 3.3.1），批量脚本须遵守属性名边界锚定等三条铁律（§ 3.3.3）。

### 4.6 改造前后示例

```scss
/* 替换前 */
.panel {
  background: #e6f0fe;
  &__tag {
    background-color: #E8F1FF;
    color: #e6f0fe;                       // 非背景属性 → 保留原样
  }
  &__mask {
    background: rgba(230, 247, 255, 0.2);
  }
  &__card {
    background: #edeff280 url('./bg.png') no-repeat center;
  }
  &__fallback {
    background: var(--card-bg, #e6f0fe);  // var() 备用值 → 跳过
  }
}
```

```scss
/* 替换后（.scss） */
.panel {
  // background: #e6f0fe;
  background: var(--brand-color-tint);
  &__tag {
    // background-color: #E8F1FF;
    background-color: var(--brand-color-tint);
    color: #e6f0fe;                       // 非背景属性 → 保留原样
  }
  &__mask {
    // background: rgba(230, 247, 255, 0.2);
    background: rgba(var(--brand-color-tint-rgb), 0.2);
  }
  &__card {
    // background: #edeff280 url('./bg.png') no-repeat center;
    background: rgba(var(--brand-color-tint-rgb), 0.5) url('./bg.png') no-repeat center;
  }
  &__fallback {
    background: var(--card-bg, #e6f0fe);  // var() 备用值 → 跳过
  }
}
```

### 4.7 遗漏检测与自动重试（必须执行）

任务 2 第一轮替换完成后，**必须**执行遗漏检测：

```bash
# ① 6 位 / 8 位 hex 浅蓝色值（含大小写），排除注释行与 var() 备用值
grep -rniE "#(e6f0fe|e6f7ff|e8f0fe|e8f1ff|e7f7ff|eff6ff|eef2ff|dcf4ff|d9f3fb|eceff8|edeff2)([0-9a-fA-F]{2})?\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ② rgb / rgba 数值格式浅蓝色值
grep -rnE "rgb[a]?\(\s*(230,\s*240,\s*254|230,\s*247,\s*255|232,\s*240,\s*254|232,\s*241,\s*255|231,\s*247,\s*255|239,\s*246,\s*255|238,\s*242,\s*255|220,\s*244,\s*255|217,\s*243,\s*251|236,\s*239,\s*248|237,\s*239,\s*242)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ③ 仅看背景属性上的残留（判定遗漏的核心依据）
grep -rniE "(background|background-color|backgroundColor)\s*:\s*[^;]*(#(e6f0fe|e6f7ff|e8f0fe|e8f1ff|e7f7ff|eff6ff|eef2ff|dcf4ff|d9f3fb|eceff8|edeff2)|rgb[a]?\(\s*(230|231|232|236|237|238|239|217|220),)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("
```

**遗漏判定与重试规则**：

1. 命中行属于 § 3.0.1 六项检查中的任一**合法跳过场景**（尤其 `var()` 备用值、已注释行）→ 非遗漏。
2. 命中行**不在** `background` / `background-color` / `backgroundColor` 属性上 → 非遗漏（按 § 4.1 不予替换）。
3. 命中行在背景属性上且非合法跳过 → **遗漏**，立即重新执行任务 2 逐项替换。
4. 替换完成后 → **再次执行遗漏检测**，循环直到无遗漏，方可进入任务 3。
5. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`。

---

## 五、任务 3：旧 CSS 变量迁移

包含两类旧→新 CSS 变量迁移，**均须执行**。

### 5.1 按钮变量新旧对照表

```
--color-button-filled-primary-bg          → --color-button-filled-primary
--color-button-filled-primary-bg-hover    → --color-button-filled-primary-hover
--color-button-filled-primary-bg-tint     → --color-button-filled-primary-tint
--color-button-filled-primary-bg-disabled → --color-button-filled-primary-disabled
--color-button-filled-secondary-bg        → --color-button-filled-primary-secondary
--color-button-filled-secondary-bg-hover  → --color-button-filled-primary-secondary-hover
--color-button-filled-secondary-bg-disabled → --color-button-filled-primary-secondary-disabled
```

### 5.2 导航色变量新旧对照表

将旧版 `--dayone-theme-header-*` 迁移为新版 `--brand-nav-header-*`：

```
--dayone-theme-header-back          → --brand-nav-header-bg
--dayone-theme-header-icon          → --brand-nav-header-icon
--dayone-theme-header-lanucher-icon → --brand-nav-header-launcher-icon
--dayone-theme-header-placeholder   → --brand-nav-header-placeholder
--dayone-theme-header-select        → --brand-nav-header-select
--dayone-theme-header-select-black  → --brand-nav-header-select-bg
--dayone-theme-header-font          → --brand-nav-header-font
--dayone-theme-header-back-opacity  → --brand-nav-header-elem-opacity
--dayone-theme-header-back-hover    → --brand-nav-header-elem-hover
```

> 📝 **说明**：
> - 旧变量名 `--dayone-theme-header-lanucher-icon` 中的 `lanucher` 为历史 typo，新变量名已修正为 `launcher`；替换时**以对照表右侧新变量名为准**。
> - `--dayone-theme-header-font` 旧写法常带固定值（如 `--dayone-theme-header-font: white;`）。**只迁移变量名本身**，取值与引用位置保持不变。
> - 无论变量出现在**定义处**（`--dayone-theme-header-back: ...`）还是**引用处**（`var(--dayone-theme-header-back)`），均按对照表迁移变量名。

### 5.3 执行方式

> 🚨 **前缀顺序铁律**：部分旧变量名互为前缀，**必须先替换更长（更具体）的变量名，再替换其前缀短名**，避免误伤：
>
> - 先替换 `--dayone-theme-header-back-opacity`、`--dayone-theme-header-back-hover`，**再**替换 `--dayone-theme-header-back`。
> - 先替换 `--dayone-theme-header-select-black`，**再**替换 `--dayone-theme-header-select`。

```
① 全文搜索所有旧变量名（定义处与 var() 引用处均需覆盖）
② 按「长名 → 短名」顺序，将每处旧变量名替换为对照表对应的新变量名
③ --dayone-theme-header-font 只替换变量名，保留其原有取值（如 white）
④ 替换后全文再次搜索旧变量名前缀，确认无残留
⑤ 添加到替换报告中
```

---

## 六、任务 4：Primary 按钮色改造

### 6.1 识别目标按钮

搜索匹配以下 class 模式的按钮：`button-primary`、`ant-btn-primary`、`btn-primary`、`a-Button--primary`、**class 名称或 class token 中含 `btn-conform`**、**class 名称或 class token 中含 `add_button`、`confirm_button`、`cancel_button`**，以及其他包含 `primary` 关键词的按钮类名。

> ⚠️ `btn-conform` 虽然不含 `primary` 关键词，但属于 Primary 按钮语义，必须与其他 primary 按钮使用相同规则识别、改造和遗漏检测；不得因缺少 `primary` 字样而跳过。

> ⚠️ **业务语义按钮识别（`add_button` / `confirm_button` / `cancel_button`）**：这三类按钮均不含 `primary` 关键词，但都属于 Primary 按钮语义，必须一并识别、改造与遗漏检测，不得因缺少 `primary` 字样而跳过。其中：
> - **`add_button`（新增）、`confirm_button`（确认）** 属于**实心 Primary 按钮**，按 6.2 规则按背景白 / 非白正常改造（白底走规则 A，非白底走规则 B）。
> - **`cancel_button`（取消）** 属于**空心（轮廓）按钮**，无论其背景为何色，一律走**空心按钮色替换规则**——即 6.2 规则 A（白色背景 primary 按钮 / 轮廓按钮）：只改 `color` 与 `border-color`（改用 `--color-button-filled-primary` 状态系列），背景保持原样，不改 `background` / `background-color`。

**要求**：必须遍历每个文件内的**所有** primary 按钮样式块（含 `btn-conform`、`add_button`、`confirm_button`、`cancel_button`），不可遗漏。

### 6.2 改造规则

按背景色分两类，每类分三种状态处理：

#### 规则 A：白色背景 primary 按钮 / 空心（轮廓）按钮（`#fff` / `#ffffff` 等，含 `cancel_button`）

> `cancel_button` 无论背景为何色，一律走本规则（空心按钮规则）：只改 `color` 与 `border-color`，背景保持原样。

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `color` + `border-color` → `var(--color-button-filled-primary)` |
| hover | `color` + `border-color` → `var(--color-button-filled-primary-hover)` |
| active | `color` + `border-color` → `var(--color-button-filled-primary-active)` |

#### 规则 B：非白色背景 primary 按钮

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `background` / `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary)`（与 background 同一变量）** |
| hover | `background` / `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary-hover)`（与 background 同一变量）** |
| active | `background` / `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary-active)`（与 background 同一变量）** |

> 💡 **为什么 `color` 必须使用按钮字体色变量（`--color-button-filled-primary-color` / `-color-hover`）？** 填充型 primary 按钮的文字直接叠在按钮背景色之上。如果 `color` 使用固定色值（如 `#fff`），一旦运行时把按钮背景色换成与该文字色相近的颜色，就会出现文字与背景色相近、看起来模糊的问题。按钮字体色变量是随按钮背景色**自动计算的对比色**，能保证任意按钮色下文字都清晰可读。
>
> 💡 **按钮边框规则（非白底填充按钮）**：`border-color` 与 `border` 简写中的色值必须**与按钮背景色使用同一套变量**（`--color-button-filled-primary` / `-hover` / `-active`），**不要与按钮字体色变量一样**。填充型 primary 按钮的边框与背景是同一块色面，边框应随按钮背景色一起变化并与背景保持视觉一致；因此边框状态分派与 `background` 完全对应（非 hover/active → `--color-button-filled-primary`，hover → `-hover`，active → `-active`）。

### 6.3 按钮边框替换细则

**规则 A：单独的 `border-color` 属性** → 按状态整体替换为按钮背景色变量（`--color-button-filled-primary` 系列）。

**规则 B：`border` 简写属性（含色值）** → **只替换其中的色值部分**，`border-width` / `border-style` 保持原样。

**规则 C：无色值 / 缺失** → `border: none` / `border: 0` / 完全无 `border` 属性时**不处理、不新增**。

**执行要点**：
1. 非白底填充 primary 按钮的边框替换与 `background` **共用同一套变量**（`--color-button-filled-primary` / `-hover` / `-active`），**不要与按钮字体色变量（`--color-button-filled-primary-color` / `-color-hover`）一样**。
2. 只有**非白色背景**的 primary 按钮走本节规则；白色背景 primary 按钮（轮廓按钮）的 `border-color` 走 6.2 规则 A，同样用 `--color-button-filled-primary` 系列。
3. 状态分派与 `background` 保持一致；同一状态选择器（`&:hover` / `&:active`）内部，`background` / `border-color` / `border` 使用同一状态对应的**背景色变量**，`color` 使用同一状态对应的**字体色变量**。
4. 与要求 2 一致：`.scss` / `.less` 用 `//` 注释原行；`.css` 用 `/* */` 注释原行；`.tsx` / `.jsx` / `.ts` / `.js` 直接替换。

### 6.4 改造前后示例

三类典型场景（A 白底轮廓按钮 / B 非白底填充按钮 / C 次按钮 / B' 含 border/border-color）的完整改造前后 SCSS 对照见 **[references/examples.md](references/examples.md) 第一节**。核心口诀：

- **白底轮廓**：`color` + `border-color` → `--color-button-filled-primary` 系列，背景保持白色。
- **非白底填充**：`background` / `border-color` / `border` 中色值 → `--color-button-filled-primary` 系列（背景与边框同一变量）；`color` → `--color-button-filled-primary-color(-hover)` 按钮字体色变量。

### 6.5 遗漏检测与自动重试（必须执行）

任务 4 第一轮改造完成后，**必须**执行遗漏检测：重新搜索项目中所有 primary 按钮样式块，检查其 `background` / `background-color` / `border-color` / `border` 属性是否仍使用了硬编码色值而非 CSS 变量。

**遗漏检测命令**：

```bash
# 搜索所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码背景色
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 20 | grep -E "background(-color)?:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"

# 重点检测 ant-btn-primary、btn-conform、add_button、confirm_button 的 background / background-color 是否为硬编码
grep -rn "ant-btn-primary\|btn-conform\|add_button\|confirm_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(background|background-color):\s*#"

# 检测所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码 border / border-color
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(^|\s)(border|border-color):\s*[^;]*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"
```

**遗漏判定与重试规则**：

1. 对搜索命中的样式块逐一判断：
   - `background` / `background-color` 使用了 CSS 变量 → **已完成改造**
   - `background` 为白色 → 按 6.2 规则 A 处理，**非遗漏项**
   - `background` / `background-color` 使用了硬编码色值且非白色 → **遗漏**
   - **非白色背景 primary 按钮的 `border-color` / `border` 中的色值仍为硬编码，或未使用与 background 相同的按钮背景色变量（`--color-button-filled-primary` 系列）** → **遗漏**
   - **空心（轮廓）按钮（含 `cancel_button`）** 按 6.2 规则 A 处理，背景保持原样、不改 `background`；只需核对其 `color` / `border-color` 是否已改用 `--color-button-filled-primary` 状态系列，未改用 → **遗漏**，`background` 仍为原值**非遗漏项**
2. 若存在遗漏 → **立即重新执行任务 4**，逐一改造所有遗漏样式块。
3. 改造完成后 → **再次执行遗漏检测**。
4. 重复以上过程，直到**所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景**，方可进入任务 5。
5. 同时核对每个非白色背景 primary 按钮的字体色 `color` 与边框：
   - 字体色 `color`：非 hover/active 应为 `--color-button-filled-primary-color`，hover/active 应为 `--color-button-filled-primary-color-hover`；
   - 边框 `border-color` / `border` 中色值：必须与 `background` 使用**同一背景色变量**——非 hover/active 应为 `--color-button-filled-primary`，hover 应为 `--color-button-filled-primary-hover`，active 应为 `--color-button-filled-primary-active`（**不应与字体色变量一样**）；
   - 若仍为固定色值、固定色值 CSS 变量，或边框错误地使用了字体色变量 → 判定为遗漏，一并补改。

> ⚠️ **特别关注 `ant-btn-primary`、`btn-conform`、`add_button`、`confirm_button`、`cancel_button`**：这几类场景容易被遗漏；其中 `btn-conform`、`add_button`、`confirm_button`、`cancel_button` 均不含 `primary` 关键词，不能依赖通用 `primary` 搜索发现。`add_button` / `confirm_button` 为实心 Primary 按钮，需逐一确认 `background` / `background-color` 已完成替换；`cancel_button` 为空心（轮廓）按钮，需确认 `color` / `border-color` 已改用 `--color-button-filled-primary` 状态系列（背景保持原样）。

---

## 七、任务 5：生成 Neo 主题换肤功能升级报告

> 🚨 **本任务是前四项任务的收尾步骤，必须在任务 1 / 2 / 3 / 4 全部执行完成后执行。**
> 报告内容**必须依据当前项目代码的实际改动生成**（以 `git diff` / `git status` 为准），而非仅凭执行过程中的记忆或中间临时记录。

### 7.1 执行前置条件

生成报告前，确认以下五项均已完成：

- [ ] 任务 1（蓝色硬编码色值替换）已完成，且 3.3.5 遗漏检测通过
- [ ] 任务 2（浅蓝硬编码色值替换）已完成，且 4.7 遗漏检测通过
- [ ] 任务 3（旧 CSS 变量迁移）已完成
- [ ] 任务 4（Primary 按钮色改造）已完成，且 6.5 遗漏检测通过
- [ ] 「替换后校验」（见第十一章）已执行且无异常

### 7.2 依据实际代码改动收集数据（必须）

**禁止**凭记忆或中间记录直接编写报告。必须先通过版本控制获取当前项目的真实改动：

```bash
git status --short         # 改动文件清单
git diff                   # 全部改动明细（唯一数据来源）
git diff --stat            # 增删行数统计
git diff --name-only       # 被修改的文件路径
```

若项目未启用 git 或改动尚未落盘，则以本次会话中实际执行的文件写入操作为准逐一核对。

### 7.3 报告生成规则

1. **数据来源以实际 diff 为准**：报告中的所有明细须与 `git diff` 一一对应；执行过程中的临时记录若与实际 diff 不符，**以实际 diff 为准**。
2. **覆盖全部四项任务的改动**：同时汇总任务 1 / 2 / 3 / 4 产生的全部实际改动。
3. **文件命名固定**：报告文件名必须为 `Neo主题换肤功能升级报告.md`，生成在项目根目录。
4. **逐文件核对**：对 `git diff --name-only` 列出的每个文件，核对其改动类型并归入报告对应章节。

### 7.4 报告结构

报告须包含总体汇总、任务 1 明细（含跳过详情、完全匹配详情、近似匹配详情）、任务 2 明细（浅蓝背景色替换）、任务 3 明细（按钮变量与导航变量分开）、任务 4 明细、改动文件清单、校验结果七大章节。

> 📚 完整报告模板（含所有表格结构、复制即可填充）见 **[references/report-template.md](references/report-template.md)**。

---

## 八、ECharts 图表处理规范

> **重要**：ECharts option 中的硬编码色值**不进行替换**。ECharts 不支持 `var(--css-variable)`。
>
> ⚠️ **如何确认「属于 ECharts」**：不能只看单行属性名，**必须读取完整文件上下文向上回溯**。判定细则见 [references/guards-and-detection.md](references/guards-and-detection.md) 第三节。

正确做法：在组件 JSX 中通过 `getCssVarHex()` 读取 CSS 变量的 hex 值后传入：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart = () => {
  const brandColor = getCssVarHex('--brand-color');
  const option = {
    color: [brandColor],
    series: [{ itemStyle: { color: brandColor } }],
  };
  return <ReactECharts option={option} />;
};
```

---

## 九、组件开发规范速查

当需要**新建**支持换肤的组件时，品牌色 / 按钮色使用示例与「要素 → CSS 变量」映射表见 **[references/examples.md](references/examples.md) 第二节**。要点：品牌相关颜色一律用 `var(--xxx)`，填充按钮字体色用 `--color-button-filled-primary-color`，链接 / 边框 / 关键文字用对应语义化 Token。

---

## 十、可用主题 CSS 变量

> Neo 平台主题 CSS 变量的完整列表、默认色值及响应使用示例见 **[references/theme-css-variables.md](references/theme-css-variables.md)**。

核心变量体系概览：

| 类别 | 变量数 | 用途 |
|:--|:--|:--|
| 品牌核心变量 | 6 对（hex + -rgb） | `--brand-color` / `--brand-color-hover` / `--brand-color-shade` / ... |
| 语义化 Token — 背景 | 6 个 | `--color-bg-brand` / `--color-bg-brand-hover` / ... |
| 语义化 Token — 边框 | 6 个 | `--color-border-brand` / `--color-border-brand-hover` / ... |
| 语义化 Token — 图标 | 7 个 | `--color-icon-brand` / `--color-icon-brand-hover` / ... |
| 语义化 Token — 文本 | 7 个 | `--color-text-brand` / `--color-text-brand-link` / ... |
| 按钮色变量 | 18 个 | `--color-button-filled-primary` / `--color-button-filled-primary-hover` / ... |
| 导航 Banner 色 | 11 个 | `--brand-nav-header-bg` / `--brand-nav-header-font` / ... |

> 每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值），用于 `rgba(var(--xxx-rgb), alpha)` 半透明场景。

---

## 十一、替换后校验（必须执行）

> **重要**：全部替换完成后，**必须运行以下校验命令**确认无异常。

### 11.1 CSS 属性名完整性校验

```bash
# 检测 CSS 属性名被撕裂的异常（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"
# 预期输出：空（无任何匹配）
```

**如果发现匹配**，说明出现了"属性名撕裂"错误，必须立即修复。修复方法见 [references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节。

### 11.2 残留硬编码色值校验

- **蓝色残留**：使用与 **§ 3.3.5 遗漏检测完全相同的三条 grep 命令**（本文件内已内联，见上文任务 1 § 3.3.5）。
- **浅蓝残留**：使用与 **§ 4.7 遗漏检测完全相同的三条 grep 命令**（见上文任务 2 § 4.7），重点核对 `background` / `background-color` 上是否仍有清单内浅蓝色值。

**合法残留项（无需处理）**：
- `$变量名: #2065CF;` — SCSS 变量定义
- `.xxx-blue { color: #1890ff; }` — class 含 blue 关键字
- `var(--xxx, #0564f5)` / `var(--card-bg, #e6f0fe)` — **var() 中备用（回退）的硬编码色值，不需要替换**
- `color: #e6f0fe` — 浅蓝色值出现在非背景属性上（任务 2 只改 `background` / `background-color`）
- `path[fill='#1890ff']` — SVG 属性选择器
- `stroke: #1890ff` — SVG stroke 属性
- `mix(#0564f5, ...)` — SCSS 函数参数

---

## 十二、常见错误与排查

批量脚本替换可能出现三类典型错误——① CSS 属性名被撕裂（`border-// color:`）、② 注释行被重复替换（双 `//` 前缀）、③ 重复的替换行。现象、根因、修复代码与预防措施详见 **[references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节**。

**核心预防**：属性名边界锚定、替换前检查行首是否已注释、遍历时用副本或从后向前处理。

---

## 十三、执行检查清单

完成全部任务后逐项检查：

**任务 1 — 蓝色硬编码色值替换**
- [ ] 3.0.1 防护 1「先判定后替换」已执行（每个匹配行按固定顺序跑完检查 1~6，全部通过才替换）
- [ ] 防护 2 已遵守（块内已有的 `// var(...)` 注释仅跳过其自身，未据此放行同块其他活跃行）
- [ ] 匹配规则总则已遵守（完全匹配优先；1-2 色阶近似匹配按近似匹配规则处理并标记；超阈值一律保留）
- [ ] 3.3.5 遗漏检测已通过（仅剩合法跳过项）
- [ ] 6 位 hex、8 位 hex、rgb、rgba 格式均已替换
- [ ] 第二批补充蓝色已全部覆盖：`#3c50e0`、`#115bdd`、`#3a75c6`、`#4378be`、`#4477bc`、`#5f7ab8`、`#2869ff`、`#2a72d3`、`#287eff`、`#2866f2` → `var(--brand-color)`；`#5581f4`、`#4285f4`、`#009ffe` → `var(--brand-color-hover)`；`rgba(40,105,255,0.2)` → `rgba(var(--brand-color-rgb), 0.2)`；`rgba(0,159,254,0.2)` → `rgba(var(--brand-color-hover-rgb), 0.2)`
- [ ] 第三批补充蓝色已全部覆盖：`#475ffd`、`#4376bb` → `var(--brand-color)`；`#457ff5` → `var(--brand-color-hover)`；`rgba(68, 119, 188, 1)` → `var(--brand-color)`（alpha=1 直接用主变量）
- [ ] **`var()` 中备用（回退）的硬编码色值一律未替换**（如 `var(--brand-color, #0564f5)`）
- [ ] 8 位 hex 已按规则处理（前 6 位命中则换算 alpha 后替换为 rgba + `-rgb` 伴侣变量）
- [ ] 近似色匹配仅以 `#0564f5` 为基准判定，报告中已单独记录
- [ ] 所有形态的注释代码中的硬编码色值一律未替换
- [ ] 类名/变量名、SASS 变量名含色值 / blue 关键字已跳过
- [ ] ECharts option、取色器对象、`var()` 回退、颜色数组中的色值未替换

**任务 2 — 浅蓝硬编码色值替换**
- [ ] 11 组浅蓝色值（`#e6f0fe`、`#e6f7ff`、`#e8f0fe`、`#e8f1ff`、`#e7f7ff`、`#eff6ff`、`#eef2ff`、`#dcf4ff`、`#d9f3fb`、`#eceff8`、`#edeff2`）在 `background` / `background-color` 上已全部替换为 `var(--brand-color-tint)`
- [ ] 含透明度写法已按规则处理：`#edeff280` → `rgba(var(--brand-color-tint-rgb), 0.5)`；`rgba(230, 247, 255, 0.2)` → `rgba(var(--brand-color-tint-rgb), 0.2)`
- [ ] 非背景属性（`color` / `border-color` / `box-shadow` …）上的浅蓝色值未被替换
- [ ] 浅蓝未做近似匹配（清单外浅色一律保留原样）
- [ ] 6 项防护检查已复用执行；`var()` 备用值、已注释行中的浅蓝色值未替换
- [ ] 4.7 遗漏检测已通过（仅剩合法跳过项）

**任务 3 — 旧 CSS 变量迁移**
- [ ] 按钮变量 `-bg` 后缀已全部更新
- [ ] 导航色变量已全部迁移（`--dayone-theme-header-*` → `--brand-nav-header-*`，含定义与引用；全文无残留）
- [ ] 前缀顺序铁律已遵守（长名先替换）

**任务 4 — Primary 按钮改造**
- [ ] 6.5 遗漏检测已通过（所有 primary 按钮的 `background-color` 均已使用 CSS 变量或为白色背景）
- [ ] 白色背景 primary 按钮的 `color` + `border-color` 已改造为 `--color-button-filled-primary` 系列
- [ ] 非白色背景 primary 按钮的 `background-color` 已改造
- [ ] 非白色背景 primary 按钮的字体色 `color` 已改用按钮字体色变量（非 hover/active → `--color-button-filled-primary-color`；hover/active → `-color-hover`）
- [ ] 非白色背景 primary 按钮的边框已改造（`border-color` 与 `border` 中色值改用与 background 相同的按钮背景色变量 `--color-button-filled-primary` 系列，**非字体色变量**；`border` 简写只替换其中色值）
- [ ] `ant-btn-primary`、`btn-conform`、`add_button`、`confirm_button` 的 `background-color` 已确认替换（均按 Primary 实心按钮语义处理）
- [ ] `cancel_button` 已按空心（轮廓）按钮规则（规则 A）改造：`color` / `border-color` 改用 `--color-button-filled-primary` 状态系列，背景保持原样

**校验与报告**
- [ ] 11.1 CSS 属性名完整性校验已通过（无匹配）
- [ ] 11.2 残留硬编码色值校验已通过（蓝色 + 浅蓝，仅剩合法跳过项）
- [ ] 任务 5 已执行：已依据当前项目代码的实际改动（`git diff`）生成 `Neo主题换肤功能升级报告.md`
- [ ] 报告内容与实际代码改动一致（改动文件数、替换次数、逐文件明细均与 `git diff` 结果核对无误）
- [ ] 无破坏代码逻辑的变更

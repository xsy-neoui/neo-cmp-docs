---
name: neo-theme-skill
description: 当用户要求项目支持 Neo 主题换肤功能时触发。将 Neo 平台历史项目中的硬编码色值、旧版 CSS 变量、按钮样式改造为支持运行时主题换肤的标准写法。覆盖三大核心任务：① 硬编码色值替换为 CSS 变量；② 旧版 CSS 变量迁移为新版变量名;③ primary 模式按钮色改造为按钮色 CSS 变量。每次执行需按顺序完成全部三项任务，最终生成 Neo主题换肤功能升级报告.md。触发关键词：项目支持Neo主题换肤功能、项目支持主题换肤、Neo主题换肤功能升级、Neo主题换肤升级、主题换肤功能升级、主题换肤升级、项目换肤升级。
---

# Neo 平台主题换肤功能升级技能

将 Neo 平台历史项目的硬编码色值、旧版 CSS 变量、按钮样式，改造为支持运行时主题换肤的标准写法。

## 触发条件

当用户提出以下需求时启动本技能：

- **"让项目支持 Neo 主题换肤功能"**
- "项目支持 Neo 主题换肤功能升级"
- "项目主题换肤升级"
- "Neo 主题换肤功能升级"

> 本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

---

## 一、Neo 平台主题换肤机制概述

Neo 平台基于 **CSS 变量 + TokenHelper 运行时引擎** 实现主题换肤，核心设计要点：

1. **Hex 主变量 + -rgb 伴侣变量双输出**：`--brand-color: #0564f5` + `--brand-color-rgb: 5, 100, 245`
2. **品牌色、按钮色、导航色三套独立体系**，通过 `TokenHelper.setBaseColor()` / `setButtonPrimaryColor()` / `setNavBannerColor()` 分别控制
3. **组件通过 `var(--xxx)` 消费 CSS 变量**，运行时主题切换自动生效

### 核心原则

- ✅ 所有品牌相关颜色必须使用 CSS 变量
- ❌ 禁止硬编码品牌色 hex/rgb 值
- ❌ 禁止从 `ColorsConfig` 读取颜色后以内联 `style={{}}` 写入

---

## 二、升级任务总览

每次执行本技能，**必须按顺序**完成以下四项任务：

| 步骤 | 任务 | 说明 |
|:--|:--|:--|
| **1** | 硬编码色值 → CSS 变量替换 | 遍历源码，将品牌相关硬编码色值替换为 `var(--xxx)`；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有硬编码色值均已替换** |
| **2** | 旧 CSS 变量 → 新 CSS 变量迁移 | 包含两类：① 将带 `-bg` 后缀的旧按钮变量名替换为新变量名；② 将旧版导航色变量（`--dayone-theme-header-*`）替换为新版导航色变量（`--brand-nav-header-*`） |
| **3** | Primary 按钮色改造 | 按背景色白/非白区分规则，替换为按钮色变量；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有 primary 按钮背景色均已改造** |
| **4** | 生成主题换肤功能升级报告 | **前三项任务全部完成后**，**依据当前项目代码的实际改动**（`git diff` / `git status`）汇总所有改动，生成 `Neo主题换肤功能升级报告.md` |

> ⚠️ **报告生成时机与依据**：任务 1~3 执行过程中可临时记录改动明细，但**最终报告必须在全部任务执行完成后**、依据**当前项目代码的实际改动**统一生成，确保报告内容与仓库真实 diff 一致。

---

## 三、任务 1：硬编码色值替换

### 3.0 匹配规则总则（Task 1 强制前置条件，最高优先级）

1. **优先完全匹配**：源代码色值与 3.1 替换规则对照表**逐字符完全匹配**（大小写不敏感）时 → 直接命中并按对应规则替换，无需报告标记。
2. **允许近似色匹配（唯一基准 `#0564f5`，1-2 色阶差）**：未列在完全匹配表内、但与主品牌基准色 `#0564f5`（rgb(5, 100, 245)）差异极小（≤ 2 色阶）时 → 推断为主品牌色近似变体，统一替换为 `var(--brand-color)`（含透明度时用 `var(--brand-color-rgb)`）。**近似匹配只与 `#0564f5` 这一个基准比较**（表中其余色值仅参与完全匹配）。近似替换**必须**在报告中标记 `[近似匹配]`，供人工复核。精确阈值见 [references/color-matching-details.md](references/color-matching-details.md) 第二节。
3. **超阈值一律不替换**：与 `#0564f5` 差异超出近似阈值（Δ_ch > 32 或 d > 50）→ 保留原样。
4. **禁止基于色名自动扩展**：不得基于色名、变量名（含 `primary`、`blue`）或代码上下文推断替换目标；替换必须由色值本身的匹配结果驱动。
5. **8 位十六进制**（`#RRGGBBAA`）：**前 6 位** 命中即视为命中，详细规则与 alpha 换算见 [references/color-matching-details.md](references/color-matching-details.md) 第一节。
6. **rgb / rgba**：三个数字与表中色值完全相等（允许逗号后空格差异）→ 完全匹配；否则仅与 `#0564f5` 按双阈值判定是否近似。
7. **近似匹配必须在报告中单独标记**：所有非完全匹配的替换都要在报告「近似匹配详情」表中单列，附源色值、匹配基准、色阶差、替换目标。

> ⚠️ 违反上述总则（例如将差异超过 2 色阶的色值当作品牌色替换）属于**错误改动**，必须在报告中回滚并标记。

### 3.0.1 强制防护流程（先于所有替换动作）

对**每一个**色值匹配行，必须**先跑完全部 6 项跳过检查**，全部通过才允许替换。**顺序固定、不可跳步**：

```
匹配行
  ↓
检查 1：类名 / 变量名含色值？（如 text-[#0564f5]）→ 跳过
检查 2：测试文件？（*.test.* / *.spec.* / __tests__/）→ 跳过
检查 3：已注释行？（单行 // / 行内 // / 单/多行块注释 /* */ / JSX {/* */}）→ 跳过
检查 4：blue 类选择器回溯？（向上回溯规则块的祖先选择器含 blue）→ 跳过
检查 5：ECharts option / 颜色数组 / var() 回退 / 取色器对象？→ 跳过
检查 6：SASS / Less 变量名含 blue（$blue-base、@blue-6）？→ 跳过
  ↓
✅ 全部通过 → 才允许进入替换决策
```

**执行铁律**：
- 顺序不可乱、不可跳步；任一步命中即判为「合法跳过」，立即终止该行处理，不再执行后续检查，也不得替换。
- 命中即在报告「跳过详情」表中记录文件、行号、色值、命中的检查项与跳过原因。
- 3.3.5 遗漏检测阶段同样必须重跑这 6 项检查。

**防护补充**：块内已存在的 `// var(...)` 注释行**只在检查 3 中跳过它自身**，不构成对同块其他活跃行的替换许可；每一行的命运由它自己的 6 项检查结果独立决定。

> 📚 6 项检查的详细判定规则、注释状态机、ECharts / 取色器 / blue 选择器的完整判定细则与示例见 **[references/guards-and-detection.md](references/guards-and-detection.md)**。

### 3.1 替换规则对照表（完整 32 组，完全匹配）

> 所有色值大小写均匹配（`#0564f5` / `#0564F5`）；`rgb()` 与 hex 等价（允许逗号后空格差异）；`rgba()` 使用对应 `-rgb` 伴侣变量并保留原始 alpha（`rgba(5, 100, 245, 0.2)` → `rgba(var(--brand-color-rgb), 0.2)`）。

#### 3.1.1 主品牌色 → `var(--brand-color)`（21 组）

| Hex（小写/大写） | rgb | 说明 |
|:--|:--|:--|
| `#0564f5` / `#0564F5` | `rgb(5, 100, 245)` | **基准色** |
| `#096dd9` / `#096DD9` | `rgb(9, 109, 217)` | Ant Design v4 主色 |
| `#2065cf` / `#2065CF` | `rgb(32, 101, 207)` | |
| `#1d77ff` / `#1D77FF` | `rgb(29, 119, 255)` | |
| `#1677ff` / `#1677FF` | `rgb(22, 119, 255)` | Ant Design v5 主色 |
| `#0052d9` / `#0052D9` | `rgb(0, 82, 217)` | TDesign 主色 |
| `#2b7fff` / `#2B7FFF` | `rgb(43, 127, 255)` | |
| `#0060df` / `#0060DF` | `rgb(0, 96, 223)` | |
| `#1a7aff` / `#1A7AFF` | `rgb(26, 122, 255)` | |
| `#257cff` / `#257CFF` | `rgb(37, 124, 255)` | 实战补充 |
| `#0656d5` / `#0656D5` | `rgb(6, 86, 213)` | 实战补充 |
| `#007bff` / `#007BFF` | `rgb(0, 123, 255)` | Bootstrap 主蓝 |
| `#2468f2` / `#2468F2` | `rgb(36, 104, 242)` | 实战补充 |
| `#1c61da` / `#1C61DA` | `rgb(28, 97, 218)` | 实战补充 |
| `#1865d9` / `#1865D9` | `rgb(24, 101, 217)` | 实战补充 |
| `#2563eb` / `#2563EB` | `rgb(37, 99, 235)` | Tailwind blue-600 |
| `#1d4ed8` / `#1D4ED8` | `rgb(29, 78, 216)` | Tailwind blue-700 |
| `#047bdb` / `#047BDB` | `rgb(4, 123, 219)` | amis cxd 主色 |
| `#1758e7` / `#1758E7` | `rgb(23, 88, 231)` | 实战补充 |
| `#007eff` / `#007EFF` | `rgb(0, 126, 255)` | 实战补充 |
| `#3399cc` / `#3399CC` | `rgb(51, 153, 204)` | 经典 Web 蓝（仅完全匹配，不参与近似） |

#### 3.1.2 次品牌色 → `var(--brand-color-hover)`（11 组）

| Hex（小写/大写） | rgb | 说明 |
|:--|:--|:--|
| `#4e80f5` / `#4E80F5` | `rgb(78, 128, 245)` | |
| `#1890ff` / `#1890FF` | `rgb(24, 144, 255)` | Ant Design v4 hover |
| `#40a9ff` / `#40A9FF` | `rgb(64, 169, 255)` | |
| `#3886fb` / `#3886FB` | `rgb(56, 134, 251)` | |
| `#238dff` / `#238DFF` | `rgb(35, 141, 255)` | |
| `#3783ff` / `#3783FF` | `rgb(55, 131, 255)` | |
| `#4096ff` / `#4096FF` | `rgb(64, 150, 255)` | Ant Design v5 hover |
| `#5b8ff9` / `#5B8FF9` | `rgb(91, 143, 249)` | |
| `#69c0ff` / `#69C0FF` | `rgb(105, 192, 255)` | Ant Design 浅蓝 |
| `#4ca1dc` / `#4CA1DC` | `rgb(76, 161, 220)` | |
| `#4b87f1` / `#4B87F1` | `rgb(75, 135, 241)` | 次品牌色变体 |

#### 3.1.3 8 位十六进制（含透明度）与 alpha 换算

- 取 8 位色值 `#RRGGBBAA` 的**前 6 位** `#RRGGBB` 与上表比对（大小写不敏感）：命中 → 替换为对应 `-rgb` 伴侣变量 + 换算后 alpha；未命中且非近似 → 保留原样。
- 替换格式：`#RRGGBBAA` → `rgba(var(--xxx-rgb), <alpha_decimal>)`，`alpha_decimal = round(parseInt(AA,16)/255, 2)`。
- 边界：`AA=FF` → 直接用主变量 `var(--xxx)`（不写 rgba）；`AA=00` → 保留 `rgba(var(--xxx-rgb), 0)`。

| AA | 值 | AA | 值 | AA | 值 | AA | 值 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| `00` | 0 | `33` | 0.2 | `80` | 0.5 | `CC` | 0.8 |
| `0D` | 0.05 | `40` | 0.25 | `99` | 0.6 | `E6` | 0.9 |
| `1A` | 0.1 | `4D` | 0.3 | `B3` | 0.7 | `F2` | 0.95 |
| `26` | 0.15 | `66` | 0.4 | | | `FF` | 1 |

示例：`#0564f533` → `rgba(var(--brand-color-rgb), 0.2)`；`#0564f5FF` → `var(--brand-color)`；`#4e80f5cc` → `rgba(var(--brand-color-hover-rgb), 0.8)`。

> 📚 更多 8 位 hex 示例、注释保留写法、别名出处见 **[references/color-matching-details.md](references/color-matching-details.md) 第一/三节**。

#### 3.1.4 近似匹配阈值（唯一基准 `#0564f5`，1-2 色阶差 → `var(--brand-color)`）

未在 3.1.1 / 3.1.2 完全匹配表中列出的色值，**只与唯一基准色 `#0564f5`（rgb(5, 100, 245)）比较**，差异 ≤ 2 色阶时推断为主品牌色近似变体并替换为 `var(--brand-color)`（含透明度用 `rgba(var(--brand-color-rgb), a)`）。

> 🚨 **单一基准原则**：近似匹配**只认 `#0564f5` 这一个基准**，**不与表中其他色值（含次品牌色、`#3399cc`）比较**——表中其余色值仅参与完全匹配。次品牌色 `var(--brand-color-hover)` 只能由完全匹配命中。

给定源色 `Cs=(Rs,Gs,Bs)`、基准 `Ct=(5,100,245)`：
- 单通道最大差异 `Δ_ch = max(|Rs-5|, |Gs-100|, |Bs-245|)`
- 欧氏距离 `d = √((Rs-5)² + (Gs-100)² + (Bs-245)²)`

| 相似度 | Δ_ch | d | 判定 | 处理 |
|:--|:--|:--|:--|:--|
| 完全匹配 | = 0 | = 0 | ✅ 命中 | 直接替换，无需报告标记 |
| 1 色阶差 | ≤ 16 | ≤ 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·1色阶]` |
| 2 色阶差 | ≤ 32 且 > 16 | ≤ 50 且 > 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·2色阶]` |
| 超阈值 | > 32 或 d > 50 | — | ❌ 不命中 | 保留原样，不替换 |

> **注**：`Δ_ch` 与 `d` 需**同时满足**对应区间才判定为该色阶差；任一超出即视为超阈值。近似匹配基准恒为 `#0564f5`、目标恒为 `var(--brand-color)`，不存在多候选、无需 Tiebreaker。
>
> 示例：`#0968f5`（Δ=4, d≈5.7）→ `var(--brand-color)` `[近似·1色阶]`；`#256bd8`（Δ=32, d≈43.7）→ `var(--brand-color)` `[近似·2色阶]`；`#3080d0`（Δ=43）→ 保留原样。
>
> 📚 完整近似匹配示例、8 位 hex 近似规则、注释与报告格式见 **[references/color-matching-details.md](references/color-matching-details.md) 第二节**。

### 3.1.5 近似色执行缺口修补 —— 全量色值普查（必须执行）

> 🚨 **为什么必须有这一步**：SKILL 的固定 grep 命令只枚举了完全匹配表中的确定色值；**近似色没有固定 grep 模式，永远不会被 grep 捞出，也就永远不会被送进近似判定**。

除按 3.1 完全匹配表逐色 grep 外，**必须**额外执行一次「全量蓝色普查」：抽取源码中所有 hex / rgb(a) 色值，逐一交给匹配器判定，surfacing 出所有与 `#0564f5` 差 1-2 色阶但不在完全匹配表中的近似色。

> 📚 全量普查的完整 grep + node 命令、匹配器用法见 **[references/guards-and-detection.md](references/guards-and-detection.md) § 6.4**。

对普查输出的每个近似命中：先按 3.0.1 防护 1 的 6 项跳过检查逐项判定，全部通过后按近似匹配规则（[references/color-matching-details.md](references/color-matching-details.md) 第二节）替换为 `var(--brand-color)`（含透明度用 `var(--brand-color-rgb)`），并在报告「近似匹配详情」表中单独记录。若普查过程中反复出现某个高频近似色，应考虑将其反馈补充进完全匹配表。

### 3.2 操作要求（按优先级从高到低排列）

#### 要求 1：变量名保护（跳过非硬编码色值）【最高优先级】

- 类名/变量名中包含硬编码色值（`text-[#0564f5]`、`bg-[#4e80f5]`）→ **跳过**
- SASS/Less 变量名含 `blue` 关键字（`$blue-base: #096dd9`、`@blue-6: #1890ff`）→ **跳过**

#### 要求 2：注释保留原有写法【高优先级】

| 文件类型 | 注释方式 | 操作 |
|:--|:--|:--|
| `.scss` / `.less` | `//` | 注释掉原有行，在其下方新增替换行 |
| `.css` | `/* */` | 注释掉原有行，在其下方新增替换行 |
| `.tsx` / `.jsx` / `.ts` / `.js` | 不注释 | 直接替换，不保留原有写法 |

> 📚 SCSS / CSS / TSX 三类文件的替换前后示例见 **[references/examples.md](references/examples.md) § 3.1**。

#### 要求 3：跳过测试文件和已注释行【高优先级】

> 🚨 **强制铁律**：**硬编码色值替换必须严格排除掉所有被注释的代码**——凡是位于任何形式的注释内的色值，一律不得替换、不得计入遗漏、不得计入残留。

- 跳过 `*.test.*`、`*.spec.*`、`__tests__/` 目录下的所有文件
- 跳过一切被注释的代码，覆盖以下五类形态（命中任一即视为已注释）：
  1. 单行 `//` 注释
  2. 行内 `//` 注释后的色值
  3. 单行块注释 `/* ... */`
  4. 多行块注释 `/* ... */` 中间行（含以 `*` 起首的续行，由块注释状态机跟踪 `/*` 与 `*/` 开合）
  5. JSX 注释 `{/* ... */}`

> 📚 5 类注释形态的详细判定、块注释状态机、字符串字面量豁免、代码示例见 **[references/guards-and-detection.md](references/guards-and-detection.md) 第二节**。

#### 要求 4：多类场景跳过不替换【高优先级】

| 场景 | 判定方式 |
|:--|:--|
| ① 在注释中 | 色值位于注释内容中 → 跳过（见要求 3） |
| ② ECharts 属性 | 色值作为 echarts option 的属性值 → **跳过**。⚠️ **不能只看单行属性名**，必须读取完整文件上下文、向上回溯到最外层 option 对象。判定细则见下方 📚 引用 |
| ③ 颜色数组中 | 色值位于数组字面量内（如 `['#0564f5', '#4e80f5']`）→ 跳过 |
| ④ var() 默认值 | 作为 `var()` 的回退值（如 `var(--custom-color, #0564f5)`）→ 跳过 |
| ⑤ class 名含 blue | class 名中包含 `blue` 关键字 → 跳过；**并向上回溯所属 CSS 规则块（含多行、嵌套、`&` 拼接）的祖先选择器** |
| ⑥ SASS/Less 变量名含 blue | 变量名中包含 `blue` 关键字，其对应的硬编码色值也 → 跳过 |
| ⑦ 取色器对象 | 色值作为对象的属性值存在，且该对象**所有其他属性值也都是色值**（hex / rgb / rgba）→ 认定为取色器（调色板）对象，其中所有硬编码色值 → **跳过** |

> 📚 ECharts 三类匹配（A 强特征属性 / B 祖先 key 链 / C 独立配置模块）判定细则、取色器对象判定条件、blue 选择器回溯规则的完整规则与示例见 **[references/guards-and-detection.md](references/guards-and-detection.md) 第三/四/五节**。ECharts 判定**必须**读取完整文件上下文向上回溯，不能只看单行属性名。

#### 要求 5：rgba 色值使用 -rgb 伴侣变量替换【高优先级】

`rgba()` 格式色值必须使用对应的 `-rgb` 伴侣变量并保留原有透明度值；`rgb()` 按常规 hex 色值方式替换。

> 📚 示例见 **[references/examples.md](references/examples.md) § 3.2**。

---

> ⚠️ **分隔线说明**：以上 5 条要求为**最高优先级**，必须优先严格执行到位。以下 3 条为常规优先级。

#### 要求 6：替换后检查代码逻辑

- CSS 变量名拼写正确
- `var()` 语法正确（括号配对、逗号位置）
- 替换后颜色语义一致：主品牌色 → `--brand-color`，次品牌色 → `--brand-color-hover`
- 不会破坏原有选择器、属性键、其他属性值

#### 要求 7：记录本任务的替换明细（供最终报告汇总）

每完成一个文件的替换，先临时记录本次改动明细（文件、原写法、替换后、匹配类型）。这些明细将在**全部任务执行完成后**，由「任务 4」依据当前项目代码的实际改动（`git diff`）统一核对并汇总进最终报告。

> 📌 临时记录仅用于辅助，**最终报告以实际代码改动为准**（见 [任务 4](#六任务-4生成-neo-主题换肤功能升级报告)）。

#### 要求 8：不修改非相关内容

- 仅替换匹配上述色值列表中的值或与列表色值差 ≤ 2 色阶的近似色
- 不修改未列出且超阈值的其他颜色值
- 不修改代码结构、逻辑或其他属性

### 3.3 安全替换执行规范

#### 3.3.1 替换策略选择

| 匹配量 | 策略 | 说明 |
|:--|:--|:--|
| 少量（< 20 个匹配） | **逐行 replace_in_file** | 每次精确替换一条 CSS 属性声明，最安全 |
| 中量（20-200 个匹配） | **逐文件逐行解析** | Python 按行解析文件，属性级精准替换 |
| 大量（> 200 个匹配） | **分区域并行** | 按目录拆分，多个 agent 并行，各自独立校验 |

#### 3.3.2 逐行 replace_in_file 方式（首选）

```
① 使用 search_content 搜索所有匹配的硬编码色值
② 对每个命中行，**必须先按 3.0.1 防护 1 的固定顺序跑完全部 6 项跳过检查**，全部通过才进入替换
③ 对需要替换的行执行 replace_in_file 替换（SCSS/CSS 保留注释；TSX/TS/JS 直接替换）
④ 每替换一个文件后按要求 6 检查逻辑
⑤ 更新 Neo主题换肤功能升级报告.md
```

#### 3.3.3 批量脚本替换安全规则（匹配量 > 200 时）

三条铁律：

1. **属性名边界锚定**：禁止裸匹配 `color: #xxx`（会误伤 `border-color`、`background-color`），必须用 `(^|\{|;)\s*color:` 之类锚定。
2. **逐行拆解属性名与值**：只替换属性值中的色值，属性名保持不变。
3. **替换后必跑完整性校验**：检测属性名撕裂（`grep -rn "[a-z]\-// [a-z]"`）、孤立 var() 行、残留品牌色。

> 📚 完整 Python 代码、误伤属性对照表、校验命令与常见错误修复见 **[references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md)**。

#### 3.3.4 完整执行流程

```
① 评估匹配量级，选择合适策略（3.3.1）
② 使用 search_content 搜索所有匹配的硬编码色值
③ 对每个命中行，先执行 3.0.1 防护 1 的 6 项跳过检查（顺序固定），全部通过才允许替换
④ 按照选择的策略执行替换
⑤ 如果使用了批量脚本，必须执行完整性校验（3.3.3 规则 3）
⑥ 更新 Neo主题换肤功能升级报告.md
⑦ 执行 3.3.5 遗漏检测 → 如有遗漏则自动重复 ①~⑥，直到无遗漏
```

#### 3.3.5 遗漏检测与自动重试（必须执行）

任务 1 第一轮替换完成后，**必须**执行遗漏检测：重新使用 `search_content` 全面搜索当前项目源码，检查是否存在遗漏的硬编码色值。

**检测范围**：主品牌色 21 组 + 次品牌色 11 组的所有大小写/格式变形（6 位 hex、8 位 hex、`rgb()`、`rgba()`）。

**遗漏检测命令（三条 grep，必须全部执行）**：

```bash
# ① 6 位 hex（主品牌色 21 组 + 次品牌色 11 组，含大小写）
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#3399cc|#3399CC|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC|#4b87f1|#4B87F1" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ② 8 位 hex（含透明度）
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|3399cc|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc|4b87f1)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ③ rgb/rgba 数值格式
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|26,\s*122,\s*255|37,\s*124,\s*255|6,\s*86,\s*213|0,\s*123,\s*255|36,\s*104,\s*242|28,\s*97,\s*218|24,\s*101,\s*217|37,\s*99,\s*235|29,\s*78,\s*216|4,\s*123,\s*219|23,\s*88,\s*231|0,\s*126,\s*255|51,\s*153,\s*204|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255|76,\s*161,\s*220|75,\s*135,\s*241)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("
```

> 📌 `grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)"` 排除各类注释行（含多行块注释以 `*` 起始的续行），配合防护 1 检查 3 确保已注释代码中的色值不被误判为残留。
> 📚 近似色不会被上述固定 grep 捞出，须另按 3.1.5 全量普查（[references/guards-and-detection.md](references/guards-and-detection.md) § 6.4）处理。

**遗漏判定与重试规则**：

1. 对搜索命中行逐一判断：是否属于**合法跳过场景**（参见 3.0.1 防护 1 的 6 项检查）。
2. 若命中行**不属于**任一合法跳过场景 → 判定为**遗漏**。
3. 如存在遗漏 → **立即重新执行任务 1**（从 3.1 替换规则开始，逐项替换所有遗漏项）。
4. 替换完成后 → **再次执行遗漏检测**。
5. 重复以上过程，直到**所有命中行均为合法跳过**，方可进入任务 2。
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`。

> ⚠️ **关键原则**：遗漏检测不是可选项，是任务 1 的强制组成部分。无论第一次替换看起来多么完整，都必须执行遗漏检测并在报告中记录结果。

---

## 四、任务 2：旧 CSS 变量迁移

包含两类旧→新 CSS 变量迁移，**均须执行**。

### 4.1 按钮变量新旧对照表

```
--color-button-filled-primary-bg          → --color-button-filled-primary
--color-button-filled-primary-bg-hover    → --color-button-filled-primary-hover
--color-button-filled-primary-bg-tint     → --color-button-filled-primary-tint
--color-button-filled-primary-bg-disabled → --color-button-filled-primary-disabled
--color-button-filled-secondary-bg        → --color-button-filled-primary-secondary
--color-button-filled-secondary-bg-hover  → --color-button-filled-primary-secondary-hover
--color-button-filled-secondary-bg-disabled → --color-button-filled-primary-secondary-disabled
```

### 4.2 导航色变量新旧对照表

将旧版 `--dayone-theme-header-*` 迁移为新版 `--brand-nav-header-*`：

```
--dayone-theme-header-back          → --brand-nav-header-bg
--dayone-theme-header-icon          → --brand-nav-header-icon
--dayone-theme-header-lanucher-icon → --brand-nav-header-launcher-icon
--dayone-theme-header-placeholder   → --brand-nav-header-placeholder
--dayone-theme-header-select        → --brand-nav-header-select
--dayone-theme-header-select-black  → --brand-nav-header-select-bg
--dayone-theme-header-font          → --brand-nav-header-font
--dayone-theme-header-back-opacity  → --brand-nav-header-elem-opacity
--dayone-theme-header-back-hover    → --brand-nav-header-elem-hover
```

> 📝 **说明**：
> - 旧变量名 `--dayone-theme-header-lanucher-icon` 中的 `lanucher` 为历史 typo，新变量名已修正为 `launcher`；替换时**以对照表右侧新变量名为准**。
> - `--dayone-theme-header-font` 旧写法常带固定值（如 `--dayone-theme-header-font: white;`）。**只迁移变量名本身**，取值与引用位置保持不变。
> - 无论变量出现在**定义处**（`--dayone-theme-header-back: ...`）还是**引用处**（`var(--dayone-theme-header-back)`），均按对照表迁移变量名。

### 4.3 执行方式

> 🚨 **前缀顺序铁律**：部分旧变量名互为前缀，**必须先替换更长（更具体）的变量名，再替换其前缀短名**，避免误伤：
>
> - 先替换 `--dayone-theme-header-back-opacity`、`--dayone-theme-header-back-hover`，**再**替换 `--dayone-theme-header-back`。
> - 先替换 `--dayone-theme-header-select-black`，**再**替换 `--dayone-theme-header-select`。

```
① 全文搜索所有旧变量名（定义处与 var() 引用处均需覆盖）
② 按「长名 → 短名」顺序，将每处旧变量名替换为对照表对应的新变量名
③ --dayone-theme-header-font 只替换变量名，保留其原有取值（如 white）
④ 替换后全文再次搜索旧变量名前缀，确认无残留
⑤ 添加到替换报告中
```

---

## 五、任务 3：Primary 按钮色改造

### 5.1 识别目标按钮

搜索匹配以下 class 模式的按钮：`button-primary`、`ant-btn-primary`、`btn-primary`、`a-Button--primary`、**class 名称或 class token 中含 `btn-conform`**、**class 名称或 class token 中含 `add_button`、`confirm_button`、`cancel_button`**，以及其他包含 `primary` 关键词的按钮类名。

> ⚠️ `btn-conform` 虽然不含 `primary` 关键词，但属于 Primary 按钮语义，必须与其他 primary 按钮使用相同规则识别、改造和遗漏检测；不得因缺少 `primary` 字样而跳过。

> ⚠️ **业务语义按钮识别（`add_button` / `confirm_button` / `cancel_button`）**：这三类按钮均不含 `primary` 关键词，但都属于 Primary 按钮语义，必须一并识别、改造与遗漏检测，不得因缺少 `primary` 字样而跳过。其中：
> - **`add_button`（新增）、`confirm_button`（确认）** 属于**实心 Primary 按钮**，按 5.2 规则按背景白 / 非白正常改造（白底走规则 A，非白底走规则 B）。
> - **`cancel_button`（取消）** 属于**空心（轮廓）按钮**，无论其背景为何色，一律走**空心按钮色替换规则**——即 5.2 规则 A（白色背景 primary 按钮 / 轮廓按钮）：只改 `color` 与 `border-color`（改用 `--color-button-filled-primary` 状态系列），背景保持原样，不改 `background` / `background-color`。

**要求**：必须遍历每个文件内的**所有** primary 按钮样式块（含 `btn-conform`、`add_button`、`confirm_button`、`cancel_button`），不可遗漏。

### 5.2 改造规则

按背景色分两类，每类分三种状态处理：

#### 规则 A：白色背景 primary 按钮 / 空心（轮廓）按钮（`#fff` / `#ffffff` 等，含 `cancel_button`）

> `cancel_button` 无论背景为何色，一律走本规则（空心按钮规则）：只改 `color` 与 `border-color`，背景保持原样。

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `color` + `border-color` → `var(--color-button-filled-primary)` |
| hover | `color` + `border-color` → `var(--color-button-filled-primary-hover)` |
| active | `color` + `border-color` → `var(--color-button-filled-primary-active)` |

#### 规则 B：非白色背景 primary 按钮

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `background` / `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary)`（与 background 同一变量）** |
| hover | `background` / `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary-hover)`（与 background 同一变量）** |
| active | `background` / `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)`；**`border-color` 或 `border` 中的色值 → `var(--color-button-filled-primary-active)`（与 background 同一变量）** |

> 💡 **为什么 `color` 必须使用按钮字体色变量（`--color-button-filled-primary-color` / `-color-hover`）？** 填充型 primary 按钮的文字直接叠在按钮背景色之上。如果 `color` 使用固定色值（如 `#fff`），一旦运行时把按钮背景色换成与该文字色相近的颜色，就会出现文字与背景色相近、看起来模糊的问题。按钮字体色变量是随按钮背景色**自动计算的对比色**，能保证任意按钮色下文字都清晰可读。
>
> 💡 **按钮边框规则（非白底填充按钮）**：`border-color` 与 `border` 简写中的色值必须**与按钮背景色使用同一套变量**（`--color-button-filled-primary` / `-hover` / `-active`），**不要与按钮字体色变量一样**。填充型 primary 按钮的边框与背景是同一块色面，边框应随按钮背景色一起变化并与背景保持视觉一致；因此边框状态分派与 `background` 完全对应（非 hover/active → `--color-button-filled-primary`，hover → `-hover`，active → `-active`）。

### 5.3 按钮边框替换细则

**规则 A：单独的 `border-color` 属性** → 按状态整体替换为按钮背景色变量（`--color-button-filled-primary` 系列）。

**规则 B：`border` 简写属性（含色值）** → **只替换其中的色值部分**，`border-width` / `border-style` 保持原样。

**规则 C：无色值 / 缺失** → `border: none` / `border: 0` / 完全无 `border` 属性时**不处理、不新增**。

**执行要点**：
1. 非白底填充 primary 按钮的边框替换与 `background` **共用同一套变量**（`--color-button-filled-primary` / `-hover` / `-active`），**不要与按钮字体色变量（`--color-button-filled-primary-color` / `-color-hover`）一样**。
2. 只有**非白色背景**的 primary 按钮走本节规则；白色背景 primary 按钮（轮廓按钮）的 `border-color` 走 5.2 规则 A，同样用 `--color-button-filled-primary` 系列。
3. 状态分派与 `background` 保持一致；同一状态选择器（`&:hover` / `&:active`）内部，`background` / `border-color` / `border` 使用同一状态对应的**背景色变量**，`color` 使用同一状态对应的**字体色变量**。
4. 与要求 2 一致：`.scss` / `.less` 用 `//` 注释原行；`.css` 用 `/* */` 注释原行；`.tsx` / `.jsx` / `.ts` / `.js` 直接替换。

### 5.4 改造前后示例

三类典型场景（A 白底轮廓按钮 / B 非白底填充按钮 / C 次按钮 / B' 含 border/border-color）的完整改造前后 SCSS 对照见 **[references/examples.md](references/examples.md) 第一节**。核心口诀：

- **白底轮廓**：`color` + `border-color` → `--color-button-filled-primary` 系列，背景保持白色。
- **非白底填充**：`background` / `border-color` / `border` 中色值 → `--color-button-filled-primary` 系列（背景与边框同一变量）；`color` → `--color-button-filled-primary-color(-hover)` 按钮字体色变量。

### 5.5 遗漏检测与自动重试（必须执行）

任务 3 第一轮改造完成后，**必须**执行遗漏检测：重新搜索项目中所有 primary 按钮样式块，检查其 `background` / `background-color` / `border-color` / `border` 属性是否仍使用了硬编码色值而非 CSS 变量。

**遗漏检测命令**：

```bash
# 搜索所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码背景色
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 20 | grep -E "background(-color)?:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"

# 重点检测 ant-btn-primary、btn-conform、add_button、confirm_button 的 background / background-color 是否为硬编码
grep -rn "ant-btn-primary\|btn-conform\|add_button\|confirm_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(background|background-color):\s*#"

# 检测所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码 border / border-color
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(^|\s)(border|border-color):\s*[^;]*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"
```

**遗漏判定与重试规则**：

1. 对搜索命中的样式块逐一判断：
   - `background` / `background-color` 使用了 CSS 变量 → **已完成改造**
   - `background` 为白色 → 按 5.2 规则 A 处理，**非遗漏项**
   - `background` / `background-color` 使用了硬编码色值且非白色 → **遗漏**
   - **非白色背景 primary 按钮的 `border-color` / `border` 中的色值仍为硬编码，或未使用与 background 相同的按钮背景色变量（`--color-button-filled-primary` 系列）** → **遗漏**
   - **空心（轮廓）按钮（含 `cancel_button`）** 按 5.2 规则 A 处理，背景保持原样、不改 `background`；只需核对其 `color` / `border-color` 是否已改用 `--color-button-filled-primary` 状态系列，未改用 → **遗漏**，`background` 仍为原值**非遗漏项**
2. 若存在遗漏 → **立即重新执行任务 3**，逐一改造所有遗漏样式块。
3. 改造完成后 → **再次执行遗漏检测**。
4. 重复以上过程，直到**所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景**，方可进入任务 4。
5. 同时核对每个非白色背景 primary 按钮的字体色 `color` 与边框：
   - 字体色 `color`：非 hover/active 应为 `--color-button-filled-primary-color`，hover/active 应为 `--color-button-filled-primary-color-hover`；
   - 边框 `border-color` / `border` 中色值：必须与 `background` 使用**同一背景色变量**——非 hover/active 应为 `--color-button-filled-primary`，hover 应为 `--color-button-filled-primary-hover`，active 应为 `--color-button-filled-primary-active`（**不应与字体色变量一样**）；
   - 若仍为固定色值、固定色值 CSS 变量，或边框错误地使用了字体色变量 → 判定为遗漏，一并补改。

> ⚠️ **特别关注 `ant-btn-primary`、`btn-conform`、`add_button`、`confirm_button`、`cancel_button`**：这几类场景容易被遗漏；其中 `btn-conform`、`add_button`、`confirm_button`、`cancel_button` 均不含 `primary` 关键词，不能依赖通用 `primary` 搜索发现。`add_button` / `confirm_button` 为实心 Primary 按钮，需逐一确认 `background` / `background-color` 已完成替换；`cancel_button` 为空心（轮廓）按钮，需确认 `color` / `border-color` 已改用 `--color-button-filled-primary` 状态系列（背景保持原样）。

---

## 六、任务 4：生成 Neo 主题换肤功能升级报告

> 🚨 **本任务是前三项任务的收尾步骤，必须在任务 1 / 2 / 3 全部执行完成后执行。**
> 报告内容**必须依据当前项目代码的实际改动生成**（以 `git diff` / `git status` 为准），而非仅凭执行过程中的记忆或中间临时记录。

### 6.1 执行前置条件

生成报告前，确认以下四项均已完成：

- [ ] 任务 1（硬编码色值替换）已完成，且 3.3.5 遗漏检测通过
- [ ] 任务 2（旧 CSS 变量迁移）已完成
- [ ] 任务 3（Primary 按钮色改造）已完成，且 5.5 遗漏检测通过
- [ ] 「替换后校验」（见第十章）已执行且无异常

### 6.2 依据实际代码改动收集数据（必须）

**禁止**凭记忆或中间记录直接编写报告。必须先通过版本控制获取当前项目的真实改动：

```bash
git status --short         # 改动文件清单
git diff                   # 全部改动明细（唯一数据来源）
git diff --stat            # 增删行数统计
git diff --name-only       # 被修改的文件路径
```

若项目未启用 git 或改动尚未落盘，则以本次会话中实际执行的文件写入操作为准逐一核对。

### 6.3 报告生成规则

1. **数据来源以实际 diff 为准**：报告中的所有明细须与 `git diff` 一一对应；执行过程中的临时记录若与实际 diff 不符，**以实际 diff 为准**。
2. **覆盖全部三项任务的改动**：同时汇总任务 1 / 2 / 3 产生的全部实际改动。
3. **文件命名固定**：报告文件名必须为 `Neo主题换肤功能升级报告.md`，生成在项目根目录。
4. **逐文件核对**：对 `git diff --name-only` 列出的每个文件，核对其改动类型并归入报告对应章节。

### 6.4 报告结构

报告须包含总体汇总、任务 1 明细（含跳过详情、完全匹配详情、近似匹配详情）、任务 2 明细（按钮变量与导航变量分开）、任务 3 明细、改动文件清单、校验结果六大章节。

> 📚 完整报告模板（含所有表格结构、复制即可填充）见 **[references/report-template.md](references/report-template.md)**。

---

## 七、ECharts 图表处理规范

> **重要**：ECharts option 中的硬编码色值**不进行替换**。ECharts 不支持 `var(--css-variable)`。
>
> ⚠️ **如何确认「属于 ECharts」**：不能只看单行属性名，**必须读取完整文件上下文向上回溯**。判定细则见 [references/guards-and-detection.md](references/guards-and-detection.md) 第三节。

正确做法：在组件 JSX 中通过 `getCssVarHex()` 读取 CSS 变量的 hex 值后传入：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart = () => {
  const brandColor = getCssVarHex('--brand-color');
  const option = {
    color: [brandColor],
    series: [{ itemStyle: { color: brandColor } }],
  };
  return <ReactECharts option={option} />;
};
```

---

## 八、组件开发规范速查

当需要**新建**支持换肤的组件时，品牌色 / 按钮色使用示例与「要素 → CSS 变量」映射表见 **[references/examples.md](references/examples.md) 第二节**。要点：品牌相关颜色一律用 `var(--xxx)`，填充按钮字体色用 `--color-button-filled-primary-color`，链接 / 边框 / 关键文字用对应语义化 Token。

---

## 九、可用主题 CSS 变量

> Neo 平台主题 CSS 变量的完整列表、默认色值及响应使用示例见 **[references/theme-css-variables.md](references/theme-css-variables.md)**。

核心变量体系概览：

| 类别 | 变量数 | 用途 |
|:--|:--|:--|
| 品牌核心变量 | 6 对（hex + -rgb） | `--brand-color` / `--brand-color-hover` / `--brand-color-shade` / ... |
| 语义化 Token — 背景 | 6 个 | `--color-bg-brand` / `--color-bg-brand-hover` / ... |
| 语义化 Token — 边框 | 6 个 | `--color-border-brand` / `--color-border-brand-hover` / ... |
| 语义化 Token — 图标 | 7 个 | `--color-icon-brand` / `--color-icon-brand-hover` / ... |
| 语义化 Token — 文本 | 7 个 | `--color-text-brand` / `--color-text-brand-link` / ... |
| 按钮色变量 | 18 个 | `--color-button-filled-primary` / `--color-button-filled-primary-hover` / ... |
| 导航 Banner 色 | 11 个 | `--brand-nav-header-bg` / `--brand-nav-header-font` / ... |

> 每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值），用于 `rgba(var(--xxx-rgb), alpha)` 半透明场景。

---

## 十、替换后校验（必须执行）

> **重要**：全部替换完成后，**必须运行以下校验命令**确认无异常。

### 10.1 CSS 属性名完整性校验

```bash
# 检测 CSS 属性名被撕裂的异常（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"
# 预期输出：空（无任何匹配）
```

**如果发现匹配**，说明出现了"属性名撕裂"错误，必须立即修复。修复方法见 [references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节。

### 10.2 残留硬编码色值校验

搜索未替换的 6 位 hex / 8 位 hex 品牌色值，使用与 **§ 3.3.5 遗漏检测完全相同的三条 grep 命令**（本文件内已内联，见上文任务 1 § 3.3.5）。

**合法残留项（无需处理）**：
- `$变量名: #2065CF;` — SCSS 变量定义
- `.xxx-blue { color: #1890ff; }` — class 含 blue 关键字
- `var(--xxx, #0564f5)` — var() 回退值
- `path[fill='#1890ff']` — SVG 属性选择器
- `stroke: #1890ff` — SVG stroke 属性
- `mix(#0564f5, ...)` — SCSS 函数参数

---

## 十一、常见错误与排查

批量脚本替换可能出现三类典型错误——① CSS 属性名被撕裂（`border-// color:`）、② 注释行被重复替换（双 `//` 前缀）、③ 重复的替换行。现象、根因、修复代码与预防措施详见 **[references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节**。

**核心预防**：属性名边界锚定、替换前检查行首是否已注释、遍历时用副本或从后向前处理。

---

## 十二、执行检查清单

完成全部任务后逐项检查：

**任务 1 — 硬编码色值替换**
- [ ] 3.0.1 防护 1「先判定后替换」已执行（每个匹配行按固定顺序跑完检查 1~6，全部通过才替换）
- [ ] 防护 2 已遵守（块内已有的 `// var(...)` 注释仅跳过其自身，未据此放行同块其他活跃行）
- [ ] 匹配规则总则已遵守（完全匹配优先；1-2 色阶近似匹配按近似匹配规则处理并标记；超阈值一律保留）
- [ ] 3.3.5 遗漏检测已通过（仅剩合法跳过项）
- [ ] 6 位 hex、8 位 hex、rgb、rgba 格式均已替换
- [ ] 8 位 hex 已按规则处理（前 6 位命中则换算 alpha 后替换为 rgba + `-rgb` 伴侣变量）
- [ ] 近似色匹配仅以 `#0564f5` 为基准判定，报告中已单独记录
- [ ] 所有形态的注释代码中的硬编码色值一律未替换
- [ ] 类名/变量名、SASS 变量名含色值 / blue 关键字已跳过
- [ ] ECharts option、取色器对象、`var()` 回退、颜色数组中的色值未替换

**任务 2 — 旧 CSS 变量迁移**
- [ ] 按钮变量 `-bg` 后缀已全部更新
- [ ] 导航色变量已全部迁移（`--dayone-theme-header-*` → `--brand-nav-header-*`，含定义与引用；全文无残留）
- [ ] 前缀顺序铁律已遵守（长名先替换）

**任务 3 — Primary 按钮改造**
- [ ] 5.5 遗漏检测已通过（所有 primary 按钮的 `background-color` 均已使用 CSS 变量或为白色背景）
- [ ] 白色背景 primary 按钮的 `color` + `border-color` 已改造为 `--color-button-filled-primary` 系列
- [ ] 非白色背景 primary 按钮的 `background-color` 已改造
- [ ] 非白色背景 primary 按钮的字体色 `color` 已改用按钮字体色变量（非 hover/active → `--color-button-filled-primary-color`；hover/active → `-color-hover`）
- [ ] 非白色背景 primary 按钮的边框已改造（`border-color` 与 `border` 中色值改用与 background 相同的按钮背景色变量 `--color-button-filled-primary` 系列，**非字体色变量**；`border` 简写只替换其中色值）
- [ ] `ant-btn-primary`、`btn-conform`、`add_button`、`confirm_button` 的 `background-color` 已确认替换（均按 Primary 实心按钮语义处理）
- [ ] `cancel_button` 已按空心（轮廓）按钮规则（规则 A）改造：`color` / `border-color` 改用 `--color-button-filled-primary` 状态系列，背景保持原样

**校验与报告**
- [ ] 10.1 CSS 属性名完整性校验已通过（无匹配）
- [ ] 10.2 残留硬编码色值校验已通过（仅剩合法跳过项）
- [ ] 任务 4 已执行：已依据当前项目代码的实际改动（`git diff`）生成 `Neo主题换肤功能升级报告.md`
- [ ] 报告内容与实际代码改动一致（改动文件数、替换次数、逐文件明细均与 `git diff` 结果核对无误）
- [ ] 无破坏代码逻辑的变更

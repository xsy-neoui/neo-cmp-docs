---
name: neo-theme-skill
description: 当用户要求项目支持 Neo 主题换肤功能时触发。将 Neo 平台历史项目中的硬编码色值、旧版 CSS 变量、按钮样式改造为支持运行时主题换肤的标准写法。覆盖三大核心任务：① 硬编码色值替换为 CSS 变量；② 旧版 CSS 变量迁移为新版变量名；③ primary 模式按钮色改造为按钮色 CSS 变量。每次执行需按顺序完成全部三项任务，最终生成 Neo主题换肤功能升级报告.md。触发关键词：项目支持Neo主题换肤功能、项目支持主题换肤、Neo主题换肤功能升级、Neo主题换肤升级、主题换肤功能升级、主题换肤升级、项目换肤升级。
---

# Neo 平台主题换肤功能升级技能

将 Neo 平台历史项目的硬编码色值、旧版 CSS 变量、按钮样式，改造为支持运行时主题换肤的标准写法。

## 触发条件

当用户提出以下需求时启动本技能：

- **"让项目支持 Neo 主题换肤功能"**
- "项目支持 Neo 主题换肤功能升级"
- "项目主题换肤升级"
- "Neo 主题换肤功能升级"

> 本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

---

## 一、Neo 平台主题换肤机制概述

Neo 平台基于 **CSS 变量 + TokenHelper 运行时引擎** 实现主题换肤，核心设计要点：

1. **Hex 主变量 + -rgb 伴侣变量双输出**：`--brand-color: #0564f5` + `--brand-color-rgb: 5, 100, 245`
2. **品牌色、按钮色、导航色三套独立体系**，通过 `TokenHelper.setBaseColor()` / `setButtonPrimaryColor()` / `setNavBannerColor()` 分别控制
3. **组件通过 `var(--xxx)` 消费 CSS 变量**，运行时主题切换自动生效

### 核心原则

- ✅ 所有品牌相关颜色必须使用 CSS 变量
- ❌ 禁止硬编码品牌色 hex/rgb 值
- ❌ 禁止从 `ColorsConfig` 读取颜色后以内联 `style={{}}` 写入

---

## 二、可用主题 CSS 变量

> Neo 平台主题 CSS 变量的完整列表、默认色值及各类场景的响应使用示例，详见 **[references/theme-css-variables.md](references/theme-css-variables.md)**。

核心变量体系概览：

| 类别 | 变量数 | 用途 |
|:--|:--|:--|
| 品牌核心变量 | 6 对（hex + -rgb） | `--brand-color` / `--brand-color-hover` / `--brand-color-shade` / ... |
| 语义化 Token — 背景 | 6 个 | `--color-bg-brand` / `--color-bg-brand-hover` / ... |
| 语义化 Token — 边框 | 6 个 | `--color-border-brand` / `--color-border-brand-hover` / ... |
| 语义化 Token — 图标 | 7 个 | `--color-icon-brand` / `--color-icon-brand-hover` / ... |
| 语义化 Token — 文本 | 7 个 | `--color-text-brand` / `--color-text-brand-link` / ... |
| 按钮色变量 | 18 个 | `--color-button-filled-primary` / `--color-button-filled-primary-hover` / ... |
| 导航 Banner 色 | 11 个 | `--brand-nav-header-bg` / `--brand-nav-header-font` / ... |

> 每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值，如 `5, 100, 245`），用于 `rgba(var(--xxx-rgb), alpha)` 半透明场景。

---

## 三、升级任务总览

每次执行本技能，**必须按顺序**完成以下三项任务：

### 任务清单

| 步骤 | 任务 | 说明 |
|:--|:--|:--|
| **1** | 硬编码色值 → CSS 变量替换 | 遍历源码，将品牌相关硬编码色值替换为 `var(--xxx)` |
| **2** | 旧 CSS 变量 → 新 CSS 变量迁移 | 将带 `-bg` 后缀的旧变量名替换为新变量名 |
| **3** | Primary 按钮色改造 | 按背景色白/非白区分规则，替换为按钮色变量 |
| **4** | 生成替换报告 | 汇总所有改动到 `Neo主题换肤功能升级报告.md` |

---

## 四、任务 1：硬编码色值替换

### 4.1 替换规则对照表

#### 主品牌色 → `var(--brand-color)`

```
#0564f5  → var(--brand-color)
#0564F5  → var(--brand-color)
rgb(5, 100, 245)  → var(--brand-color)
rgb(5,100,245)    → var(--brand-color)

#096dd9  → var(--brand-color)
#096DD9  → var(--brand-color)
rgb(9, 109, 217)  → var(--brand-color)
rgb(9,109,217)    → var(--brand-color)

#2065cf  → var(--brand-color)
#2065CF  → var(--brand-color)
rgb(32, 101, 207) → var(--brand-color)
rgb(32,101,207)   → var(--brand-color)

#1d77ff  → var(--brand-color)
#1D77FF  → var(--brand-color)
rgb(29, 119, 255) → var(--brand-color)
rgb(29,119,255)   → var(--brand-color)
```

#### 次品牌色 → `var(--brand-color-hover)`

```
#4e80f5  → var(--brand-color-hover)
#4E80F5  → var(--brand-color-hover)
rgb(78, 128, 245) → var(--brand-color-hover)
rgb(78,128,245)   → var(--brand-color-hover)

#1890ff  → var(--brand-color-hover)
#1890FF  → var(--brand-color-hover)
rgb(24, 144, 255) → var(--brand-color-hover)
rgb(24,144,255)   → var(--brand-color-hover)

#40a9ff  → var(--brand-color-hover)
#40A9FF  → var(--brand-color-hover)
rgb(64, 169, 255) → var(--brand-color-hover)
rgb(64,169,255)   → var(--brand-color-hover)

#3886fb  → var(--brand-color-hover)
#3886FB  → var(--brand-color-hover)
rgb(56, 134, 251) → var(--brand-color-hover)
rgb(56,134,251)   → var(--brand-color-hover)

#238dff  → var(--brand-color-hover)
#238DFF  → var(--brand-color-hover)
rgb(35, 141, 255) → var(--brand-color-hover)
rgb(35,141,255)   → var(--brand-color-hover)

#3783ff  → var(--brand-color-hover)
#3783FF  → var(--brand-color-hover)
rgb(55, 131, 255) → var(--brand-color-hover)
rgb(55,131,255)   → var(--brand-color-hover)
```

### 4.2 操作要求（共 7 条，必须全部满足）

#### 要求 1：变量名保护（跳过非硬编码色值）

不要在以下情境替换：
- 类名/变量名中包含硬编码色值，如 `text-[#0564f5]`、`bg-[#4e80f5]` → **跳过**

#### 要求 2：注释保留原有写法

| 文件类型 | 注释方式 | 操作 |
|:--|:--|:--|
| `.scss` / `.less` | `//` | 注释掉原有行，在其下方新增替换行 |
| `.css` | `/* */` | 注释掉原有行，在其下方新增替换行 |
| `.tsx` / `.jsx` / `.ts` / `.js` | 不注释 | 直接替换，不保留原有写法 |

**示例（.scss）**：

```scss
// 替换前
.button {
  background-color: #0564f5;
}

// 替换后
.button {
  // background-color: #0564f5;  // [*] 已替换为 var(--brand-color)
  background-color: var(--brand-color);
}
```

**示例（.css）**：

```css
/* 替换前 */
.button {
  background-color: #0564f5;
}

/* 替换后 */
.button {
  /* background-color: #0564f5; */ /* [*] 已替换为 var(--brand-color) */
  background-color: var(--brand-color);
}
```

#### 要求 3：跳过测试文件和已注释行

- 跳过 `*.test.*`、`*.spec.*`、`__tests__/` 目录下的所有文件
- 跳过已注释行（以 `//` 或 `/*` 开头、或被 `/* */` 包裹的行）

#### 要求 4：五类场景跳过不替换

| 场景 | 判定方式 |
|:--|:--|
| ① 在注释中 | 色值位于注释内容中，非有效代码 → 跳过 |
| ② ECharts 属性 | 色值作为 echart option 的属性值 → **跳过**（ECharts 需使用 `getCssVarHex()` 方案） |
| ③ 颜色数组中 | 色值位于数组字面量内，如 `['#0564f5', '#4e80f5']` → 跳过 |
| ④ var() 默认值 | 作为 `var()` 的回退值，如 `var(--custom-color, #0564f5)` → 跳过 |
| ⑤ class 含 blue | class 名中包含 `blue` 关键字 → 跳过 |

#### 要求 5：替换后检查代码逻辑

每次替换后确认：
- CSS 变量名拼写正确
- `var()` 语法正确（括号配对、逗号位置）
- 替换后颜色语义一致：主品牌色 → `--brand-color`，次品牌色 → `--brand-color-hover`
- 不会破坏原有选择器、属性键、其他属性值

#### 要求 6：生成Neo主题换肤功能升级报告.md

每完成一个文件的替换，记录到报告中。报告格式：

```markdown
# 硬编码色值 CSS 变量替换报告

## 汇总信息

| 指标 | 数值 |
|:--|:--|
| 扫描文件总数 | XXX |
| 修改文件总数 | XXX |
| 替换次数（主品牌色） | XXX |
| 替换次数（次品牌色） | XXX |
| 跳过次数 | XXX |
| 操作日期 | YYYY-MM-DD |

## 跳过详情

| 文件 | 行号 | 色值 | 跳过原因 |
|:--|:--|:--|:--|
| src/components/Foo.scss | 12 | #0564f5 | 变量名保护：类名 text-[#0564f5] |
| src/charts/Chart.tsx | 45 | #0564f5 | ECharts option 属性 |
| ... | ... | ... | ... |

## 替换详情

| 文件 | 原写法 | 替换后 | 状态 |
|:--|:--|:--|:--|
| src/components/Header.scss | `color: #0564f5` | `color: var(--brand-color)` | ✅ |
| src/components/Button.scss | `background: #4e80f5` | `background: var(--brand-color-hover)` | ✅ |
| ... | ... | ... | ... |
```

#### 要求 7：不修改非相关内容

- 仅替换匹配上述色值列表中的值（大小写均匹配）
- 不修改未列出的其他颜色值
- 不修改代码结构、逻辑或其他属性

### 4.3 执行流程

```
① 使用 search_content 搜索所有匹配的硬编码色值
② 对每个命中行，逐一检查是否属于跳过场景（要求 1 / 3 / 4）
③ 对于需要替换的行，按文件类型选择注释策略（要求 2）
④ 执行 replace_in_file 替换
⑤ 更新 Neo主题换肤功能升级报告.md
⑥ 每替换一个文件后检查逻辑（要求 5）
```

---

## 五、任务 2：旧 CSS 变量迁移

### 5.1 新旧变量对照表

```
--color-button-filled-primary-bg          → --color-button-filled-primary
--color-button-filled-primary-bg-hover    → --color-button-filled-primary-hover
--color-button-filled-primary-bg-tint     → --color-button-filled-primary-tint
--color-button-filled-primary-bg-disabled → --color-button-filled-primary-disabled
--color-button-filled-secondary-bg        → --color-button-filled-primary-secondary
--color-button-filled-secondary-bg-hover  → --color-button-filled-primary-secondary-hover
--color-button-filled-secondary-bg-disabled → --color-button-filled-primary-secondary-disable
```

### 5.2 执行方式

对项目源码执行全文搜索旧变量名，逐一替换：

```
① 搜索 --color-button-filled-primary-bg
② 搜索 --color-button-filled-secondary-bg
③ 确认命中文的件和行号
④ 将每处旧变量名替换为对应的新变量名
⑤ 同样添加到替换报告中
```

---

## 六、任务 3：Primary 按钮色改造

### 6.1 识别目标按钮

搜索匹配以下 class 模式的按钮：
- `button-primary`
- `ant-btn-primary`
- `btn-primary`
- `a-Button--primary`
- 其他包含 `primary` 关键词的按钮类名

**要求**：必须遍历每个文件内的**所有** primary 按钮样式块，不可遗漏。

### 6.2 使用规则 1：白色背景 primary 按钮

**条件**：背景色为 `#FFFFFF` / `#FFF` / `#ffffff` / `#fff`

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `color` 和 `border-color` → `var(--color-button-filled-primary)` |
| hover 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-hover)` |
| active 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-active)` |

### 6.3 使用规则 2：非白色背景 primary 按钮

**条件**：背景色**不是**白色

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `background` 或 `background-color` → `var(--color-button-filled-primary)` |
| hover 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-hover)` |
| active 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-active)` |

### 6.4 使用规则 3：通用规则（适用于所有 primary 按钮）

| 背景色 | 状态 | 操作 |
|:--|:--|:--|
| 白色 | 非 hover/active | `color` + `border-color` → `var(--color-button-filled-primary)` |
| 白色 | hover | `color` + `border-color` → `var(--color-button-filled-primary-hover)` |
| 白色 | active | `color` + `border-color` → `var(--color-button-filled-primary-active)` |
| 非白色 | 非 hover/active | `background-color` → `var(--color-button-filled-primary)` |
| 非白色 | hover | `background-color` → `var(--color-button-filled-primary-hover)` |
| 非白色 | active | `background` / `background-color` → `var(--color-button-filled-primary-active)` |

### 6.5 改造前后示例对照

#### 场景 A：白色背景轮廓 primary 按钮

```scss
/* ===== 改造前 ===== */
.button-primary {
  background: #fff;
  color: #0564f5;
  border: 1px solid #0564f5;

  &:hover {
    color: #4e80f5;
    border-color: #4e80f5;
  }

  &:active {
    color: #096dd9;
    border-color: #096dd9;
  }
}

/* ===== 改造后 ===== */
.button-primary {
  background: #fff;
  color: var(--color-button-filled-primary);
  border: 1px solid var(--color-button-filled-primary);

  &:hover {
    color: var(--color-button-filled-primary-hover);
    border-color: var(--color-button-filled-primary-hover);
    background-color: rgba(var(--color-button-filled-primary-rgb), 0.06);
  }

  &:active {
    color: var(--color-button-filled-primary-active);
    border-color: var(--color-button-filled-primary-active);
  }
}
```

#### 场景 B：非白色背景填充 primary 按钮

```scss
/* ===== 改造前 ===== */
.ant-btn-primary {
  background: #0564f5;
  color: #fff;
  border: none;

  &:hover { background: #4e80f5; }
  &:active { background: #096dd9; }
  &:disabled { background: #80bfff; }
}

/* ===== 改造后 ===== */
.ant-btn-primary {
  background: var(--color-button-filled-primary);
  color: var(--color-button-filled-primary-color);
  border: none;

  &:hover {
    background: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-color-hover);
  }
  &:active {
    background: var(--color-button-filled-primary-active);
  }
  &:disabled {
    background: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

#### 场景 C：次按钮

```scss
/* ===== 改造前 ===== */
.btn-secondary {
  background: #a8d7ff;
  color: #fff;

  &:hover { background: #80bfff; }
  &:disabled { background: #e6f4ff; }
}

/* ===== 改造后 ===== */
.btn-secondary {
  background: var(--color-button-filled-primary-secondary);
  color: var(--color-button-filled-primary-color);

  &:hover { background: var(--color-button-filled-primary-secondary-hover); }
  &:disabled {
    background: var(--color-button-filled-primary-secondary-disable);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

---

## 七、ECharts 图表处理规范

> **重要**：ECharts option 中的硬编码色值**不进行替换**。ECharts 不支持 `var(--css-variable)`。

正确的做法是在组件 JSX 中通过 `getCssVarHex()` 读取 CSS 变量的 hex 值后传入：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart = () => {
  const brandColor = getCssVarHex('--brand-color');

  const option = {
    color: [brandColor],
    series: [{ itemStyle: { color: brandColor } }],
  };

  return <ReactECharts option={option} />;
};
```

---

## 八、组件开发规范速查

> 当需要**新建**支持换肤的组件时，参考以下规范。

### 8.1 品牌色使用

```scss
.my-tab.active {
  border-left: 3px solid var(--brand-color);
  color: var(--color-text-brand);
  background: var(--color-bg-brand-tint);
}
```

### 8.2 按钮色使用

```scss
.btn-primary {
  background-color: var(--color-button-filled-primary, #0564f5);
  color: var(--color-button-filled-primary-color);

  &:hover { background-color: var(--color-button-filled-primary-hover); }
  &:active { background-color: var(--color-button-filled-primary-active); }
  &:disabled {
    background-color: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

### 8.3 要素映射表

| 元素 | CSS 变量 |
|:--|:--|
| 填充按钮背景 | `--color-button-filled-primary` |
| 轮廓按钮边框/文字 | `--color-button-filled-primary`（复用） |
| 文本按钮颜色 | `--color-button-filled-primary`（复用） |
| 链接文字 | `--color-text-brand-link`（正常）→ `--color-text-brand-hover`（悬停） |
| 输入框聚焦边框 | `--color-border-brand` |
| 关键数据文字 | `--color-text-brand` |
| 浅色背景卡片 | `--color-bg-brand-tint` |
| 半透明覆盖层 | `rgba(var(--brand-color-rgb), 0.15)` |

---

## 九、执行检查清单

完成全部任务后逐项检查：

- [ ] 所有匹配的硬编码色值已替换
- [ ] 类名/变量名中的色值已正确跳过
- [ ] SCSS 中用 `//` 保留原有写法，CSS 中用 `/* */` 保留
- [ ] 测试文件已全部跳过
- [ ] ECharts option 中的色值未替换
- [ ] `var()` 默认值中的色值未替换
- [ ] class 含 `blue` 关键字未替换
- [ ] 旧变量 `-bg` 后缀已全部更新
- [ ] 白色背景 primary 按钮的 `color` + `border-color` 已改造
- [ ] 非白色背景 primary 按钮的 `background-color` 已改造
- [ ] 所有 primary 按钮样式块已遍历
- [ ] `Neo主题换肤功能升级报告.md` 已生成
- [ ] 无破坏代码逻辑的变更

---
name: neo-theme-skill
description: 当用户要求项目支持 Neo 主题换肤功能时触发。将 Neo 平台历史项目中的硬编码色值、旧版 CSS 变量、按钮样式改造为支持运行时主题换肤的标准写法。覆盖三大核心任务：① 硬编码色值替换为 CSS 变量；② 旧版 CSS 变量迁移为新版变量名；③ primary 模式按钮色改造为按钮色 CSS 变量。每次执行需按顺序完成全部三项任务，最终生成 Neo主题换肤功能升级报告.md。触发关键词：项目支持Neo主题换肤功能、项目支持主题换肤、Neo主题换肤功能升级、Neo主题换肤升级、主题换肤功能升级、主题换肤升级、项目换肤升级。
---

# Neo 平台主题换肤功能升级技能

将 Neo 平台历史项目的硬编码色值、旧版 CSS 变量、按钮样式，改造为支持运行时主题换肤的标准写法。

## 触发条件

当用户提出以下需求时启动本技能：

- **"让项目支持 Neo 主题换肤功能"**
- "项目支持 Neo 主题换肤功能升级"
- "项目主题换肤升级"
- "Neo 主题换肤功能升级"

> 本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

---

## 一、Neo 平台主题换肤机制概述

Neo 平台基于 **CSS 变量 + TokenHelper 运行时引擎** 实现主题换肤，核心设计要点：

1. **Hex 主变量 + -rgb 伴侣变量双输出**：`--brand-color: #0564f5` + `--brand-color-rgb: 5, 100, 245`
2. **品牌色、按钮色、导航色三套独立体系**，通过 `TokenHelper.setBaseColor()` / `setButtonPrimaryColor()` / `setNavBannerColor()` 分别控制
3. **组件通过 `var(--xxx)` 消费 CSS 变量**，运行时主题切换自动生效

### 核心原则

- ✅ 所有品牌相关颜色必须使用 CSS 变量
- ❌ 禁止硬编码品牌色 hex/rgb 值
- ❌ 禁止从 `ColorsConfig` 读取颜色后以内联 `style={{}}` 写入

---

## 二、升级任务总览

每次执行本技能，**必须按顺序**完成以下三项任务：

### 任务清单

| 步骤 | 任务 | 说明 |
|:--|:--|:--|
| **1** | 硬编码色值 → CSS 变量替换 | 遍历源码，将品牌相关硬编码色值替换为 `var(--xxx)`；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有硬编码色值均已替换** |
| **2** | 旧 CSS 变量 → 新 CSS 变量迁移 | 将带 `-bg` 后缀的旧变量名替换为新变量名 |
| **3** | Primary 按钮色改造 | 按背景色白/非白区分规则，替换为按钮色变量；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有 primary 按钮背景色均已改造** |
| **4** | 生成替换报告 | 汇总所有改动到 `Neo主题换肤功能升级报告.md` |

---

## 三、任务 1：硬编码色值替换

> 🚨 **匹配规则总则（Task 1 强制前置条件，最高优先级，先于所有要求）**：
>
> 1. **优先完全匹配**：源代码中的硬编码色值与 3.1 替换规则对照表列出的色值**逐字符完全匹配**（大小写不敏感）时 → 直接命中并按对应规则替换，无需报告标记。
> 2. **允许近似色匹配（1-2 色阶差）**：源代码中的色值虽未在表中列出，但与表中某个 hex 主色值**差异极小（≤ 2 色阶）**时 → 可推断为该品牌色的近似变体并按对应 CSS 变量替换。此时**必须**在报告中标记 `[近似匹配]`，供人工复核。近似色的精确定义、阈值、歧义处理详见 **3.1.2 近似色匹配规则**。
> 3. **超阈值一律不替换**：源色值与表中任一色值的差异均超出近似阈值（单通道 > 32 或欧氏距离 > 50）→ **不视为近似色**，必须保留原样。
> 4. **禁止基于色名自动扩展**：**不得**基于色名、变量名（含 `primary`、`blue`）或代码上下文自行推断替换目标；替换必须由色值本身的匹配结果（完全匹配 或 1-2 色阶近似匹配）驱动。
> 5. **8 位十六进制的特殊匹配规则**：8 位色值 `#RRGGBBAA` 的**前 6 位** `#RRGGBB` 若按上述规则 1 或 2 命中即视为命中，具体规则见下方 **3.1.1 8 位十六进制色值（含透明度）匹配规则**。
> 6. **rgb / rgba 数值格式**：`rgb(r, g, b)` / `rgba(r, g, b, a)` 的三个数字若与表中数值完全相等（允许逗号后空格差异）→ 完全匹配；若三个数字均在 ±16 范围内 → 视为近似色（1 色阶差），按 3.1.2 规则处理。
> 7. **近似匹配必须在报告中单独标记**：所有非完全匹配（即近似匹配）替换都要在 `Neo主题换肤功能升级报告.md` 中单列，附源色值、匹配基准、色阶差、替换目标，供人工复核。
>
> ⚠️ 违反上述总则（例如将差异超过 2 色阶的色值当作品牌色替换）属于**错误改动**，必须在报告中回滚并标记。

### 3.1 替换规则对照表

#### 主品牌色 → `var(--brand-color)`

```
#0564f5  → var(--brand-color)
#0564F5  → var(--brand-color)
rgb(5, 100, 245)  → var(--brand-color)
rgb(5,100,245)    → var(--brand-color)

#096dd9  → var(--brand-color)
#096DD9  → var(--brand-color)
rgb(9, 109, 217)  → var(--brand-color)
rgb(9,109,217)    → var(--brand-color)

#2065cf  → var(--brand-color)
#2065CF  → var(--brand-color)
rgb(32, 101, 207) → var(--brand-color)
rgb(32,101,207)   → var(--brand-color)

#1d77ff  → var(--brand-color)
#1D77FF  → var(--brand-color)
rgb(29, 119, 255) → var(--brand-color)
rgb(29,119,255)   → var(--brand-color)

// Ant Design v5 主色
#1677ff  → var(--brand-color) 
#1677FF  → var(--brand-color)
rgb(22, 119, 255) → var(--brand-color)
rgb(22,119,255)   → var(--brand-color)

#0052d9  → var(--brand-color)
#0052D9  → var(--brand-color)
rgb(0, 82, 217) → var(--brand-color)
rgb(0,82,217)   → var(--brand-color)

#2b7fff  → var(--brand-color)
#2B7FFF  → var(--brand-color)
rgb(43, 127, 255) → var(--brand-color)
rgb(43,127,255)   → var(--brand-color)

#0060df  → var(--brand-color)
#0060DF  → var(--brand-color)
rgb(0, 96, 223) → var(--brand-color)
rgb(0,96,223)   → var(--brand-color)

#1a7aff  → var(--brand-color) 
#1A7AFF  → var(--brand-color)
rgb(26, 122, 255) → var(--brand-color)
rgb(26,122,255)   → var(--brand-color)

```

#### 次品牌色 → `var(--brand-color-hover)`

```
#4e80f5  → var(--brand-color-hover)
#4E80F5  → var(--brand-color-hover)
rgb(78, 128, 245) → var(--brand-color-hover)
rgb(78,128,245)   → var(--brand-color-hover)

#1890ff  → var(--brand-color-hover)
#1890FF  → var(--brand-color-hover)
rgb(24, 144, 255) → var(--brand-color-hover)
rgb(24,144,255)   → var(--brand-color-hover)

#40a9ff  → var(--brand-color-hover)
#40A9FF  → var(--brand-color-hover)
rgb(64, 169, 255) → var(--brand-color-hover)
rgb(64,169,255)   → var(--brand-color-hover)

#3886fb  → var(--brand-color-hover)
#3886FB  → var(--brand-color-hover)
rgb(56, 134, 251) → var(--brand-color-hover)
rgb(56,134,251)   → var(--brand-color-hover)

#238dff  → var(--brand-color-hover)
#238DFF  → var(--brand-color-hover)
rgb(35, 141, 255) → var(--brand-color-hover)
rgb(35,141,255)   → var(--brand-color-hover)

#3783ff  → var(--brand-color-hover)
#3783FF  → var(--brand-color-hover)
rgb(55, 131, 255) → var(--brand-color-hover)
rgb(55,131,255)   → var(--brand-color-hover)

// Ant Design v5 hover、Ant Design 浅蓝
#4096ff  → var(--brand-color-hover) 
#4096FF  → var(--brand-color-hover)
rgb(64, 150, 255) → var(--brand-color-hover)
rgb(64,150,255)   → var(--brand-color-hover)

#5b8ff9  → var(--brand-color-hover)
#5B8FF9  → var(--brand-color-hover)
rgb(91, 143, 249) → var(--brand-color-hover)
rgb(91,143,249)   → var(--brand-color-hover)

#69c0ff  → var(--brand-color-hover) 
#69C0FF  → var(--brand-color-hover)
rgb(105, 192, 255) → var(--brand-color-hover)
rgb(105,192,255)   → var(--brand-color-hover)
```

### 3.1.1 补充说明：8 位十六进制色值（含透明度）匹配规则

对于源代码中出现的 **8 位十六进制色值**（格式 `#RRGGBBAA`），按以下规则处理：

**匹配规则**：
1. 取该 8 位色值的**前 6 位** `#RRGGBB`（大小写不敏感），与本 3.1 表中所有列出的 hex 主色值进行**完全匹配比对**
2. 如**前 6 位命中**表中任一色值 → 该 8 位色值应替换为对应的 **-rgb 伴侣变量** + 换算后的 alpha 值
3. 如前 6 位**未命中**任何表中色值 → **保留原样，不替换**

**替换格式**：

```
#RRGGBBAA → rgba(var(--xxx-rgb), <alpha_decimal>)
```

- `--xxx-rgb`：前 6 位 `#RRGGBB` 命中的目标主变量的 **-rgb 伴侣变量**
- `<alpha_decimal>`：后 2 位 hex 换算为 0-1 范围的十进制数，保留 2 位小数

**alpha 换算公式**：`alpha_decimal = round(hex_alpha_decimal / 255, 2)`，其中 `hex_alpha_decimal` = 后 2 位十六进制转十进制。

**常用 alpha 十六进制 → 十进制对照表**：

| Hex (AA) | Decimal | 语义 | Hex (AA) | Decimal | 语义 |
|:--|:--|:--|:--|:--|:--|
| `00` | `0` | 完全透明 | `80` | `0.5` | 50% 半透明 |
| `0D` | `0.05` | 5% | `99` | `0.6` | 60% |
| `1A` | `0.1` | 10% | `B3` | `0.7` | 70% |
| `26` | `0.15` | 15% | `CC` | `0.8` | 80% |
| `33` | `0.2` | 20% | `E6` | `0.9` | 90% |
| `40` | `0.25` | 25% | `F2` | `0.95` | 95% |
| `4D` | `0.3` | 30% | `FF` | `1` | 完全不透明 |
| `66` | `0.4` | 40% |  |  |  |

**替换示例**：

```
/* 主品牌色 8 位变体 */
#0564f533 → rgba(var(--brand-color-rgb), 0.2)       (前 6 位命中 #0564f5，AA=33 → 0.2)
#0564F580 → rgba(var(--brand-color-rgb), 0.5)       (前 6 位命中 #0564f5，AA=80 → 0.5)
#0564f5FF → var(--brand-color)                       (AA=FF → 1，完全不透明，直接用主变量)
#0564f500 → rgba(var(--brand-color-rgb), 0)          (AA=00 → 0，完全透明)

#096dd91a → rgba(var(--brand-color-rgb), 0.1)
#2065cf4d → rgba(var(--brand-color-rgb), 0.3)

/* 次品牌色 8 位变体 */
#4e80f533 → rgba(var(--brand-color-hover-rgb), 0.2)
#1890ffcc → rgba(var(--brand-color-hover-rgb), 0.8)
#1a7aff66 → rgba(var(--brand-color-hover-rgb), 0.4)  (补充色也适用同规则)

/* 未命中示例：前 6 位不在表中，保留原样 */
#123456ff → 保留原样（#123456 不在 3.1 表中）
#ff000080 → 保留原样（#ff0000 不在 3.1 表中）
```

**特殊边界规则**：

- `AA = FF`（完全不透明）→ 优先直接替换为主变量 `var(--xxx)`（不使用 rgba 形式），保持代码简洁
- `AA = 00`（完全透明）→ 仍按 `rgba(var(--xxx-rgb), 0)` 替换，保留透明层的语义
- 若 AA 值不在上方对照表中 → 按公式实时换算，四舍五入保留 2 位小数（如 `#0564f570` → `0x70 / 255 = 0.44` → `rgba(var(--brand-color-rgb), 0.44)`）

**注释保留写法**（与要求 2 一致）：

```scss
// 替换前
.overlay {
  background: #0564f533;
}

// 替换后（.scss）
.overlay {
  // background: #0564f533;
  background: rgba(var(--brand-color-rgb), 0.2);
}
```

### 3.1.2 近似色匹配规则（1-2 色阶差自动推断替换）

对于源代码中未在 3.1 表中完全列出的色值，若与表中某个 hex 主色值**差异极小（≤ 2 色阶）**，可推断为该品牌色的近似变体并按对应 CSS 变量替换。本规则支持基于"颜色相近"、"视觉相似"、"色相接近"、"RGB 距离小"等相似性判断进行自动匹配。

#### 3.1.2.1 色阶差定义与判定阈值

给定源色值 `Cs = (Rs, Gs, Bs)` 和表中候选基准色值 `Ct = (Rt, Gt, Bt)`：

- **单通道最大差异**：`Δ_ch = max(|Rs - Rt|, |Gs - Gt|, |Bs - Bt|)`
- **欧氏距离**：`d = √((Rs-Rt)² + (Gs-Gt)² + (Bs-Bt)²)`

**判定阈值**：

| 相似度 | 单通道差异 Δ_ch | 欧氏距离 d | 判定 | 处理方式 |
|:--|:--|:--|:--|:--|
| 完全匹配 | = 0 | = 0 | ✅ 命中 | 直接替换，无需报告标记 |
| 1 色阶差 | ≤ 16 | ≤ 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·1色阶]` |
| 2 色阶差 | ≤ 32 且 > 16 | ≤ 50 且 > 25 | ✅ 近似命中 | 替换 + 报告标记 `[近似匹配·2色阶]` |
| 超阈值 | > 32 或 d > 50 | — | ❌ 不命中 | 保留原样，不替换 |

> **注**：Δ_ch 与 d 需**同时满足**对应区间才判定为该色阶差；任一超出阈值均视为超阈值。

#### 3.1.2.2 多候选歧义处理（Tiebreaker）

若源色值同时落在多个表中色值的 ≤ 2 色阶邻域内，按以下顺序决策：

1. **完全匹配优先**：若某个候选为完全匹配（d = 0），忽略其他所有近似候选，直接采用完全匹配
2. **距离最小优先**：候选中欧氏距离 `d` 最小者胜出
3. **色阶差更小优先**：若 d 相等，1 色阶差候选优先于 2 色阶差候选
4. **主色优先于次色**：若 d、色阶差均相等，主品牌色（`--brand-color`）优先于次品牌色（`--brand-color-hover`）
5. **表中列表顺序优先**：若上述条件仍无法决策，取 3.1 表中排在前面的候选

#### 3.1.2.3 匹配示例

**主品牌色附近示例**（基准 `#0564f5` = rgb(5, 100, 245)）：

```
#0665f5 → Δ_ch=1,  d≈1.4   → 1 色阶差 → var(--brand-color)       [近似匹配·1色阶]
#0968f5 → Δ_ch=4,  d≈5.7   → 1 色阶差 → var(--brand-color)       [近似匹配·1色阶]
#0e6cf3 → Δ_ch=9,  d≈10.5  → 1 色阶差 → var(--brand-color)       [近似匹配·1色阶]
#1670f0 → Δ_ch=17, d≈21.7  → 2 色阶差 → var(--brand-color)       [近似匹配·2色阶]
#256bd8 → Δ_ch=32, d≈40.8  → 2 色阶差 → var(--brand-color)       [近似匹配·2色阶]
#3080d0 → Δ_ch=43, d≈50.8  → 超阈值   → 保留原样，不替换
```

**次品牌色附近示例**（基准 `#4e80f5` = rgb(78, 128, 245)）：

```
#5085f6 → Δ_ch=5,  d≈7.1   → 1 色阶差 → var(--brand-color-hover) [近似匹配·1色阶]
#5787f7 → Δ_ch=9,  d≈12.4  → 1 色阶差 → var(--brand-color-hover) [近似匹配·1色阶]
#638ef2 → Δ_ch=21, d≈27.1  → 2 色阶差 → var(--brand-color-hover) [近似匹配·2色阶]
```

**歧义候选示例**（源色值同时靠近主色与次色）：

```
源色值 #196ffa（rgb(25, 111, 250)），需在 #0564f5 与 #1d77ff 之间选择：
- vs #0564f5 (rgb(5, 100, 245)):  Δ_ch=20, d≈23.7 → 2 色阶差候选
- vs #1d77ff (rgb(29, 119, 255)): Δ_ch=8,  d≈10.8 → 1 色阶差候选

按 Tiebreaker：1 色阶差候选优先 → 命中 #1d77ff
最终替换：var(--brand-color) [近似匹配·1色阶]
```

**超阈值示例**（不替换）：

```
#3080d0 → 与 #0564f5 差 Δ_ch=43，超出 32 阈值 → 保留原样
#7fb3ff → 与 #4e80f5 差 Δ_ch=51，超出 32 阈值 → 保留原样
#0080ff → 与 #0564f5 差 d≈52，超出 50 阈值 → 保留原样
```

#### 3.1.2.4 8 位十六进制色值的近似匹配

8 位色值 `#RRGGBBAA` 的近似匹配规则：

- 取前 6 位 `#RRGGBB` 与表中色值按上述 3.1.2.1 阈值判定
- 若前 6 位为完全匹配或 1-2 色阶近似 → 命中，后 2 位按 3.1.1 换算 alpha
- 最终替换为 `rgba(var(--xxx-rgb), <alpha>)`，报告中同时标记 `[近似匹配·N色阶]`

**示例**：

```
#0968f533 → 前 6 位 #0968f5 与 #0564f5 差 1 色阶 → rgba(var(--brand-color-rgb), 0.2) [近似匹配·1色阶]
#5085f680 → 前 6 位 #5085f6 与 #4e80f5 差 1 色阶 → rgba(var(--brand-color-hover-rgb), 0.5) [近似匹配·1色阶]
```

#### 3.1.2.5 近似匹配的注释保留写法

近似匹配的替换需在注释中**显式标注**匹配基准与色阶差，便于 code review 复核：

```scss
/* 替换前 */
.card {
  color: #0968f5;
}

/* 替换后（.scss） */
.card {
  // color: #0968f5;  // [近似匹配·1色阶] 基准 #0564f5, Δ_ch=4, d≈5.7 → var(--brand-color)
  color: var(--brand-color);
}
```

```css
/* 替换后（.css） */
.card {
  /* color: #0968f5; */  /* [近似匹配·1色阶] 基准 #0564f5, Δ_ch=4, d≈5.7 → var(--brand-color) */
  color: var(--brand-color);
}
```

#### 3.1.2.6 报告中的近似匹配单独记录

近似匹配替换必须在 `Neo主题换肤功能升级报告.md` 中**单独列出**，格式如下：

```markdown
## 近似匹配详情（需人工复核）

| 文件 | 行号 | 源色值 | 匹配基准 | 色阶差 | Δ_ch | d | 替换为 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| src/Foo.scss | 12 | `#0968f5` | `#0564f5` | 1 色阶 | 4 | 5.7 | `var(--brand-color)` |
| src/Bar.tsx | 34 | `#638ef2` | `#4e80f5` | 2 色阶 | 21 | 27.1 | `var(--brand-color-hover)` |
| src/Baz.less | 56 | `#0968f533` | `#0564f5` | 1 色阶 | 4 | 5.7 | `rgba(var(--brand-color-rgb), 0.2)` |
```

> ⚠️ **人工复核建议**：近似匹配是自动推断结果，建议在合并 PR 前人工检查每一条替换是否符合设计意图。若发现误判，可在源文件中回滚该处替换，并在报告中标记 `[已回滚]`。

### 3.2 操作要求（共 8 条，按优先级从高到低排列，越靠前越优先执行）

> ⚠️ **优先级说明**：以下 8 条要求按优先级从高到低排列，序号越靠前优先级越高。
> **前 5 条（要求 1 ~ 要求 5）为最高优先级，必须严格优先执行到位**；后续要求（要求 6 ~ 要求 8）在前 5 条完全满足的前提下再执行。

#### 要求 1：变量名保护（跳过非硬编码色值）【最高优先级】

不要在以下情境替换：
- 类名/变量名中包含硬编码色值，如 `text-[#0564f5]`、`bg-[#4e80f5]` → **跳过**
- SASS/Less 变量名含 `blue` 关键字，如 `$blue-base: #096dd9`、`@blue-6: #1890ff` → **跳过**

#### 要求 2：注释保留原有写法【高优先级】

| 文件类型 | 注释方式 | 操作 |
|:--|:--|:--|
| `.scss` / `.less` | `//` | 注释掉原有行，在其下方新增替换行 |
| `.css` | `/* */` | 注释掉原有行，在其下方新增替换行 |
| `.tsx` / `.jsx` / `.ts` / `.js` | 不注释 | 直接替换，不保留原有写法 |

**示例（.scss）**：

```scss
// 替换前
.button {
  background-color: #0564f5;
}

// 替换后
.button {
  // background-color: #0564f5;
  background-color: var(--brand-color);
}
```

**示例（.css）**：

```css
/* 替换前 */
.button {
  background-color: #0564f5;
}

/* 替换后 */
.button {
  /* background-color: #0564f5; */
  background-color: var(--brand-color);
}
```

#### 要求 3：跳过测试文件和已注释行【高优先级】

- 跳过 `*.test.*`、`*.spec.*`、`__tests__/` 目录下的所有文件
- 跳过已注释行（以 `//` 或 `/*` 开头、或被 `/* */` 包裹的行）

#### 要求 4：五类场景跳过不替换【高优先级】

| 场景 | 判定方式 |
|:--|:--|
| ① 在注释中 | 色值位于注释内容中，非有效代码 → 跳过 |
| ② ECharts 属性 | 色值作为 echart option 的属性值 → **跳过**（ECharts 需使用 `getCssVarHex()` 方案） |
| ③ 颜色数组中 | 色值位于数组字面量内，如 `['#0564f5', '#4e80f5']` → 跳过 |
| ④ var() 默认值 | 作为 `var()` 的回退值，如 `var(--custom-color, #0564f5)` → 跳过 |
| ⑤ class / 变量名含 blue | class 名中包含 `blue` 关键字 → 跳过 |
| ⑥ SASS/Less 变量名含 blue | 变量名中包含 `blue` 关键字（如 `$blue-base`、`@blue-6`），其对应的硬编码色值也 → 跳过 |

#### 要求 5：rgba 色值使用 -rgb 伴侣变量替换【高优先级】

当需要替换的色值为 `rgba()` 格式时，必须使用对应的 **-rgb 伴侣变量**并保留原有的透明度值：

```
rgba(5, 100, 245, 0.2)  → rgba(var(--brand-color-rgb), 0.2)
rgba(78, 128, 245, 0.15) → rgba(var(--brand-color-hover-rgb), 0.15)
```

> 核心原则：**保留原始透明度**，仅替换颜色分量部分，alpha 值原样保留。
>
> **注意**：仅处理 `rgba()` 格式，`rgb()` 格式的色值按常规 hex 色值方式替换为 `var(--brand-color)` 等 hex 主变量。

---

> ⚠️ **分隔线说明**：以上 5 条要求为**最高优先级**，必须优先严格执行到位。
> 以下 3 条要求（要求 6 ~ 要求 8）为常规优先级，在前 5 条完全满足后再处理。

---

#### 要求 6：替换后检查代码逻辑

每次替换后确认：
- CSS 变量名拼写正确
- `var()` 语法正确（括号配对、逗号位置）
- 替换后颜色语义一致：主品牌色 → `--brand-color`，次品牌色 → `--brand-color-hover`
- 不会破坏原有选择器、属性键、其他属性值

#### 要求 7：生成Neo主题换肤功能升级报告.md

每完成一个文件的替换，记录到报告中。报告格式：

```markdown
# 硬编码色值 CSS 变量替换报告

## 汇总信息

| 指标 | 数值 |
|:--|:--|
| 扫描文件总数 | XXX |
| 修改文件总数 | XXX |
| 替换次数（主品牌色·完全匹配） | XXX |
| 替换次数（次品牌色·完全匹配） | XXX |
| 替换次数（近似匹配·1 色阶） | XXX |
| 替换次数（近似匹配·2 色阶） | XXX |
| 跳过次数 | XXX |
| 操作日期 | YYYY-MM-DD |

## 跳过详情

| 文件 | 行号 | 色值 | 跳过原因 |
|:--|:--|:--|:--|
| src/components/Foo.scss | 12 | #0564f5 | 变量名保护：类名 text-[#0564f5] |
| src/charts/Chart.tsx | 45 | #0564f5 | ECharts option 属性 |
| src/components/Foo.scss | 78 | #3080d0 | 超阈值：与最近基准差 Δ_ch=43，不视为品牌色 |
| ... | ... | ... | ... |

## 完全匹配替换详情

| 文件 | 原写法 | 替换后 | 状态 |
|:--|:--|:--|:--|
| src/components/Header.scss | `color: #0564f5` | `color: var(--brand-color)` | ✅ |
| src/components/Button.scss | `background: #4e80f5` | `background: var(--brand-color-hover)` | ✅ |
| ... | ... | ... | ... |

## 近似匹配详情（需人工复核）

> 以下为按 3.1.2 近似色匹配规则自动推断的替换，色阶差 ≤ 2，建议人工检查是否符合设计意图。

| 文件 | 行号 | 源色值 | 匹配基准 | 色阶差 | Δ_ch | d | 替换为 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| src/Foo.scss | 12 | `#0968f5` | `#0564f5` | 1 色阶 | 4 | 5.7 | `var(--brand-color)` |
| src/Bar.tsx | 34 | `#638ef2` | `#4e80f5` | 2 色阶 | 21 | 27.1 | `var(--brand-color-hover)` |
| src/Baz.less | 56 | `#0968f533` | `#0564f5` | 1 色阶 | 4 | 5.7 | `rgba(var(--brand-color-rgb), 0.2)` |
| ... | ... | ... | ... | ... | ... | ... | ... |
```

#### 要求 8：不修改非相关内容

- 仅替换匹配上述色值列表中的值（大小写均匹配）或与列表色值差 ≤ 2 色阶的近似色（按 3.1.2 规则处理）
- 不修改未列出且超阈值的其他颜色值
- 不修改代码结构、逻辑或其他属性

### 3.3 安全替换执行规范

#### 3.3.1 替换策略选择

根据匹配量选择合适策略，避免在大规模场景下使用高风险方式：

| 匹配量 | 策略 | 说明 |
|:--|:--|:--|
| 少量（< 20 个匹配） | **逐行 replace_in_file** | 每次精确替换一条 CSS 属性声明，最安全 |
| 中量（20-200 个匹配） | **逐文件逐行解析** | Python 按行解析文件，属性级精准替换 |
| 大量（> 200 个匹配） | **分区域并行** | 按目录拆分，多个 agent 并行，各自独立校验 |

#### 3.3.2 逐行 replace_in_file 方式（首选）

适用于匹配量可控的场景。每次替换一条属性声明，`old_str` 包含完整的一行内容：

```
① 使用 search_content 搜索所有匹配的硬编码色值
② 对每个命中行，逐一检查是否属于跳过场景（要求 1 / 3 / 4）
③ 对需要替换的行：
   - SCSS/CSS：old_str 为"属性名: 色值"所在行原文，new_str 为注释行 + 替换行
   - TSX/TS/JS：old_str 为包含色值的原文片段，new_str 为替换后片段
④ 执行 replace_in_file 替换
⑤ 每替换一个文件后检查逻辑（要求 6）
⑥ 更新 Neo主题换肤功能升级报告.md
```

#### 3.3.3 批量脚本替换安全规则（匹配量巨大时）

当匹配量超过 200 个必须使用脚本批量处理时，**必须**遵守以下规则：

**规则 1：CSS 属性名必须用起始边界锚定，禁止裸匹配属性名**

```python
# ❌ 绝对禁止：color 作为子串出现在 border-color、background-color 中
re.sub(r'color: #0564f5', ...)

# ✅ 正确：用行首或声明分隔符锚定
re.sub(r'(^|\{|;)\s*color:\s*#0564f5', ...)
```

常见的会被子串匹配误伤的 CSS 属性名：
| 搜索的属性 | 会被误匹配的复合属性 |
|:--|:--|
| `color:` | `border-color:`、`background-color:`、`text-decoration-color:`、`caret-color:` |
| `shadow:` | `box-shadow:`、`text-shadow:` |

**规则 2：逐行解析属性名与属性值，独立替换值中的色值部分**

```python
# ✅ 安全方式：拆解属性名与值，只替换值中的色值
for i, line in enumerate(lines):
    if ':' in line:
        prop, value = line.split(':', 1)
        # 检查 prop 是否为完整的目标属性名（按空白/缩进分割取最后一个 token）
        prop_name = prop.strip().split()[-1] if prop.strip() else ''
        if prop_name == 'color' and '#0564f5' in value:
            # 替换 value 中的色值，保持 prop 不变
            new_value = value.replace('#0564f5', 'var(--brand-color)')
            lines[i] = f'{prop}:{new_value}'
```

**规则 3：替换后必须执行完整性校验**

批量替换全部完成后，**必须**运行以下校验命令，禁止跳过：

```bash
# 校验 1：检测 CSS 属性名被撕裂（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"

# 校验 2：检测孤立的 var() 引用（前面没有注释标记的独立 var 行）
# 如果某行只有缩进 + var(...) + 分号，但上一行不是 // 注释，说明替换未完整
# 用例：搜索 "var(--brand-color);" 行，检查上下文

# 校验 3：搜索残留的硬编码品牌色值（确认无遗漏）
# 包含全部主品牌色（4 组 × 大小写）+ 次品牌色（6 组 × 大小写）
grep -rn "#0564f5\|#0564F5\|#096dd9\|#096DD9\|#2065cf\|#2065CF\|#1d77ff\|#1D77FF\|\
#4e80f5\|#4E80F5\|#1890ff\|#1890FF\|#40a9ff\|#40A9FF\|#3886fb\|#3886FB\|#238dff\|#238DFF\|#3783ff\|#3783FF" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

**如校验 1 发现匹配项，说明出现了属性名撕裂错误，必须立即修复（见第十章的修复方法）。**

#### 3.3.4 完整执行流程

```
① 评估匹配量级，选择合适策略（3.3.1）
② 使用 search_content 搜索所有匹配的硬编码色值
③ 对每个命中行，逐一检查是否属于跳过场景（要求 1 / 3 / 4）
④ 按照选择的策略执行替换
⑤ 如果使用了批量脚本，必须执行完整性校验（3.3.3 规则 3）
⑥ 更新 Neo主题换肤功能升级报告.md
⑦ 执行 3.3.5 遗漏检测 → 如有遗漏则自动重复 ①~⑥，直到无遗漏
```

#### 3.3.5 遗漏检测与自动重试（必须执行）

任务 1 第一轮替换完成后，**必须**执行遗漏检测：重新使用 `search_content` 全面搜索当前项目源码，检查是否存在遗漏的硬编码色值。

**检测范围**（以下色值的所有大小写/格式变形，含 6 位 hex、8 位 hex、`rgb()` 与 `rgba()`）：

主品牌色（→ `var(--brand-color)` 或 `-rgb` 伴侣）：

| 应替换的色值（前 6 位） | 8 位变体示例 | 目标 CSS 变量 |
|:--|:--|:--|
| `#0564f5` / `#0564F5` / `rgb(5, 100, 245)` / `rgba(5, 100, 245, ...)` | `#0564f5<AA>`（任意 AA） | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#096dd9` / `#096DD9` / `rgb(9, 109, 217)` / `rgba(9, 109, 217, ...)` | `#096dd9<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2065cf` / `#2065CF` / `rgb(32, 101, 207)` / `rgba(32, 101, 207, ...)` | `#2065cf<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1d77ff` / `#1D77FF` / `rgb(29, 119, 255)` / `rgba(29, 119, 255, ...)` | `#1d77ff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1677ff` / `#1677FF` / `rgb(22, 119, 255)` / `rgba(22, 119, 255, ...)` | `#1677ff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#0052d9` / `#0052D9` / `rgb(0, 82, 217)` / `rgba(0, 82, 217, ...)` | `#0052d9<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2b7fff` / `#2B7FFF` / `rgb(43, 127, 255)` / `rgba(43, 127, 255, ...)` | `#2b7fff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#0060df` / `#0060DF` / `rgb(0, 96, 223)` / `rgba(0, 96, 223, ...)` | `#0060df<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |

次品牌色（→ `var(--brand-color-hover)` 或 `-rgb` 伴侣）：

| 应替换的色值（前 6 位） | 8 位变体示例 | 目标 CSS 变量 |
|:--|:--|:--|
| `#4e80f5` / `#4E80F5` / `rgb(78, 128, 245)` / `rgba(78, 128, 245, ...)` | `#4e80f5<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#1890ff` / `#1890FF` / `rgb(24, 144, 255)` / `rgba(24, 144, 255, ...)` | `#1890ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#40a9ff` / `#40A9FF` / `rgb(64, 169, 255)` / `rgba(64, 169, 255, ...)` | `#40a9ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#3886fb` / `#3886FB` / `rgb(56, 134, 251)` / `rgba(56, 134, 251, ...)` | `#3886fb<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#238dff` / `#238DFF` / `rgb(35, 141, 255)` / `rgba(35, 141, 255, ...)` | `#238dff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#3783ff` / `#3783FF` / `rgb(55, 131, 255)` / `rgba(55, 131, 255, ...)` | `#3783ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#1a7aff` / `#1A7AFF` / `rgb(26, 122, 255)` / `rgba(26, 122, 255, ...)` | `#1a7aff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#4096ff` / `#4096FF` / `rgb(64, 150, 255)` / `rgba(64, 150, 255, ...)` | `#4096ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#5b8ff9` / `#5B8FF9` / `rgb(91, 143, 249)` / `rgba(91, 143, 249, ...)` | `#5b8ff9<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#69c0ff` / `#69C0FF` / `rgb(105, 192, 255)` / `rgba(105, 192, 255, ...)` | `#69c0ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |

**搜索命令**：

```bash
# 搜索所有待替换的 6 位 hex 色值（排除已注释行、var() 回退值、测试文件、node_modules）
# 主品牌色 8 组 + 次品牌色 10 组，均含大小写
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#1a7aff|#1A7AFF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索所有 8 位 hex 色值（含透明度），前 6 位命中表中任一色值
# 匹配格式：#RRGGBBAA，AA 为任意 2 位十六进制
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|1a7aff|4096ff|5b8ff9|69c0ff)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索所有待替换的 rgb/rgba 色值（同时匹配 rgb() 和 rgba() 格式）
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|26,\s*122,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

**遗漏判定与重试规则**：

1. 对搜索命中行逐一判断：是否属于**合法跳过场景**（参见 3.2 要求 1 / 3 / 4）：
   - 类名/变量名中的色值 → **合法跳过**
   - 测试文件 → **合法跳过**
   - 已注释行 → **合法跳过**
   - ECharts option 属性 → **合法跳过**
   - 颜色数组 → **合法跳过**
   - `var()` 默认值 → **合法跳过**
   - class / 变量名含 `blue` 关键字 → **合法跳过**
   - SASS/Less 变量定义 → **合法跳过**
2. 若命中行**不属于**以上任一合法跳过场景 → 判定为**遗漏**
3. 如存在遗漏 → **立即重新执行任务 1（从 3.1 替换规则开始，按 3.2 要求逐项替换所有遗漏项）**
4. 替换完成后 → **再次执行遗漏检测（本步骤）**
5. 重复以上过程，直到**所有命中行均为合法跳过**，方可进入任务 2
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`

> ⚠️ **关键原则**：遗漏检测不是可选项，是任务 1 的强制组成部分。无论第一次替换看起来多么完整，都必须执行遗漏检测并在报告中记录结果。

---

## 四、任务 2：旧 CSS 变量迁移

### 4.1 新旧变量对照表

```
--color-button-filled-primary-bg          → --color-button-filled-primary
--color-button-filled-primary-bg-hover    → --color-button-filled-primary-hover
--color-button-filled-primary-bg-tint     → --color-button-filled-primary-tint
--color-button-filled-primary-bg-disabled → --color-button-filled-primary-disabled
--color-button-filled-secondary-bg        → --color-button-filled-primary-secondary
--color-button-filled-secondary-bg-hover  → --color-button-filled-primary-secondary-hover
--color-button-filled-secondary-bg-disabled → --color-button-filled-primary-secondary-disable
```

### 4.2 执行方式

对项目源码执行全文搜索旧变量名，逐一替换：

```
① 搜索 --color-button-filled-primary-bg
② 搜索 --color-button-filled-secondary-bg
③ 确认命中文的件和行号
④ 将每处旧变量名替换为对应的新变量名
⑤ 同样添加到替换报告中
```

---

## 五、任务 3：Primary 按钮色改造

### 5.1 识别目标按钮

搜索匹配以下 class 模式的按钮：
- `button-primary`
- `ant-btn-primary`
- `btn-primary`
- `a-Button--primary`
- 其他包含 `primary` 关键词的按钮类名

**要求**：必须遍历每个文件内的**所有** primary 按钮样式块，不可遗漏。

### 5.2 使用规则 1：白色背景 primary 按钮

**条件**：背景色为 `#FFFFFF` / `#FFF` / `#ffffff` / `#fff`

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `color` 和 `border-color` → `var(--color-button-filled-primary)` |
| hover 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-hover)` |
| active 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-active)` |

### 5.3 使用规则 2：非白色背景 primary 按钮

**条件**：背景色**不是**白色

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `background` 或 `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)` |
| hover 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)` |
| active 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)` |

> 💡 **为什么 `color` 必须使用按钮字体色变量（`--color-button-filled-primary-color` / `--color-button-filled-primary-color-hover`）？**
>
> 填充型 primary 按钮的文字直接叠在按钮背景色之上。如果 `color` 使用固定色值（如 `#fff`）或固定色值的 CSS 变量，一旦运行时把按钮背景色换成与该文字色相近的颜色（例如浅色系按钮色配白色文字），就会出现**文字与背景色相近、看起来模糊**的问题。
>
> `--color-button-filled-primary-color` / `--color-button-filled-primary-color-hover` 是随按钮背景色**自动计算的对比色**（自动在深/浅之间选择），能保证任意按钮色下文字都清晰可读。因此**非白色背景 primary 按钮的 `color` 一律改用按钮字体色变量，禁止保留固定色值或使用固定色值的 CSS 变量**。

### 5.4 使用规则 3：通用规则（适用于所有 primary 按钮）

| 背景色 | 状态 | 操作 |
|:--|:--|:--|
| 白色 | 非 hover/active | `color` + `border-color` → `var(--color-button-filled-primary)` |
| 白色 | hover | `color` + `border-color` → `var(--color-button-filled-primary-hover)` |
| 白色 | active | `color` + `border-color` → `var(--color-button-filled-primary-active)` |
| 非白色 | 非 hover/active | `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)` |
| 非白色 | hover | `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)` |
| 非白色 | active | `background` / `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)` |

> 💡 **按钮字体色规则（非白色背景 primary 按钮）**：`color` 必须使用按钮字体色变量而非固定色值/固定色值 CSS 变量——
> - 非 hover / active 态：`color` → `var(--color-button-filled-primary-color)`
> - hover / active 态：`color` → `var(--color-button-filled-primary-color-hover)`
>
> 目的是避免文字色与运行时切换后的按钮背景色相近，导致文字看起来模糊；按钮字体色变量为自动对比色，可保证任意按钮色下文字清晰可读。
>
> 白色背景轮廓 primary 按钮的 `color` 显示的是品牌色本身（文字即品牌色），仍使用 `--color-button-filled-primary` 系列，**不改用**按钮字体色变量。

### 5.5 改造前后示例对照

#### 场景 A：白色背景轮廓 primary 按钮

```scss
/* ===== 改造前 ===== */
.button-primary {
  background: #fff;
  color: #0564f5;
  border: 1px solid #0564f5;

  &:hover {
    color: #4e80f5;
    border-color: #4e80f5;
  }

  &:active {
    color: #096dd9;
    border-color: #096dd9;
  }
}

/* ===== 改造后 ===== */
.button-primary {
  background: #fff;
  color: var(--color-button-filled-primary);
  border: 1px solid var(--color-button-filled-primary);

  &:hover {
    color: var(--color-button-filled-primary-hover);
    border-color: var(--color-button-filled-primary-hover);
    background-color: rgba(var(--color-button-filled-primary-rgb), 0.06);
  }

  &:active {
    color: var(--color-button-filled-primary-active);
    border-color: var(--color-button-filled-primary-active);
  }
}
```

#### 场景 B：非白色背景填充 primary 按钮

```scss
/* ===== 改造前 ===== */
.ant-btn-primary {
  background: #0564f5;
  color: #fff;
  border: none;

  &:hover { background: #4e80f5; }
  &:active { background: #096dd9; }
  &:disabled { background: #80bfff; }
}

/* ===== 改造后 ===== */
.ant-btn-primary {
  background: var(--color-button-filled-primary);
  color: var(--color-button-filled-primary-color);
  border: none;

  &:hover {
    background: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-color-hover);
  }
  &:active {
    background: var(--color-button-filled-primary-active);
    color: var(--color-button-filled-primary-color-hover);
  }
  &:disabled {
    background: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

#### 场景 C：次按钮

```scss
/* ===== 改造前 ===== */
.btn-secondary {
  background: #a8d7ff;
  color: #fff;

  &:hover { background: #80bfff; }
  &:disabled { background: #e6f4ff; }
}

/* ===== 改造后 ===== */
.btn-secondary {
  background: var(--color-button-filled-primary-secondary);
  color: var(--color-button-filled-primary-color);

  &:hover { background: var(--color-button-filled-primary-secondary-hover); }
  &:disabled {
    background: var(--color-button-filled-primary-secondary-disable);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

### 5.6 遗漏检测与自动重试（必须执行）

任务 3 第一轮改造完成后，**必须**执行遗漏检测：重新搜索项目中所有 `ant-btn-primary` 样式块，检查其 `background` / `background-color` 属性是否仍使用了硬编码色值而非 CSS 变量。

#### 5.6.1 搜索范围

搜索匹配以下 class 模式的所有按钮样式块：
- `ant-btn-primary`
- `button-primary`
- `btn-primary`
- `a-Button--primary`
- 其他包含 `primary` 关键词的按钮类名

#### 5.6.2 检测命令

```bash
# 搜索所有 primary 按钮样式块中的硬编码背景色
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 20 | grep -E "background(-color)?:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"

# 重点检测 ant-btn-primary 中的 background-color 是否为硬编码色值
grep -rn "ant-btn-primary" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(background|background-color):\s*#"
```

#### 5.6.3 遗漏判定与重试规则

1. 对搜索命中的样式块逐一判断：
   - `background` / `background-color` 使用了 CSS 变量（如 `var(--color-button-filled-primary)`）→ **已完成改造**
   - `background` 为白色（`#fff` / `#FFF` / `#ffffff` / `#FFFFFF`）→ 按 5.2 轮廓按钮规则处理，**非遗漏项**（白色背景本身就是最终值）
   - `background` / `background-color` 使用了硬编码色值且非白色 → 判定为**遗漏**
2. 若存在遗漏 → **立即重新执行任务 3（从 5.1 识别目标按钮开始，按 5.2/5.3/5.4 规则逐一改造所有遗漏的 primary 按钮样式块）**
3. 改造完成后 → **再次执行遗漏检测（本步骤）**
4. 重复以上过程，直到**所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景**，方可进入任务 4
5. 同时核对每个非白色背景 primary 按钮的字体色 `color`：非 hover/active 态应为 `var(--color-button-filled-primary-color)`、hover/active 态应为 `var(--color-button-filled-primary-color-hover)`；若仍为固定色值或固定色值 CSS 变量 → 判定为遗漏，一并补改
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`

> ⚠️ **特别关注 `ant-btn-primary`**：这是最容易被遗漏的场景。其默认样式通常写在基础组件库（如 antd）的覆盖样式表中，需要逐一确认 `background` 和 `background-color` 属性均已完成替换。

---

## 六、ECharts 图表处理规范

> **重要**：ECharts option 中的硬编码色值**不进行替换**。ECharts 不支持 `var(--css-variable)`。

正确的做法是在组件 JSX 中通过 `getCssVarHex()` 读取 CSS 变量的 hex 值后传入：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart = () => {
  const brandColor = getCssVarHex('--brand-color');

  const option = {
    color: [brandColor],
    series: [{ itemStyle: { color: brandColor } }],
  };

  return <ReactECharts option={option} />;
};
```

---

## 七、组件开发规范速查

> 当需要**新建**支持换肤的组件时，参考以下规范。

### 7.1 品牌色使用

```scss
.my-tab.active {
  border-left: 3px solid var(--brand-color);
  color: var(--color-text-brand);
  background: var(--color-bg-brand-tint);
}
```

### 7.2 按钮色使用

```scss
.btn-primary {
  background-color: var(--color-button-filled-primary, #0564f5);
  color: var(--color-button-filled-primary-color);

  &:hover { background-color: var(--color-button-filled-primary-hover); }
  &:active { background-color: var(--color-button-filled-primary-active); }
  &:disabled {
    background-color: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

### 7.3 要素映射表

| 元素 | CSS 变量 |
|:--|:--|
| 填充按钮背景 | `--color-button-filled-primary` |
| 轮廓按钮边框/文字 | `--color-button-filled-primary`（复用） |
| 文本按钮颜色 | `--color-button-filled-primary`（复用） |
| 链接文字 | `--color-text-brand-link`（正常）→ `--color-text-brand-hover`（悬停） |
| 输入框聚焦边框 | `--color-border-brand` |
| 关键数据文字 | `--color-text-brand` |
| 浅色背景卡片 | `--color-bg-brand-tint` |
| 半透明覆盖层 | `rgba(var(--brand-color-rgb), 0.15)` |

---

## 八、可用主题 CSS 变量

> Neo 平台主题 CSS 变量的完整列表、默认色值及各类场景的响应使用示例，详见 **[references/theme-css-variables.md](references/theme-css-variables.md)**。

核心变量体系概览：

| 类别 | 变量数 | 用途 |
|:--|:--|:--|
| 品牌核心变量 | 6 对（hex + -rgb） | `--brand-color` / `--brand-color-hover` / `--brand-color-shade` / ... |
| 语义化 Token — 背景 | 6 个 | `--color-bg-brand` / `--color-bg-brand-hover` / ... |
| 语义化 Token — 边框 | 6 个 | `--color-border-brand` / `--color-border-brand-hover` / ... |
| 语义化 Token — 图标 | 7 个 | `--color-icon-brand` / `--color-icon-brand-hover` / ... |
| 语义化 Token — 文本 | 7 个 | `--color-text-brand` / `--color-text-brand-link` / ... |
| 按钮色变量 | 18 个 | `--color-button-filled-primary` / `--color-button-filled-primary-hover` / ... |
| 导航 Banner 色 | 11 个 | `--brand-nav-header-bg` / `--brand-nav-header-font` / ... |

> 每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值，如 `5, 100, 245`），用于 `rgba(var(--xxx-rgb), alpha)` 半透明场景。

---

## 九、替换后校验（必须执行）

> **重要**：全部替换完成后，**必须运行以下校验命令**确认无异常。

### 9.1 CSS 属性名完整性校验

```bash
# 检测 CSS 属性名被撕裂的异常（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"
# 预期输出：空（无任何匹配）
```

**如果发现匹配**，说明出现了"属性名撕裂"错误，必须立即修复（修复方法见 十.1）。

### 9.2 残留硬编码色值校验

```bash
# 搜索未替换的 6 位 hex 品牌色值（排除已注释行、var() 回退值、测试文件、node_modules）
# 主品牌色 8 组 + 次品牌色 10 组，全部含大小写
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#1a7aff|#1A7AFF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索未替换的 8 位 hex 品牌色值（含透明度）
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|1a7aff|4096ff|5b8ff9|69c0ff)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

合法残留项（无需处理）：
- `$变量名: #2065CF;` — SCSS 变量定义
- `.xxx-blue { color: #1890ff; }` — class 含 blue 关键字
- `var(--xxx, #0564f5)` — var() 回退值
- `path[fill='#1890ff']` — SVG 属性选择器
- `stroke: #1890ff` — SVG stroke 属性
- `mix(#0564f5, ...)` — SCSS 函数参数

---
## 十、常见错误与排查

### 10.1 CSS 属性名被撕裂

**现象**：

```scss
/* 异常：属性名被从中间注入注释，变成畸形属性 */
border-// color: #1890ff;
  color: var(--brand-color-hover);
```

**根因**：正则 `color: #xxx` 没有边界锚定，匹配到了 `border-color` 中的 `color` 子串并执行了替换。同理 `background-color`、`text-decoration-color` 等复合属性也会被误伤。

**修复方法**：

```python
import re

# 遍历找出并修复所有损坏行
def fix_torn_property(content):
    for prefix in ['background', 'border', 'text-decoration', 'caret']:
        pattern = rf'({prefix})-// (\w+): (#[0-9a-fA-F]{{6}});\s*// \[[\*]\] .*\n\s*\2: (var\(--[\w-]+\));'
        def fix(m):
            prop = f'{m.group(1)}-{m.group(2)}'
            return f'// {prop}: {m.group(3)};  // [*] 已替换为 {m.group(4)}\n  {prop}: {m.group(4)};'
        content = re.sub(pattern, fix, content)
    return content
```

**预防**：严格遵守 3.3.3 规则 1/2，必须用属性名边界锚定（`^|{|;`）或逐属性拆解后再替换值。

### 10.2 注释行被重复替换

**现象**：已注释的行被再次替换，导致双 `// ` 前缀：

```scss
// // background-color: #0564f5;  // [*] 已替换为 var(--brand-color)
```

**根因**：替换脚本未在每次操作前检查行首是否以 `//` 或 `/*` 开头。

**预防**：每次替换前检查 `line.strip().startswith('//')` 或 `line.strip().startswith('/*')`。

### 10.3 重复的替换行

**现象**：同一属性出现两条相同的 `var()` 替换行。

**根因**：因 `insert()` 插入新行后未更新遍历索引，导致同一行被处理两次。

**预防**：遍历文件行时使用副本（如 `lines[:]`）并从后向前处理，或收集所有修改后一次性应用。

---
## 十一、执行检查清单

完成全部任务后逐项检查：

- [ ] **匹配规则总则已遵守**（完全匹配优先直接替换；1-2 色阶近似匹配按 3.1.2 规则处理并标记；超阈值一律保留）
- [ ] **任务 1 遗漏检测已通过**（执行 3.3.5 搜索命令，仅剩合法跳过项，无遗漏）
- [ ] 所有匹配的硬编码色值已替换（包括 6 位 hex、8 位 hex、rgb、rgba 格式）
- [ ] **8 位 hex 色值（`#RRGGBBAA`）已按 3.1.1 规则处理**（前 6 位命中则换算 alpha 后替换为 rgba + -rgb 伴侣变量）
- [ ] **近似色匹配已按 3.1.2 阈值判定**（1 色阶差 Δ_ch ≤ 16 且 d ≤ 25；2 色阶差 Δ_ch ≤ 32 且 d ≤ 50）
- [ ] **多候选歧义已按 Tiebreaker 决策**（完全匹配 > 距离最小 > 色阶差更小 > 主色优先 > 列表顺序）
- [ ] **近似匹配已在报告"近似匹配详情"表中单独记录**（含源色值、基准、Δ_ch、d、目标变量），并附注释标注供人工复核
- [ ] **补充的相近品牌色值已全部替换**（Ant Design v5 / TDesign / Neo 默认色如 `#1677ff`、`#1a7aff`、`#4096ff` 等）
- [ ] 类名/变量名中的色值已正确跳过
- [ ] SCSS 中用 `//` 保留原有写法，CSS 中用 `/* */` 保留
- [ ] 测试文件已全部跳过
- [ ] ECharts option 中的色值未替换
- [ ] `var()` 默认值中的色值未替换
- [ ] class 含 `blue` 关键字未替换
- [ ] 旧变量 `-bg` 后缀已全部更新
- [ ] **任务 3 遗漏检测已通过**（执行 5.6 搜索命令，所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景）
- [ ] 所有 primary 按钮样式块已遍历，无遗漏
- [ ] 白色背景 primary 按钮的 `color` + `border-color` 已改造
- [ ] 非白色背景 primary 按钮的 `background-color` 已改造
- [ ] **非白色背景 primary 按钮的字体色 `color` 已改用按钮字体色变量**（非 hover/active 态 → `--color-button-filled-primary-color`；hover/active 态 → `--color-button-filled-primary-color-hover`），未保留固定色值或固定色值 CSS 变量
- [ ] **ant-btn-primary 的 background-color 已确认替换**
- [ ] **CSS 属性名完整性校验已通过**（执行 九.1 命令，确认无匹配）
- [ ] **残留硬编码色值校验已通过**（执行 九.2 命令，仅剩合法跳过项）
- [ ] `Neo主题换肤功能升级报告.md` 已生成
- [ ] 无破坏代码逻辑的变更

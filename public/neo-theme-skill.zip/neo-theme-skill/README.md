# neo-theme-skill 说明

## 触发条件

当用户提出 **"项目支持 Neo 主题换肤功能"** 或类似需求时触发。

本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

## 核心能力

### 1. 蓝色硬编码色值 → CSS 变量替换

自动识别项目中的品牌相关蓝色硬编码色值（48 个唯一色值，含大小写与 rgb/rgba 变体），按规则替换为 CSS 变量写法：

- 主品牌色 33 个色值（含 `#1a7aff`、第一批实战补充 `#257cff`/`#0656d5`/`#007bff` 等 11 色、经典 Web 蓝 `#3399cc`，第二批实战补充 `#3c50e0`/`#115bdd`/`#3a75c6`/`#4378be`/`#4477bc`/`#5f7ab8`/`#2869ff`/`#2a72d3`/`#287eff`/`#2866f2`，以及第三批实战补充 `#475ffd`/`#4376bb`）→ `var(--brand-color)`
- 次品牌色 15 个色值（含 `#4b87f1`、`#5581f4`、`#4285f4`、`#009ffe`、`#457ff5`）→ `var(--brand-color-hover)`
- 显式覆盖高频 rgba 写法：`rgba(40,105,255,0.2)` → `rgba(var(--brand-color-rgb), 0.2)`、`rgba(0,159,254,0.2)` → `rgba(var(--brand-color-hover-rgb), 0.2)`、`rgba(68,119,188,1)` → `var(--brand-color)`（alpha=1 直接用主变量）
- 支持 6 位 hex、8 位 hex（含透明度）、rgb/rgba 格式
- **近似色匹配只以 `#0564f5` 为唯一基准**（1-2 色阶差 → `var(--brand-color)`），避免误伤非品牌蓝色
- 智能跳过多类场景：类名/变量名含色值、测试文件、已注释行、blue 选择器（含嵌套回溯）、ECharts 属性、颜色数组、取色器对象、**var() 中备用（回退）的硬编码色值**、SASS/Less blue 变量
- 按文件类型保留原有写法（scss 用 `//`、css 用 `/* */`、tsx 直接替换）

### 2. 浅蓝硬编码色值 → `var(--brand-color-tint)` 替换

将 `background` / `background-color`（JSX `backgroundColor`）上的浅蓝硬编码色值替换为 `var(--brand-color-tint)`：

- 浅蓝清单 11 色：`#e6f0fe`、`#e6f7ff`、`#e8f0fe`、`#e8f1ff`、`#e7f7ff`、`#eff6ff`、`#eef2ff`、`#dcf4ff`、`#d9f3fb`、`#eceff8`、`#edeff2`
- 含透明度写法：`#edeff280` → `rgba(var(--brand-color-tint-rgb), 0.5)`；`rgba(230, 247, 255, 0.2)` → `rgba(var(--brand-color-tint-rgb), 0.2)`
- **只改背景属性**：`color` / `border-color` / `box-shadow` 等属性上的浅蓝色值保留原样
- **只做完全匹配**：清单外浅色（如 `#f0f8ff`）一律不替换，浅蓝不参与近似匹配
- 复用任务 1 的 6 项防护检查与忽略规则（含 var() 备用值、已注释行）

### 3. 旧 CSS 变量迁移

包含两类旧→新 CSS 变量迁移：

- **按钮变量**：带 `-bg` 后缀的旧版按钮色变量名替换为新版命名（7 对）。
- **导航色变量**：旧版导航色变量 `--dayone-theme-header-*` 替换为新版 `--brand-nav-header-*`（9 对，含定义处与 `var()` 引用处；注意 `-back` / `-select` 前缀顺序，先长名后短名）。

### 4. Primary 按钮色改造

遍历所有 primary 模式按钮，按背景色白色/非白色区分处理。除 `button-primary`、`ant-btn-primary`、`btn-primary`、`a-Button--primary` 等类名外，**class 名称或 class token 中含 `btn-conform`、`add_button`、`confirm_button`、`cancel_button` 的按钮也必须按 Primary 按钮识别**，即使其类名不含 `primary`：

- 白色背景 → `color` + `border-color` 改用按钮色变量（`--color-button-filled-primary` 系列）
- 非白色背景 → `background-color` 改用按钮背景色变量；`color` 改用按钮字体色变量；`border-color` / `border` 中色值改用**与 background 相同的按钮背景色变量**（`--color-button-filled-primary` 系列，**非字体色变量**）
- 覆盖 hover / active / disabled 全部状态
- **`add_button`（新增）、`confirm_button`（确认）** 为实心 Primary 按钮，按背景白 / 非白正常改造
- **`cancel_button`（取消）** 为空心（轮廓）按钮，一律走白底轮廓规则（规则 A）：只改 `color` / `border-color`，背景保持原样

## 结构

```
neo-theme-skill/
├── SKILL.md                              # 主技能文档（含 frontmatter，保留关键规则与流程）
├── README.md                             # 本文件
├── references/
│   ├── theme-css-variables.md            # 主题 CSS 变量完整参考（含使用示例 + 反向映射）
│   ├── color-matching-details.md         # 8 位十六进制 + 近似色匹配完整细则、浅蓝色值表、示例、报告格式
│   ├── guards-and-detection.md           # 6 项跳过检查细则 + 遗漏检测 / 校验命令
│   ├── batch-and-troubleshooting.md      # 批量脚本替换安全规则 + 常见错误排查
│   └── examples.md                       # Primary 按钮改造前后对照 + 新建组件换肤规范
└── scripts/
    ├── neoThemeColorMatcher.js           # 硬编码色值 → CSS 变量匹配决策引擎（可编程实现）
    └── README.md                         # 脚本说明与用法
```

## 输出

执行完成后（任务 1~4 全部完成），在项目根目录生成 `Neo主题换肤功能升级报告.md`，包含：

- 汇总信息（扫描文件数、蓝色 / 浅蓝替换次数、跳过次数）
- 跳过详情（哪些色值被跳过及原因）
- 替换详情（每处替换的前后对照，蓝色与浅蓝分章节）

## 遵循 skill-creator 约定

- `SKILL.md` 主文档 + `references/` 目录结构
- YAML frontmatter 含 `name` / `description`，描述带触发关键词
- 主文档控制行数，详细信息分拆到 references
- 明确的执行步骤和检查清单

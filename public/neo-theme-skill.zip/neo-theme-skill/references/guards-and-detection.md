# 防护流程细则 & 检测命令 & 特殊场景判定

> 本文件是 `SKILL.md` 任务 1 的配套细则，收录以下三类内容：
> 1. 6 项跳过检查的详细说明（含防护 2 注释行示例）；
> 2. ECharts 判定细则、取色器对象保护、blue 选择器回溯的完整规则与示例；
> 3. 遗漏检测与残留校验的完整 grep 命令。

---

## 一、6 项跳过检查详解

`SKILL.md` § 3.0 防护 1 定义了 6 项跳过检查，本节收录每项的完整判定要点与示例。

| 检查 | 判定要点 | 示例 |
|:--|:--|:--|
| **检查 1**：类名/变量名含色值 | class 名或 CSS-in-JS 变量名内直接嵌入 hex/rgb | `text-[#0564f5]` / `bg-[#4e80f5]` |
| **检查 2**：测试文件 | 路径含 `*.test.*` / `*.spec.*` / `__tests__/` | `Button.test.tsx` |
| **检查 3**：已注释行（详见二节） | 5 种注释形态之一 | `// color: #0564f5;` |
| **检查 4**：blue 类选择器回溯 | 向上回溯所在 CSS 规则块（含嵌套、`&` 拼接），任一祖先选择器 class 名含 `blue` | `.blue-badge { color: #0564f5; }` |
| **检查 5**：ECharts / 数组 / var 回退 / 取色器（详见三/四/五节） | 详见对应细则 | 见示例 |
| **检查 6**：SASS/Less 变量名含 blue | 变量定义名含 `blue` 关键字 | `$blue-base: #096dd9;` |

### 1.1 防护 2：已有 `// var(...)` 注释 ≠ 替换许可

块内已存在的 `// var(...)` 注释行**只在检查 3 中跳过它自身**，不构成对同块其他活跃行的替换许可。

```scss
.panel {
  // color: #0564f5;              // ← 检查 3 命中 → 只跳过它自己
  color: var(--brand-color);      // ← 已是 var()，无需处理

  border-color: #0564f5;          // ← 活跃行：仍须独立跑完 6 项检查后才替换
}
```

---

## 二、检查 3：已注释行的 5 种形态

**命中任一即视为已注释，一律跳过**：

| 形态 | 示例 | 判定要点 |
|:--|:--|:--|
| ① 单行 `//` 注释 | `// color: #0564f5;` | 行首（允许前置空白）以 `//` 起始 |
| ② 行内 `//` 注释后的色值 | `color: red; // fallback #0564f5` | 色值出现在 `//` 之后 |
| ③ 单行块注释 `/* ... */` | `/* color: #0564f5; */` | 行首以 `/*` 起始且同行含 `*/` |
| ④ 多行块注释中间行 | `* color: #0564f5;` | 由块注释状态机判定 |
| ⑤ JSX 注释 `{/* ... */}` | `{/* <div style={{ color: '#0564f5' }} /> */}` | 被 `{/*` 与 `*/}` 包裹的整段 |

### 2.1 块注释状态机判定

对每个 `.scss` / `.css` / `.less` / `.ts` / `.tsx` / `.js` / `.jsx` 文件逐行扫描时维护 `inBlockComment` 布尔标志：

- 行内出现 `/*` 且其后未出现 `*/` → 进入块注释状态；
- 行内出现 `*/` → 退出块注释状态；
- `inBlockComment = true` 期间的所有行（含以 `*` 起首的续行、含开合 `/*` `*/` 所在行本身）一律视为注释；
- 字符串字面量内的 `/*` / `*/` 不计入注释状态切换。

### 2.2 示例

```scss
// ① 单行注释：整行跳过
// color: #0564f5;

// ② 行内注释：#0564f5 位于 // 之后 → 跳过
color: red;  // 原品牌色 #0564f5

/* ③ 单行块注释：整行跳过 */
/* color: #0564f5; */

/* ④ 多行块注释：以下所有行均跳过
 * color: #0564f5;      ← 跳过
 * border: 1px solid #4e80f5;  ← 跳过
 */
```

```tsx
{/* ⑤ JSX 注释：整段跳过
  const style = { color: '#0564f5' };
  <div style={{ background: '#4e80f5' }} />
*/}
```

---

## 三、检查 5 之 ① ECharts 判定细则

> 🚫 **失效根因**：ECharts option 里常见的属性名（`color`、`borderColor`、`backgroundColor`、`lineStyle`、`itemStyle` 等）与普通 CSS-in-JS / 内联样式的属性名高度重合。若**只看色值所在的单行或就近几行**，很容易把真正的 ECharts 色值漏判（未跳过而误替换），也可能把普通内联样式误判成 ECharts。因此**不允许仅凭单行属性名**做 ECharts 判定。

### 3.1 判定铁律

**必须读取完整文件上下文，向上回溯到「最外层 option 对象」再判定。** 不能只看色值所在的最近一层 `{}`——ECharts 色值往往深埋在嵌套结构里（如 `legend.pageIconColor`、`xAxis.axisLabel.color`、`series[].itemStyle.color`）。回溯必须一路向上，直到当前对象字面量最外层的顶层对象（即被 `return {...}` / `export default {...}` / `module.exports = {...}` / `const option = {...}` / 传入图表 API 的那个根对象），并沿途记录**祖先 key 链**。

### 3.2 三类匹配（命中任一即判定为 ECharts option）

**匹配 A — 强特征属性（顶层或任意层级出现任一即成立）**：

- `series: [{ type: 'bar' | 'line' | 'pie' | 'scatter' | 'radar' | 'map' | 'gauge' | 'funnel' | 'candlestick' | 'heatmap' | 'graph' | 'tree' | 'treemap' | 'sunburst' | 'boxplot' | 'themeRiver' | 'lines' | 'effectScatter' | 'pictorialBar' | ... }]`
- `xAxis` / `yAxis` / `radiusAxis` / `angleAxis` / `singleAxis`（含 `axisLine`、`axisLabel`、`axisTick`、`axisPointer`、`splitLine` 等子属性）
- `legend`（含 `pageIconColor`、`pageIconInactiveColor`、`pageTextStyle`、`inactiveColor`、`selectedMode` 等专有子属性）
- `grid`（直角坐标系网格）
- `tooltip`（且与 `series` / 坐标轴同级，含 `axisPointer`、`confine`、`extraCssText`、`formatter` 等）
- `dataZoom` / `visualMap`（含 `inRange`、`outOfRange`、`calculable`、`pieces`） / `polar` / `radar` / `geo` / `parallel` / `toolbox` / `brush` / `graphic` / `timeline` / `calendar` / `dataset` / `title`（图表专有顶层配置）

**匹配 B — 祖先 key 链（色值对象挂在某个 ECharts 专有 key 之下即成立）**：沿祖先 key 链，只要某一层的 key 名属于上述强特征 key（`series` / `xAxis` / `yAxis` / `legend` / `grid` / `tooltip` / `visualMap` / `dataZoom` / `polar` / `radar` / `geo` / `toolbox` / `graphic` / `title` / `axisLine` / `axisLabel` / `splitLine` / `itemStyle` / `lineStyle` / `areaStyle` / `nameTextStyle` / `emphasis` 等），即判定色值处于 ECharts option 内。

例如：`#4E80F5` 位于 `legend.pageIconColor` → 其祖先 key 链含 `legend` → 命中。

**匹配 C — 独立 ECharts 配置模块（整文件/整对象识别）**：某个对象字面量作为**模块级配置**被导出或返回，且其**顶层键中同时出现 ≥ 2 个 ECharts 顶层 option 键**（`title` / `grid` / `legend` / `xAxis` / `yAxis` / `series` / `tooltip` / `visualMap` / `dataZoom` / `polar` / `radar` / `geo` / `toolbox` / `angleAxis` / `radiusAxis` / `dataset` 等）时，**整个对象判定为 ECharts option**。此判定**不依赖**是否 `import echarts`、是否用 `<ReactECharts>`、变量是否叫 `option`。常见导出/返回形态：

- `define(function(require, exports, module) { return { title, grid, legend, xAxis, yAxis, series, ... }; })`（AMD 模块）
- `export default { ... }` / `export const chartOption = { ... }`
- `module.exports = { ... }`
- `return { ... }`（工厂函数 / `getOption()` 返回图表配置）

### 3.3 辅助特征（提升置信度，不单独作为判定依据）

- 变量 / 参数名为 `option`、`chartOption`、`echartsOption`、`getOption()` 返回值等；
- 该色值最终传入 `<ReactECharts option={...} />`、`echarts.init(...).setOption(...)`、`myChart.setOption(...)`；
- 文件顶部 `import` 了 `echarts` / `echarts-for-react` / `@ant-design/charts` 等图表库；
- 文件名 / 路径含 `chart`、`echart`、`option`、`bi` 等图表语义。

### 3.4 判定流程

```
命中色值行（属性名疑似图表色，如 color/itemStyle/lineStyle/pageIconColor...）
  ↓
向上回溯到「最外层」对象字面量起始 {，并记录祖先 key 链 + 变量声明 / 函数返回 / define/export/传参位置
  ↓
匹配 A：任意层级出现强特征属性（series[].type / xAxis / yAxis / legend / grid / dataZoom / visualMap ...）？
匹配 B：祖先 key 链含 ECharts 专有 key（legend / series / xAxis / itemStyle ...）？
匹配 C：最外层对象顶层键含 ≥ 2 个 ECharts 顶层 option 键，且经 define/export/module.exports/return 导出或返回？
  ├─ 任一命中 → 判定为 ECharts option → 跳过（辅助特征仅增强置信度）
  └─ 全否 → 不足以判定为 ECharts → 回到其余检查逐一判定
```

### 3.5 判定示例

**匹配 C：AMD 模块 return 一个含多顶层键的对象 → 整体跳过**

```js
define(function (require, exports, module) {
  'use strict';
  return {
    title: { text: '气泡图', left: 16 },
    grid: { top: '10%' },
    legend: { show: true, pageIconColor: '#4E80F5' },   // 跳过（匹配 B / C）
    visualMap: [{ type: 'continuous', inRange: { symbolSize: [10, 70] } }],
    tooltip: { textStyle: { color: '#182437' } },        // 跳过
    xAxis: { nameTextStyle: { color: '#6A7280' } },      // 跳过
    yAxis: { nameTextStyle: { color: '#6A7280' } },      // 跳过
    dataZoom: [{}, { disabled: true }],
    series: [{ type: 'scatter', data: [] }],
  };
});
```

**匹配 A / B：命中 series[].type + xAxis + legend → 全部色值跳过**

```tsx
const option = {
  legend: { textStyle: { color: '#0564f5' } },   // 跳过（祖先 key legend）
  xAxis: { axisLine: { lineStyle: { color: '#4e80f5' } } },  // 跳过
  yAxis: {},
  series: [
    { type: 'bar', itemStyle: { color: '#0564f5' } },  // 跳过
  ],
};
return <ReactECharts option={option} />;

// ❌ 无任何 ECharts 强特征 / 祖先 key / 多顶层键，只是普通内联样式对象 → 不按 ECharts 跳过
const style = { color: '#0564f5', padding: 8 };
```

> **要点**：ECharts 判定的核心是「回溯到**最外层** option 对象 + 检查祖先 key 链 + 识别独立配置模块」，**读取完整文件上下文**是硬性前提。配置模块（AMD `define` / `export default` / `module.exports` / 工厂函数 `return`）即使不 `import echarts`、不用 `<ReactECharts>`、变量不叫 `option`，也必须按匹配 C 整体跳过。

---

## 四、检查 5 之 ② 取色器对象保护规则

「调色板 / 色板 / 取色器」对象里的色值是**数据**而非**主题样式**，替换会破坏取值逻辑，须整体跳过。

**判定条件（同时满足才算取色器对象，其内色值一律跳过）**：

1. 色值是某**对象字面量** `{ ... }` 的**属性值**（如 `key: '#0564f5'`）；
2. 该对象**每一个属性值都是色值**（hex / `rgb(...)` / `rgba(...)`，允许引号包裹）；
3. 对象内无任何非色值属性值（数字、布尔、文案、嵌套对象、函数、`var(...)` 等）。

**要点**：只看属性值类型（与 key 名无关）；hex/rgb/rgba 混用仍算全色值；纯色值数组（普通场景③）与纯色值对象等价处理；嵌套时以最内层纯色值对象为判定单元；判定忽略注释。

```ts
// ✅ 取色器（全部属性值为色值）→ 整体跳过
const palette = { primary: '#0564f5', hover: '#4e80f5', mask: 'rgba(5, 100, 245, 0.2)' };

// ❌ 含非色值属性（title/fontSize）→ 不是取色器，其中 #0564f5 回到其余检查判定
const theme = { title: '主色', fontSize: 14, primary: '#0564f5' };
```

---

## 五、检查 4 之 blue 选择器回溯规则

场景 ⑤ 仅查「色值同一行」是否含 `blue`，但 `blue` 保护规则常是**选择器在上、色值在下**的多行/嵌套结构。对每个色值匹配行**必须**先向上回溯其所属 CSS 规则块的选择器：

- **回溯范围**：从匹配行向上找到最近的 `{` 定位所属规则块；SCSS/Less 嵌套需**逐层向上拼接所有祖先选择器**，`&.blue`、`&-blue`、`.icon-blue &` 等 `&` 拼接形式一并拼接判定。
- **命中即跳过**：拼接后的选择器任一 class 名 / 标签名含 `blue`（大小写不敏感，如 `Blue`、`blueGray`）→ 判为「合法跳过」。

```scss
.blue-badge { color: #0564f5; }                       // 回溯到 .blue-badge → 跳过
.card { .blue-tag { background: #4e80f5; } }          // 逐层回溯命中 .blue-tag → 跳过
.btn { &.blue { border-color: #096dd9; } }            // & 拼接为 .btn.blue → 跳过
```

---

## 六、遗漏检测与残留校验命令

### 6.1 任务 1 遗漏检测（SKILL.md § 3.3.5）

```bash
# ① 搜索所有 6 位 hex 色值（主品牌色 21 组 + 次品牌色 11 组，均含大小写）
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#3399cc|#3399CC|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC|#4b87f1|#4B87F1" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ② 搜索所有 8 位 hex 色值（含透明度）
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|3399cc|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc|4b87f1)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("

# ③ 搜索所有 rgb/rgba 色值
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|26,\s*122,\s*255|37,\s*124,\s*255|6,\s*86,\s*213|0,\s*123,\s*255|36,\s*104,\s*242|28,\s*97,\s*218|24,\s*101,\s*217|37,\s*99,\s*235|29,\s*78,\s*216|4,\s*123,\s*219|23,\s*88,\s*231|0,\s*126,\s*255|51,\s*153,\s*204|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255|76,\s*161,\s*220|75,\s*135,\s*241)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)" | grep -v "var("
```

> 📌 `grep -vE "^[^:]+:[0-9]+:\s*(//|/\*|\*)"` 排除各类注释行（含多行块注释中以 `*` 起始的续行），配合防护 1 检查 3 共同确保**已注释代码中的硬编码色值不会被误判为「未替换的残留项」**。

### 6.2 任务 3 遗漏检测（SKILL.md § 5.5）

```bash
# 搜索所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码背景色
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 20 | grep -E "background(-color)?:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"

# 重点检测 ant-btn-primary、btn-conform、add_button、confirm_button 中 background-color 是否为硬编码色值
grep -rn "ant-btn-primary\|btn-conform\|add_button\|confirm_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(background|background-color):\s*#"

# 检测所有 primary 按钮样式块（含 btn-conform / add_button / confirm_button / cancel_button）中的硬编码 border / border-color
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary\|btn-conform\|add_button\|confirm_button\|cancel_button" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(^|\s)(border|border-color):\s*[^;]*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"
```

### 6.3 CSS 属性名完整性校验（SKILL.md § 10.1）

```bash
# 检测 CSS 属性名被撕裂的异常（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"
# 预期输出：空（无任何匹配）
```

**如果发现匹配**，说明出现了「属性名撕裂」错误，必须立即修复（详见 [batch-and-troubleshooting.md](batch-and-troubleshooting.md) 第二节）。

### 6.4 全量色值普查（SKILL.md § 3.1.5 近似色缺口修补）

近似色永远不会被固定 grep 捞出，须额外执行全量抽取 + 匹配器判定：

```bash
# 全量抽取所有 hex(6/8 位) 与 rgb/rgba 色值（去重），交由匹配器判定
grep -rhoE "#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?|rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}[^)]*\)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" --exclude-dir="dist" --exclude-dir="build" \
  | sort -u > /tmp/all-colors.txt
```

```bash
# 逐一喂给匹配器，打印所有近似命中（approximate*），供人工复核后替换
node -e '
const { matchBrandColor } = require("./skills/neo-theme-skill/scripts/neoThemeColorMatcher");
const fs = require("fs");
const colors = fs.readFileSync("/tmp/all-colors.txt", "utf8").split("\n").filter(Boolean);
for (const c of colors) {
  const r = matchBrandColor(c.trim());
  if (r.matchType && r.matchType.startsWith("approximate")) {
    console.log(`[近似·${r.shade}色阶] ${c.trim()} → ${r.output} (基准 ${r.baseHex}, Δ=${r.delta}, d≈${r.distance})`);
  }
}
'
```

对普查输出的每个近似命中：先按 6 项跳过检查逐项判定，全部通过后按近似匹配规则（[color-matching-details.md](color-matching-details.md) 第二节）替换为 `var(--brand-color)`，并在报告「近似匹配详情」表中单独记录。

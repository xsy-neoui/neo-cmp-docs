# Neo 主题换肤功能升级报告模板

> 本文件是 `SKILL.md` 任务 4「生成 Neo 主题换肤功能升级报告」的配套模板。SKILL.md 中保留报告生成规则与前置条件，具体表格结构对照本文件。

---

## 一、报告文件命名与位置

- **文件名（固定）**：`Neo主题换肤功能升级报告.md`
- **生成位置**：项目根目录

## 二、数据来源（必须依据 git diff）

生成报告前，必须先通过版本控制获取真实改动：

```bash
git status --short        # 改动文件清单
git diff                  # 全部改动明细（逐行）
git diff --stat           # 增删行数统计
git diff --name-only      # 被修改的文件路径
```

若项目未启用 git 或改动尚未落盘，则以本次会话中实际执行的文件写入操作为准逐一核对，确保报告与磁盘上的真实文件内容一致。

## 三、报告结构（复制此模板填充）

```markdown
# Neo 主题换肤功能升级报告

## 一、总体汇总

| 指标 | 数值 |
|:--|:--|
| 操作日期 | YYYY-MM-DD |
| 改动文件总数（git diff --name-only） | XXX |
| 新增行数 / 删除行数（git diff --stat） | +XXX / -XXX |
| 任务 1·硬编码色值替换次数 | XXX |
| 任务 2·旧 CSS 变量迁移次数 | XXX |
| 任务 3·Primary 按钮改造样式块数 | XXX |
| 跳过次数（合法跳过） | XXX |

## 二、任务 1：硬编码色值替换

### 2.1 汇总信息

| 指标 | 数值 |
|:--|:--|
| 扫描文件总数 | XXX |
| 修改文件总数 | XXX |
| 替换次数（主品牌色·完全匹配） | XXX |
| 替换次数（次品牌色·完全匹配） | XXX |
| 替换次数（近似匹配·1 色阶） | XXX |
| 替换次数（近似匹配·2 色阶） | XXX |
| 跳过次数 | XXX |

### 2.2 跳过详情

| 文件 | 行号 | 色值 | 跳过原因 |
|:--|:--|:--|:--|
| src/components/Foo.scss | 12 | #0564f5 | 变量名保护：类名 text-[#0564f5] |
| src/charts/Chart.tsx | 45 | #0564f5 | ECharts option 属性 |
| src/components/Foo.scss | 78 | #3080d0 | 超阈值：与基准差 Δ_ch=43，不视为品牌色 |
| ... | ... | ... | ... |

### 2.3 完全匹配替换详情

| 文件 | 原写法 | 替换后 | 状态 |
|:--|:--|:--|:--|
| src/components/Header.scss | `color: #0564f5` | `color: var(--brand-color)` | ✅ |
| src/components/Button.scss | `background: #4e80f5` | `background: var(--brand-color-hover)` | ✅ |
| ... | ... | ... | ... |

### 2.4 近似匹配详情（需人工复核）

> 以下为按 3.1.2 近似色匹配规则自动推断的替换，色阶差 ≤ 2，建议人工检查是否符合设计意图。匹配基准恒为 `#0564f5`，替换目标恒为 `var(--brand-color)`。

| 文件 | 行号 | 源色值 | 匹配基准 | 色阶差 | Δ_ch | d | 替换为 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| src/Foo.scss | 12 | `#0968f5` | `#0564f5` | 1 色阶 | 4 | 5.7 | `var(--brand-color)` |
| src/Bar.tsx | 34 | `#256bd8` | `#0564f5` | 2 色阶 | 32 | 43.7 | `var(--brand-color)` |
| src/Baz.less | 56 | `#0968f533` | `#0564f5` | 1 色阶 | 4 | 5.7 | `rgba(var(--brand-color-rgb), 0.2)` |
| ... | ... | ... | ... | ... | ... | ... | ... |

## 三、任务 2：旧 CSS 变量迁移

### 3.1 按钮变量迁移

| 文件 | 旧变量名 | 新变量名 | 状态 |
|:--|:--|:--|:--|
| src/styles/button.scss | `--color-button-filled-primary-bg` | `--color-button-filled-primary` | ✅ |
| ... | ... | ... | ... |

### 3.2 导航色变量迁移

| 文件 | 旧变量名 | 新变量名 | 状态 |
|:--|:--|:--|:--|
| src/styles/header.scss | `--dayone-theme-header-back` | `--brand-nav-header-bg` | ✅ |
| src/styles/header.scss | `--dayone-theme-header-back-hover` | `--brand-nav-header-elem-hover` | ✅ |
| ... | ... | ... | ... |

## 四、任务 3：Primary 按钮色改造

| 文件 | 按钮类名 | 背景类型 | 改造项 | 改造后 | 状态 |
|:--|:--|:--|:--|:--|:--|
| src/styles/btn.scss | `.ant-btn-primary` | 非白色 | `background-color` | `var(--color-button-filled-primary)` | ✅ |
| src/styles/btn.scss | `.ant-btn-primary` | 非白色 | `color` | `var(--color-button-filled-primary-color)` | ✅ |
| src/styles/btn.scss | `.ant-btn-primary` | 非白色 | `border-color` | `var(--color-button-filled-primary)` | ✅ |
| ... | ... | ... | ... | ... | ... |

## 五、改动文件清单（git diff --name-only）

- src/components/Header.scss
- src/styles/button.scss
- ...

## 六、校验结果

| 校验项 | 命令 | 结果 |
|:--|:--|:--|
| CSS 属性名完整性（10.1） | `grep -rn "[a-z]\-// [a-z]" ...` | ✅ 无匹配 |
| 残留硬编码色值（10.2） | `grep -rnE "#0564f5\|..." ...` | ✅ 仅剩合法跳过项 |
```

## 四、生成要点

1. **数据来源以实际 diff 为准**：报告中的所有明细必须与 `git diff` 的真实结果一一对应；执行过程中的临时记录若与实际 diff 不符，**以实际 diff 为准并修正**。
2. **覆盖全部三项任务的改动**：报告须同时汇总任务 1、2、3 在代码中产生的全部实际改动。
3. **逐文件核对**：对 `git diff --name-only` 列出的每个文件，核对其改动类型（色值替换 / 变量迁移 / 按钮改造）并归入报告对应章节。
4. **近似匹配单独记录**：所有非完全匹配的替换必须在「近似匹配详情」表中单独列出，供人工复核。

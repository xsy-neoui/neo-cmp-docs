# 批量脚本替换安全规则 & 常见错误排查

> 本文件是 `SKILL.md` 任务 1（蓝色）与任务 2（浅蓝）的配套细则。仅当匹配量巨大（> 200 处）必须用脚本批量替换、或替换后校验发现异常时，才需查阅本文件。少量 / 中量替换按 SKILL.md 3.3.1 / 3.3.2 逐行方式执行即可，无需脚本。

---

## 一、批量脚本替换安全规则（匹配量 > 200 时）

当匹配量超过 200 个必须使用脚本批量处理时，**必须**遵守以下规则：

### 规则 1：CSS 属性名必须用起始边界锚定，禁止裸匹配属性名

```python
# ❌ 绝对禁止：color 作为子串出现在 border-color、background-color 中
re.sub(r'color: #0564f5', ...)

# ✅ 正确：用行首或声明分隔符锚定
re.sub(r'(^|\{|;)\s*color:\s*#0564f5', ...)
```

常见的会被子串匹配误伤的 CSS 属性名：

| 搜索的属性 | 会被误匹配的复合属性 |
|:--|:--|
| `color:` | `border-color:`、`background-color:`、`text-decoration-color:`、`caret-color:` |
| `shadow:` | `box-shadow:`、`text-shadow:` |

### 规则 2：逐行解析属性名与属性值，独立替换值中的色值部分

```python
# ✅ 安全方式：拆解属性名与值，只替换值中的色值
for i, line in enumerate(lines):
    if ':' in line:
        prop, value = line.split(':', 1)
        # 检查 prop 是否为完整的目标属性名（按空白/缩进分割取最后一个 token）
        prop_name = prop.strip().split()[-1] if prop.strip() else ''
        if prop_name == 'color' and '#0564f5' in value:
            # 替换 value 中的色值，保持 prop 不变
            new_value = value.replace('#0564f5', 'var(--brand-color)')
            lines[i] = f'{prop}:{new_value}'
```

### 规则 3：替换后必须执行完整性校验

批量替换全部完成后，**必须**运行以下校验命令，禁止跳过：

```bash
# 校验 1：检测 CSS 属性名被撕裂（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"

# 校验 2：检测孤立的 var() 引用（前面没有注释标记的独立 var 行）
# 如果某行只有缩进 + var(...) + 分号，但上一行不是 // 注释，说明替换未完整
# 用例：搜索 "var(--brand-color);" 行，检查上下文

# 校验 3：搜索残留的硬编码品牌色值（确认无遗漏）
# 包含全部主品牌色（33 组 × 大小写，含 #1a7aff、#3399cc 及三批实战补充色）+ 次品牌色（15 组 × 大小写）
# 与 SKILL.md § 3.3.5 / § 11.2 的色值清单保持一致
# 浅蓝色值（任务 2）另按 SKILL.md § 4.7 的三条 grep 单独校验
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC|#4b87f1|#4B87F1|#3399cc|#3399CC|#3c50e0|#3C50E0|#115bdd|#115BDD|#3a75c6|#3A75C6|#4378be|#4378BE|#4477bc|#4477BC|#5f7ab8|#5F7AB8|#2869ff|#2869FF|#2a72d3|#2A72D3|#287eff|#287EFF|#2866f2|#2866F2|#5581f4|#5581F4|#4285f4|#4285F4|#009ffe|#009FFE|#475ffd|#475FFD|#4376bb|#4376BB|#457ff5|#457FF5" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

**如校验 1 发现匹配项，说明出现了属性名撕裂错误，必须立即修复（见下方第二节）。**

---

## 二、常见错误与排查

### 2.1 CSS 属性名被撕裂

**现象**：

```scss
/* 异常：属性名被从中间注入注释，变成畸形属性 */
border-// color: #1890ff;
  color: var(--brand-color-hover);
```

**根因**：正则 `color: #xxx` 没有边界锚定，匹配到了 `border-color` 中的 `color` 子串并执行了替换。同理 `background-color`、`text-decoration-color` 等复合属性也会被误伤。

**修复方法**：

```python
import re

# 遍历找出并修复所有损坏行
def fix_torn_property(content):
    for prefix in ['background', 'border', 'text-decoration', 'caret']:
        pattern = rf'({prefix})-// (\w+): (#[0-9a-fA-F]{{6}});\s*// \[[\*]\] .*\n\s*\2: (var\(--[\w-]+\));'
        def fix(m):
            prop = f'{m.group(1)}-{m.group(2)}'
            return f'// {prop}: {m.group(3)};  // [*] 已替换为 {m.group(4)}\n  {prop}: {m.group(4)};'
        content = re.sub(pattern, fix, content)
    return content
```

**预防**：严格遵守本文件第一节规则 1/2，必须用属性名边界锚定（`^|{|;`）或逐属性拆解后再替换值。

### 2.2 注释行被重复替换

**现象**：已注释的行被再次替换，导致双 `// ` 前缀：

```scss
// // background-color: #0564f5;  // [*] 已替换为 var(--brand-color)
```

**根因**：替换脚本未在每次操作前检查行首是否以 `//` 或 `/*` 开头。

**预防**：每次替换前检查 `line.strip().startswith('//')` 或 `line.strip().startswith('/*')`。

### 2.3 重复的替换行

**现象**：同一属性出现两条相同的 `var()` 替换行。

**根因**：因 `insert()` 插入新行后未更新遍历索引，导致同一行被处理两次。

**预防**：遍历文件行时使用副本（如 `lines[:]`）并从后向前处理，或收集所有修改后一次性应用。

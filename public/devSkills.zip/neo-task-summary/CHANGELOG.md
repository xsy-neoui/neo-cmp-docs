# Changelog

## 1.0.0 (2026-04-15)

- 初始版本：从 neo-backend-dev / neo-frontend-dev / neo-solution-design 中提取任务总结规范为独立技能包
- 支持结构化任务回顾文档生成（任务背景、最终结果、过程问题记录）
- 问题记录采用「意图 → 问题 → 解法」三段式

# Changelog

## 2026-04-15
- 新增：neo-solution-design 技能包（方案设计）
- 新增：前置条件 — 生成任何文档前必须确认工程项目存在
- 新增：所有产物（solutions/、src/）必须在项目目录内的目录结构规范
- 新增：平台能力速查表（platform-capabilities.md）
- 新增：技术方案文档模板（solution-template.md）
- 新增：Open API 参考手册（认证、查询、CRUD、审批流、文件上传下载等）
- 新增：四阶段门禁流程（需求→技术设计→任务拆分→编码实现）
- 新增：编码实现阶段工程项目前置检查

# NeoCRM 常见业务场景设计模式

## 一、场景分类与技术选型

### 1.1 数据展示类

需要在 CRM 页面上展示聚合统计、图表、看板等非标准视图。

| 场景 | 前端 | 后端 | 说明 |
|------|------|------|------|
| 简单实体列表/详情 | xObject 直查 | 无需后端 | 标准 CRUD，前端直接调平台 API |
| 聚合统计/图表 | customApi 调后端 | 自定义 API | 后端做 SQL 聚合，前端渲染 ECharts |
| 多实体关联查询 | customApi 调后端 | 自定义 API | 后端 join 多表，组装返回 |
| 平台内置数据（阶段/业务类型等） | 前端直调平台 API | 无需后端 | 用 neo-open-api 的 fetch/xObject |

**选型原则**：能用平台标准能力就不写后端，需要聚合/跨表/复杂逻辑才上自定义 API。

### 1.2 数据校验类

在数据创建/更新时执行业务规则校验。

| 场景 | 实现方式 | 触发时机 |
|------|----------|----------|
| 字段必填/格式校验 | Trigger (before add/update) | 保存前 |
| 唯一性/查重校验 | Trigger (before add) | 创建前 |
| 跨实体一致性校验 | Trigger (before update) | 更新前 |
| 状态流转校验 | 可视化流扩展 | 阶段推进前 |

### 1.3 数据同步类

数据变更后自动同步到关联实体或外部系统。

| 场景 | 实现方式 | 说明 |
|------|----------|------|
| 实时同步（少量数据） | Trigger (after add/update) | 同步执行，15秒限制 |
| 异步同步（耗时操作） | Trigger + FutureTask | after 触发器中启异步任务 |
| 批量定时同步 | 计划作业 (ScheduleJob) | 定时批量处理 |
| 外部系统集成 | 自定义 API + CommonHttpClient | 提供 webhook 或主动推送 |

### 1.4 工作台/Dashboard 类

为特定角色提供统一工作入口，聚合多维度数据。

**典型架构**：
```
自定义页面（customPage）
├── 前端组件（单个大组件或多个子组件）
│   ├── 筛选栏（调平台 API 获取选项数据）
│   ├── 图表区（调自定义 API 获取聚合数据）
│   └── 列表区（调自定义 API 获取明细数据）
└── 后端代码包
    ├── 初始化 API（返回筛选项等配置数据）
    ├── 聚合查询 API（返回图表/统计数据）
    └── 列表查询 API（返回分页明细数据）
```

**设计要点**：
- 筛选项初始化数据（部门、业务类型等）单独一个 API，页面加载时调一次
- 图表和列表数据分开 API，避免单个接口过重
- 平台内置数据（阶段列表、业务类型等）由前端直接调平台 API，不经后端中转
- 前端组件间通过 state 联动，不重复请求

---

## 二、前后端职责划分

### 2.1 前端负责

- UI 渲染和交互
- 调用平台内置 API（实体 CRUD、阶段查询、业务类型查询等）
- 简单的数据格式化和展示逻辑
- 组件间状态联动
- 调用自定义 API 获取聚合数据

### 2.2 后端负责

- 复杂 SQL 查询和聚合统计
- 跨实体数据组装
- 业务规则校验（Trigger）
- 数据同步和级联操作
- 外部系统集成
- AI 能力调用（提示词模板等）

### 2.3 判断标准

| 问题 | 答案 → 前端 | 答案 → 后端 |
|------|-------------|-------------|
| 是否需要 SQL 聚合？ | 否，单表简单查询 | 是，GROUP BY / JOIN |
| 是否涉及多实体？ | 否，单实体 CRUD | 是，需要关联查询 |
| 是否有业务规则？ | 否，纯展示 | 是，需要校验/计算 |
| 是否调外部系统？ | 否 | 是 |
| 平台有现成 API？ | 是，直接调 | 否，需要自定义 |

---

## 三、平台内置 API vs 自定义 API

### 3.1 优先使用平台内置 API 的场景

以下数据建议前端直接调用平台 API，不需要后端中转：

| 数据 | 平台 API | 说明 |
|------|----------|------|
| 实体 CRUD | xObject.query / insert / update / delete | 标准数据操作 |
| 商机阶段列表 | POST /rest/data/v2.0/xobjects/stage/actions/getStageListByEntityTypeApiKey | 按业务类型获取阶段 |
| 业务类型列表 | GET /rest/data/v2.0/xobjects/{apiKey}/busiType | 获取实体的业务类型 |
| 实体描述信息 | GET /rest/data/v2/objects/{apiKey}/description | 获取字段定义 |
| 用户/部门信息 | 平台标准接口 | 组织架构数据 |

### 3.2 必须使用自定义 API 的场景

- SQL 聚合查询（SUM / COUNT / GROUP BY）
- 多表 JOIN 查询
- 复杂业务逻辑计算
- 需要调用后端 SDK（缓存、异步、HTTP 等）
- AI 能力调用

---

## 四、实体模型设计模式

### 4.1 扩展标准实体

在标准实体上添加自定义字段，适用于需要在现有业务对象上增加属性的场景。

```
标准实体（如 Opportunity）
└── 新增自定义字段
    ├── customField1__c (text)
    ├── customField2__c (number)
    └── customField3__c (lookup → 其他实体)
```

### 4.2 新建自定义实体

创建全新的业务对象，适用于标准实体无法满足的场景。

```
自定义实体 myEntity__c
├── 标准字段（id, name, createdTime 等自动生成）
├── 自定义字段
│   ├── field1__c
│   └── field2__c
└── 关联关系
    └── parentId__c (lookup → 标准实体或其他自定义实体)
```

### 4.3 命名规范

| 类型 | 规范 | 示例 |
|------|------|------|
| 自定义实体 API Key | 小驼峰 + `__c` | `pipelineSnapshot__c` |
| 自定义字段 API Key | 小驼峰 + `__c` | `totalAmount__c` |
| 标准实体 API Key | 首字母大写 | `Opportunity`、`Account` |
| 标准字段 API Key | 小驼峰，无后缀 | `name`、`closeDate`、`money` |

---

## 五、代码包组织模式

### 5.1 按业务模块组织

一个业务模块对应一个代码包，包内包含该模块所有的 Trigger、API、Job。

```
src/codePackages/
├── 客户管理/          → other.xsy.account
│   ├── AccountTrigger.java
│   └── AccountApi.java
├── Pipeline管理/      → other.xsy.pipeline
│   ├── StageTabsApi.java
│   ├── OpportunityListApi.java
│   └── FilterInitApi.java
└── 数据同步/          → other.xsy.sync
    └── DataSyncJob.java
```

### 5.2 包名规范

- 必须三级：`other.{company}.{module}`
- 不能四级或以上（如 `other.xsy.pipeline.api` 是错误的）
- 同一模块的 Trigger 和 API 放同一个包

### 5.3 代码包拆分原则

| 原则 | 说明 |
|------|------|
| 按业务域拆分 | 客户管理、商机管理、订单管理各一个包 |
| 避免过大 | 单个包不超过 10 个 Java 类 |
| 避免过碎 | 不要一个 API 一个包 |
| 共享逻辑 | 工具类放在被依赖最多的包中，或单独一个工具包 |

---

## 六、组件设计模式

### 6.1 单页面单组件

适用于功能完整的独立页面（如工作台、Dashboard）。

```
sellerWorkspace__c/
├── index.tsx    # 包含所有 UI 逻辑
├── model.ts     # 设计器配置（pageType: customPage）
├── style.scss   # 样式
└── doc.md       # 文档
```

### 6.2 实体详情页嵌入组件

适用于在标准实体详情页中嵌入自定义展示区域。

```
oppStats__c/
├── index.tsx    # 展示商机统计信息
├── model.ts     # pageType: entityDetailPage, entityApiKey: Opportunity
├── style.scss
└── doc.md
```

### 6.3 组件数据来源选择

| model.ts 配置 | 含义 | 适用场景 |
|---------------|------|----------|
| `dataSourceType: 'xObject'` | 直查实体 | 简单 CRUD |
| `dataSourceType: 'customApi'` | 调自定义 API | 聚合查询、复杂逻辑 |
| 无 dataSourceType | 无接口调用 | 纯展示组件 |

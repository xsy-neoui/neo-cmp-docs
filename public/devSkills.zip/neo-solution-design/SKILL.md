---
name: neo-solution-design
description: Neo 项目方案设计技能，辅助在 NeoCRM 平台上进行需求分析和技术方案设计。当用户需要：(1) 分析业务需求并拆解为技术任务，(2) 设计前后端组件架构，(3) 设计自定义 API 接口，(4) 设计数据模型和实体关系，(5) 评估平台能力和限制，(6) 输出技术方案文档，(7) 从 PRD/原型图推导技术实现方案时，使用此技能。
---

# Neo 项目方案设计

辅助完成 NeoCRM PaaS 平台项目的需求分析和技术方案设计，输出可直接交付给前后端开发技能包执行的方案文档。


## 前置条件：确认工程项目与实体模型

在生成任何文档（需求文档、方案设计、任务列表）之前，必须先确认工程项目已存在且实体模型已拉取。

### 检查步骤

1. 检查项目目录下是否存在 `neo.config.js` 文件
   - 如果项目不存在，先询问用户项目名称，然后执行 `neo create project -n <项目名称>` 创建项目
2. 检查项目是否已登录（项目目录下是否存在 `.neo-cli/token.json`）
   - 如果未登录，按照"登录租户"流程引导用户完成登录
3. 检查 `src/xObjects/AllxObjects.md` 是否存在
   - 如果不存在，执行 `node neo-entity-management/scripts/gen_entitylist.js <项目目录>` 拉取实体列表

**三步全部完成后，才能开始需求收集和方案设计。** 实体模型是方案设计的基础输入，没有它无法准确评估实体复用、字段扩展和平台能力。

所有产物必须放在项目目录下，目录结构示例：

```
<项目名称>/
├── neo.config.js
├── solutions/                    # 方案设计文档
│   └── {feature-name}/
│       ├── requirements.md       # 需求文档
│       ├── design.md             # 技术设计文档
│       └── tasks.md              # 任务列表
├── src/
│   ├── components/               # 前端组件
│   │   └── xxxWidget__c/
│   ├── codePackages/           # 后端代码包
│   │   └── xxx代码包/
│   └── xObjects/             # 实体模型描述
└── .neo-cli/                     # 登录凭证
```

**禁止将任何文件放在工作区根目录的 src/ 或 solutions/ 下，必须放在项目目录内。**

## 定位与全局流程

本技能包处于开发流程的最上游，覆盖"需求收集"、"方案设计"和"技术设计"三个阶段，产出的方案文档是 neo-frontend-dev 和 neo-backend-dev 技能包的输入。

**所有方案设计文档统一存放在项目目录的 `solutions/{feature-name}/` 目录下（如 `<项目名称>/solutions/pipeline-management/`）。**

NeoCRM 项目开发全流程分为四个阶段：

```
〇、需求收集（neo-solution-design）
  1. 明确目标用户和使用场景
  2. 识别用户意图：修改老功能 / 开发新功能
  3. 生成需求文档 → solutions/{feature-name}/requirements.md
  4. ⛔ 用户确认需求文档（用户手动）— 确认后才进入下一阶段

一、方案设计 + 技术设计（neo-solution-design）
  前置条件：需求文档已确认 ✅
  1. 识别方案涉及到的业务对象(xObjects)
  2. 功能设计
  3. 历史资产读取（基于老功能迭代时）
  4. 实体模型评估（AI 完成）
  5. 平台能力评估（AI 完成）
  6. 后端设计（AI 完成）
  7. 前端设计（有自定义组件时必须，纯后端需求可选）
  8. 生成技术设计文档 → solutions/{feature-name}/design.md
  9. ⛔ 用户确认技术方案（用户手动）— 确认后才进入下一阶段

二、任务拆分（neo-solution-design）
  前置条件：技术设计文档已确认 ✅
  1. 基于需求文档和技术设计文档拆分任务
  2. 生成任务列表 → solutions/{feature-name}/tasks.md
  3. ⛔ 用户确认任务列表（用户手动）— 确认后才进入编码实现

三、编码实现（neo-backend-dev / neo-frontend-dev）
  前置条件：任务列表已确认 ✅ + 工程项目已创建 ✅
  0. 检查工程项目是否已创建（检查项目目录下是否存在 neo.config.js），如果不存在则先执行 `neo create project -n <项目名称>` 创建项目
  1. 模型构建（委托 neo-entity-management 通过 API 创建实体/字段）
  2. 后端接口实现（AI 完成 | 使用 neo-backend-dev 技能包）
  3. 前端组件实现（AI 完成 | 使用 neo-frontend-dev 技能包）
  4. 部署验证（AI 辅助部署 + 用户验证效果）
  5. 用户确认实现效果（用户手动）
```

## ⛔ 阶段门禁规则（严格执行）

每个阶段之间设有门禁，必须获得用户明确确认后才能进入下一阶段：

| 门禁 | 触发条件 | 通过条件 |
|------|----------|----------|
| 需求 → 技术设计 | requirements.md 生成完毕 | 用户明确确认需求文档（如"确认"、"没问题"、"可以"） |
| 技术设计 → 任务拆分 | design.md 生成完毕 | 用户明确确认技术方案（如"确认"、"没问题"、"可以"） |
| 任务拆分 → 编码实现 | tasks.md 生成完毕 | 用户明确确认任务列表 |

**禁止行为：**
- ❌ 需求文档生成后直接生成技术设计文档（未等用户确认）
- ❌ 技术设计文档生成后直接生成任务列表（未等用户确认）
- ❌ 在同一轮对话中连续生成 requirements.md + design.md + tasks.md

**正确行为：**
- ✅ 生成 requirements.md 后，提示用户审阅并等待确认
- ✅ 用户确认需求后，再生成 design.md，然后提示用户审阅并等待确认
- ✅ 用户确认技术方案后，再生成 tasks.md

## 参考文档索引

根据设计阶段按需查阅：

| 文档 | 用途 | 何时查阅 |
|------|------|----------|
| [platform-capabilities.md](references/platform-capabilities.md) | 平台能力速查（开发能力、限制、技术栈） | 阶段二-3 平台能力评估时 |
| [design-patterns.md](references/design-patterns.md) | 常见业务场景的设计模式和选型指南 | 阶段二-3/4/5 技术选型和架构设计时 |
| [solution-template.md](references/solution-template.md) | 方案文档输出模板（需求/设计/任务） | 各阶段输出文档时 |
| [rest-api-reference.md](../neo-backend-dev/references/rest-api-reference.md) | 平台 REST API 完整接口列表（1399 个接口） | 评估平台 API 能力、判断前端能否直调时 |
| [sdk-api-reference.md](../neo-backend-dev/references/sdk-api-reference.md) | 后端 SDK 类和方法签名参考 | 后端设计阶段评估 SDK 能力时 |

---

## 阶段〇：需求收集

### 0.1 识别用户意图

收到用户需求后，首先判断：

- **是新功能还是修改老功能？** 这决定了后续是否需要读取历史资产
- 如果用户描述模糊，主动询问确认

### 0.2 需求澄清

通过主动提问补全需求信息，确保以下要素清晰：

- **业务目标**：这个需求要解决什么问题？服务哪些角色？
- **功能边界**：哪些是本次必须做的，哪些是后续迭代的？
- **触发条件**：功能在什么场景下触发？（用户操作 / 数据变更 / 定时 / 外部调用）
- **输入输出**：功能的输入数据是什么？期望的输出或效果是什么？
- **异常处理**：出错时的预期行为？（拦截报错 / 静默跳过 / 降级处理）
- **涉及实体**：涉及哪些业务对象？（标准实体 / 自定义实体）

如果用户一次性提供了足够清晰的需求，可以跳过部分提问，直接进入需求文档生成。

### 0.3 生成需求文档

将澄清后的需求整理为结构化的需求文档，输出到 `solutions/{feature-name}/requirements.md`。

需求文档必须包含：
1. **需求概述**：一段话描述需求背景和目标
2. **修改意图**：新功能 / 修改老功能
3. **业务对象清单**：涉及的实体，标注 API Key 和是否标准实体
4. **功能需求列表**：每个功能点用用户故事格式描述，附验收标准
5. **非功能需求**（如有）：性能、安全、日志等要求

格式参考 [solution-template.md](references/solution-template.md) 中的需求文档模板。

### 0.4 用户确认需求文档

将需求文档呈现给用户确认。

**⛔ 门禁：必须等待用户明确确认需求文档后，才能进入技术设计阶段。**

确认话术示例：
> 需求文档已生成，请审阅 `solutions/{feature-name}/requirements.md`。确认没问题后我再进行技术方案设计。

---

## 阶段一：方案设计 + 技术设计

**前置条件：用户已确认需求文档 ✅**

### 1.1 业务对象识别

从需求中提取涉及的业务对象，标注是标准实体还是自定义实体：

| 对象 | API Key | 是否标准实体 | 用途 |
|------|---------|-------------|------|
| 商机 | Opportunity | 是 | 核心数据 |
| 自定义实体 | myEntity__c | 否（需新建） | 扩展数据 |

这一步要显式完成，因为业务对象直接影响后续所有设计决策。

### 1.2 功能设计

将需求拆解为可独立实现的功能模块：

1. 列出功能清单，每个功能标注实现方式（前端组件 / 后端 API / Trigger 等）
2. 确认数据流向：数据从哪里来、到哪里去、经过哪些处理
3. 如果用户提供了原型图/HTML，先解析原型再做功能设计，确保设计与原型一致

### 1.3 历史资产读取

**仅在修改老功能或迭代已有功能时执行**。

读取项目中已有的前端组件和后端代码包文档，了解现有实现：
- 前端组件：读取 `src/components/*/doc.md`，了解组件功能和依赖关系
- 后端代码包：读取 `src/codePackages/*/doc.md`，了解 API 接口和触发器配置
- 实体模型：读取 `src/xObjects/fields/*.md`，了解已有实体字段

这一步必须在技术设计之前完成——先知道系统里已经有什么，才能决定是改还是建。

### 1.4 实体模型评估

评估现有实体能否满足需求：
- 读取已有实体字段定义（通过 `node neo-entity-management/scripts/gen_entity_desc.js` 或已有的实体模型文档）
- 判断是否需要新建自定义实体
- 判断是否需要在标准实体上添加自定义字段
- 列出需要新建或修改的实体和字段清单

输出：

| 实体 | API Key | 操作 | 字段变更 |
|------|---------|------|----------|
| 商机 | Opportunity | 扩展 | 新增 customField__c |
| 快照 | snapshot__c | 新建 | 全部字段 |

### 1.5 平台能力评估

根据功能清单，逐项评估实现方式，参考 [platform-capabilities.md](references/platform-capabilities.md) 和 [rest-api-reference.md](../neo-backend-dev/references/rest-api-reference.md)：

**核心判断逻辑**：
- 平台有现成 API 的数据 → 前端直调，不经后端中转
- 需要 SQL 聚合/多表关联/复杂逻辑 → 自定义 API
- 数据校验/同步/级联 → Trigger
- 定时批量处理 → 计划作业
- AI 能力调用 → 前端可直接调用提示词模板 API（`/rest/data/v2.0/ai/prompt/actions/getExecuteData`），复杂 AI 逻辑走后端自定义 API

**常见的"前端直调"场景**（不需要后端中转）：
- 商机阶段列表：`POST /rest/data/v2.0/xobjects/stage/actions/getStageListByEntityTypeApiKey`
- 业务类型列表：`GET /rest/data/v2.0/xobjects/{apiKey}/busiType`
- 实体 CRUD：通过 neo-open-api 的 xObject
- BI 视图数据：`POST /rest/neobi/v2.0/bestoractices/queryDataTask`

更多场景参考 [design-patterns.md](references/design-patterns.md)。

### 1.6 后端设计

对每个后端代码包，明确：
- 代码包名称和 Java 包名（三级，other.{company}.{module}）
- 包含的扩展类型（Trigger / 自定义 API / 计划作业 / 流程扩展）

对每个 Trigger：
- 生效实体、触发动作、触发时机、执行逻辑

对每个自定义 API：
- 请求方式、路径、参数、返回结构、执行逻辑
- 路径格式：`/rest/data/v2.0/scripts/api/{baseUrl}/{path}`

对每个计划作业：
- 执行周期、执行逻辑

### 1.7 前端设计

**有自定义组件时必须，纯后端需求（如只有 Trigger/计划作业）可跳过。**

对每个需要自定义的前端组件，明确：
- 组件名称（以 `__c` 结尾）
- 功能描述
- 数据来源（xObject 直查实体 / customApi 调后端 API / 无接口调用 / 平台 API 直调）
- 页面类型（customPage / entityDetailPage / entityListPage 等）
- 可配置属性（propsSchema，无明确需求则留空）
- 依赖的后端 API 和平台 API 列表

### 1.8 输出技术方案文档

将设计结果输出为结构化的方案文档，格式参考 [solution-template.md](references/solution-template.md)。

技术设计文档输出到 `solutions/{feature-name}/design.md`。

方案文档中需包含依赖关系图：

```
前端组件A
├─→ 后端API-1（自定义API）→ {实体X, 实体Y}
├─→ 平台API-阶段接口 → {Stage}
└─→ 平台API-业务类型接口 → {EntityType}

Trigger（自动触发）
└─→ 实体X（add/before）
```

方案文档应包含足够的细节，使得：
- 后端开发者可以直接根据 API 设计和实体模型开始编码
- 前端开发者可以直接根据组件设计和 API 文档开始编码
- 如果前端不依赖自定义 API（只用平台 API），前后端可并行开发

### 1.9 用户确认技术方案

将技术设计文档呈现给用户确认。

**⛔ 门禁：必须等待用户明确确认技术方案后，才能进入任务拆分阶段。**

确认话术示例：
> 技术设计文档已生成，请审阅 `solutions/{feature-name}/design.md`。确认没问题后我再进行任务拆分。

---

## 阶段二：任务拆分

**前置条件：用户已确认技术设计文档 ✅**

### 2.1 生成任务列表

基于需求文档和技术设计文档，将实现工作拆分为可执行的任务列表，输出到 `solutions/{feature-name}/tasks.md`。

任务拆分规则：
1. **模型构建**（委托 neo-entity-management）：通过 Metadata API 创建实体和字段
2. **后端实现**：按代码包拆分，每个 API / Trigger / Job 一个子任务
3. **前端实现**：按组件拆分，每个组件一个子任务
4. **部署验证**：后端部署 + 前端发布 + 功能验证

每个任务应标注：
- 使用的技能包（neo-backend-dev / neo-frontend-dev）
- 依赖的前置任务
- 验收标准
- 对应的需求编号（可追溯性）

格式参考 [solution-template.md](references/solution-template.md) 中的任务文档模板。

### 2.2 用户确认任务列表

将任务列表呈现给用户确认。

**⛔ 门禁：必须等待用户明确确认任务列表后，才能进入编码实现阶段。**

确认话术示例：
> 任务列表已生成，请审阅 `solutions/{feature-name}/tasks.md`。确认没问题后可以开始编码实现。

用户确认任务列表后，进入阶段三编码实现（由 neo-backend-dev / neo-frontend-dev 技能包接管）。

---

## 阶段三：编码实现（交接说明）

本阶段由 neo-backend-dev 和 neo-frontend-dev 技能包执行。方案设计技能包在用户确认任务列表后完成使命。

## 设计原则

1. **平台优先**：优先使用平台标准能力，减少自定义开发
2. **前端直调**：平台有现成 API 的数据，前端直接调用，不经后端中转
3. **职责单一**：前端组件粒度适中，单个组件职责单一
4. **模块化**：后端 API 按业务模块组织代码包，避免单个包过大
5. **命名规范**：实体字段遵循平台命名规范（自定义字段以 `__c` 结尾）
6. **性能意识**：考虑平台限制（同步15秒超时、单次DML 10000条、缓存200KB等）
7. **聚合后移**：复杂查询和聚合逻辑放后端 API，前端只负责展示

# 示例组件

> 本目录摘录自 [neo-cmp-cli 内置模板](https://neo-cmp-docs.netlify.app/示例模板) 中的 **React + TypeScript** 示例组件源码，作为 `neo-frontend-dev` 技能的本地对照参考。每个组件目录包含完整的 `index.tsx` / `model.ts` / `style.scss`。

## 目录结构

```
examples/
├── README.md                                   # 本文件
├── neo-custom-cmp-template/                    # 通用业务模板（`neo init -t neo`）
│   ├── simpleCmp__c/                           # 简单示例组件，适合快速上手
│   ├── customApi__c/                           # 自定义 API 示例（通用代理 + 表格）
│   ├── entityDetail__c/                        # 实体数据详情（多列布局）
│   ├── entityForm__c/                          # 实体表单（新增数据）
│   ├── entityTable__c/                         # 实体数据表格（增删改查）
│   └── common/
│       └── EntityPickerList/                   # 关联字段选择器（entityForm/entityTable 共用）
└── neo-web-entity-grid/                        # PC 端大列表模板（`neo init -t neo-web-entity-grid`）
    ├── entityGrid__c/                          # 基础大列表（NeoEntityGrid 基础用法）
    ├── entityGrid2__c/                         # 自定义筛选列表（BaseCmp + 广播监听 + 动态筛选联动）
    ├── entityGrid3__c/                         # Picker 列表（NeoEntityGrid pickView 模式，子组件）
    ├── entityGrid4__c/                         # 大列表/自定义工具栏（customToolbarButtons 扩展）
    ├── createForm__c/                          # 新增数据表单（xObject.create + 事件动作）
    └── searchForm__c/                          # 自定义查询表单（xObject 查询条件 + 事件动作）
```

## 组件与平台能力对照

| 组件 | 文件 | 展示的平台能力 |
|---|---|---|
| `simpleCmp__c` | `neo-custom-cmp-template/` | 最小化类组件 + `props.env.ctx` 获取系统语言 + `className` 合并 |
| `customApi__c` | `neo-custom-cmp-template/` | `BaseCmp` + `NeoEvent.function` + `customApi.run` 通用代理 + `antd Table` + `propsSchema.customApi` |
| `entityDetail__c` | `neo-custom-cmp-template/` | `xObject.getDesc` 获取字段描述 + `xObject.get` 获取详情 + `xObjectDetailApi` 配置 + 多列布局 + 按字段类型渲染 |
| `entityForm__c` | `neo-custom-cmp-template/` | `NeoEvent.dispatch` + `xObject.getDesc` + `xObject.create` 新增 + `antd Form` + 关联字段选择（`EntityPickerList`） + `xObjectDataApi` 配置 |
| `entityTable__c` | `neo-custom-cmp-template/` | `BaseCmp` + `NeoEvent.function` + 完整 CRUD（`query/create/update/delete`） + 分页 + 编辑模态框 + `xObjectDataApi` 配置 |
| `entityGrid__c` | `neo-web-entity-grid/` | `NeoEntityGrid` 基础用法 + `xObjectEntityList` + `dataViewIdSelect` + 功能开关显隐控制 |
| `entityGrid2__c` | `neo-web-entity-grid/` | `BaseCmp` + `NeoEvent.function` + `NeoEvent.listen` 广播监听 + `additionalConditions` 动态筛选联动 |
| `entityGrid3__c` | `neo-web-entity-grid/` | `exposedToDesigner: false` 子组件 + `NeoEntityGrid pickView` Picker 模式 + 单选/多选 |
| `entityGrid4__c` | `neo-web-entity-grid/` | `customToolbarButtons` 自定义工具栏头部/底部插槽 + `customRender` 自定义渲染 |
| `createForm__c` | `neo-web-entity-grid/` | `NeoEvent.dispatch`（含 eventParams 定义） + `xObject.create` + 关联字段 Modal 选择 + 动态表单 |
| `searchForm__c` | `neo-web-entity-grid/` | `NeoEvent.dispatch` 触发 onQuery + 查询条件映射（type 1/3） + 值归一化 + 关联字段选择 |

## 使用方式

开发新组件时，可以先找到最接近需求的示例组件，参照其目录结构、`model.ts` 的 `propsSchema` 写法、数据接入方式（`xObject` / `customApi`）、事件动作模式等。

- **纯展示** → 参考 `simpleCmp__c`
- **需要调外部 API** → 参考 `customApi__c`
- **需要读写平台实体** → 参考 `entityDetail__c` / `entityForm__c` / `entityTable__c`
- **需要 PC 端大列表** → 参考 `entityGrid__c` / `entityGrid2__c` / `entityGrid4__c`
- **需要 Picker 选择器** → 参考 `entityGrid3__c`（或 `EntityPickerList`）
- **需要新增表单** → 参考 `createForm__c` / `entityForm__c`
- **需要查询筛选表单** → 参考 `searchForm__c`（与 `entityGrid2__c` 联动）
- **需要自定义工具栏** → 参考 `entityGrid4__c`（`customToolbarButtons`）
- **需要事件动作联动** → 参考 `customApi__c`（`@NeoEvent.function`）或 `entityTable__c`（`BaseCmp` + `@NeoEvent.function`）
- **需要触发表单提交/查询事件** → 参考 `createForm__c` / `searchForm__c`（`@NeoEvent.dispatch` + `eventParams`）
- **需要广播监听** → 参考 `entityGrid2__c`（`NeoEvent.listen`）

> **注意**：这些是模板内置的示例组件，并非可直接运行的最小可运行示例。完整的最小可运行示例（`infoCard__c`，含 `@NeoEvent.dispatch` / `@NeoEvent.function`）见 `references/minimal-example.md`。
>
> **命名规范**：`examples/neo-custom-cmp-template/common/EntityPickerList` 是跨组件复用的自研 UI 子组件（非平台独立组件），因此不遵循 `__c` 后缀约定。它放在 `common/` 目录下（对应 SKILL.md 硬约束 1 的 `src/common/` 规范），不作为独立 `cmpType` 注册，无需 `__c` 后缀。

## 跨组件依赖

`neo-web-entity-grid` 模板中的 `createForm__c` 和 `searchForm__c` 在关联字段选择弹窗中嵌入了 `entityGrid3__c`（Picker 列表）作为子组件。代码中通过 `import NeoEntityGrid from 'entityGrid3__c'` 直接引用。

**`neo.config.js` 中必须配置远程依赖**，否则 `createForm__c` 和 `searchForm__c` 运行时无法加载 `entityGrid3__c`：

```js
// neo.config.js
module.exports = {
  neoCommonModule: {
    remoteDeps: ['entityGrid3__c'], // 远程依赖组件（按 cmpType 填写）
    externals: ['entityGrid3__c'],  // 构建时剔除，运行时从远程组件加载
  },
  // ...
};
```

- `entityGrid3__c` 自身设置了 `exposedToDesigner: false`，不在设计器面板中展示，仅作为子组件被其他组件嵌入使用。
- 模块联邦机制详见 `references/module-sharing.md`。

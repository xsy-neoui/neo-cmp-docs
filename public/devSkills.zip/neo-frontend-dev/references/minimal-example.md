# 最小可运行示例（含事件动作）

> **本文档由 `SKILL.md` 的「最小可运行示例」章节拆分而来**，作为 `neo-frontend-dev` 技能的本地对照参考。主文档对应位置仅保留摘要与跳转链接。

目录 `src/components/infoCard__c/`，`cmpType` 即 `infoCard__c`。

### `types.ts`

```ts
export interface InfoCardProps {
  /** 卡片标题（propsSchema: panelInput） */
  title?: string;
  /** 尺寸（propsSchema: panelSelect） */
  size?: 'small' | 'middle' | 'large';
  /** 视觉风格（propsSchema: neoRadio） */
  variant?: 'primary' | 'ghost';
  /** 是否显示边框（propsSchema: panelSwitch） */
  showBorder?: boolean;
  /** 平台注入：设计器隐藏时注入 design-hide */
  className?: string;
  /** 平台注入：页面数据上下文 */
  data?: any;
  /** 平台注入：运行环境（含 ctx） */
  env?: any;
  /** 点击事件（propsSchema 不配，由事件动作面板绑定） */
  onCardClick?: (payload: { title: string }) => void;
}
```

### `index.tsx`（类组件 + 事件动作）

```tsx
import * as React from 'react';
import classnames from 'classnames';
// @ts-ignore 平台运行时注入，无需安装
import { BaseCmp, NeoEvent } from 'neo-ui-common';
import { InfoCardProps } from './types';
import './index.scss';

const SIZE_CLASS: Record<NonNullable<InfoCardProps['size']>, string> = {
  small: 'infoCard__c--sm',
  middle: 'infoCard__c--md',
  large: 'infoCard__c--lg',
};

export default class InfoCardC extends BaseCmp<InfoCardProps, {}> {
  constructor(props: InfoCardProps) {
    super(props);
    // 组件动作使用 this 时必须绑定上下文
    this.refresh = this.refresh.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  /** 对外可触发的事件（需在 model.events 声明） */
  @NeoEvent.dispatch
  onCardClick(payload: { title: string }) {
    // 标记为事件触发点；平台会按 model.events 注入绑定
    return payload;
  }

  /** 可被其他组件事件动作调用（需在 model.functions 声明） */
  @NeoEvent.function
  async refresh() {
    // 典型：重新拉一次数据；此处略
    this.forceUpdate();
  }

  handleClick() {
    const { title = '标题', onCardClick } = this.props;
    this.onCardClick({ title });
    onCardClick?.({ title });
  }

  render() {
    const { title = '标题', size = 'middle', variant = 'primary', showBorder = true, className } = this.props;
    return (
      <div
        className={classnames(
          'infoCard__c',               // 根类名必须与目录名一致
          SIZE_CLASS[size],
          `infoCard__c--${variant}`,
          { 'infoCard__c--bordered': showBorder },
          className,                    // 合并平台注入的 className（含 design-hide）
        )}
        onClick={this.handleClick}
      >
        <div className="infoCard__c__header">{title}</div>
        <div className="infoCard__c__body">{/* 业务内容 */}</div>
      </div>
    );
  }
}
```

### `index.scss`

```scss
.infoCard__c {
  display: flex;
  flex-direction: column;
  padding: 12px 16px;
  border-radius: 4px;
  background: #fff;

  &__header { font-weight: 600; font-size: 14px; }
  &__body   { margin-top: 8px; color: rgba(0, 0, 0, 0.65); }

  &--sm       { padding: 8px 12px; }
  &--md       { padding: 12px 16px; }
  &--lg       { padding: 16px 24px; }
  &--primary  { background: #e6f7ff; }
  &--ghost    { background: transparent; }
  &--bordered { border: 1px solid #d9d9d9; }
}
```

### `model.ts`

```ts
export class InfoCardModel {
  label = '信息卡片';
  description = '展示标题与业务信息的卡片组件';
  iconUrl = '';
  tags = ['自定义组件'];
  exposedToDesigner = true;
  enableDuplicate = true;
  targetPage = ['all'];
  targetObject = ['all'];
  targetApplication = ['all'];
  targetDevice = 'all';

  defaultComProps = {
    title: '标题',
    size: 'middle',
    variant: 'primary',
    showBorder: true,
  };

  /** 对外触发事件（对应组件里的 @NeoEvent.dispatch） */
  events = [
    { apiKey: 'onCardClick', label: '点击卡片后', helpText: '卡片被点击时触发' },
  ];

  /** 可被调用的组件动作（对应组件里的 @NeoEvent.function） */
  functions = [
    { apiKey: 'refresh', label: '刷新卡片', helpTextKey: '重新拉取数据并刷新显示' },
  ];

  /** 属性面板：使用平台真实类型 */
  propsSchema = [
    { type: 'panelInput', name: 'title', label: '标题', placeholder: '请输入标题' },
    {
      type: 'panelSelect',
      name: 'size',
      label: '尺寸',
      value: 'middle',
      options: [
        { label: '小', value: 'small' },
        { label: '中', value: 'middle' },
        { label: '大', value: 'large' },
      ],
    },
    {
      type: 'neoRadio',
      name: 'variant',
      label: '风格',
      options: [
        { label: '主要', value: 'primary' },
        { label: '虚线', value: 'ghost' },
      ],
    },
    { type: 'panelSwitch', name: 'showBorder', label: '显示边框', defaultChecked: true },
  ];
}

export default InfoCardModel;
```

> 更完整的 `propsSchema` 类型（`panelNumber` / `panelColor` / `neoDatePicker` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldDescApi` / `customApi` 等）见 `props-schema.md`。

## 参考

- `SKILL.md` — 11 步开发关键步骤
- `props-schema.md` — `propsSchema` 平台真实类型完全清单
- `examples/` — 更多实际组件示例源码

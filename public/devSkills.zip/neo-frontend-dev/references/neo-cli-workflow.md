# neo-cmp-cli 工作流

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

neo-cmp-cli 基于 [AKFun](https://github.com/wibetter/akfun) 提供项目初始化、编译构建、本地预览、外链调试、发布到 NeoCRM 等能力。

::: v-pre

## 命令速查

完整命令表中的 **交互点 → 询问话术 → 非交互式参数** 。`neo-frontend-dev` 开发中可直接调用的命令：

| 命令 | `neo-frontend-dev` 调用步骤 | 核心参数 |
|---|---|---|
| `neo create project` | 创建项目 | `--name <项目名>` |
| `neo init` | 按用户指定模板初始化组件项目 | `-t <type> -n <name>` |
| `neo create cmp` | 创建组件 | `-n <cmpName> -d <all\|web\|mobile>` |
| `neo preview` | 预览组件 | `-n <cmpName> -m <local\|online>` |
| `neo linkDebug` | 调试组件 | `-p <pc\|h5>` |
| `neo login` | 授权登录 | `-e <env>` |
| `neo push cmp` | 发布组件 | `-n <cmpName>` |

> **首次创建项目**：默认使用 `neo create project --name=<name>` 创建**空项目骨架**（推荐）；仅当用户明确指定模板类型（如 echarts / antd / neo-h5-cmps）时，才改为 `neo init -t <type> -n <name>`。

## `neo preview` vs `neo linkDebug`

| 维度 | `neo preview` | `neo linkDebug` |
|---|---|---|
| 场景 | 组件**不依赖**平台运行时（纯展示、固定数据） | 组件**依赖**平台数据源、上下文、事件动作 |
| 模块 | 本地 mock；不能用 `neo-ui-common` / `neo-ui-component-web` | 真实平台运行时；虚拟模块由平台注入 |
| 代码热更新 | ✅ | ✅ |
| 事件动作 / 组件联动 | ❌ | ✅ |

**经验法则**：只要组件 `import` 了 `neo-ui-common` / `neo-ui-component-*`，就直接用 `neo linkDebug`。

## `neo linkDebug` 流程

1. **启动**：`neo linkDebug`，终端输出脚本地址（通常 `http://localhost:1024/index.js`）。
2. **设计器启用 debug**：NeoCRM 页面设计器 URL 追加 `?debug=true` 并访问。
3. **添加外链**：左侧「外部链接」面板里添加上一步输出的脚本地址。
4. **拖入画布**：物料面板中找到自定义组件，拖到画布上联调。

## `neo.config.js` 常见配置

> 无需显式配置时，CLI 会根据 `src/components/` 自动生成入口。可在命令行输出中查看生成的 entry。

```js
module.exports = {
  settings: {
    enableESLint: true,
    enableESLintFix: false,
    enableStyleLint: true,
    enableStyleLintFix: false,
  },

  webpack: {
    // 自定义入口（会覆盖自动生成）
    // entry: { index: './src/index.js' },

    resolve: {
      extensions: ['.js', '.jsx', '.ts', '.tsx', '.vue', '.json'],
      alias: {
        '@': 'src',
      },
    },

    template: '',              // 自定义 HTML 模板路径
    sassResources: [           // 全局注入的 Sass 资源
      'src/assets/css/common.scss',
      'src/assets/css/mixin.scss',
    ],

    ignoreNodeModules: true,   // 是否忽略 node_modules（默认 false）
    allowList: [],             // ignoreNodeModules 为 true 时仍要打包的例外

    createDeclaration: false,  // 是否生成 .d.ts
    projectDir: ['./src'],
  },

  // 环境变量（用 #变量名# 占位符）
  envParams: {
    common: { '#version#': '20250822.1' },
    local: {
      '#dataApiBase#': 'http://localhost:1024',
      '#assetsPublicPath#': 'http://localhost:1024',
      '#routeBasePath#': '/',
    },
  },

  preview: {
    proxyTable: {
      '/api': {
        target: 'https://api.example.com',
        changeOrigin: true,
      },
    },
    https: false,
  },

  build2lib: {
    NODE_ENV: 'production',
    libraryName: '',
    assetsPublicPath: '/',
    productionSourceMap: false,
    productionGzip: false,
    bundleAnalyzerReport: false,
    ignoreNodeModules: true,
    allowList: [],
  },

  // 对每个命令单独配置 entry，会覆盖 webpack.entry
  linkDebug: { /* entry: {} */ },
  build2lib: { /* entry: {} */ },
  pushCmp:   { /* entry: {} */ },

  // 自定义 loader / plugin / babel plugin
  webpack: {
    moduleRules: [],
    plugins: [],
    babelPlugins: [
      // 例：antd 按需引入
      // ['import', { libraryName: 'antd', libraryDirectory: 'es', style: true }],
    ],
  },

  // 关闭样式自动隔离（不推荐）
  // disableAutoAddStyleScope: true,

  // 模块共享（详见 module-sharing.md）
  // neoCommonModule: { ... },
};
```

> 更多工程配置见 [AKFun 工程配置说明](https://www.npmjs.com/package/akfun)。

## 目录速查

```
<project>/
├── src/
│   ├── components/
│   │   └── <cmpName>__c/
│   │       ├── index.tsx
│   │       ├── model.ts
│   │       └── index.scss
│   ├── assets/
│   │   ├── img/
│   │   └── css/
│   │       ├── common.scss
│   │       └── mixin.scss
│   └── initData/            # 本地预览用的模拟 props
├── public/
│   └── template.html
├── @types/
├── neo.config.js
├── tsconfig.json
├── .prettierrc.js
├── commitlint.config.js
└── package.json
```

## 虚拟模块 externals（自建 Webpack 时参考）

`neo-ui-common` / `neo-ui-component-web` / `neo-ui-component-h5` 是**平台虚拟模块**（非真实 NPM 包），只在平台运行时注入。使用 `neo-cmp-cli` 默认会处理；自建 Webpack 需在 `externals` 中映射：

```js
module.exports = {
  externals: [
    { /* 其他对象形 externals */ },
    function (context, request, callback) {
      const neoModules = ['neo-ui-common', 'neo-ui-component-web', 'neo-ui-component-h5'];
      if (neoModules.includes(request)) {
        return callback(null, `neoRequire("${request}")`, 'commonjs');
      }
      callback();
    },
  ],
};
```

## 常见问题
以下仅列出与组件开发密切相关的常见问题：

- **`neo preview` 报「找不到 neo-ui-common」** → 虚拟模块，本地没有；改用 `neo linkDebug`。
- **发布后「属性里『是否显示』设为『否』未生效」** → 组件根节点没把 `props.className` 合进 DOM。
- **发布后「事件动作不执行」** → 组件未 `extends BaseCmp`；或组件动作里用 `this` 时构造函数没 `bind(this)`。
- **发布后「根节点样式未生效」** → 根节点 className 不是目录名，样式隔离作用域不匹配。

## 参考

- [安装](https://neo-cmp-docs.netlify.app/guide/安装)
- [CLI使用说明](https://neo-cmp-docs.netlify.app/guide/CLI使用说明)

:::

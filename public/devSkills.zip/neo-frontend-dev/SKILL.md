---
name: neo-frontend-dev
description: Neo 前端自定义组件开发技能（React 16 + TypeScript）。当用户需要：(1) 开发/实现/改造 Neo 平台自定义组件，(2) 编写组件 index.tsx/model.ts/propsSchema，(3) 对接平台数据源（xObject/customApi）和事件动作，(4) 使用平台预置组件（NeoEntityList/NeoEntityGrid），(5) 配置组件属性面板和样式隔离时，使用此技能。
---

# Neo 前端自定义组件开发

基于 neo-cmp-cli 工具链，辅助完成 NeoCRM 平台前端自定义组件的开发全流程。

## 前置条件

- 已全局安装 neo-cmp-cli：`npm i -g neo-cmp-cli`。通过 `neo -v` 检测是否已安装
- Node.js 环境

## 重要约定

- **前置检查**：收到开发需求后，先检查项目目录下 `solutions/` 是否存在已确认的任务列表（tasks.md）。如果不存在，**主动询问用户**："当前没有找到方案设计文档，是否需要先使用 neo-solution-design 技能包进行需求梳理和技术方案设计？这有助于明确组件设计、接口对接和任务拆分。" 用户选择跳过后才继续直接开发。
- **项目优先**：在创建任何代码文件之前，必须先完成工程项目的确认或创建（核心工作流第 1 步）。禁止在没有 `neo.config.js` 的目录下编写代码。
- 组件目录名必须以 `__c` 结尾（如 `helloNeo__c`）
- `neo login -e production` 默认登录生产环境。执行登录前必须询问用户要登录到哪个环境。环境参数：`production`、`gray`、`sandbox`、`cd`、`tencentuat`、`custom`
- `neo login` 执行后自动打开浏览器授权，轮询 `.neo-cli/token.json` 确认登录成功
- 执行 push/pull/delete 时直接执行，未登录失败后再询问环境并登录重试
- 执行 push/pull/delete 时使用组件目录全名（如 `helloNeo__c`）

## 核心工作流

### 1. 创建项目

**检查步骤**：
1. 在工作空间的子目录中搜索 `neo.config.js` 文件
2. 如果找到一个或多个项目，列出所有找到的项目目录，询问用户使用哪个项目
3. 如果没有找到任何项目，询问用户项目名称，然后执行创建

如果用户未指定项目名称，先询问。未指定路径则告知默认位置并询问是否修改。

必须使用 `neo create project` 命令创建项目，不要手动创建目录结构。该命令会生成完整的项目骨架（package.json、neo.config.js、src 目录等）。

```bash
neo create project -n <项目名称>
```

### 2. 登录租户

**前置检查**：先检查项目目录下 `.neo-cli/token.json` 是否存在。如果存在，说明已登录，跳过此步骤直接进入下一步。

如果未登录，先让用户选择要登录的环境，提供以下选项列表：

| 选项 | 环境值 | 说明 |
|------|--------|------|
| 线上生产环境（crm.xiaoshouyi.com） | `production` | 默认 |
| 沙盒环境（crm-sandbox.xiaoshouyi.com） | `sandbox` | |
| 自定义环境（在 neo.config.js / neoConfig 中自行配置） | `custom` | |

用户选择后，按以下步骤执行登录：

1. 在项目目录下后台启动 `neo login`（该命令会启动本地服务监听 `localhost:1028`，并打开浏览器授权页面，是长运行命令，必须后台启动）：
```bash
neo login -e <env>
```

2. 提示用户在浏览器中完成授权（用户登录并选择租户后，平台会回调 `http://localhost:1028/?code=xxx`，neo-cmp-cli 自动用 code 换取 token）

3. 轮询 `neo login` 进程的终端输出，检测到以下关键字之一即判定登录成功：
   - `登录成功`
   - `成功获取 access token`
   
   登录成功后，`neo login` 输出中会包含实例地址和租户信息，例如：
   ```
   ========== 登录成功 ==========
   实例地址: https://crm-gray.xiaoshouyi.com/
   当前租户信息: 销售易开发平台测试(灰度)（292408）
   当前登录用户: Whitn
   ```
   
   从输出中提取 `实例地址` 确认登录环境正确。

### 3. 创建组件

```bash
neo create cmp --name <组件名称>
```

组件名称必须以小写字母开头，且以`__c结尾

### 4. 组件开发

开发前参考示例了解最佳实践：
- 简单展示组件（无接口调用） → [references/helloBuddy-example.md](references/helloBuddy-example.md)
- 调用自定义 API 组件 → [references/oppStats-example.md](references/oppStats-example.md)
- 实体数据 CRUD 组件 → [references/entityTable-example.md](references/entityTable-example.md)
- 调用 AI 提示词模板 → [references/component-dev.md](references/component-dev.md)（"调用 AI 提示词模板"章节）

核心文件：`index.tsx`（渲染逻辑）+ `model.ts`（设计器配置）+ `doc.md`（组件文档）

每个组件目录下必须包含一个 `doc.md` 文件，用于描述组件功能和依赖关系。格式如下：

```markdown
# 组件名称

## 功能描述
简要说明组件的用途和核心功能。

## 依赖关系
- 被哪些组件/页面使用：列出使用了本组件的其他组件或页面
- 依赖的后端 API：列出本组件调用的自定义 API（如有）
- 依赖的实体数据源：列出本组件使用的实体对象（如有）

## 关联业务对象

| 对象名称 | API Key |
|----------|---------|
| 对象中文名 | apiKey |
```

组件创建或修改完成后，必须同步更新该组件目录下的 `doc.md`。如果修改影响了其他组件的依赖关系，也要同步更新相关组件的 `doc.md`。

开发组件时，如果用户没有明确要求可配置属性，model.ts 中的 `propsSchema` 和 `defaultComProps` 留空即可，不要主动添加可配置属性。

详细指南见 [references/component-dev.md](references/component-dev.md)。


### 5. 授权与发布

授权配置详见 [references/auth-config.md](references/auth-config.md)。

```bash
### 依赖安装策略

`npm install` 耗时较长，采用延迟安装 + 复用策略：

**触发时机**：仅在执行 `neo push cmp`（发布组件）前检查，不在项目创建时安装。后端代码包部署不需要 node_modules。

**执行流程**：
1. 检查当前项目目录下是否存在 `node_modules/`
2. 如果已存在，跳过安装
3. 如果不存在，先在工作区内查找其他已有 `node_modules/` 的 Neo 项目（查找同级目录下包含 `neo.config.js` 和 `node_modules/` 的目录）
4. 如果找到可复用的项目，直接复制其 `node_modules/` 到当前项目：`cp -r <其他项目>/node_modules <当前项目>/`
5. 如果没有可复用的项目，执行 `npm install`

### 5. 授权与发布 --name <组件名称>
neo pull cmp --name <组件名称>
neo delete cmp --name <组件名称>
neo logout
```

## 修改系统中已有组件

1. 本地没有则自动 `neo pull cmp --name <组件名称>`，拉取后自动读取代码
2. 询问用户修改哪个组件
3. 执行修改，参考 [references/entityTable-example.md](references/entityTable-example.md)
4. 自动递增版本号并发布，修改完成后主动询问是否发布

## 获取实体模型

### 生成实体字典
```bash
node neo-entity-management/scripts/gen_entitylist.js <项目目录>
```

### 查询实体字段
1. 在 `src/xObjects/AllxObjects.md` 中查找匹配实体
2. 检查 `src/xObjects/fields/<apiKey>.md` 是否存在
3. 不存在则运行：`node neo-entity-management/scripts/gen_entity_desc.js <项目目录> <apiKey>`

### 平台 API 参考

所有 API 携带 `Authorization: Bearer <access_token>`。token 和 API 基础地址从项目目录下 `.neo-cli/token.json` 读取，该文件在 `neo login` 成功后自动生成，包含 `access_token`（认证凭证）和 `instance_uri`（API 基础地址，由登录环境决定，如 production 对应 `https://crm.xiaoshouyi.com`）。
- 获取实体列表：`GET /rest/metadata/v2.0/xobjects/filter?custom=<true|false>&active=true`
- 获取实体字段：`GET /rest/metadata/v2.0/xobjects/<apiKey>/items`

## 命令速查

| 命令 | 说明 |
|------|------|
| `neo create project` | 创建空项目 |
| `neo create cmp` | 创建组件 |
| `neo login -e <env>` / `neo logout` | 登录/登出 |
| `neo push cmp` | 发布组件 |
| `neo pull cmp` | 拉取组件 |
| `neo delete cmp` | 删除组件 |

## 跨技能包委托

| 场景 | 委托方向 |
|:---|:---|
| 开发前需要确认实体字段 API Key、类型和选项值 | → 委托 neo-entity-management 查询 |
| 需要创建新实体或字段 | → 委托 neo-entity-management 处理 |
| 需要方案设计和任务拆分 | → 委托 neo-solution-design 处理 |
| 任务完成后需要总结 | → 委托 neo-task-summary 处理 |

## 注意事项

- 构建时自动剔除平台预置依赖（antd 4.9.4、react 16.x 等）
- 发布时自动添加样式隔离
- 当前暂不支持本地预览，需发布后查看
- 自定义 API 的调用路径是 `/rest/data/v2.0/scripts/api/{baseUrl}/{path}`，不是 `/rest/custom/v2.0/`
- `customApi.run` 返回的 `result.data` 可能是 JSON 字符串，需要 `typeof === 'string'` 时 `JSON.parse`，也可能是已解析的对象，始终做类型判断
- 开发涉及业务对象的功能前，必须先通过 `gen_entity_desc.js` 获取实体的真实字段模型
- 可使用 `query_crm.js` 工具验证数据查询：`node neo-entity-management/scripts/query_crm.js <项目目录> "<SQL>"`
- CRM 查询 SQL 中日期/时间条件必须使用时间戳（毫秒），如 `closeDate >= 1711900800000`，不要使用日期字符串格式
- **model.ts 必须使用 `export class XxxModel` 格式**，不能使用普通对象字面量导出，否则报 `"e is not a constructor"` 错误
- Windows 环境下安装 neo-cmp-cli 后如果提示"neo：无法将 neo 项识别为 cmdlet"，需要将 npm 全局路径加入 PATH

# Changelog

## 2026-04-15
- 新增：方案设计阶段编码前必须确认工程项目存在，代码必须放在项目目录的 src/codePackages/ 下
- 新增：部署 Trigger 遇到 order 冲突时自动将 order+1 重试
- 新增：SQL 日期条件参数为 null 时跳过拼接的最佳实践
- 新增：SQL 日期条件使用日期字符串格式，不用时间戳
- 新增：doc.md 中关联业务对象表格（对象名称 + API Key）
- 新增：doc.md 细化规则 — Trigger 记录实体/动作/时机/顺序/逻辑，自定义 API 产出完整接口文档
- 新增：组件/代码包修改后必须同步更新 doc.md
- 新增：每个代码包目录必须包含 doc.md
- 优化：登录流程 — 环境选项列表含域名、后台启动 neo login + 轮询终端输出检测登录成功
- 优化：登录后不再需要手动修改 neo.config.js
- 优化：强化三级包名规则 — 用户给出四级包名时自动纠正
- 优化：强化 QueryResult 无 getTotalSize() 方法的警告
- 优化：强化 @RestApi/@RestMapping/RequestMethod 正确注解名称
- 验证：通过 DeepSeek API 运行 32 项自动化测试，准确率 96.9%+

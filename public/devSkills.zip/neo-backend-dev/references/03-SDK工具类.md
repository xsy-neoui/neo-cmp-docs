# SDK 工具类

本文档汇总 NeoCRM PaaS SDK 中所有工具类的用法和代码示例。

---

## 1. 异步任务（FutureTask）

在同步脚本中提交异步任务，避免同步超时。

```java
import com.rkhd.platform.sdk.service.FutureTaskService;
import com.rkhd.platform.sdk.task.FutureTask;
import com.rkhd.platform.sdk.exception.AsyncTaskException;
import com.rkhd.platform.sdk.log.Logger;
import com.rkhd.platform.sdk.log.LoggerFactory;

// 提交异步任务（注意 catch AsyncTaskException，不是 ScriptBusinessException）
try {
    FutureTaskService.instance().addFutureTask(MyTask.class, "参数字符串");
} catch (AsyncTaskException e) {
    logger.error("创建异步任务失败：" + e.getMessage());
}
```

异步任务实现类：

```java
package other.{company}.{module};

import com.rkhd.platform.sdk.task.FutureTask;
import com.rkhd.platform.sdk.exception.ScriptBusinessException;
import com.rkhd.platform.sdk.log.Logger;
import com.rkhd.platform.sdk.log.LoggerFactory;

public class MyTask implements FutureTask {
    private static final Logger LOG = LoggerFactory.getLogger();

    @Override
    public void execute(String params) throws ScriptBusinessException {
        LOG.info("异步任务执行, 参数: " + params);
        // 业务逻辑
    }
}
```

通用异步分发模式（通过反射调用服务方法）：

```java
import com.rkhd.platform.sdk.task.FutureTask;
import com.rkhd.platform.sdk.exception.ScriptBusinessException;
import com.alibaba.fastjson.JSONObject;
import java.lang.reflect.Method;

public class BusTaskImpl implements FutureTask {
    @Override
    public void execute(String param) throws ScriptBusinessException {
        JSONObject json = JSONObject.parseObject(param);
        try {
            Method method = BusService.class.getMethod(
                json.getString("method"), String.class, JSONObject.class);
            method.invoke(new BusService(), json.getString("logLabel"), json.getJSONObject("param"));
        } catch (Exception e) {
            throw new ScriptBusinessException(e.getMessage());
        }
    }
}
```

**限制**：同步脚本中最多提交 50 次 | 异步脚本中不可调用 FutureTask | 异步最大运行 90 秒

---

## 2. 批量数据处理（BatchJobPro）

用于处理超大数据量（超过单次 DML 10,000 条限制），平台自动分批执行。**BatchJobPro 不需要 scriptTrigger.xml 配置**，它是工具类，被 ScheduleJob/API/Trigger 等调用。

```java
import com.rkhd.platform.sdk.task.BatchJobPro;
import com.rkhd.platform.sdk.task.param.*;
import com.rkhd.platform.sdk.model.XObject;
import com.rkhd.platform.sdk.service.BatchJobProService;
import com.rkhd.platform.sdk.exception.BatchJobException;
import com.rkhd.platform.sdk.log.Logger;
import com.rkhd.platform.sdk.log.LoggerFactory;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class MyBatchJobPro implements BatchJobPro<XObject> {
    private static final Logger LOG = LoggerFactory.getLogger();

    @Override
    public BatchJobData prepare(PrepareParam prepareParam) throws BatchJobException {
        String num = prepareParam.get("num");
        // ⚠️ prepare SQL 不支持 ORDER BY
        String sql = "SELECT id, name FROM myEntity__c WHERE id > 0 LIMIT " + num + ",1000";
        return new BatchJobDataBuilder().setSql(sql).setAdmin(true).buildQueryData();
    }

    @Override
    public void execute(List<XObject> records, BatchJobParam batchJobParam) {
        LOG.debug("待处理数据量：" + records.size());
        // 业务逻辑...
    }

    @Override
    public void finish(BatchJobParam batchJobParam) {
        LOG.debug("批处理结束");
    }
}

// 启动：传入自定义参数
Map<String, String> params = new HashMap<>();
params.put("num", "0");
BatchJobProService.instance().addBatchJob(MyBatchJobPro.class, params);
```

**限制**：每批 1~200 条 | 单个 prepare 最大 100,000 条 | 每日最大 1,000,000 条

---

## 3. 元数据服务（MetadataService）

获取实体业务类型，创建记录时必须设置 entityType。

```java
import com.rkhd.platform.sdk.service.MetadataService;
import com.rkhd.platform.sdk.model.MetadataModel;

// 获取默认业务类型
MetadataModel busiType = MetadataService.instance()
    .getBusiType("customEntity__c", "defaultBusiType");
Long entityTypeId = busiType.getId();

// 创建记录时设置
xObject.setAttribute("entityType", entityTypeId);
```

---

## 4. 日志工具（Logger）

```java
import com.rkhd.platform.sdk.log.Logger;
import com.rkhd.platform.sdk.log.LoggerFactory;

private static final Logger LOG = LoggerFactory.getLogger();

// 推荐的 accessId + logLabel 模式
private final String accessId = "[" + String.valueOf(System.currentTimeMillis()).substring(7) + "]";
String logLabel = String.format("%s对象[%s]操作：", accessId, id);

LOG.debug(logLabel + "开始处理");
LOG.info(logLabel + "处理完成");
LOG.warn(logLabel + "数据异常");
LOG.error(logLabel + "出错了-->" + e.getMessage(), e);
```

日志查看：系统后台 → 日志审计 → 业务逻辑代码日志 → 文本输出

---

## 5. 数据操作服务（XObjectService）

```java
import com.rkhd.platform.sdk.service.XObjectService;

XObjectService svc = XObjectService.instance();

// 查询
svc.query(sql);                          // 基本查询
svc.query(sql, true);                    // 包含已删除数据
svc.query(sql, true, true);              // 包含已删除 + 管理员权限

// 创建（返回 OperateResult，用 getDataId() 获取新 ID）
svc.insert(xObject);
svc.insert(xObject, true);               // 管理员权限
svc.insert(list, true, true);            // 批量，partialSuccess + admin

// 更新
svc.update(xObject);
svc.update(list, true, true);            // 批量

// 删除
svc.delete(xObject);
svc.delete(list, true);                  // 批量

// 锁定/解锁
svc.lock(xObject, true);
svc.unlock(xObject, true);

// 转移
svc.transfer(xObject, targetUserId, true);
```

**注意**：insert 不回填 ID 到原对象，必须从 OperateResult.getDataId() 获取

---

## 6. 内部接口调用（RkhdHttpClient）

调用销售易平台内部 `/rest/` 接口，自动处理认证。

```java
import com.rkhd.platform.sdk.http.RkhdHttpClient;
import com.rkhd.platform.sdk.http.RkhdHttpData;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

// POST 请求
RkhdHttpData data = RkhdHttpData.newBuilder()
    .callString("/rest/data/v2.0/some/api")
    .callType("POST")
    .header("xsy-criteria", "10")  // 管理员权限
    .body(jsonString)
    .build();
JSONObject result = RkhdHttpClient.instance().execute(data, JSON::parseObject);
```

常用请求头：

| 请求头 | 值 | 说明 |
|--------|-----|------|
| xsy-criteria | 10 | 管理员权限 |
| xsy-execoption | -36867 | 跳过校验规则（慎用） |
| xsy-execmode | continue | 部分成功继续 |
| xsy-execmode | stop | 任一失败全部回滚 |

---

## 7. 外部接口调用（CommonHttpClient）

调用第三方外部接口。

```java
import com.rkhd.platform.sdk.http.CommonHttpClient;
import com.rkhd.platform.sdk.http.CommonData;
import com.rkhd.platform.sdk.http.HttpResult;

// GET 请求
CommonData getData = CommonData.newBuilder()
    .callType("GET")
    .callString("https://external-api.com/data?id=123")
    .header("Authorization", "Bearer token")
    .build();
HttpResult result = CommonHttpClient.instance().execute(getData);
String body = result.getResult();

// POST 请求
CommonData postData = CommonData.newBuilder()
    .callType("POST")
    .callString("https://external-api.com/create")
    .header("Content-Type", "application/json")
    .body(jsonString)
    .build();
HttpResult postResult = CommonHttpClient.instance().execute(postData);
```

**限制**：最多 50 次/脚本 | 超时 10 秒 | 入参最大 15 MB

---

## 8. 关联表查询（XoqlService）

```java
import com.rkhd.platform.sdk.service.XoqlService;
import com.rkhd.platform.sdk.model.QueryResult;
import com.alibaba.fastjson.JSONObject;
import java.util.List;

// 返回 JSONObject（不是 XObject），用 getString()/getLong() 读取
QueryResult<JSONObject> result = XoqlService.instance().query(sql, true);
if (result.getSuccess()) {
    List<JSONObject> records = result.getRecords();
    for (JSONObject r : records) {
        Long id = r.getLong("id");
        String name = r.getString("accountName");
    }
}
```

适用场景：聚合查询 GROUP BY、子查询、跨实体关联

---

## 9. 租户级缓存（CacheService）

```java
import com.rkhd.platform.sdk.service.CacheService;

CacheService cache = CacheService.instance();
cache.put("myKey", "myValue");
String value = cache.get("myKey");
cache.remove("myKey");
```

**限制**：最大 200 KB | 最多 64 个 key | 同步 50 次 | 异步 100 次

---

## 10. 运行时上下文（ScriptRuntimeContext）

```java
import com.rkhd.platform.sdk.context.ScriptRuntimeContext;

ScriptRuntimeContext ctx = ScriptRuntimeContext.instance();
// 获取当前租户 ID、用户 ID 等运行时环境信息
```

---

## 11. 加解密工具（SymmetricCryptoUtil）

```java
import com.rkhd.platform.sdk.util.encrypt.SymmetricCryptoUtil;

String encrypted = SymmetricCryptoUtil.encrypt("明文数据", "密钥");
String decrypted = SymmetricCryptoUtil.decrypt(encrypted, "密钥");
```

---

## 12. 租户级参数配置（CustomConfigService）

```java
import com.rkhd.platform.sdk.service.CustomConfigService;
import java.util.Map;

Map<String, String> configs = CustomConfigService.instance().getConfigSet("configSetApiName");
String value = configs.get("configItemKey");
```

---

## 13. 邮件服务（EmailService）

```java
import com.rkhd.platform.sdk.service.EmailService;
import com.rkhd.platform.sdk.model.EmailBody;
import java.util.Arrays;

EmailBody body = EmailBody.newBuilder()
    .subject("邮件主题")
    .body("邮件内容")
    .smtpHost("smtp.163.com")
    .smtpPort("465")
    .isSSL(true)
    .receiverList(Arrays.asList("receiver@example.com"))
    .senderUserName("sender@163.com")
    .senderUserPass("password")
    .build();
EmailService.instance().sendEmail(body);
```

---

## 14. 分布式锁（LockService）

```java
import com.rkhd.platform.sdk.service.LockService;
import com.rkhd.platform.sdk.exception.LockServiceException;

LockService lockService = LockService.newLock(dataId.toString());
try {
    if (lockService.lock()) {
        // 业务逻辑（获取锁成功）
    }
} catch (LockServiceException e) {
    logger.error("获取锁异常：" + e.getMessage());
} finally {
    lockService.unLock();  // 必须在 finally 中释放
}
```

**限制**：最大同时 5000 个 key

---

## 15. AI 提示词模板（XAIPromptTemplateService）

### HTTP API 方式

```java
// POST /rest/data/v2.0/ai/prompt/actions/getExecuteData
// Body: { "apiKey": "模板APIKey", "stream": false, "variables": { "var1": "val1" } }
```

### SDK 方式

```java
import com.rkhd.platform.sdk.prompt.XAIPromptTemplateService;
import com.rkhd.platform.sdk.prompt.XAIPromptTemplateResult;

// 类名规则：{模板APIKey}__c
// 输入类：{类名}.{类名}Input
// 输出类：{类名}.{类名}Output
TemplateClass__c template = new TemplateClass__c();
TemplateClass__c.TemplateClass__cInput input = new TemplateClass__c.TemplateClass__cInput();
input.setVariable("value");
template.setInput(input);

XAIPromptTemplateResult<TemplateClass__c.TemplateClass__cOutput> result =
    XAIPromptTemplateService.instance().generate(template);
TemplateClass__c.TemplateClass__cOutput output = result.getData();
```

| 对比项 | HTTP API | SDK |
|--------|----------|-----|
| 适用场景 | Trigger、定时任务 | CustomApi |
| 类型安全 | 弱类型 | 强类型 |
| 灵活性 | 高（动态变量） | 低（预定义类） |

# NeoCRM Open API 参考

从 DITA 文档解析生成，包含平台 REST API 的请求方式、地址、参数和功能说明。

共 1399 个 API 接口

## API 概览

| 功能 | 请求方式 | API 地址 |
|------|----------|----------|
| 刷新令牌 |  | `https://login.xiaoshouyi.com/auc/oauth2/token` |
| 获取指定用户的Access Token | GET | `/rest/data/v2.0/oauth/token/actions/getDelegateToken` |
| 获取当前用户信息 | GET | `/rest/auc/v2.0/userInfo` |
| 获取对象描述 | GET | `/rest/data/v2.0/xobjects/{apiKey}/description` |
| 创建对象 | POST | `/rest/data/v2.0/xobjects/{apiKey}` |
| 更新对象 | PATCH | `/rest/data/v2.0/xobjects/{apiKey}/{id}` |
| 删除对象 | DELETE | `/rest/data/v2.0/xobjects/{apiKey}/{id}` |
| 获取对象信息 | GET | `/rest/data/v2.0/xobjects/{apiKey}/{id}` |
| 获取销售线索接口描述 | GET | `/rest/data/v2.0/xobjects/lead/description` |
| 创建销售线索 | POST | `/rest/data/v2.0/xobjects/lead` |
| 更新销售线索 | PATCH | `/rest/data/v2.0/xobjects/lead/{id}` |
| 锁定销售线索 | PUT | `/rest/data/v2.0/xobjects/lead/actions/locks/{id}/lock` |
| 解锁销售线索 | DELETE | `/rest/data/v2.0/xobjects/lead/actions/locks/{id}/lock` |
| 转换销售线索 | POST | `/rest/data/v2.0/xobjects/lead/actions/convert` |
| 删除销售线索 | DELETE | `/rest/data/v2.0/xobjects/lead/{id}` |
| 获取销售线索信息 | GET | `/rest/data/v2.0/xobjects/lead/{id}` |
| 变更销售线索跟进状态 | POST | `/rest/data/v2.0/xobjects/lead/actions/setLeadStatus` |
| 销售线索转换客户 | POST | `/rest/data/v2.0/xobjects/lead/actions/saveConvert` |
| 线索领取分配 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/claimOrAssign` |
| 线索回收 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/recycle` |
| 线索退回公海池 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/release` |
| 废弃线索公海池里的线索 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/batchClose` |
| 线索详情页废弃线索 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/close` |
| 线索恢复 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/recover` |
| 公海池线索改变分组 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/changeFromLeadHighSea` |
| 用户私池线索改变分组 | POST | `/rest/data/v2.0/xobjects/leadHighSea/actions/change` |
| 查询线索公海池分组 | GET | `/rest/data/v2.0/xobjects/lead/actions/getHighSeaList` |
| 公海池领取客户 | PATCH | `/rest/data/v2.0/highSea/account/claim` |
| 公海池分配客户 | PATCH | `/rest/data/v2.0/highSea/account/assign` |
| 初始化公海池分组 | PATCH | `/rest/data/v2.0/xobjects/account/actions/initHighSea` |
| 客户私池改变公海池分组 | PATCH | `/rest/data/v2.0/xobjects/account/actions/change` |
| 获取公海池列表 | GET | `/rest/data/v2.0/xobjects/account/actions/getHighSeaList` |
| 获取公海池退回原因列表 | GET | `/rest/data/v2.0/xobjects/account/actions/getHighSeaReleaseReasons` |
| 获取公海池操作日志列表 | GET | `/rest/data/v2.0/xobjects/account/actions/getHighSeaOperateLogs` |
| 区域公海领取 | PUT | `/rest/data/v2.0/xobjects/territory/actions/claim` |
| 区域公海退回 | PUT | `/rest/data/v2.0/xobjects/territory/actions/release` |
| 区域公海分配 | PUT | `/rest/data/v2.0/xobjects/territory/actions/assign` |
| 区域公海回收 | PUT | `/rest/data/v2.0/xobjects/territory/actions/recycle` |
| 区域公海废弃 | PUT | `/rest/data/v2.0/xobjects/territory/actions/close` |
| 区域公海删除 | PUT | `/rest/data/v2.0/xobjects/territory/actions/delete` |
| 区域公海解冻 | PUT | `/rest/data/v2.0/xobjects/territory/actions/unfreeze` |
| 区域公海恢复 | PUT | `/rest/data/v2.0/xobjects/territory/actions/recover` |
| 改变区域公海分组 | PUT | `/rest/data/v2.0/xobjects/territory/actions/change` |
| 查询区域公海分组 | POST | `/rest/data/v2.0/xobjects/territory/actions/highSeaList` |
| 获取销售机会接口描述 | GET | `/rest/data/v2.0/xobjects/opportunity/description` |
| 创建销售机会 | POST | `/rest/data/v2.0/xobjects/opportunity` |
| 更新销售机会 | PATCH | `/rest/data/v2.0/xobjects/opportunity/{id}` |
| 锁定销售机会 | PUT | `/rest/data/v2.0/xobjects/opportunity/actions/locks/{id}/lock` |
| 解锁销售机会 | DELETE | `/rest/data/v2.0/xobjects/opportunity/actions/locks/{id}/lock` |
| 合并销售机会 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/merge` |
| 删除销售机会 | DELETE | `/rest/data/v2.0/xobjects/opportunity/{id}` |
| 获取销售机会信息 | GET | `/rest/data/v2.0/xobjects/opportunity/{id}` |
| 商机输单 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/loseCheckApproval` |
| 商机输单重启 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/active` |
| 商机阶段实例描述 | GET | `/rest/data/v2.0/xobjects/oppProcess/description` |
| 商机阶段停留时间描述 | GET | `/rest/data/v2.0/xobjects/oppStagePeriod/description` |
| 商机阶段轨迹描述 | GET | `/rest/data/v2.0/xobjects/stageTrack/description` |
| 获取商机阶段关键信息 | POST | `/rest/data/v2.0/xobjects/stage/actions/getKeyinformationsByStageId` |
| 获取商机来源选项信息 | GET | `/rest/data/v2.0/xobjects/stage/actions/getOpportunitySourceOptions` |
| 获取商机阶段流程类型 | GET | `/rest/data/v2.0/xobjects/oppProcess/actions/processType` |
| 推进商机阶段 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/changeStage` |
| 批量查询商机阶段 | GET | `/rest/data/v2.0/xobjects/opportunity/stages` |
| 根据商机业务类型查询商机阶段 | POST | `/rest/data/v2.0/xobjects/stage/actions/getStageListByEntityTypeApiKey` |
| 按业务类型分组查询商机阶段 | POST | `/rest/data/v2.0/xobjects/stage/actions/groupByEntity` |
| 获取商机阶段红绿灯状态 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/checkOpportunityTipsData` |
| 商机输单保存 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/lose` |
| 获取商机阶段关键事件 | POST | `/rest/data/v2.0/xobjects/oppProcess/actions/listByOpp` |
| 选中或取消关键事件 | POST | `/rest/data/v2.0/xobjects/opportunity/actions/activitySet` |
| 获取商机阶段关键事件文件 | POST | `/rest/data/v2.0/xobjects/stage/actions/getKeyFileByOpportunity` |
| 根据客户获取商机阶段关键事件文件数量 | POST | `/rest/data/v2.0/xobjects/stage/actions/getKeyFileCountByAccount` |
| 根据客户获取商机阶段关键事件文件 | POST | `/rest/data/v2.0/xobjects/stage/actions/getKeyFileByAccount` |
| 删除关键事件文档 | DELETE | `/rest/data/v2.0/xobjects/oppProcess/actions/deleteKeyFileById` |
| 获取商机联系人接口描述 | GET | `/rest/data/v2.0/xobjects/opportunityRegisterContact/description` |
| 创建商机联系人 | POST | `/rest/data/v2.0/xobjects/opportunityRegisterContact` |
| 更新商机联系人 | PATCH | `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}` |
| 删除商机联系人 | DELETE | `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}` |
| 获取商机联系人信息 | GET | `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}` |
| 获取商机报备接口描述 | GET | `/rest/data/v2.0/xobjects/opportunityRegister/description` |
| 创建商机报备 | POST | `/rest/data/v2.0/xobjects/opportunityRegister` |
| 更新商机报备 | PATCH | `/rest/data/v2.0/xobjects/opportunityRegister/{id}` |
| 删除商机报备 | DELETE | `/rest/data/v2.0/xobjects/opportunityRegister/{id}` |
| 获取商机报备信息 | GET | `/rest/data/v2.0/xobjects/opportunityRegister/{id}` |
| 获取客户接口描述 | GET | `/rest/data/v2.0/xobjects/account/description` |
| 创建客户 | POST | `/rest/data/v2.0/xobjects/account` |
| 更新客户 | PATCH | `/rest/data/v2.0/xobjects/account/{id}` |
| 锁定客户 | PUT | `/rest/data/v2.0/xobjects/account/actions/locks/{id}/lock` |
| 解锁客户 | DELETE | `/rest/data/v2.0/xobjects/account/actions/locks/{id}/lock` |
| 合并客户 | POST | `/rest/data/v2.0/xobjects/account/actions/merge` |
| 废弃客户 | PATCH | `/rest/data/v2.0/xobjects/account/actions/close` |
| 删除客户 | DELETE | `/rest/data/v2.0/xobjects/account/{id}` |
| 获取客户信息 | GET | `/rest/data/v2.0/xobjects/account/{id}` |
| 客户退回公海池 | PATCH | `/rest/data/v2.0/xobjects/account/actions/release` |
| 查询首页排行榜 | POST | `/rest/data/v2.0/xobjects/account/actions/queryRank` |
| 客户名称查重 | POST | `/rest/data/v2.0/xobjects/account/actions/queryByKeywords` |
| 获取联系人接口描述 | GET | `/rest/data/v2.0/xobjects/contact/description` |
| 创建联系人 | POST | `/rest/data/v2.0/xobjects/contact` |
| 更新联系人 | PATCH | `/rest/data/v2.0/xobjects/contact/{id}` |
| 锁定联系人 | PUT | `/rest/data/v2.0/xobjects/contact/actions/locks/{id}/lock` |
| 解锁联系人 | DELETE | `/rest/data/v2.0/xobjects/contact/actions/locks/{id}/lock` |
| 删除联系人 | DELETE | `/rest/data/v2.0/xobjects/contact/{id}` |
| 获取联系人信息 | GET | `/rest/data/v2.0/xobjects/contact/{id}` |
| 查询联系人名片 | GET | `/rest/data/v2.0/xobjects/contact/actions/getBusinessCardByContactId` |
| 保存联系人名片 | POST | `/rest/data/v2.0/xobjects/contact/actions/saveBusinessCard` |
| 查询当前租户客户的状态是否符合自动创建客户 | GET | `/rest/data/v2.0/xobjects/contact/actions/isCreateAccount` |
| 获取客户账户接口描述 | GET | `/rest/data/v2.0/xobjects/customerAccount/description` |
| 创建客户账户 | POST | `/rest/data/v2.0/xobjects/customerAccount` |
| 更新客户账户 | PATCH | `/rest/data/v2.0/xobjects/customerAccount/{id}` |
| 锁定客户账户 | PUT | `/rest/data/v2.0/xobjects/customerAccount/actions/locks/{id}/lock` |
| 解锁客户账户 | DELETE | `/rest/data/v2.0/xobjects/customerAccount/actions/locks/{id}/lock` |
| 获取客户账户信息 | GET | `/rest/data/v2.0/xobjects/customerAccount/{id}` |
| 获取客户账户明细接口描述 | GET | `/rest/data/v2.0/xobjects/customerAccountDetail/description` |
| 创建账户明细并更新账户数据 | POST | `/rest/data/v2.0/xobjects/customerAccountDetail/actions/save` |
| 更新客户账户明细状态 | POST | `/rest/data/v2.0/xobjects/customerAccountDetail/actions/updateStatus?id={id}` |
| 获取账户明细信息 | GET | `/rest/data/v2.0/xobjects/customerAccountDetail/{id}` |
| 获取账户配置接口描述 | GET | `/rest/data/v2.0/xobjects/customerAccountSetting/description` |
| 创建账户配置 | POST | `/rest/data/v2.0/xobjects/customerAccountSetting` |
| 更新账户配置 | PATCH | `/rest/data/v2.0/xobjects/customerAccountSetting/{id}` |
| 锁定账户配置 | PUT | `/rest/data/v2.0/xobjects/customerAccountSetting/actions/locks/{id}/lock` |
| 解锁账户配置 | DELETE | `/rest/data/v2.0/xobjects/customerAccountSetting/actions/locks/{id}/lock` |
| 删除账户配置 | DELETE | `/rest/data/v2.0/xobjects/customerAccountSetting/{id}` |
| 获取账户配置信息 | GET | `/rest/data/v2.0/xobjects/customerAccountSetting/{id}` |
| 获取账户转账接口描述 | GET | `/rest/data/v2.0/xobjects/accountTransfer/description` |
| 获取拜访计划接口描述 | GET | `/rest/data/v2.0/xobjects/visitPlan/description` |
| 创建拜访计划 | POST | `/rest/data/v2.0/xobjects/visitPlan` |
| 更新拜访计划 | PATCH | `/rest/data/v2.0/xobjects/visitPlan/{id}` |
| 锁定拜访计划 | POST | `/rest/data/v2.0/xobjects/visitPlan/actions/locks` |
| 解锁拜访计划 | DELETE | `/rest/data/v2.0/xobjects/visitPlan/actions/locks` |
| 删除拜访计划 | DELETE | `/rest/data/v2.0/xobjects/visitPlan/{id}` |
| 获取拜访计划信息 | GET | `/rest/data/v2.0/xobjects/visitPlan/{id}` |
| 获取拜访路线接口描述 | GET | `/rest/data/v2.0/xobjects/visitRoute/description` |
| 创建拜访路线 | POST | `/rest/data/v2.0/xobjects/visitRoute` |
| 更新拜访路线 |  | `/rest/data/v2.0/xobjects/visitRoute/{id}` |
| 删除拜访路线 | DELETE | `/rest/data/v2.0/xobjects/visitRoute/{id}` |
| 获取拜访路线信息 | GET | `/rest/data/v2.0/xobjects/visitRoute/{id}` |
| 获取拜访路线与客户关系接口描述 | GET | `/rest/data/v2/objects/visitRouteAccountRel/description` |
| 创建拜访路线与客户关系 | POST | `/rest/data/v2/objects/visitRouteAccountRel` |
| 删除拜访路线与客户关系 | DELETE | `/rest/data/v2/objects/visitRouteAccountRel/{id}` |
| 获取拜访路线与客户关系信息 | GET | `/rest/data/v2/objects/visitRouteAccountRel/{id}` |
| 查询拜访路线与客户关系列表 | GET | `/rest/data/v2/objects/visitRouteAccountRel/list` |
| 获取拜访计划与拜访路线关系接口描述 | GET | `/rest/data/v2/objects/visitPlanRouteRel/description` |
| 创建拜访计划与拜访路线关系 | POST | `/rest/data/v2/objects/visitPlanRouteRel` |
| 删除拜访计划与拜访路线关系 | DELETE | `/rest/data/v2/objects/visitPlanRouteRel/{id}` |
| 获取拜访计划与拜访路线关系信息 | GET | `/rest/data/v2/objects/visitPlanRouteRel/{id}` |
| 获取拜访记录接口描述 | GET | `/rest/data/v2.0/xobjects/visitRecord/description` |
| 获取拜访记录信息 | GET | `/rest/data/v2.0/xobjects/visitRecord/{id}` |
| 获取拜访日程接口描述 | GET | `/rest/data/v2.0/xobjects/visitPlanDetail/description` |
| 创建拜访日程 | POST | `/rest/data/v2.0/xobjects/visitPlanDetail` |
| 更新拜访日程 | PATCH | `/rest/data/v2.0/xobjects/visitPlanDetail/{id}` |
| 删除拜访日程 | DELETE | `/rest/data/v2.0/xobjects/visitPlanDetail/{id}` |
| 获取拜访日程信息 | GET | `/rest/data/v2.0/xobjects/visitPlanDetail/{id}` |
| 统计每天的拜访日程个数 | POST | `/rest/data/v2.0/xobjects/visitPlanDetail/actions/countVisitDetail` |
| 获取某一天的拜访日程 |  | `/rest/data/v2.0/xobjects/visitPlanDetail/actions/listVisitDetailByDay` |
| 统计每天的拜访客次是否达标 |  | `/rest/data/v2.0/xobjects/visitPlanDetail/actions/statisticsVisit` |
| 统计拜访客次 | GET | `/rest/data/v2.0/xobjects/visitPlanDetail/actions/getVisitCountByPlan` |
| 周边拜访对象搜索 | POST | `/rest/data/v2.0/xobjects/visitPlanDetail/actions/searchAroundVisitObject` |
| 获取产品接口描述 | GET | `/rest/data/v2.0/xobjects/product/description` |
| 创建产品 | POST | `/rest/data/v2.0/xobjects/product` |
| 更新产品 | PATCH | `/rest/data/v2.0/xobjects/product/{id}` |
| 锁定产品 | PUT | `/rest/data/v2.0/xobjects/product/actions/locks/{id}/lock` |
| 解锁产品 | DELETE | `/rest/data/v2.0/xobjects/product/actions/locks/{id}/lock` |
| 删除产品 | DELETE | `/rest/data/v2.0/xobjects/product/{id}` |
| 获取产品信息 | GET | `/rest/data/v2.0/xobjects/product/{id}` |
| 获取产品需求接口描述 | GET | `/rest/data/v2.0/xobjects/productRequirement/description` |
| 创建产品需求 | POST | `/rest/data/v2.0/xobjects/productRequirement` |
| 更新产品需求 | PATCH | `/rest/data/v2.0/xobjects/productRequirement/{id}` |
| 删除产品需求 | DELETE | `/rest/data/v2.0/xobjects/productRequirement/{id}` |
| 获取产品需求信息 | GET | `/rest/data/v2.0/xobjects/productRequirement/{id}` |
| 创建产品选项 | POST | `/rest/data/v2.0/xobjects/productOption` |
| 更新产品选项 | PATCH | `/rest/data/v2.0/xobjects/productOption/{id}` |
| 删除产品选项 | DELETE | `/rest/data/v2.0/xobjects/productOption/{id}` |
| 获取产品选项信息 | GET | `/rest/data/v2.0/xobjects/productOption/{id}` |
| 创建产品功能 | POST | `/rest/data/v2.0/xobjects/productFeature` |
| 更新产品功能 | PATCH | `/rest/data/v2.0/xobjects/productFeature/{id}` |
| 删除产品功能 | DELETE | `/rest/data/v2.0/xobjects/productFeature/{id}` |
| 获取产品功能信息 | GET | `/rest/data/v2.0/xobjects/productFeature/{id}` |
| 创建产品约束 | POST | `/rest/data/v2.0/xobjects/optionConstraint` |
| 更新产品约束 | PATCH | `/rest/data/v2.0/xobjects/optionConstraint/{id}` |
| 删除产品约束 | DELETE | `/rest/data/v2.0/xobjects/optionConstraint/{id}` |
| 获取产品约束信息 | GET | `/rest/data/v2.0/xobjects/optionConstraint/{id}` |
| 获取产品目录接口描述 | GET | `/rest/data/v2.0/xobjects/productCategory/description` |
| 创建产品目录 | POST | `/rest/data/v2.0/xobjects/productCategory` |
| 更新产品目录 | PATCH | `/rest/data/v2.0/xobjects/productCategory/{id}` |
| 删除产品目录 | DELETE | `/rest/data/v2.0/xobjects/productCategory/{id}` |
| 获取产品目录信息 | GET | `/rest/data/v2.0/xobjects/productCategory/{id}` |
| 获取产品目录树 | GET | `/rest/data/v2.0/xobjects/productCategory/actions/directoryTree` |
| 获取产品目录列表 | GET | `/rest/data/v2.0/xobjects/productCategory/actions/directoryList` |
| 创建组合产品 | POST | `/rest/data/v2.0/xobjects/product/actions/importProductBundles` |
| 获取合同接口描述 | GET | `/rest/data/v2.0/xobjects/contract/description` |
| 创建合同 | POST | `/rest/data/v2.0/xobjects/contract` |
| 更新合同 | PATCH | `/rest/data/v2.0/xobjects/contract/{id}` |
| 锁定合同 | PUT | `/rest/data/v2.0/xobjects/contract/actions/locks/{id}/lock` |
| 解锁合同 | DELETE | `/rest/data/v2.0/xobjects/contract/actions/locks/{id}/lock` |
| 转移合同 | POST | `/rest/data/v2.0/xobjects/contract/actions/transfers` |
| 删除合同 | DELETE | `/rest/data/v2.0/xobjects/contract/{id}` |
| 获取合同详细信息 | GET | `/rest/data/v2.0/xobjects/contract/{id}` |
| 批量获取合同信息 | POST | `/rest/data/v2.0/xobjects/contract/actions/info/batch` |
| 获取订单接口描述 | GET | `/rest/data/v2.0/xobjects/order/description` |
| 创建订单 | POST | `/rest/data/v2.0/xobjects/order` |
| 更新订单 | PATCH | `/rest/data/v2.0/xobjects/order/{id}` |
| 锁定订单 | PUT | `/rest/data/v2.0/xobjects/order/actions/locks/{id}/lock` |
| 解锁订单 | DELETE | `/rest/data/v2.0/xobjects/order/actions/locks/{id}/lock` |
| 删除订单 | DELETE | `/rest/data/v2.0/xobjects/order/{id}` |
| 订单生效 | PATCH | `/rest/data/v2.0/xobjects/order/actions/activation?recordId={orderId}` |
| 订单失效 | PATCH | `/rest/data/v2.0/xobjects/order/actions/deactivation?recordId={orderId}` |
| 订单作废 | PATCH | `/rest/data/v2.0/xobjects/order/actions/cancel?recordId={orderId}&cancelResonId={cancelReaSonId}` |
| 获取订单信息 | GET | `/rest/data/v2.0/xobjects/order/{id}` |
| 同步订单明细至商机 | POST | `/rest/data/v2.0/xobjects/order/actions/syncOpportunity` |
| 同步订单明细至报价单 | POST | `/rest/data/v2.0/xobjects/order/actions/syncQuote` |
| 查询当前订单业务类型是否支持合作伙伴自助下单 | GET | `/rest/data/v2.0/xobjects/order/actions/isOrderType4PRM?busiTypeId={busiTypeId}` |
| 查询订单新版 UI 开关是否打开 | GET | `/rest/data/v2.0/xobjects/order/actions/breezeSwitch?deviceTypeId={deviceTypeId}` |
| 判断客户字段是否可编辑 | GET | `/rest/data/v2.0/xobjects/order/actions/validateAccount?orderId={orderId}` |
| 判断订单明细是否可修改 | GET | `/rest/data/v2.0/xobjects/order/actions/canUpdateDetail?srcObjectApiKey={srcObjectApiKey}&srcObjectEntityType={srcObjectEntityType}` |
| 获取订单明细描述 | GET | `/rest/data/v2.0/xobjects/orderProduct/description` |
| 创建订单明细 | POST | `/rest/data/v2.0/xobjects/orderProduct` |
| 更新订单明细 | PATCH | `/rest/data/v2.0/xobjects/orderProduct/{id}` |
| 锁定订单明细 | PUT | `/rest/data/v2.0/xobjects/orderProduct/actions/locks/{id}/lock` |
| 解锁订单明细 | DELETE | `/rest/data/v2.0/xobjects/orderProduct/actions/locks/{id}/lock` |
| 复制订单明细 | POST | `/rest/data/v2.0/xobjects/orderProduct/actions/copyOrderProduct?scrOrderId={scrOrderId}&targetOrderId={targetOrderId}` |
| 删除订单明细 | DELETE | `/rest/data/v2.0/xobjects/orderProduct/{id}` |
| 获取订单明细信息 | GET | `/rest/data/v2.0/xobjects/orderProduct/{id}` |
| 订单明细序号更新 | POST | `/rest/data/v2.0/xobjects/order/actions/batchReSort` |
| 获取订单支付关系接口描述 | GET | `/rest/data/v2.0/xobjects/orderPayment/description` |
| 创建订单支付关系 | POST | `/rest/data/v2.0/xobjects/orderPayment` |
| 更新订单支付关系 | PATCH | `/rest/data/v2.0/xobjects/orderPayment/{id}` |
| 删除订单支付关系 | DELETE | `/rest/data/v2.0/xobjects/orderPayment/{id}` |
| 获取订单支付关系信息 | GET | `/rest/data/v2.0/xobjects/orderPayment/{id}` |
| 查询支付表单字段 | GET | `/rest/data/v2.0/xobjects/orderPayment/actions/getPaymentItems` |
| 查询订单支付关系 | GET | `/rest/data/v2.0/xobjects/orderPayment/actions/findByOrderId` |
| 获取价格表接口描述 | GET | `/rest/data/v2.0/xobjects/priceBook/description` |
| 创建价格表 | POST | `/rest/data/v2.0/xobjects/priceBook` |
| 更新价格表 | PATCH | `/rest/data/v2.0/xobjects/priceBook/{id}` |
| 锁定价格表 | PUT | `/rest/data/v2.0/xobjects/priceBook/actions/locks/{id}/lock` |
| 解锁价格表 | DELETE | `/rest/data/v2.0/xobjects/priceBook/actions/locks/{id}/lock` |
| 删除价格表 | DELETE | `/rest/data/v2.0/xobjects/priceBook/{id}` |
| 获取价格表信息 | GET | `/rest/data/v2.0/xobjects/priceBook/{id}` |
| 获取价格表明细接口描述 | GET | `/rest/data/v2.0/xobjects/priceBookEntry/description` |
| 创建价格表明细 | POST | `/rest/data/v2.0/xobjects/priceBookEntry` |
| 更新价格表明细 | PATCH | `/rest/data/v2.0/xobjects/priceBookEntry/{id}` |
| 锁定价格表明细 | PUT | `/rest/data/v2.0/xobjects/priceBookEntry/actions/locks/{id}/lock` |
| 解锁价格表明细 | DELETE | `/rest/data/v2.0/xobjects/priceBookEntry/actions/locks/{id}/lock` |
| 删除价格表明细 | DELETE | `/rest/data/v2.0/xobjects/priceBookEntry/{id}` |
| 获取价格表明细信息 | GET | `/rest/data/v2.0/xobjects/priceBookEntry/{id}` |
| 获取阶梯价格表接口描述 | GET | `/rest/data/v2.0/xobjects/priceSchedule/description` |
| 创建阶梯价格表 | POST | `/rest/data/v2.0/xobjects/priceSchedule` |
| 更新阶梯价格表 | PATCH | `/rest/data/v2.0/xobjects/priceSchedule/{id}` |
| 删除阶梯价格表 | DELETE | `/rest/data/v2.0/xobjects/priceSchedule/{id}` |
| 获取阶梯价格表信息 | GET | `/rest/data/v2.0/xobjects/priceSchedule/{id}` |
| 获取阶梯价格表明细接口描述 | GET | `/rest/data/v2.0/xobjects/priceTier/description` |
| 创建阶梯价格表明细 | POST | `/rest/data/v2.0/xobjects/priceTier` |
| 更新阶梯价格表明细 | PATCH | `/rest/data/v2.0/xobjects/priceTier/{id}` |
| 删除阶梯价格表明细 | DELETE | `/rest/data/v2.0/xobjects/priceTier/{id}` |
| 获取阶梯价格表明细信息 | GET | `/rest/data/v2.0/xobjects/priceTier/{id}` |
| 获取产品阶梯价格表接口描述 | GET | `/rest/data/v2.0/xobjects/productPriceSchedule/description` |
| 创建产品阶梯价格表 | POST | `/rest/data/v2.0/xobjects/productPriceSchedule` |
| 更新产品阶梯价格表 | PATCH | `/rest/data/v2.0/xobjects/productPriceSchedule/{id}` |
| 删除产品阶梯价格表 | DELETE | `/rest/data/v2.0/xobjects/productPriceSchedule/{id}` |
| 获取产品阶梯价格表信息 | GET | `/rest/data/v2.0/xobjects/productPriceSchedule/{id}` |
| 获取产品选项阶梯价格表接口描述 | GET | `/rest/data/v2.0/xobjects/productOptionPriceSchedule/description` |
| 创建产品选项阶梯价格表 | POST | `/rest/data/v2.0/xobjects/productOptionPriceSchedule` |
| 更新产品选项阶梯价格表 | PATCH | `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}` |
| 删除产品选项阶梯价格表 | DELETE | `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}` |
| 获取产品选项阶梯价格表信息 | GET | `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}` |
| 获取产品功能阶梯价格接口表描述 | GET | `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/description` |
| 创建产品功能阶梯价格表 | POST | `/rest/data/v2.0/xobjects/productFeaturePriceSchedule` |
| 更新产品功能阶梯价格表 | PATCH | `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}` |
| 删除指定产品功能阶梯价格表 | DELETE | `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}` |
| 获取产品功能阶梯价格表信息 | GET | `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}` |
| 复制产品价格规则 | GET | `/rest/data/v2.0/xobjects/cpqRule/actions/copy` |
| 复制规则组合 | GET | `/rest/data/v2.0/xobjects/ruleSet/actions/copy` |
| 查询生效的产品价格规则 | GET | `/rest/data/v2.0/xobjects/cpqRule/actions/query` |
| 获取报价单接口描述 | GET | `/rest/data/v2.0/xobjects/quote/description` |
| 创建报价单 | POST | `/rest/data/v2.0/xobjects/quote` |
| 更新报价单 | PATCH | `/rest/data/v2.0/xobjects/quote/{id}` |
| 删除报价单 | DELETE | `/rest/data/v2.0/xobjects/quote/{id}` |
| 获取报价单信息 | GET | `/rest/data/v2.0/xobjects/quote/{id}` |
| 同步报价单明细至商机 | POST | `/rest/data/v2.0/xobjects/quote/actions/syncOpportunity` |
| 获取报价单明细接口描述 | GET | `/rest/data/v2.0/xobjects/quoteLine/description` |
| 创建报价单明细 | POST | `/rest/data/v2.0/xobjects/quoteLine` |
| 更新报价单明细 | PATCH | `/rest/data/v2.0/xobjects/quoteLine/{id}` |
| 复制报价单明细 | POST | `/rest/data/v2.0/xobjects/quote/actions/copyQuoteLine` |
| 删除报价单明细 | DELETE | `/rest/data/v2.0/xobjects/quoteLine/{id}` |
| 获取报价单明细信息 | GET | `/rest/data/v2.0/xobjects/quoteLine/{id}` |
| 报价单明细序号更新 | POST | `/rest/data/v2.0/xobjects/quote/actions/batchReSort` |
| 创建应收 | POST | `/rest/data/v2.0/xobjects/invoice` |
| 更新应收 | PATCH | `/rest/data/v2.0/xobjects/invoice/{id}` |
| 删除应收 | DELETE | `/rest/data/v2.0/xobjects/invoice/{id}` |
| 创建应收明细 | POST | `/rest/data/v2.0/xobjects/invoiceItem` |
| 更新应收明细 | PATCH | `/rest/data/v2.0/xobjects/invoiceItem/{id}` |
| 删除应收明细 | DELETE | `/rest/data/v2.0/xobjects/invoiceItem/{id}` |
| 创建应收变更单 | POST | `/rest/data/v2.0/xobjects/invoiceAdjustment` |
| 更新应收变更单 | PATCH | `/rest/data/v2.0/xobjects/invoiceAdjustment/{id}` |
| 删除应收变更单 | DELETE | `/rest/data/v2.0/xobjects/invoiceAdjustment/{id}` |
| 创建应收变更明细 | POST | `/rest/data/v2.0/xobjects/invoiceItemAdjustment` |
| 更新应收变更明细 | PATCH | `/rest/data/v2.0/xobjects/invoiceItemAdjustment/{id}` |
| 删除应收变更明细 | DELETE | `/rest/data/v2.0/xobjects/invoiceItemAdjustment/{id}` |
| 创建收款计划 | POST | `/rest/data/v2.0/xobjects/paymentApplicationPlan` |
| 更新收款计划 | PUT | `/rest/data/v2.0/xobjects/paymentApplicationPlan/{id}` |
| 删除收款计划 | DELETE | `/rest/data/v2.0/xobjects/paymentApplicationPlan/{id}` |
| 创建收款 | POST | `/rest/data/v2.0/xobjects/paymentApplication` |
| 更新收款 | PATCH | `/rest/data/v2.0/xobjects/paymentApplication/{id}` |
| 删除收款 | DELETE | `/rest/data/v2.0/xobjects/paymentApplication/{id}` |
| 生成收款 | POST | `/rest/data/v2.0/xobjects/paymentApplication/actions/generatePayment` |
| 创建收款明细 | POST | `/rest/data/v2.0/xobjects/paymentItem` |
| 更新收款明细 | PATCH | `/rest/data/v2.0/xobjects/paymentItem/{id}` |
| 删除收款明细 | DELETE | `/rest/data/v2.0/xobjects/paymentItem/{id}` |
| 创建退款 | POST | `/rest/data/v2.0/xobjects/refund` |
| 更新退款 | PATCH | `/rest/data/v2.0/xobjects/refund/{id}` |
| 删除退款 | DELETE | `/rest/data/v2.0/xobjects/refund/{id}` |
| 创建退款明细 | POST | `/rest/data/v2.0/xobjects/refundItem` |
| 更新退款明细 | PATCH | `/rest/data/v2.0/xobjects/refundItem/{id}` |
| 删除退款明细 | DELETE | `/rest/data/v2.0/xobjects/refundItem/{id}` |
| 获取交付记录接口描述 | GET | `/rest/data/v2.0/xobjects/deliveryRecord/description` |
| 创建交付记录 | POST | `/rest/data/v2.0/xobjects/deliveryRecord` |
| 更新交付记录 | PATCH | `/rest/data/v2.0/xobjects/deliveryRecord/{id}` |
| 锁定交付记录 | PUT | `/rest/data/v2.0/xobjects/deliveryRecord/actions/locks/{id}/lock` |
| 解锁交付记录 | DELETE | `/rest/data/v2.0/xobjects/deliveryRecord/actions/locks/{id}/lock` |
| 删除交付记录 | DELETE | `/rest/data/v2.0/xobjects/deliveryRecord/{id}` |
| 获取交付记录信息 | GET | `/rest/data/v2.0/xobjects/deliveryRecord/{id}` |
| 交付记录确认收货 | PATCH | `/rest/data/v2.0/xobjects/deliveryRecord/actions/confirmReceipt?recordId={id}` |
| 获取交付记录明细接口描述 | GET | `/rest/data/v2.0/xobjects/deliveryRecordDetail/description` |
| 创建交付记录明细 | POST | `/rest/data/v2.0/xobjects/deliveryRecordDetail` |
| 更新交付记录明细 | PATCH | `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}` |
| 删除交付记录明细 | DELETE | `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}` |
| 获取交付记录明细信息 | GET | `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}` |
| 创建发票 | POST | `/rest/data/v2.0/xobjects/receipt` |
| 更新发票 | PATCH | `/rest/data/v2.0/xobjects/receipt/{id}` |
| 生成发票 | POST | `/rest/data/v2.0/xobjects/receipt/actions/generateReceipt` |
| 删除发票 | DELETE | `/rest/data/v2.0/xobjects/receipt/{id}` |
| 创建发票明细 | POST | `/rest/data/v2.0/xobjects/receiptItem` |
| 更新发票明细 | PATCH | `/rest/data/v2.0/xobjects/receiptItem/{id}` |
| 删除发票明细 | DELETE | `/rest/data/v2.0/xobjects/receiptItem/{id}` |
| 生成应收单 | POST | `/rest/data/v2.0/xobjects/invoice/actions/generateInvoice` |
| 应收单生效 | PATCH | `/rest/data/v2.0/xobjects/invoice/actions/activation` |
| 应收单失效 | PATCH | `/rest/data/v2.0/xobjects/invoice/actions/deactivation` |
| 应收单作废 | PATCH | `/rest/data/v2.0/xobjects/invoice/actions/cancel` |
| 收款单生效 | PATCH | `/rest/data/v2.0/xobjects/paymentApplication/actions/activation` |
| 收款单失效 | PATCH | `/rest/data/v2.0/xobjects/paymentApplication/actions/deactivation` |
| 收款单作废 | PATCH | `/rest/data/v2.0/xobjects/paymentApplication/actions/cancel` |
| 应收变更单生效 | PATCH | `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/activation` |
| 应收变更单失效 | PATCH | `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/deactivation` |
| 应收变更单作废 | PATCH | `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/cancel` |
| 退款生效 | PATCH | `/rest/data/v2.0/xobjects/refund/actions/activation` |
| 退款失效 | PATCH | `/rest/data/v2.0/xobjects/refund/actions/deactivacanceltion` |
| 退款作废 | PATCH | `/rest/data/v2.0/xobjects/refund/actions/cancel` |
| 发票生效 | PATCH | `/rest/data/v2.0/xobjects/receipt/actions/activation` |
| 发票失效 | PATCH | `/rest/data/v2.0/xobjects/receipt/actions/deactivation` |
| 发票作废 | PATCH | `/rest/data/v2.0/xobjects/receipt/actions/cancel` |
| 创建货币设置 | POST | `/rest/metadata/v2.0/settings/systemSettings/currencies` |
| 更新货币设置 | PATCH | `/rest/metadata/v2.0/settings/systemSettings/currencies/currencyUnit1` |
| 删除货币设置 | DELETE | `/rest/metadata/v2.0/settings/systemSettings/currencies/currencyUnit2` |
| 获取指定货币设置信息 | GET | `/rest/metadata/v2.0/settings/systemSettings/currencies/{ApiKey}` |
| 获取所有货币设置 | GET | `/rest/metadata/v2.0/settings/systemSettings/currencies` |
| 启用单个货币设置 | POST | `/rest/metadata/v2.0/settings/systemSettings/currencies/{currencyApiKey}/enableStatus` |
| 禁用单个货币设置 | DELETE | `/rest/metadata/v2.0/settings/systemSettings/currencies/{currencyApiKey}/enableStatus` |
| 获取促销累加接口描述 | GET | `/rest/data/v2.0/xobjects/salesPromotionCounter/description` |
| 获取市场活动接口描述 | GET | `/rest/data/v2.0/xobjects/campaign/description` |
| 创建市场活动 | POST | `/rest/data/v2.0/xobjects/campaign` |
| 更新市场活动 | PATCH | `/rest/data/v2.0/xobjects/campaign/{id}` |
| 删除市场活动 | DELETE | `/rest/data/v2.0/xobjects/campaign/{id}` |
| 获取市场活动信息 | GET | `/rest/data/v2.0/xobjects/campaign/{id}` |
| 获取活动成员总数 | POST | `/rest/data/v2.0/xobjects/campaignMember/actions/count` |
| 获取活动成员列表信息 | POST | `/rest/data/v2.0/xobjects/campaignMember/actions/query` |
| 活动成员注册 | POST | `/rest/data/v2.0/xobjects/campaignMember/actions/register` |
| 活动成员签到 | POST | `/rest/data/v2.0/xobjects/campaignMember/actions/checkin` |
| 创建活动记录 | POST（APPLICATION/JSON） | `/rest/data/v2.0/xobjects/activityrecord` |
| 更新活动记录 | PUT（APPLICATION/JSON） | `/rest/data/v2.0/xobjects/activityrecord` |
| 删除活动记录 | DELETE | `/rest/data/v2.0/xobjects/activityrecord/{id}` |
| 获取不同业务类型活动记录的图片上传方式 | GET | `/rest/metadata/v2.0/settings/businessSettings/activity/` |
| 获取销售业绩拆分接口描述 | GET | `/rest/data/v2.0/xobjects/salesPerformanceSplit/description` |
| 创建销售业绩拆分 | POST | `/rest/data/v2.0/xobjects/salesPerformanceSplit` |
| 更新销售业绩拆分 | PATCH | `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}` |
| 锁定销售业绩拆分 | PUT | `/rest/data/v2.0/xobjects/salesPerformanceSplit/actions/locks/{id}/lock` |
| 解锁销售业绩拆分 | DELETE | `/rest/data/v2.0/xobjects/salesPerformanceSplit/actions/locks/{id}/lock` |
| 删除销售业绩拆分 | DELETE | `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}` |
| 获取销售业绩拆分信息 | GET | `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}` |
| 查询线索公海池日志 | GET | `/rest/data/v2.0/highSea/lead/log/{recordId}` |
| 获取应收单后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/invoice/` |
| 获取收款单后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/paymentApplication/` |
| 获取应收变更单后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/invoiceAdjustment/` |
| 获取退款单后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/refund/` |
| 获取发票后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/receipt/` |
| 获取交付记录后台设置 | GET | `/rest/metadata/v2.0/settings/businessSettings/deliveryRecord/` |
| 客户后台业务设置接口 | GET | `/rest/metadata/v2.0/settings/businessSettings/account/` |
| 查询前台实体列表页导出记录 | GET | `/rest/data/v2.0/xobjects/exportLog/actions/list?belongId={belongId}&startTime={startTime}&endTime={endTime}&pageNo={pageNo}&pageSize={pageSize}` |
| 查询前台实体列表页单个导出记录 | GET | `/rest/data/v2.0/xobjects/exportLog/actions/query?id={id}` |
| 获取促销活动接口描述 | GET | `/rest/data/v2.0/xobjects/salesPromotion/description` |
| 更新促销活动 | PATCH | `/rest/data/v2.0/xobjects/salesPromotion/{id}` |
| 锁定促销活动 | PUT | `/rest/data/v2.0/xobjects/salesPromotion/actions/locks/{id}/lock` |
| 解锁促销活动 | DELETE | `/rest/data/v2.0/xobjects/salesPromotion/actions/locks/{id}/lock` |
| 获取促销活动信息 | GET | `/rest/data/v2.0/xobjects/salesPromotion/{id}` |
| 更新促销活动生效状态 | POST | `/rest/data/v2.0/xobjects/salesPromotion/actions/updateStatus` |
| 获取应收发票接口描述 | GET | `/rest/data/v2.0/xobjects/invoiceReceipt/description` |
| 创建应收发票 | POST | `/rest/data/v2.0/xobjects/invoiceReceipt` |
| 更新应收发票 | PATCH | `/rest/data/v2.0/xobjects/invoiceReceipt/{id}` |
| 删除应收发票 | DELETE | `/rest/data/v2.0/xobjects/invoiceReceipt/{id}` |
| 获取应收发票信息 | GET | `/rest/data/v2.0/xobjects/invoiceReceipt/{id}` |
| 获取应收收款接口描述 | GET | `/rest/data/v2.0/xobjects/invoicePayment/description` |
| 创建应收收款 | POST | `/rest/data/v2.0/xobjects/invoicePayment` |
| 更新应收收款 | PATCH | `/rest/data/v2.0/xobjects/invoicePayment/{id}` |
| 删除应收收款 | DELETE | `/rest/data/v2.0/xobjects/invoicePayment/{id}` |
| 获取应收收款信息 | GET | `/rest/data/v2.0/xobjects/invoicePayment/{id}` |
| 获取应收收款退款接口描述 | GET | `/rest/data/v2.0/xobjects/invoicePaymentRefund/description` |
| 创建应收收款退款 | POST | `/rest/data/v2.0/xobjects/invoicePaymentRefund` |
| 更新应收收款退款 | PATCH | `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}` |
| 删除应收收款退款 | DELETE | `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}` |
| 获取应收收款退款信息 | GET | `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}` |
| 查询团队成员继承 | POST | `/rest/data/v2.0/xobjects/groupMemberExtends/actions/getGroupmemberExtendsParam` |
| 查询用户级CPQ license | GET | `/rest/data/v2.0/xobjects/quote/actions/checkUserCPQLicense` |
| 查询实体导入记录 | POST | `/rest/data/v2.0/import/record/actions/list` |
| 查询实体单个导入记录 | GET | `/rest/data/v2.0/import/record/{id}` |
| 查询实体导出记录 | POST | `/rest/data/v2.0/export/record/actions/list` |
| 查询实体单个导出记录 | GET | `/rest/data/v2.0/export/record/{id}` |
| 获取单位接口描述 | GET | `/rest/data/v2.0/xobjects/unit/description` |
| 创建单位 | POST | `/rest/data/v2.0/xobjects/unit` |
| 更新单位 | PATCH | `/rest/data/v2.0/xobjects/unit/{id}` |
| 锁定单位 | PUT | `/rest/data/v2.0/xobjects/unit/actions/locks/{id}/lock` |
| 解锁单位 | DELETE | `/rest/data/v2.0/xobjects/unit/actions/locks/{id}/lock` |
| 删除单位 | DELETE | `/rest/data/v2.0/xobjects/unit/{id}` |
| 获取单位信息 | GET | `/rest/data/v2.0/xobjects/unit/{id}` |
| 获取规格接口描述 | GET | `/rest/data/v2.0/xobjects/specification/description` |
| 创建规格 | POST | `/rest/data/v2.0/xobjects/specification` |
| 更新规格 | PATCH | `/rest/data/v2.0/xobjects/specification/{id}` |
| 锁定规格 | PUT | `/rest/data/v2.0/xobjects/specification/actions/locks/{id}/lock` |
| 解锁规格 | DELETE | `/rest/data/v2.0/xobjects/specification/actions/locks/{id}/lock` |
| 删除规格 | DELETE | `/rest/data/v2.0/xobjects/specification/{id}` |
| 获取规格信息 | GET | `/rest/data/v2.0/xobjects/specification/{id}` |
| 获取规格值接口描述 | GET | `/rest/data/v2.0/xobjects/specificationValue/description` |
| 创建规格值 | POST | `/rest/data/v2.0/xobjects/specificationValue` |
| 更新规格值 | PATCH | `/rest/data/v2.0/xobjects/specificationValue/{id}` |
| 锁定规格值 | PUT | `/rest/data/v2.0/xobjects/specificationValue/actions/locks/{id}/lock` |
| 解锁规格值 | DELETE | `/rest/data/v2.0/xobjects/specificationValue/actions/locks/{id}/lock` |
| 删除规格值 | DELETE | `/rest/data/v2.0/xobjects/specificationValue/{id}` |
| 获取规格值信息 | GET | `/rest/data/v2.0/xobjects/specificationValue/{id}` |
| 获取商品接口描述 | GET | `/rest/data/v2.0/xobjects/goods/description` |
| 创建商品 | POST | `/rest/data/v2.0/xobjects/goods` |
| 更新商品 | PATCH | `/rest/data/v2.0/xobjects/goods/{id}` |
| 锁定商品 | PUT | `/rest/data/v2.0/xobjects/goods/actions/locks/{id}/lock` |
| 解锁商品 | DELETE | `/rest/data/v2.0/xobjects/goods/actions/locks/{id}/lock` |
| 删除商品 | DELETE | `/rest/data/v2.0/xobjects/goods/{id}` |
| 获取商品信息 | GET | `/rest/data/v2.0/xobjects/goods/{id}` |
| 获取商品单位接口描述 | GET | `/rest/data/v2.0/xobjects/goodsUnit/description` |
| 创建商品单位 | POST | `/rest/data/v2.0/xobjects/goodsUnit` |
| 更新商品单位 | PATCH | `/rest/data/v2.0/xobjects/goodsUnit/{id}` |
| 锁定商品单位 | PUT | `/rest/data/v2.0/xobjects/goodsUnit/actions/locks/{id}/lock` |
| 解锁商品单位 | DELETE | `/rest/data/v2.0/xobjects/goodsUnit/actions/locks/{id}/lock` |
| 删除商品单位 | DELETE | `/rest/data/v2.0/xobjects/goodsUnit/{id}` |
| 获取商品单位的信息 | GET | `/rest/data/v2.0/xobjects/goodsUnit/{id}` |
| 获取商品规格接口描述 | GET | `/rest/data/v2.0/xobjects/goodsSpecification/description` |
| 创建商品规格 | POST | `/rest/data/v2.0/xobjects/goodsSpecification` |
| 更新商品规格 | PATCH | `/rest/data/v2.0/xobjects/goodsSpecification/{id}` |
| 锁定商品规格 | PUT | `/rest/data/v2.0/xobjects/goodsSpecification/actions/locks/{id}/lock` |
| 解锁商品规格 | DELETE | `/rest/data/v2.0/xobjects/goodsSpecification/actions/locks/{id}/lock` |
| 删除商品规格 | DELETE | `/rest/data/v2.0/xobjects/goodsSpecification/{id}` |
| 获取商品规格信息 | GET | `/rest/data/v2.0/xobjects/goodsSpecification/{id}` |
| 获取商品规格值接口描述 | GET | `/rest/data/v2.0/xobjects/goodsSpecificationValue/description` |
| 创建商品规格值 | POST | `/rest/data/v2.0/xobjects/goodsSpecificationValue` |
| 更新商品规格值 | PATCH | `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}` |
| 锁定商品规格值 | PUT | `/rest/data/v2.0/xobjects/goodsSpecificationValue/actions/locks/{id}/lock` |
| 解锁商品规格值 | DELETE | `/rest/data/v2.0/xobjects/goodsSpecificationValue/actions/locks/{id}/lock` |
| 删除商品规格值 | DELETE | `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}` |
| 获取商品规格值信息 | GET | `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}` |
| 精准查询工商信息 | GET | `/rest/data/v2.0/dataproduct/company/info` |
| 模糊查询工商信息 | GET | `/rest/data/v2.0/dataproduct/company/list` |
| 查询变更信息 | GET | `/rest/data/v2.0/dataproduct/company/changeInfo` |
| 查询股东信息 | GET | `/rest/data/v2.0/dataproduct/company/investor` |
| 查询企业对外投资信息 | GET | `/rest/data/v2.0/dataproduct/company/ investment` |
| 查询企业分支机构信息 | GET | `/rest/data/v2.0/dataproduct/company/branch` |
| 查询行政处罚信息 | GET | `/rest/data/v2.0/dataproduct/company/punishment` |
| 查询经营异常信息 | GET | `/rest/data/v2.0/dataproduct/company/abnormal` |
| 查询严重违法失信信息 | GET | `/rest/data/v2.0/dataproduct/company/illegal` |
| 查询企业主要人员信息 | GET | `/rest/data/v2.0/dataproduct/company/staff` |
| 获取限量限额接口描述 | GET | `/rest/data/v2.0/xobjects/promotionLimited/description` |
| 创建限量限额 | POST | `/rest/data/v2.0/xobjects/promotionLimited` |
| 更新限量限额 | PATCH | `/rest/data/v2.0/xobjects/promotionLimited/{id}` |
| 锁定限量限额 | PUT | `/rest/data/v2.0/xobjects/promotionLimited/actions/locks/{id}/lock` |
| 解锁限量限额 | DELETE | `/rest/data/v2.0/xobjects/promotionLimited/actions/locks/{id}/lock` |
| 删除限量限额 | DELETE | `/rest/data/v2.0/xobjects/promotionLimited/{id}` |
| 获取限量限额信息 | GET | `/rest/data/v2.0/xobjects/promotionLimited/{id}` |
| 获取资产接口描述 | GET | `/rest/data/v2.0/xobjects/asset/description` |
| 创建资产 | POST | `/rest/data/v2.0/xobjects/asset` |
| 更新资产 | PATCH | `/rest/data/v2.0/xobjects/asset/{id}` |
| 删除资产 | DELETE | `/rest/data/v2.0/xobjects/asset/{id}` |
| 获取资产信息 | GET | `/rest/data/v2.0/xobjects/asset/{id}` |
| 获取仓库接口描述 | GET | `/rest/data/v2/objects/warehouse/description` |
| 创建仓库 | POST | `/rest/data/v2/objects/warehouse` |
| 更新仓库 | PATCH | `/rest/data/v2/objects/warehouse/{id}` |
| 删除仓库 | DELETE | `/rest/data/v2/objects/warehouse/{id}` |
| 获取仓库信息 | GET | `/rest/data/v2/objects/warehouse/{id}` |
| 获取仓库明细接口描述 | GET | `/rest/data/v2/objects/warehouseDetail/description` |
| 创建仓库明细 | POST | `/rest/data/v2/objects/warehouseDetail` |
| 更新仓库明细 | PATCH | `/rest/data/v2/objects/warehouseDetail/{id}` |
| 删除仓库明细 | DELETE | `/rest/data/v2/objects/warehouseDetail/{id}` |
| 获取仓库明细信息 | GET | `/rest/data/v2/objects/warehouseDetail/{id}` |
| 获取入库单接口描述 | GET | `/rest/data/v2/objects/stockIn/description` |
| 创建入库单 | POST | `/rest/data/v2/objects/stockIn` |
| 更新入库单 | PATCH | `/rest/data/v2/objects/stockIn/{id}` |
| 删除入库单 | DELETE | `/rest/data/v2/objects/stockIn/{id}` |
| 获取入库单信息 | GET | `/rest/data/v2/objects/stockIn/{id}` |
| 确认入库 | POST | `/rest/data/v2/objects/stockIn/actions/confirm` |
| 获取入库单明细接口描述 | GET | `/rest/data/v2/objects/stockInDetail/description` |
| 创建入库单明细 | POST | `/rest/data/v2/objects/stockInDetail` |
| 更新入库单明细 | PATCH | `/rest/data/v2/objects/stockInDetail/{id}` |
| 删除入库单明细 | DELETE | `/rest/data/v2/objects/stockInDetail/{id}` |
| 获取入库单明细信息 | GET | `/rest/data/v2/objects/stockInDetail/{id}` |
| 获取出库单接口描述 | GET | `/rest/data/v2/objects/stockOut/description` |
| 创建出库单 | POST | `/rest/data/v2/objects/stockOut` |
| 更新出库单 | PATCH | `/rest/data/v2/objects/stockOut/{id}` |
| 删除出库单 | DELETE | `/rest/data/v2/objects/stockOut/{id}` |
| 获取出库单信息 | GET | `/rest/data/v2/objects/stockOut/{id}` |
| 确认出库 | POST | `/rest/data/v2/objects/stockOut/actions/confirm` |
| 获取出库单明细接口描述 | GET | `/rest/data/v2/objects/stockOutDetail/description` |
| 创建出库单明细 | POST | `/rest/data/v2/objects/stockOutDetail` |
| 更新出库单明细 | PATCH | `/rest/data/v2/objects/stockOutDetail/{id}` |
| 删除出库单明细 | DELETE | `/rest/data/v2/objects/stockOutDetail/{id}` |
| 获取出库单明细信息 | GET | `/rest/data/v2/objects/stockOutDetail/{id}` |
| 获取移库单接口描述 | GET | `/rest/data/v2/objects/stockTransfer/description` |
| 创建移库单 | POST | `/rest/data/v2/objects/stockTransfer` |
| 更新移库单 | PATCH | `/rest/data/v2/objects/stockTransfer/{id}` |
| 删除移库单 | DELETE | `/rest/data/v2/objects/stockTransfer/{id}` |
| 获取移库单信息 | GET | `/rest/data/v2/objects/stockTransfer/{id}` |
| 确认移库 | POST | `/rest/data/v2.0/xobjects/stockTransfer/actions/confirm` |
| 获取移库单明细接口描述 | GET | `/rest/data/v2/objects/stockTransfer/description` |
| 创建移库单明细 | POST | `/rest/data/v2/objects/stockTransferDetail` |
| 更新移库单明细 | PATCH | `/rest/data/v2/objects/stockTransferDetail/{id}` |
| 删除移库单明细 | DELETE | `/rest/data/v2/objects/stockTransferDetail/{id}` |
| 获取移库单明细信息 | GET | `/rest/data/v2/objects/stockTransferDetail/{id}` |
| 获取盘库单接口描述 | GET | `/rest/data/v2.0/xobjects/stockTaking/description` |
| 创建盘库单 | POST | `/rest/data/v2.0/xobjects/stockTaking` |
| 批量创建盘库单 | POST | `/rest/data/v2.0/xobjects/stockTaking/batch` |
| 更新盘库单 | PATCH | `/rest/data/v2.0/xobjects/stockTaking/{id}` |
| 批量更新盘库单 | PATCH | `/rest/data/v2.0/xobjects/stockTaking/batch` |
| 锁定盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/locks/{id}/lock` |
| 批量锁定盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/locks/batch` |
| 解锁盘库单 | DELETE | `/rest/data/v2.0/xobjects/stockTaking/actions/locks/{id}/lock` |
| 批量解锁盘库单 | DELETE | `/rest/data/v2.0/xobjects/stockTaking/actions/locks/batch` |
| 删除盘库单 | DELETE | `/rest/data/v2.0/xobjects/stockTaking/{id}` |
| 批量删除盘库单 | DELETE | `/rest/data/v2.0/xobjects/stockTaking/batch` |
| 获取盘库单信息 | GET | `/rest/data/v2.0/xobjects/stockTaking/{id}` |
| 批量获取盘库单信息 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/batch/ids` |
| 关注盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/follows/{id}/follow` |
| 批量关注盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/follows/batch` |
| 取消关注盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/follows/{id}/follow` |
| 批量取消关注盘库单 | DELETE | `/rest/data/v2.0/xobjects/stockTaking/actions/follows/batch` |
| 转移盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/transfers/{targetUserId}/{id}` |
| 批量转移盘库单 | PUT | `/rest/data/v2.0/xobjects/stockTaking/actions/transfers/{targetUserId}/batch` |
| 开始盘库 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/startStockTaking/{id}` |
| 结束盘库 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/completeStockTaking/{id}` |
| 确认调整 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/confirm/{id}` |
| 检查账面数量 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/checkBookQuantity/{id}` |
| 修改账面数量 | GET | `/rest/data/v2.0/xobjects/stockTaking/actions/updateBookQuantity/{id}` |
| 创建盘库单主子明细 | POST | `/rest/data/v2.0/xobjects/stockTaking/masterdetails` |
| 更新盘库单主子明细 | PATCH | `/rest/data/v2.0/xobjects/stockTaking/masterdetails` |
| 获取盘库单明细描述 | GET | `/rest/data/v2.0/xobjects/stockTakingDetail/description` |
| 创建盘库单明细 | POST | `/rest/data/v2.0/xobjects/stockTakingDetail` |
| 批量创建盘库单明细 | POST | `/rest/data/v2.0/xobjects/stockTakingDetail/batch` |
| 更新盘库单明细 | PATCH | `/rest/data/v2.0/xobjects/stockTakingDetail/{id}` |
| 批量更新盘库单明细 | PATCH | `/rest/data/v2.0/xobjects/stockTakingDetail/batch` |
| 删除盘库单明细 | DELETE | `/rest/data/v2.0/xobjects/stockTakingDetail/{id}` |
| 批量删除盘库单明细 | DELETE | `/rest/data/v2.0/xobjects/stockTakingDetail/batch` |
| 获取盘库单明细信息 | GET | `/rest/data/v2.0/xobjects/stockTakingDetail/{id}` |
| 批量获取盘库单明细信息 | GET | `/rest/data/v2.0/xobjects/stockTakingDetail/actions/batch/ids` |
| 创建盘库单明细主子明细 | POST | `/rest/data/v2.0/xobjects/stockTakingDetail/masterdetails` |
| 更新盘库单明细主子明细 | PATCH | `/rest/data/v2.0/xobjects/stockTaking/masterdetails` |
| 获取个人库物料转移接口描述 | GET | `/rest/data/v2.0/xobjects/personalMaterialTransfer/description` |
| 创建个人库物料转移 | POST | `/rest/data/v2.0/xobjects/dispatchNote` |
| 更新个人库物料转移 | PATCH | `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}` |
| 删除个人库物料转移 | DELETE | `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}` |
| 获取个人库物料转移信息 | GET | `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}` |
| 锁定个人库物料转移 | PUT | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/locks/{id}/lock` |
| 解锁个人库物料转移 | DELETE | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/locks/{id}/lock` |
| 关注个人库物料转移 | PUT | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/follows/{id}/follow` |
| 取消关注个人库物料转移 | DELETE | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/follows/{id}/follow` |
| 转移个人库物料转移 | PUT | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/transfers/{targetUserId}/{id}` |
| 接收个人库物料转移 | POST | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/accept` |
| 拒绝个人库物料转移 | POST | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/refuse` |
| 批量接收个人库物料转移 | POST | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/acceptBatch` |
| 批量拒绝个人库物料转移 | POST | `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/refuseBatch` |
| 获取领料单接口描述 | GET | `/rest/data/v2/objects/materialRequisition/description` |
| 创建领料单 | POST | `/rest/data/v2/objects/materialRequisition` |
| 更新领料单 | PATCH | `/rest/data/v2/objects/materialRequisition/{id}` |
| 删除领料单 | DELETE | `/rest/data/v2/objects/materialRequisition/{id}` |
| 获取领料单信息 | GET | `/rest/data/v2/objects/materialRequisition/{id}` |
| 领料全流程 | POST | `/rest/data/v2/objects/materialRequisition/actions/materialRequisitionWholeProcess` |
| 确认领料 | POST | `/rest/data/v2/objects/materialRequisition/actions/confirm` |
| 冻结库存 | GET | `/rest/data/v2.0/xobjects/materialRequisition/actions/freeze/{id}` |
| 取消冻结 | GET | `/rest/data/v2.0/xobjects/materialRequisition/actions/unfreeze/{id}` |
| 确认出库 | GET | `/rest/data/v2.0/xobjects/materialRequisition/actions/confirmOut/{id}` |
| 确认接收 | GET | `/rest/data/v2.0/xobjects/materialRequisition/actions/confirmReceive/{id}` |
| 获取领料单明细接口描述 | GET | `/rest/data/v2/objects/materialRequisitionDetail/description` |
| 创建领料单明细 | POST | `/rest/data/v2/objects/materialRequisitionDetail` |
| 更新领料单明细 | PATCH | `/rest/data/v2/objects/materialRequisitionDetail/{id}` |
| 删除领料单明细 | DELETE | `/rest/data/v2/objects/materialRequisitionDetail/{id}` |
| 获取领料单明细信息 | PATCH | `/rest/data/v2/objects/materialRequisitionDetail/{id}` |
| 获取退料单接口描述 | GET | `/rest/data/v2/objects/materialReturn/description` |
| 创建退料单 | POST | `/rest/data/v2/objects/materialReturn` |
| 更新退料单 | PATCH | `/rest/data/v2/objects/materialReturn/{id}` |
| 删除退料单 | DELETE | `/rest/data/v2/objects/materialReturn/{id}` |
| 获取退料单信息 | GET | `/rest/data/v2/objects/materialReturn/{id}` |
| 确认退料 | POST | `/rest/data/v2/objects/materialReturn/actions/confirm` |
| 退料全流程 | POST | `/rest/data/v2/objects/materialReturn/actions/materialReturnWholeProcess` |
| 获取退料单明细接口描述 | GET | `/rest/data/v2/objects/materialReturnDetail/description` |
| 创建退料单明细 | POST | `/rest/data/v2/objects/materialReturnDetail` |
| 更新退料单明细 | PATCH | `/rest/data/v2/objects/materialReturnDetail/{id}` |
| 删除退料单明细 | DELETE | `/rest/data/v2/objects/materialReturnDetail/{id}` |
| 获取退料单明细信息 | GET | `/rest/data/v2/objects/materialReturnDetail/{id}` |
| 撤销入库 | POST | `/rest/data/v2.0/xobjects/stockIn/actions/reverse` |
| 撤销出库 | POST | `/rest/data/v2.0/xobjects/stockOut/actions/reverse` |
| 撤销移库 | POST | `/rest/data/v2.0/xobjects/stockTransfer/actions/reverse` |
| 撤销领料 | POST | `/rest/data/v2.0/xobjects/materialRequisition/actions/reverse` |
| 撤销退料 | POST | `/rest/data/v2.0/xobjects/materialReturn/actions/reverse` |
| 获取采购退货接口描述 | GET | `/rest/data/v2.0/xobjects/purchaseReturn/description` |
| 创建采购退货 | POST | `/rest/data/v2.0/xobjects/purchaseReturn` |
| 批量创建采购退货 | POST | `/rest/data/v2.0/xobjects/purchaseReturn/batch` |
| 更新采购退货 | PATCH | `/rest/data/v2.0/xobjects/purchaseReturn/{id}` |
| 批量更新采购退货 | PATCH | `/rest/data/v2.0/xobjects/purchaseReturn/batch` |
| 删除采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/{id}` |
| 批量删除采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/batch` |
| 获取采购退货信息 | GET | `/rest/data/v2.0/xobjects/purchaseReturn/{id}` |
| 批量获取采购退货信息 |  | `/rest/data/v2.0/xobjects/purchaseReturn/actions/batch/ids` |
| 锁定采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/{id}/lock` |
| 批量锁定采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/batch` |
| 解锁采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/{id}/lock` |
| 批量解锁采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/batch` |
| 关注采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/{id}/follow` |
| 批量关注采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/batch` |
| 取消关注采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/{id}/follow` |
| 批量取消关注采购退货 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/batch` |
| 转移采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/transfers/{targetUserId}/{id}` |
| 确认生效采购退货 | PUT | `/rest/data/v2.0/xobjects/purchaseReturn/actions/confirm` |
| 作废采购退货 | POST | `/rest/data/v2.0/xobjects/purchaseReturn/actions/cancel` |
| 获取采购退货明细接口描述 | GET | `/rest/data/v2.0/xobjects/purchaseReturnDetail/description` |
| 创建采购退货明细 | POST | `/rest/data/v2.0/xobjects/purchaseReturnDetail` |
| 批量创建采购退货明细 | POST | `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch` |
| 更新采购退货明细 | PATCH | `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}` |
| 批量更新采购退货明细 | PATCH | `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch` |
| 删除采购退货明细 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}` |
| 批量删除采购退货明细 | DELETE | `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch` |
| 获取采购退货明细信息 | GET | `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}` |
| 批量获取采购退货明细信息 | POST | `/rest/data/v2.0/xobjects/purchaseReturnDetail/actions/batch/ids` |
| 获取发运单接口描述 | GET | `/rest/data/v2.0/xobjects/dispatchNote/description` |
| 创建发运单 | POST | `/rest/data/v2.0/xobjects/dispatchNote` |
| 更新发运单 | PATCH | `/rest/data/v2.0/xobjects/dispatchNote/{id}` |
| 锁定发运单 | PUT | `/rest/data/v2.0/xobjects/dispatchNote/actions/locks/{id}/lock` |
| 解锁发运单 | DELETE | `/rest/data/v2.0/xobjects/dispatchNote/actions/locks/{id}/lock` |
| 删除发运单 | DELETE | `/rest/data/v2.0/xobjects/dispatchNote/{id}` |
| 获取发运单信息 | GET | `/rest/data/v2.0/xobjects/dispatchNote/{id}` |
| 确认发运 | POST | `/rest/data/v2.0/xobjects/dispatchNote/actions/confirmShip` |
| 确认出库并发运 | POST | `/rest/data/v2.0/xobjects/dispatchNote/actions/stockOutAndConfirmShip` |
| 获取发运单明细接口描述 | GET | `/rest/data/v2.0/xobjects/dispatchNoteDetail/description` |
| 创建发运单明细 | POST | `/rest/data/v2.0/xobjects/dispatchNoteDetail` |
| 更新发运单明细 | PATCH | `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}` |
| 删除发运单明细 | DELETE | `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}` |
| 获取发运单明细信息 | GET | `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}` |
| 获取装箱单接口描述 | GET | `/rest/data/v2.0/xobjects/packingList/description` |
| 创建装箱单 | POST | `/rest/data/v2.0/xobjects/packingLIst` |
| 更新装箱单 | PATCH | `/rest/data/v2.0/xobjects/packingList/{id}` |
| 删除装箱单 | DELETE | `/rest/data/v2.0/xobjects/packingList/{id}` |
| 获取装箱单信息 | GET | `/rest/data/v2.0/xobjects/packingList/{id}` |
| 确认装箱/取消装箱 | POST | `/rest/data/v2.0/xobjects/packingList/actions/changePac` |
| 开箱验货 | POST | `/rest/data/v2.0/xobjects/packingList/actions/packingCheck` |
| 完成验货 | POST | `/rest/data/v2.0/xobjects/packingList/actions/confirmExamine` |
| 获取装箱单明细接口描述 | GET | `/rest/data/v2.0/xobjects/packingListDetail/description` |
| 创建装箱单明细 | POST | `/rest/data/v2.0/xobjects/packingListDetail` |
| 更新装箱单明细 | PATCH | `/rest/data/v2.0/xobjects/packingListDetail/{id}` |
| 删除装箱单明细 | DELETE | `/rest/data/v2.0/xobjects/packingListDetail/{id}` |
| 获取装箱单明细信息 | GET | `/rest/data/v2.0/xobjects/packingListDetail/{id}` |
| 获取接收接口描述 | GET | `/rest/data/v2.0/xobjects/receiveNote/description` |
| 创建接收 | POST | `/rest/data/v2.0/xobjects/receiveNote` |
| 更新接收 | PATCH | `/rest/data/v2.0/xobjects/receiveNote/{id}` |
| 锁定接收 | PUT | `/rest/data/v2.0/xobjects/receiveNote/actions/locks/{id}/lock` |
| 解锁接收 | DELETE | `/rest/data/v2.0/xobjects/receiveNote/actions/locks/{id}/lock` |
| 删除接收 | DELETE | `/rest/data/v2.0/xobjects/receiveNote/{id}` |
| 获取接收信息 | GET | `/rest/data/v2.0/xobjects/receiveNote/{id}` |
| 获取接收明细接口描述 | GET | `/rest/data/v2.0/xobjects/receiveNoteDetail/description` |
| 创建接收明细 | POST | `/rest/data/v2.0/xobjects/receiveNoteDetail` |
| 更新接收明细 | PATCH | `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}` |
| 锁定接收明细 | PUT | `/rest/data/v2.0/xobjects/receiveNoteDetail/actions/locks/{id}/lock` |
| 解锁接收明细 | DELETE | `/rest/data/v2.0/xobjects/receiveNoteDetail/actions/locks/{id}/lock` |
| 删除接收明细 | DELETE | `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}` |
| 获取接收明细信息 | GET | `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}` |
| 获取派工单接口描述 | GET | `/rest/data/v2.0/xobjects/fieldJob/description` |
| 创建派工单 | POST | `/rest/data/v2.0/xobjects/fieldJob` |
| 更新派工单 | PATCH | `/rest/data/v2.0/xobjects/fieldJob/{id}` |
| 删除派工单 | DELETE | `/rest/data/v2.0/xobjects/fieldJob/{id}` |
| 结束派工单 | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/finish` |
| 取消派工单 | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/cancel` |
| 获取派工单信息 | GET | `/rest/data/v2.0/xobjects/fieldJob/{id}` |
| 获取最近的服务网点 | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/getLatestSite` |
| 查询派工池 | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/queryPoolsByStatus` |
| 分配派工单 | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/assign` |
| 分配派工单（多人派工模式） | POST | `/rest/data/v2.0/xobjects/fieldJob/actions/changeServiceTeamMember` |
| 获取派工单检查项接口描述 | GET | `/rest/data/v2/objects/fieldJobCheckItem/description` |
| 创建派工单检查项 | POST | `/rest/data/v2/objects/fieldJobCheckItem` |
| 更新派工单检查项 | PATCH | `/rest/data/v2/objects/fieldJobCheckItem/{id}` |
| 删除派工单检查项 | DELETE | `/rest/data/v2/objects/fieldJobCheckItem/{id}` |
| 获取派工单检查项信息 | DELETE | `/rest/data/v2/objects/fieldJobCheckItem/{id}` |
| 获取返修单接口描述 | GET | `/rest/data/v2.0/xobjects/depotRepair/description` |
| 创建返修单 | POST | `/rest/data/v2.0/xobjects/depotRepair` |
| 更新返修单 | PATCH | `/rest/data/v2.0/xobjects/depotRepair/{id}` |
| 删除返修单 | DELETE | `/rest/data/v2.0/xobjects/depotRepair/{id}` |
| 获取返修单信息 | GET | `/rest/data/v2.0/xobjects/depotRepair/{id}` |
| 分配返修单 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/assign` |
| 取消返修单 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/cancel` |
| 开始维修 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/startRepair` |
| 暂停/恢复 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/pauseOrResume` |
| 结束维修 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/finish` |
| 类似于页面弹出picker | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/lookupSearchCustomizForFsc` |
| 从维修项模板添加维修项记录 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/addFromTemplate` |
| 安装 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/install` |
| 替换 | POST | `/rest/data/v2.0/xobjects/depotRepair/actions/replace` |
| 获取收费接口描述 | GET | `/rest/data/v2/objects/charge/description` |
| 创建收费 | POST | `/rest/data/v2/objects/charge` |
| 更新收费 | PATCH | `/rest/data/v2/objects/charge/{id}` |
| 删除收费 | DELETE | `/rest/data/v2/objects/charge/{id}` |
| 获取收费信息 | GET | `/rest/data/v2/objects/charge/{id}` |
| 获取收费明细接口描述 | GET | `/rest/data/v2/objects/chargeDetail/description` |
| 创建收费明细 | POST | `/rest/data/v2/objects/chargeDetail` |
| 更新收费明细 | PATCH | `/rest/data/v2/objects/chargeDetail/{id}` |
| 删除收费明细 | DELETE | `/rest/data/v2/objects/chargeDetail/{id}` |
| 获取收费明细信息 | GET | `/rest/data/v2/objects/chargeDetail/{id}` |
| 获取访客接口描述 | GET | `/rest/data/v2.0/xobjects/serviceVisitor/description` |
| 创建访客 | POST | `/rest/data/v2.0/xobjects/serviceVisitor` |
| 更新访客 | PATCH | `/rest/data/v2.0/xobjects/serviceVisitor/{id}` |
| 获取访客信息 | GET | `/rest/data/v2.0/xobjects/serviceVisitor/{id}` |
| 获取客户评价接口描述 | GET | `/rest/data/v2/objects/evaluation/description` |
| 删除客户评价 | DELETE | `/rest/data/v2/objects/evaluation/{id}` |
| 获取客户评价信息 | GET | `/rest/data/v2/objects/evaluation/{id}` |
| 获取客户评价数据 | POST | `/rest/data/v2.0/xobjects/evaluation/actions/queryEvaluationInfo` |
| 提交客户评价数据 | POST | `/rest/data/v2.0/xobjects/evaluation/actions/submitEvaluateData` |
| 获取评价项接口描述 | GET | `/rest/data/v2/objects/evaluationDetail/description` |
| 删除评价项 | DELETE | `/rest/data/v2/objects/evaluationDetail/{id}` |
| 获取评价项信息 | GET | `/rest/data/v2/objects/evaluationDetail/{id}` |
| 获取评价接口描述 | GET | `/rest/data/v2.0/xobjects/serviceEvaluation/description` |
| 获取评价信息 | GET | `/rest/data/v2.0/xobjects/serviceEvaluation/{id}` |
| 获取维保计划接口描述 | GET | `/rest/data/v2/objects/preventiveMaintenance/description` |
| 创建维保计划 | POST | `/rest/data/v2/objects/preventiveMaintenance` |
| 更新维保计划 | PATCH | `/rest/data/v2/objects/preventiveMaintenance/{id}` |
| 删除维保计划 | DELETE | `/rest/data/v2/objects/preventiveMaintenance/{id}` |
| 获取维保计划信息 | GET | `/rest/data/v2/objects/preventiveMaintenance/{id}` |
| 获取维保计划明细接口描述 | GET | `/rest/data/v2/objects/preventiveMaintenanceDetail/description` |
| 创建维保计划明细 | POST | `/rest/data/v2/objects/preventiveMaintenanceDetail` |
| 更新维保计划明细 | PATCH | `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}` |
| 删除维保计划明细 | DELETE | `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}` |
| 获取维保计划明细信息 | GET | `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}` |
| 获取服务项目接口描述 | GET | `/rest/data/v2/objects/serviceProject/description` |
| 创建服务项目 | POST | `/rest/data/v2/objects/serviceProject` |
| 更新服务项目 | PATCH | `/rest/data/v2/objects/serviceProject/{id}` |
| 删除服务项目 | DELETE | `/rest/data/v2/objects/serviceProject/{id}` |
| 获取服务项目信息 | GET | `/rest/data/v2/objects/serviceProject/{id}` |
| 获取服务阶段接口描述 | GET | `/rest/data/v2/objects/serviceStage/description` |
| 创建服务阶段 | POST | `/rest/data/v2/objects/serviceStage` |
| 更新服务阶段 | PATCH | `/rest/data/v2/objects/serviceStage/{id}` |
| 删除服务阶段 | DELETE | `/rest/data/v2/objects/serviceStage/{id}` |
| 获取服务阶段信息 | GET | `/rest/data/v2/objects/serviceStage/{id}` |
| 获取服务任务接口描述 | GET | `/rest/data/v2/objects/serviceTask/description` |
| 创建服务任务 | POST | `/rest/data/v2/objects/serviceTask` |
| 更新服务任务 | PATCH | `/rest/data/v2/objects/serviceTask/{id}` |
| 删除服务任务 | DELETE | `/rest/data/v2/objects/serviceTask/{id}` |
| 获取服务任务信息 | GET | `/rest/data/v2/objects/serviceTask/{id}` |
| 获取服务工单接口描述 | GET | `/rest/data/v2.0/xobjects/serviceCase/description` |
| 创建服务工单 | POST | `/rest/data/v2.0/xobjects/serviceCase` |
| 更新服务工单 | PATCH | `/rest/data/v2.0/xobjects/serviceCase/{id}` |
| 删除服务工单 | DELETE | `/rest/data/v2.0/xobjects/serviceCase/{id}` |
| 获取服务工单信息 | GET | `/rest/data/v2.0/xobjects/serviceCase/{id}` |
| 获取服务邮件接口描述 | GET | `/rest/data/v2.0/xobjects/serviceEmail/description` |
| 更新服务邮件 | PATCH | `/rest/data/v2.0/xobjects/serviceEmail/{id}` |
| 锁定服务邮件 | PUT | `/rest/data/v2.0/xobjects/serviceEmail/actions/locks/{id}/lock` |
| 解锁服务邮件 | DELETE | `/rest/data/v2.0/xobjects/serviceEmail/actions/locks/{id}/lock` |
| 删除服务邮件 | DELETE | `/rest/data/v2.0/xobjects/serviceEmail/{id}` |
| 获取服务邮件信息 | GET | `/rest/data/v2.0/xobjects/serviceEmail/{id}` |
| 录入服务邮件 | POST | `/rest/data/v2.0/xobjects/serviceEmail/mockReceive` |
| 发送服务邮件 | POST | `/rest/data/v2.0/xobjects/serviceEmail/communication/send` |
| 邮件标记已读 | POST | `/rest/data/v2.0/xobjects/serviceEmail/communication/read` |
| 邮件标记未读 | POST | `/rest/data/v2.0/xobjects/serviceEmail/communication/unread` |
| 添加邮件黑名单 | POST | `/rest/data/v2.0/xobjects/serviceEmail/blackList` |
| 获取服务邮件明细接口描述 | GET | `/rest/data/v2.0/xobjects/serviceEmailDetail/description` |
| 更新服务邮件明细 | PATCH | `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}` |
| 锁定服务邮件明细 | PUT | `/rest/data/v2.0/xobjects/serviceEmailDetail/actions/locks/{id}/lock` |
| 解锁服务邮件明细 | DELETE | `/rest/data/v2.0/xobjects/serviceEmailDetail/actions/locks/{id}/lock` |
| 删除服务邮件明细 | DELETE | `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}` |
| 获取服务邮件明细信息 | GET | `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}` |
| 获取服务邮件明细正文内容 | GET | `/rest/data/v2.0/xobjects/serviceEmailDetail/getEmailContent` |
| 获取知识条目接口描述 | GET | `/rest/data/v2.0/xobjects/serviceKnowledge/description` |
| 创建知识条目 | POST | `/rest/data/v2.0/xobjects/serviceKnowledge` |
| 更新知识条目 | PATCH | `/rest/data/v2.0/xobjects/serviceKnowledge/{id}` |
| 删除知识条目 | DELETE | `/rest/data/v2.0/xobjects/serviceKnowledge/{id}` |
| 获取知识条目信息 | GET | `/rest/data/v2.0/xobjects/serviceKnowledge/{id}` |
| 创建知识条目分类 | POST | `/rest/data/v2.0/xobjects/serviceKnowledge/actions/createCatalog` |
| 更新知识条目分类 | PATCH | `/rest/data/v2.0/xobjects/serviceKnowledge/actions/updateCatalog` |
| 删除知识条目分类 | DELETE | `/rest/data/v2.0/xobjects/serviceKnowledge/actions/deleteCatalog` |
| 获取知识条目分类列表 | GET | `/rest/data/v2.0/xobjects/serviceKnowledge/actions/getCatalogList` |
| 获取语音接口描述 | GET | `/rest/data/v2.0/xobjects/serviceCall/description` |
| 创建语音 | POST | `/rest/data/v2.0/xobjects/serviceCall` |
| 更新语音 | PATCH | `/rest/data/v2.0/xobjects/serviceCall/{id}` |
| 删除语音 | DELETE | `/rest/data/v2.0/xobjects/serviceCall/{id}` |
| 获取语音信息 | GET | `/rest/data/v2.0/xobjects/serviceCall/{id}` |
| 获取会话接口描述 | GET | `/rest/data/v2.0/xobjects/serviceChat/description` |
| 创建会话 | POST | `/rest/data/v2.0/xobjects/serviceChat` |
| 更新会话 | PATCH | `/rest/data/v2.0/xobjects/serviceChat/{id}` |
| 删除会话 | DELETE | `/rest/data/v2.0/xobjects/serviceChat/{id}` |
| 获取会话信息 | GET | `/rest/data/v2.0/xobjects/serviceChat/{id}` |
| 获取互动历史接口描述 | GET | `/rest/data/v2.0/xobjects/serviceVisitHistory/description` |
| 创建互动历史 | POST | `/rest/data/v2.0/xobjects/serviceVisitHistory` |
| 更新互动历史 | PATCH | `/rest/data/v2.0/xobjects/serviceVisitHistory/{id}` |
| 获取互动历史信息 | GET | `/rest/data/v2.0/xobjects/serviceVisitHistory/{id}` |
| 查询其所在技能组 | GET | `/rest/sc/v1.0/im/agentInfo/querySkillInfoByAgentId/{agentId}` |
| 获取技能组列表 | GET | `/rest/sc/v1.0/im/skillsetInfo/querySkillsetList` |
| 获取技能组成员信息 | GET | `/rest/sc/v1.0/im/agentInfo/queryAgentInfoBySkillId/{skillId}` |
| 获取技能组成员名称 | GET | `/rest/sc/v1.0/im/agentInfo/queryAgentsBySkillId/{skillId}` |
| 获取现场人员工作时间 | POST | `/rest/sc/v1.0/timeSchedule/getAvailableWorkTime` |
| 访客识别 | GET | `/rest/sc/v1.0/workbench/associateAccountToVisitor/{id}/{accountContactType}/{visitorId}` |
| 查询客户/联系人信息 | GET | `/rest/sc/v1.0/workbench/queryAccountAndContact/{queryInfo}` |
| 获取用户坐席账号信息 | GET | `/rest/sc/v1.0/userSeatInfo/getSeatInfoByUserId/{userId}` |
| 获取授权微信服务号列表 | GET | `/rest/sc/v1.0/weChatTemplate/getWeChatAccountList` |
| 获取微信模板消息触发事件（旧） | GET | `/rest/sc/v1.0/weChatTemplate/getWeChatTemplateEventList` |
| 发送微信模板消息 | POST | `/rest/sc/v1.0/weChatTemplate/sendWeChatTemplateAsync` |
| 创建个人备件库 | POST | `/rest/data/v2.0/xobjects/personalWarehouse` |
| 删除个人备件库 | DELETE | `/rest/data/v2.0/xobjects/personalWarehouse/{id}` |
| 个人备件库明细入库 | POST | `/rest/data/v2.0/xobjects/personalWarehouseDetail/actions/stockIn` |
| 个人备件库明细出库 | POST | `/rest/data/v2.0/xobjects/personalWarehouseDetail/actions/stockOut` |
| 删除个人备件库明细 | DELETE | `/rest/data/v2.0/xobjects/personalWarehouseDetail/{id}` |
| 获取采购订单接口描述 | GET | `/rest/data/v2.0/xobjects/purchaseOrder/description` |
| 创建采购订单 | POST | `/rest/data/v2.0/xobjects/purchaseOrder` |
| 更新采购订单 | PATCH | `/rest/data/v2.0/xobjects/purchaseOrder/{id}` |
| 删除采购订单 | DELETE | `/rest/data/v2.0/xobjects/purchaseOrder/{id}` |
| 获取采购订单信息 | GET | `/rest/data/v2.0/xobjects/purchaseOrder/{id}` |
| 采购订单确认生效 | PATCH | `/rest/data/v2.0/xobjects/purchaseOrder/actions/confirm/{id}` |
| 完成采购订单 | PATCH | `/rest/data/v2.0/xobjects/purchaseOrder/actions/finish/{id}` |
| 作废采购订单 | PATCH | `/rest/data/v2.0/xobjects/purchaseOrder/actions/cancel/{id}` |
| 获取采购订单明细接口描述 | GET | `/rest/data/v2.0/xobjects/purchaseOrderDetail/description` |
| 创建采购订单明细 | POST | `/rest/data/v2.0/xobjects/purchaseOrderDetail` |
| 更新采购订单明细 | PATCH | `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}` |
| 删除采购订单明细 | DELETE | `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}` |
| 获取采购订单信息明细 | GET | `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}` |
| 创建表单 | POST | `/rest/data/v2.0/xobjects/formInstance/actions/create` |
| 触发对象映射规则创建目标实体数据 | POST | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/createObjectByMapRule` |
| 触发对象映射规则查询实体数据 | GET | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transformObjectByMapRule` |
| 查询对象映射规则 | GET | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/queryMapRuleByTargetApiKey` |
| 根据对象映射规则转换实体数据 | POST | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transformObjectByMapRule` |
| 获取时间表接口描述 | GET | `/rest/data/v2.0/xobjects/timeSheet/description` |
| 创建时间表 | POST | `/rest/data/v2.0/xobjects/timeSheet` |
| 更新时间表 | PATCH | `/rest/data/v2.0/xobjects/timeSheet/{id}` |
| 删除时间表 | DELETE | `/rest/data/v2.0/xobjects/timeSheet/{id}` |
| 获取时间表信息 | GET | `/rest/data/v2.0/xobjects/timeSheet/{id}` |
| 获取质保接口描述 | GET | `/rest/data/v2.0/xobjects/qualityAssurance/description` |
| 创建质保 | POST | `/rest/data/v2.0/xobjects/qualityAssurance` |
| 更新质保 | PATCH | `/rest/data/v2.0/xobjects/qualityAssurance/{id}` |
| 删除质保 | DELETE | `/rest/data/v2.0/xobjects/qualityAssurance/{id}` |
| 获取质保信息 | GET | `/rest/data/v2.0/xobjects/qualityAssurance/{id}` |
| 获取质保产品接口描述 | GET | `/rest/data/v2.0/xobjects/qualityAssuranceProduct/description` |
| 创建质保产品 | POST | `/rest/data/v2.0/xobjects/qualityAssuranceProduct` |
| 更新质保产品 | PATCH | `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}` |
| 删除质保产品 | DELETE | `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}` |
| 获取质保产品信息 | GET | `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}` |
| 获取质保档案接口描述 | GET | `/rest/data/v2.0/xobjects/qualityAssuranceFile/description` |
| 创建质保档案 | POST | `/rest/data/v2.0/xobjects/qualityAssuranceFile` |
| 更新质保档案 | PATCH | `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}` |
| 删除质保档案 | DELETE | `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}` |
| 获取质保档案信息 | GET | `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}` |
| 获取外呼目标接口描述 | GET | `/rest/data/v2.0/xobjects/outboundTaskRecord/description` |
| 创建外呼目标 | POST | `/rest/data/v2.0/xobjects/outboundTaskRecord` |
| 更新外呼目标 | PATCH | `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}` |
| 锁定外呼目标 | PUT | `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/locks/{id}/lock` |
| 解锁外呼目标 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/locks/{id}/lock` |
| 删除外呼目标 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}` |
| 获取外呼目标信息 | GET | `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}` |
| 关注外呼目标 | PUT | `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/follows/{id}/follow` |
| 取消关注外呼目标 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/follows/{id}/follow` |
| 转移外呼目标 | PUT | `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/transfers/{targetUserId}/{id}` |
| 获取外呼目标池接口描述 | GET | `/rest/data/v2.0/xobjects/outboundTaskPool/description` |
| 创建外呼目标池 | POST | `/rest/data/v2.0/xobjects/outboundTaskPool` |
| 更新外呼目标池 | PATCH | `/rest/data/v2.0/xobjects/outboundTaskPool/{id}` |
| 锁定外呼目标池 | PUT | `/rest/data/v2.0/xobjects/outboundTaskPool/actions/locks/{id}/lock` |
| 解锁外呼目标池 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskPool/actions/locks/{id}/lock` |
| 删除外呼目标池 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskPool/{id}` |
| 获取外呼目标池信息 | GET | `/rest/data/v2.0/xobjects/outboundTaskPool/{id}` |
| 关注外呼目标池 | PUT | `/rest/data/v2.0/xobjects/outboundTaskPool/actions/follows/{id}/follow` |
| 取消关注外呼目标池 | DELETE | `/rest/data/v2.0/xobjects/outboundTaskPool/actions/follows/{id}/follow` |
| 转移外呼目标池 | PUT | `/rest/data/v2.0/xobjects/outboundTaskPool/actions/transfers/{targetUserId}/{id}` |
| 获取外呼任务接口描述 | GET | `/rest/data/v2.0/xobjects/outboundTask/description` |
| 创建外呼任务 | POST | `/rest/data/v2.0/xobjects/outboundTask` |
| 更新外呼任务 | PATCH | `/rest/data/v2.0/xobjects/outboundTask/{id}` |
| 锁定外呼任务 | PUT | `/rest/data/v2.0/xobjects/outboundTask/actions/locks/{id}/lock` |
| 解锁外呼任务 | DELETE | `/rest/data/v2.0/xobjects/outboundTask/actions/locks/{id}/lock` |
| 删除外呼任务 | DELETE | `/rest/data/v2.0/xobjects/outboundTask/{id}` |
| 获取外呼任务信息 | GET | `/rest/data/v2.0/xobjects/outboundTask/{id}` |
| 关注外呼任务 | PUT | `/rest/data/v2.0/xobjects/outboundTask/actions/follows/{id}/follow` |
| 取消关注外呼任务 | DELETE | `/rest/data/v2.0/xobjects/outboundTask/actions/follows/{id}/follow` |
| 转移外呼任务 | PUT | `/rest/data/v2.0/xobjects/outboundTask/actions/transfers/{targetUserId}/{id}` |
| 获取排队数据 | GET | `/rest/sc/v1.0/imMonitor/getPresentQueueDataBySkillId/{skillId}` |
| 获取会话数据 | GET | `/rest/sc/v1.0/imMonitor/getPresentChatDataBySkillId/{skillId}` |
| 获取坐席数据 | GET | `/rest/sc/v1.0/imMonitor/getPresentAgentDataBySkillId/{skillId}` |
| 获取员工技能接口描述 | GET | `/rest/data/v2.0/xobjects/employeeSkill/description` |
| 创建员工技能 | POST | `/rest/data/v2.0/xobjects/employeeSkill` |
| 更新员工技能 | PATCH | `/rest/data/v2.0/xobjects/employeeSkill/{id}` |
| 锁定员工技能 | PUT | `/rest/data/v2.0/xobjects/employeeSkill/actions/locks/{id}/lock` |
| 解锁员工技能 | DELETE | `/rest/data/v2.0/xobjects/employeeSkill/actions/locks/{id}/lock` |
| 删除员工技能 | DELETE | `/rest/data/v2.0/xobjects/employeeSkill/{id}` |
| 获取员工技能信息 | GET | `/rest/data/v2.0/xobjects/employeeSkill/{id}` |
| 获取WhatsApp消息模板发送记录接口描述 | GET | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/description` |
| 更新WhatsApp消息模板发送记录 | PATCH | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}` |
| 锁定WhatsApp消息模板发送记录 | PUT | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/actions/locks/{id}/lock` |
| 解锁WhatsApp消息模板发送记录 | DELETE | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/actions/locks/{id}/lock` |
| 删除WhatsApp消息模板发送记录 | DELETE | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}` |
| 获取WhatsApp消息模板发送记录信息 | GET | `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}` |
| 发送WhatsApp模板消息 | POST | `/rest/sc/v1.0/whatsapp/template/send/trigger/message` |
| 获取电子券接口描述 | GET | `/rest/data/v2.0/xobjects/coupon/description` |
| 获取电子券信息 | GET | `/rest/data/v2.0/xobjects/coupon/{id}` |
| 查询电子券列表 | POST | `/rest/data/v2.0/xobjects/coupon/actions/queryList` |
| 领取电子券 | POST | `/rest/data/v2.0/xobjects/coupon/actions/couponReceive` |
| 核销电子券 | PATCH | `/rest/data/v2.0/xobjects/coupon/actions/couponClosure` |
| 发行电子券（异步） | POST | `/rest/data/v2.0/xobjects/coupon/actions/publish` |
| 删除电子券 | DELETE | `/rest/data/v2.0/xobjects/coupon/{ids}/batch/interim` |
| 获取电子券方案接口描述 | GET | `/rest/data/v2.0/xobjects/couponIssue/description` |
| 创建保存电子券方案 | POST | `/rest/data/v2.0/xobjects/couponIssue` |
| 查询电子券方案列表 | POST | `/rest/data/v2.0/xobjects/couponIssue/actions/queryList` |
| 获取电子券方案信息 | GET | `/rest/data/v2.0/xobjects/couponIssue/{id}` |
| 查询电子券方案领取客户和核销客户条件 | GET | `/rest/data/v2.0/xobjects/couponIssue/actions/getCouponIssueRules` |
| 变更电子券方案状态 | POST | `/rest/data/v2.0/xobjects/couponIssue/actions/changeStatus` |
| 获取电子券追加接口描述 | GET | `/rest/data/v2.0/xobjects/couponAppend/description` |
| 创建电子券追加 | POST | `/rest/data/v2.0/xobjects/couponAppend` |
| 更新电子券追加 | PATCH | `/rest/data/v2.0/xobjects/couponAppend/{id}` |
| 锁定电子券追加 | PUT | `/rest/data/v2.0/xobjects/couponAppend/actions/locks/{id}/lock` |
| 解锁电子券追加 | DELETE | `/rest/data/v2.0/xobjects/couponAppend/actions/locks/{id}/lock` |
| 删除电子券追加 | DELETE | `/rest/data/v2.0/xobjects/couponAppend/{id}` |
| 获取电子券追加信息 | GET | `/rest/data/v2.0/xobjects/couponAppend/{id}` |
| 通过外部部门ID获取经销商客户 | POST | `/rest/prm/v1.0/account/getAccountByDepartId` |
| 通过外部用户ID获取经销商客户 | POST | `/rest/prm/v1.0/account/getAccountByUserId` |
| 查询周边客户 | POST | `/rest/data/v2.0/xobjects/account/actions/around` |
| 获取促销累加明细接口描述 | GET | `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/description` |
| 创建促销累加明细 | POST | `/rest/data/v2.0/xobjects/salesPromotionCounterDetail` |
| 批量创建促销累加明细 | POST | `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/batch` |
| 获取促销累加明细信息 | GET | `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/{id}` |
| 根据客户获取符合条件的促销活动 | POST | `/rest/data/v2.0/xobjects/salesPromotion/query/findAllWithAccount` |
| 根据促销活动获得符合条件的客户 | POST | `/rest/data/v2.0/xobjects/salesPromotion/query/findAccountByPromotion` |
| 获取返利规则接口描述 | GET | `/rest/data/v2.0/xobjects/rebateRule/description` |
| 获取返利规则信息 | GET | `/rest/data/v2.0/xobjects/rebateRule/{id}` |
| 获取返利方案接口描述 | GET | `/rest/data/v2.0/xobjects/rebatePlan/description` |
| 创建返利方案 | POST | `/rest/data/v2.0/xobjects/rebatePlan/masterdetails` |
| 更新返利方案 | PATCH | `/rest/data/v2.0/xobjects/rebatePlan/masterdetails` |
| 锁定返利方案 | PUT | `/rest/data/v2.0/xobjects/rebatePlan/actions/locks/{id}/lock` |
| 解锁返利方案 | DELETE | `/rest/data/v2.0/xobjects/rebatePlan/actions/locks/{id}/lock` |
| 删除返利方案 | DELETE | `/rest/data/v2.0/xobjects/rebatePlan/{id}` |
| 获取返利方案信息 | GET | `/rest/data/v2.0/xobjects/rebatePlan/{id}` |
| 生效或中止返利方案 | PATCH | `/rest/data/v2.0/xobjects/rebatePlan/actions/updateStatus` |
| 查询返利方案投放范围 | POST | `/rest/data/v2.0/xobjects/rebatePlan/actions/applicationAccounts` |
| 查询返利方案档期设置 | POST | `/rest/data/v2.0/xobjects/rebatePlan/actions/fiscalSetting` |
| 获取返利核销单接口描述 | GET | `/rest/data/v2.0/xobjects/rebateVerification/description` |
| 更新返利核销单 | PATCH | `/rest/data/v2.0/xobjects/rebateVerification/{id}` |
| 锁定返利核销单 | PUT | `/rest/data/v2.0/xobjects/rebateVerification/actions/locks/{id}/lock` |
| 解锁返利核销单 | DELETE | `/rest/data/v2.0/xobjects/rebateVerification/actions/locks/{id}/lock` |
| 获取返利核销单信息 | GET | `/rest/data/v2.0/xobjects/rebateVerification/{id}` |
| 获取对账单接口描述 | GET | `/rest/data/v2.0/xobjects/reconciliationStatement/description` |
| 创建对账单 | POST | `/rest/data/v2.0/xobjects/reconciliationStatement/masterdetails` |
| 更新对账单 | PATCH | `/rest/data/v2.0/xobjects/reconciliationStatement/masterdetails` |
| 锁定对账单 | PUT | `/rest/data/v2.0/xobjects/reconciliationStatement/actions/locks/{id}/lock` |
| 解锁对账单 | DELETE | `/rest/data/v2.0/xobjects/reconciliationStatement/actions/locks/{id}/lock` |
| 删除对账单 | DELETE | `/rest/data/v2.0/xobjects/reconciliationStatement/{id}` |
| 获取对账单信息 | GET | `/rest/data/v2.0/xobjects/reconciliationStatement/{id}` |
| 获取对账单明细接口描述 | /REST/DATA/V2.0/XOBJECTS/RECONCILIATIONDETAILS/DESCRIPTION | `GET` |
| 锁定对账单明细 | PUT | `/rest/data/v2.0/xobjects/reconciliationDetails/actions/locks/{id}/lock` |
| 解锁对账单明细 | DELETE | `/rest/data/v2.0/xobjects/reconciliationDetails/actions/locks/{id}/lock` |
| 获取对账单明细信息 | GET | `/rest/data/v2.0/xobjects/reconciliationDetails/{id}` |
| 获取对账配置接口描述 | GET | `/rest/data/v2.0/xobjects/reconciliationConfiguration/description` |
| 创建对账配置 | POST | `/rest/data/v2.0/xobjects/reconciliationConfiguration/masterdetails` |
| 更新对账配置 | PATCH | `/rest/data/v2.0/xobjects/reconciliationConfiguration/masterdetails` |
| 锁定对账配置 | PUT | `/rest/data/v2.0/xobjects/reconciliationConfiguration/actions/locks/{id}/lock` |
| 解锁对账配置 | DELETE | `/rest/data/v2.0/xobjects/reconciliationConfiguration/actions/locks/{id}/lock` |
| 删除对账配置 | DELETE | `/rest/data/v2.0/xobjects/reconciliationConfiguration/{id}` |
| 获取对账配置信息 | GET | `/rest/data/v2.0/xobjects/reconciliationConfiguration/{id}` |
| 获取申诉记录接口描述 | GET | `/rest/data/v2.0/xobjects/statementRecord/description` |
| 创建申诉记录 | POST | `/rest/data/v2.0/xobjects/statementRecord/masterdetails` |
| 更新申诉记录 | PATCH | `/data/v2.0/xobjects/statementRecord/masterdetails` |
| 锁定申诉记录 | PUT | `/rest/data/v2.0/xobjects/statementRecord/actions/locks/{id}/lock` |
| 解锁申诉记录 | DELETE | `/rest/data/v2.0/xobjects/statementRecord/actions/locks/{id}/lock` |
| 删除申诉记录 | DELETE | `/rest/data/v2.0/xobjects/statementRecord/{id}` |
| 获取申诉记录信息 | GET | `/rest/data/v2.0/xobjects/statementRecord/{id}` |
| 获取可售范围接口描述 | GET | `/rest/data/v2.0/xobjects/saleableScope/description` |
| 创建可售范围 | POST | `/rest/data/v2.0/xobjects/saleableScope/masterdetails` |
| 更新可售范围 | PATCH | `/rest/data/v2.0/xobjects/saleableScope/masterdetails` |
| 锁定可售范围 | PUT | `/rest/data/v2.0/xobjects/saleableScope/actions/locks/{id}/lock` |
| 解锁可售范围 | DELETE | `/rest/data/v2.0/xobjects/saleableScope/actions/locks/{id}/lock` |
| 删除可售范围 | DELETE | `/rest/data/v2.0/xobjects/saleableScope/{id}` |
| 获取可售范围信息 | GET | `/rest/data/v2.0/xobjects/saleableScope/{id}` |
| 是否开启可售范围 | GET | `/rest/data/v2.0/xobjects/saleableScope/actions/isOpenSaleableScope` |
| 获取客户可售范围 | GET | `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/saleableScopes` |
| 获取客户可售产品 | GET | `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/saleableProducts` |
| 获取产品价格表关系 | POST | `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/productsPriceBook` |
| 获取渠道协议接口描述 | GET | `/rest/data/v2.0/xobjects/channelAgreement/description` |
| 创建渠道协议 | POST | `/rest/data/v2.0/xobjects/channelAgreement/masterdetails` |
| 更新渠道协议 | PATCH | `/rest/data/v2.0/xobjects/channelAgreement/masterdetails` |
| 锁定渠道协议 | PUT | `/rest/data/v2.0/xobjects/channelAgreement/actions/locks/{id}/lock` |
| 解锁渠道协议 | DELETE | `/rest/data/v2.0/xobjects/channelAgreement/actions/locks/{id}/lock` |
| 删除渠道协议 | DELETE | `/rest/data/v2.0/xobjects/channelAgreement/{id}` |
| 获取渠道协议信息 | GET | `/rest/data/v2.0/xobjects/channelAgreement/{id}` |
| 获取积分方案接口描述 | GET | `/rest/data/v2.0/xobjects/pointPlan/description` |
| 创建积分方案 | POST | `/rest/data/v2.0/xobjects/pointPlan/masterdetails` |
| 更新积分方案 | PATCH | `/rest/data/v2.0/xobjects/pointPlan/masterdetails` |
| 锁定积分方案 | PUT | `/rest/data/v2.0/xobjects/pointPlan/actions/locks/{id}/lock` |
| 解锁积分方案 | DELETE | `/rest/data/v2.0/xobjects/pointPlan/actions/locks/{id}/lock` |
| 删除积分方案 | DELETE | `/rest/data/v2.0/xobjects/pointPlan/{id}` |
| 获取积分方案详细信息 | GET | `/rest/data/v2.0/xobjects/pointPlan/{id}` |
| 获取客户积分方案 | GET | `/rest/data/v2.0/xobjects/pointPlan/{accountId}/availablePointPlans` |
| 计算积分 | POST | `/rest/data/v2.0/xobjects/pointPlan/actions/pointCalculate` |
| 获取积分规则接口描述 | GET | `/rest/data/v2.0/xobjects/pointRule/description` |
| 创建积分规则 | POST | `/rest/data/v2.0/xobjects/pointRule/masterdetails` |
| 更新积分规则 | PATCH | `/rest/data/v2.0/xobjects/pointRule/masterdetails` |
| 锁定积分规则 | PUT | `/rest/data/v2.0/xobjects/pointRule/actions/locks/{id}/lock` |
| 解锁积分规则 | DELETE | `/rest/data/v2.0/xobjects/pointRule/actions/locks/{id}/lock` |
| 删除积分规则 | DELETE | `rest/data/v2.0/xobjects/pointRule/{id}` |
| 获取积分规则详细信息 | GET | `/rest/data/v2.0/xobjects/pointRule/{id}` |
| 获取积分明细接口描述 | GET | `/rest/data/v2.0/xobjects/pointDetail/description` |
| 创建积分明细 | POST | `/rest/data/v2.0/xobjects/pointDetail/masterdetails` |
| 更新积分明细 | PATCH | `/rest/data/v2.0/xobjects/pointDetail/masterdetails` |
| 锁定积分明细 | PUT | `/rest/data/v2.0/xobjects/pointDetail/actions/locks/{id}/lock` |
| 解锁积分明细 | DELETE | `/rest/data/v2.0/xobjects/pointDetail/actions/locks/{id}/lock` |
| 删除积分明细 | DELETE | `/rest/data/v2.0/xobjects/pointDetail/{id}` |
| 获取积分明细详细信息 | GET | `/rest/data/v2.0/xobjects/pointDetail/{id}` |
| 获取积分来源接口描述 | GET | `/rest/data/v2.0/xobjects/pointDetailSource/description` |
| 创建积分来源 | POST | `/rest/data/v2.0/xobjects/pointDetailSource/masterdetails` |
| 更新积分来源 | PATCH | `/rest/data/v2.0/xobjects/pointDetailSource/masterdetails` |
| 锁定积分来源 | PUT | `/rest/data/v2.0/xobjects/pointDetailSource/actions/locks/{id}/lock` |
| 解锁积分来源 | DELETE | `/rest/data/v2.0/xobjects/pointDetailSource/actions/locks/{id}/lock` |
| 删除积分来源 | DELETE | `/rest/data/v2.0/xobjects/pointDetailSource/{id}` |
| 获取积分来源详细信息 | GET | `/rest/data/v2.0/xobjects/pointDetailSource/{id}` |
| 获取预算调整接口描述 | GET | `/rest/data/v2.0/xobjects/budgetAdjustment/description` |
| 创建预算调整 | POST | `/rest/data/v2.0/xobjects/budgetAdjustment/masterdetails` |
| 更新预算调整 | PATCH | `/rest/data/v2.0/xobjects/budgetAdjustment/masterdetails` |
| 锁定预算调整 | PUT | `/rest/data/v2.0/xobjects/budgetAdjustment/actions/locks/{id}/lock` |
| 解锁预算调整 | DELETE | `/rest/data/v2.0/xobjects/budgetAdjustment/actions/locks/{id}/lock` |
| 删除预算调整 | DELETE | `/rest/data/v2.0/xobjects/budgetAdjustment/{id}` |
| 获取预算调整详细信息 | GET | `/rest/data/v2.0/xobjects/budgetAdjustment/{id}` |
| 好友关系关联业务对象 | POST | `/rest/qywx/v2.0/api/qwSidebar/actions/updateQwSidebarRelateEntity` |
| 分页获取主体下聊天记录 | GET | `/rest/data/v2.0/qywx/chatRecord/actions/fetch?corpId={corpId}&pageNo={pageNo}&pageSize={pageSize}` |
| 上传素材资源 | MULTIPART/FORM-DATA POST | `/rest/mc/v2.0/cms/api/action/uploadFile` |
| 创建素材 | POST | `/rest/mc/v2.0/cms/api/action/createMaterial` |
| 更新素材 | POST | `/rest/mc/v2.0/cms/api/action/updateMaterial/{id}` |
| 查询素材列表 | POST | `/rest/mc/v2.0/cms/material-center/material/queryAll` |
| 修改素材状态 | PUT | `/rest/mc/v2.0/cms/material-center/material/batchUpdateStatus/{status}` |
| 创建素材分类 | POST | `/rest/mc/v2.0/cms/api/category/action/create` |
| 更新素材分类 | POST | `/rest/mc/v2.0/cms/api/category/action/update` |
| 查询素材分类列表 | POST | `/rest/mc/v2.0/cms/api/category/action/list` |
| 删除素材分类 | POST | `/rest/mc/v2.0/cms/api/category/action/delete` |
| 获取素材发送行为记录接口描述 | GET | `/rest/data/v2.0/xobjects/materialForward/description` |
| 获取素材发送行为记录信息 | GET | `/rest/data/v2.0/xobjects/materialForward/{id}` |
| 获取素材访客行为记录接口描述 | GET | `/rest/data/v2.0/xobjects/materialVisitorBehavior/description` |
| 获取素材访客行为记录信息 | GET | `/rest/data/v2.0/xobjects/materialVisitorBehavior/{id}` |
| 获取素材行为用户信息接口描述 | GET | `/rest/data/v2.0/xobjects/materialVisitor/description` |
| 获取素材行为用户信息的信息 | GET | `/rest/data/v2.0/xobjects/materialVisitor/{id}` |
| 素材访客信息上报 | POST | `/rest/mc/v2.0/cms/api/buried-point/saveBehaviorUser` |
| 素材访问行为上报 | POST | `/rest/mc/v2.0/cms/api/buried-point/pushEvent` |
| 查询素材访客信息 | GET | `/rest/mc/v2.0/cms/api/buried-point/queryBehaviorUser` |
| 查询发送和转发素材记录 | GET | `/rest/mc/v2.0/cms/api/buried-point/queryForwardRecord` |
| 查询素材访问行为记录 | GET | `/rest/mc/v2.0/cms/api/buried-point/queryBehaviorRecord` |
| 查询话术或问答 | POST | `/rest/mc/v2.0/cms/speechLibrary/queryAll` |
| 修改话术或问答状态 | POST | `/rest/mc/v2.0/cms/speechLibrary/updateStatus` |
| 获取营销线索接口描述 | GET | `/rest/data/v2.0/xobjects/marketingLead/description` |
| 创建营销线索 | POST | `/rest/data/v2.0/xobjects/marketingLead` |
| 更新营销线索 | PATCH | `/rest/data/v2.0/xobjects/marketingLead/{id}` |
| 删除营销线索 | DELETE | `/rest/data/v2.0/xobjects/marketingLead/{id}` |
| 获取营销线索信息 | GET | `/rest/data/v2.0/xobjects/marketingLead/{id}` |
| 获取营销线索总数 | POST | `/rest/data/v2.0/xobjects/marketingLead/actions/count` |
| 获取营销线索列表信息 | POST | `/rest/data/v2.0/xobjects/marketingLead/actions/query` |
| 营销线索升级 | POST | `/rest/data/v2/xobjects/marketingLead/actions/convert` |
| 获取营销任务接口描述 | GET | `/rest/data/v2.0/xobjects/mcTask/description` |
| 获取营销任务信息 | GET | `/rest/data/v2.0/xobjects/mcTask/{id}` |
| 获取营销任务内容接口描述 | GET | `/rest/data/v2.0/xobjects/mcTaskContent/description` |
| 获取营销任务内容信息 | GET | `/rest/data/v2.0/xobjects/mcTaskContent/{id}` |
| 获取营销任务执行明细接口描述 | GET | `/rest/data/v2.0/xobjects/mcTaskDetail/description` |
| 获取营销任务执行明细信息 | GET | `/rest/data/v2.0/xobjects/mcTaskDetail/{id}` |
| 获取销售SOP接口描述 | GET | `/rest/data/v2.0/xobjects/salesSOP/description` |
| 获取销售SOP信息 | GET | `/rest/data/v2.0/xobjects/salesSOP/{id}` |
| 获取销售SOP任务执行记录接口描述 | GET | `/rest/data/v2.0/xobjects/salesSOPInstanceTask/description` |
| 获取销售SOP任务执行记录信息 | GET | `/rest/data/v2.0/xobjects/salesSOPInstanceTask/{id}` |
| 获取销售SOP执行实例接口描述 | GET | `/rest/data/v2.0/xobjects/salesSOPInstance/description` |
| 获取销售SOP执行实例信息 | GET | `/rest/data/v2.0/xobjects/salesSOPInstance/{id}` |
| 查询标签列表 | POST | `/rest/qywx/v2.0/api/customer/tagGroup/list?corpId={corpId}` |
| 批量增量打个人标签 | POST | `/rest/qywx/v2.0/api/customer/markTag/batch/personal?corpId={corpId}` |
| 批量增量打共享标签 | POST | `/rest/qywx/v2.0/api/customer/markTag/batch/shared?corpId={corpId}` |
| 获取个人标签数据 | POST | `/rest/qywx/v2.0/api/customer/tagRecord/list/personal?corpId={corpId}` |
| 获取共享标签数据 | POST | `/rest/qywx/v2.0/api/customer/tagRecord/list/shared?corpId={corpId}` |
| 新建标签组 | POST | `/rest/qywx/v2.0/api/customer/tagGroup/create` |
| 修改标签组 | PUT | `/rest/qywx/v2.0/api/customer/tagGroup/update` |
| 获取多企微群发接口描述 | GET | `/rest/data/v2.0/xobjects/multiQwMassSend/description` |
| 获取多企微群发信息 | GET | `/rest/data/v2.0/xobjects/multiQwMassSend/{id}` |
| 获取多企微任务接口描述 | GET | `/rest/data/v2.0/xobjects/multiQwTask/description` |
| 获取多企微任务信息 | GET | `/rest/data/v2.0/xobjects/multiQwTask/{id}` |
| 获取多企微任务明细接口描述 | GET | `/rest/data/v2.0/xobjects/multiQwTaskDetail/description` |
| 获取多企微任务明细信息 | GET | `/rest/data/v2.0/xobjects/multiQwTaskDetail/{id}` |
| 获取企微联系人接口描述 | GET | `/rest/data/v2.0/xobjects/qwContact/description` |
| 获取企微联系人信息 | GET | `/rest/data/v2.0/xobjects/qwContact/{id}` |
| 获取企微标签关系接口描述 | GET | `/rest/data/v2.0/xobjects/qwTagRelation/description` |
| 获取企微标签关系信息 | GET | `/rest/data/v2.0/xobjects/qwTagRelation/{id}` |
| 获取企微好友关系接口描述 | GET | `/rest/data/v2.0/xobjects/qwSidebar/description` |
| 获取企微好友关系信息 | GET | `/rest/data/v2.0/xobjects/qwSidebar/{id}` |
| 获取企微群接口描述 | GET | `/rest/data/v2.0/xobjects/qwGroup/description` |
| 获取企微群信息 | GET | `/rest/data/v2.0/xobjects/qwGroup/{id}` |
| 获取企微群成员接口描述 | GET | `/rest/data/v2.0/xobjects/qwGroupMember/description` |
| 获取企微群成员信息 | GET | `/rest/data/v2.0/xobjects/qwGroupMember/{id}` |
| 获取企微群发任务接口描述 | GET | `/rest/data/v2.0/xobjects/massSendTask/description` |
| 获取企微群发任务信息 | GET | `/rest/data/v2.0/xobjects/massSendTask/{id}` |
| 获取企微群发任务内容接口描述 | GET | `/rest/data/v2.0/xobjects/massSendTaskContent/description` |
| 获取企微群发任务内容信息 | GET | `/rest/data/v2.0/xobjects/massSendTaskContent/{id}` |
| 获取企微群发结果明细接口描述 | GET | `/rest/data/v2.0/xobjects/massSendTaskDetail/description` |
| 获取企微群发结果明细信息 | GET | `/rest/data/v2.0/xobjects/massSendTaskDetail/{id}` |
| 获取群标签日志接口描述 | GET | `/rest/data/v2.0/xobjects/qwGroupTagLog/description` |
| 获取群标签日志信息 | GET | `/rest/data/v2.0/xobjects/qwGroupTagLog/{id}` |
| 获取群SOP接口描述 | GET | `/rest/data/v2.0/xobjects/groupSop/description` |
| 获取群SOP信息 | GET | `/rest/data/v2.0/xobjects/groupSop/{id}` |
| 获取群SOP实例任务接口描述 | GET | `/rest/data/v2.0/xobjects/groupSopInstanceTask/description` |
| 获取群SOP实例任务信息 |  | `/rest/data/v2.0/xobjects/groupSopInstanceTask/{id}` |
| 获取群SOP执行实例接口描述 | GET | `/rest/data/v2.0/xobjects/groupSopInstance/description` |
| 获取群SOP执行实例信息 | GET | `/rest/data/v2.0/xobjects/groupSopInstance/{id}` |
| 获取微信访客接口描述 | GET | `/rest/data/v2.0/xobjects/wxVisitor/description` |
| 获取微信访客信息 | GET | `/rest/data/v2.0/xobjects/wxVisitor/{id}` |
| 获取敏感词监控接口描述 | GET | `/rest/data/v2.0/xobjects/sensitiveWordInstance/description` |
| 获取敏感词监控信息 | GET | `/rest/data/v2.0/xobjects/sensitiveWordInstance/{id}` |
| 获取企微直播接口描述 | GET | `/rest/data/v2.0/xobjects/living/description` |
| 获取企微直播信息 | GET | `/rest/data/v2.0/xobjects/living/{id}` |
| 获取企微直播明细接口描述 | GET | `/rest/data/v2.0/xobjects/livingDetail/description` |
| 获取企微直播明细信息 | GET | `/rest/data/v2.0/xobjects/livingDetail/{id}` |
| 获取报名留资活动接口描述 | GET | `/rest/data/v2.0/xobjects/offlineCampaign/description` |
| 获取报名留资活动信息 | GET | `/rest/data/v2.0/xobjects/offlineCampaign/{id}` |
| 获取市场活动接口描述 | GET | `/rest/data/v2.0/xobjects/campaign/description` |
| 获取市场活动信息 | GET | `/rest/data/v2.0/xobjects/campaign/{id}` |
| 获取市场活动影响力接口描述 | GET | `/rest/data/v2.0/xobjects/campaignInfluence/description` |
| 获取市场活动影响力信息 | GET | `/rest/data/v2.0/xobjects/campaignInfluence/{id}` |
| 获取会议活动接口描述 | GET | `/rest/data/v2.0/xobjects/conferenceCampaign/description` |
| 获取会议活动信息 | GET | `/rest/data/v2.0/xobjects/conferenceCampaign/{id}` |
| 获取活动成员接口描述 | GET | `/rest/data/v2.0/xobjects/campaignMember/description` |
| 获取活动成员信息 | GET | `/rest/data/v2.0/xobjects/campaignMember/{id}` |
| 获取活动短信记录接口描述 | GET | `/rest/data/v2.0/xobjects/campaignSmsLog/description` |
| 获取活动短信记录信息 | GET | `/rest/data/v2.0/xobjects/campaignSmsLog/{id}` |
| 获取内容传播活动接口描述 | GET | `/rest/data/v2.0/xobjects/contentCampaign/description` |
| 获取内容传播活动信息 | GET | `/rest/data/v2.0/xobjects/contentCampaign/{id}` |
| 获取易企秀中奖名单接口描述 | GET | `/rest/data/v2.0/xobjects/eqxWinner/description` |
| 获取易企秀中奖名单信息 | GET | `/rest/data/v2.0/xobjects/eqxWinner/{id}` |
| 获取易企秀游戏排名接口描述 | GET | `/rest/data/v2.0/xobjects/eqxGameRank/description` |
| 获取易企秀游戏排名信息 | GET | `/rest/data/v2.0/xobjects/eqxGameRank/{id}` |
| 获取易企秀参与抽奖名单接口描述 | GET | `/rest/data/v2.0/xobjects/eqxParticipant/description` |
| 获取易企秀参与抽奖名单信息 | GET | `/rest/data/v2.0/xobjects/eqxParticipant/{id}` |
| 创建常规任务 | POST | `/rest/mc/v2.0/wxkits/guide/actions/createTask` |
| 企微API调用适配器 | POST | `/rest/mc/v2.0/wxkits/qwapi/actions/invoke?corpId={corpId}` |
| 企业微信聊天记录查询 | POST | `/rest/data/v2.0/social/wxwork/actions/queryChatRecords` |
| 企业微信群发消息 | POST | `/rest/data/v2.0/social/qywxMsg/actions/batchSendMsg` |
| 企业微信根据时间范围更新群发任务结果 | GET | `/rest/data/v2.0/social/qywxMsg/actions/updateMsgResult` |
| 获取企业微信联系人接口描述 | GET | `/rest/data/v2.0/xobjects/qwContact/description` |
| 获取企业微信联系人信息 | GET | `/rest/data/v2.0/xobjects/qwContact/actions/getByExternalUserId?externalUserId={externalUserId}` |
| 查询对象与企业微信联系人手动同步规则 | GET | `/rest/data/v2.0/xobjects/qwContact/actions/getManualSyncRule` |
| 查询CRM系统用户ID和第三方用户ID的关系 | GET | `/rest/auc/v2.0/third-party/actions/id-mapping` |
| 将CRM系统用户ID和第三方用户ID绑定 | POST | `/rest/auc/v2.0/third-party/actions/id-mapping` |
| 将CRM系统用户ID和第三方用户ID解除绑定 | DELETE | `/rest/auc/v2.0/third-party/actions/id-mapping` |
| 企业微信最近访问列表 | POST | `/data/v2.0/social/recentAccess` |
| 获取租户安装应用列表 | POST | `/rest/data/v2.0/social/qywx/actions/getSuiteIdsByTenantId?tenantId={tenantId}` |
| 企业微信会话列表查询 | POST | `/rest/data/v2.0/social/wxwork/actions/queryChatSessionsByUserId?userId={userId}` |
| 生成企微自定义主页地址 | POST | `/rest/data/v2.0/inner/wxApps/actions/generator-url` |
| 创建日程 | POST | `/rest/data/v2.0/xobjects/schedule/actions/createScheduleWithMember` |
| 合并日程 | POST | `/rest/data/v2.0/xobjects/schedule/actions/transferRelationObject` |
| 删除日程 | DELETE | `/rest/data/v2.0/xobjects/schedule/actions/deleteSplitNoCheck` |
| 查询对象下的日程 | GET | `/rest/data/v2.0/xobjects/schedule/actions/getScheduleByObjectInfo?objectId={objectId}&recordId={recordId}` |
| 获取日程成员信息 |  | `/rest/data/v2.0/xobjects/schedule/getScheduleMember/{scheduleId}` |
| 创建任务 | POST | `/rest/data/v2.0/xobjects/task/actions/createTaskWithMember` |
| 更新任务数据 | PATCH | `/rest/data/v2.0/xobjects/{api_key}/actions/update?dataId=` |
| 删除任务数据 | DELETE | `/rest/data/v2.0/xobjects/task/actions/deleteNoCheck` |
| 获取任务元数据详情 | POST | `/rest/data/v2.0/xobjects/{api_key}/description` |
| 查询获取任务分页列表数据 | POST | `/rest/data/v2.0/xobjects/{api_key}/actions/pagination?pageNo={pageNo}&pageSize={pageSize}` |
| 查询对象下的任务 | GET | `/rest/data/v2.0/xobjects/task/actions/getTaskByObjectInfo?objectId={objectId}&recordId={recordId}` |
| 合并任务 | POST | `/rest/data/v2.0/xobjects/task/actions/transferRelationObject/` |
| 查询待办 | GET | `/rest/data/v2.0/todo/actions/list` |
| 查询通知列表 | GET | `/rest/notice/v2.0/notice/actions/list` |
| 发送通知（支持新消息体结构） | POST | `/rest/notice/v2.0/newNotice` |
| 查询考勤统计记录 | GET | `/rest/data/v2.0/social/attendance/actions/getAttendanceStatistics` |
| 查询打卡记录 | GET | `/rest/data/v2.0/social/attendance/actions/getAttendanceRecords` |
| 公告类别接口 | GET | `/rest/data/v2.0/social/announcement/actions/getTypeList` |
| 公告列表接口 | GET | `/rest/data/v2.0/social/announcement/list` |
| 公告详情 | GET | `/rest/data/v2.0/social/announcement/{id}` |
| 关注业务对象 | POST | `/rest/data/v2.0/social/follow/action/batchFollowObjects` |
| 取消对业务对象的关注 | DELETE | `/rest/data/v2.0/social/follow/action/batchUnfollowObjects` |
| 获取对象下动态列表 | DELETE | `/rest/data/v2.0/social/story/actions/getObjectFeeds` |
| 查询关注的所有对象 | GET | `/rest/data/v2.0/social/follow/actions/getUserFollowGroups` |
| 获取费用接口描述 | GET | `/rest/data/v2.0/xobjects/expense/description` |
| 创建费用 | POST | `/rest/data/v2.0/xobjects/expense` |
| 更新费用 | PATCH | `/rest/data/v2.0/xobjects/expense/{id}` |
| 删除费用 | DELETE | `/rest/data/v2.0/xobjects/expense/{id}` |
| 获取费用信息 | GET | `/rest/data/v2.0/xobjects/expense/{id}` |
| 动态收藏 | GET | `rest/data/v2.0/social/story/actions/addFavorite` |
| 取消动态收藏 | GET | `rest/data/v2.0/social/story/actions/deleteFavorite` |
| 我的关注 | POST | `rest/data/v2.0/social/story/actions/indexFeeds` |
| 我的收藏 | GET | `rest/data/v2.0/social/story/actions/favoritesFeeds` |
| 我的部门 | GET | `rest/data/v2.0/social/story/actions/groupFeeds` |
| 我的发布 | GET | `rest/data/v2.0/social/story/actions/profileFeeds` |
| 我的公开 | GET | `rest/data/v2.0/social/story/actions/companyFeeds` |
| 动态评论列表 | GET | `rest/data/v2.0/social/story/actions/commentList` |
| 工作圈和对象下发送动态 | POST | `/rest/data/v2.0/social/story` |
| 获取评论列表 | GET | `/rest/comment/v2.0/query/comments/{systemId}` |
| 查询公司通讯录 | GET | `/rest/data/v2.0/social/colleague/list` |
| 创建文档目录 | POST | `/rest/file/v2.0/document/actions/createDirectory` |
| 文档目录授权 | POST | `/rest/file/v2.0/document/actions/directoryAuthUser` |
| 转移文档目录 | POST | `/rest/file/v2.0/document/actions/transferDirectory` |
| 删除文档目录 | GET | `/rest/file/v2.0/document/actions/deleteDirectory` |
| 上传文档 | POST | `/rest/file/v2.0/document/batchUploadAndBindObject` |
| 文档授权 | POST | `/rest/file/v2.0/document/actions/fileAuthUser` |
| 转移文档 | POST | `/rest/file/v2.0/document/actions/transferFile` |
| 删除文档 | GET | `/rest/file/v2.0/document/actions/deleteFile` |
| 查询文档和文档目录 | GET | `/rest/file/v2.0/document/actions/getDocuments` |
| 文档绑定到对象 | POST | `/rest/file/v2.0/document/actions/bindObject` |
| 文档解绑业务对象 | POST | `/rest/file/v2.0/document/actions/unbindObject` |
| 批量下载对象下文档 | GET | `/rest/file/v2.0/document/actions/batchDownloadByObjects` |
| 对象下知识库锁定 |  | `/rest/data/v2.0/social/twitterFile/actions/lockByEntity` |
| 对象下知识库解除锁定 | DELETE | `/rest/data/v2.0/social/twitterFile/actions/lockByEntity` |
| 批量打包下载文件 | POST | `/rest/file/v2.0/document/actions/batchDownloadByMetaFileIds` |
| 通过文fileMetaId分层级压缩下载文件 | POST | `/rest/file/v2.0/document/actions/batchDownloadFolderByMetaFileIds` |
| 打包下载文档 | POST | `/rest/file/v2.0/document/actions/batchDownloadByFileIds` |
| 更新知识库文档 | PUT | `/rest/data/v2.0/xobjects/twitterFile/actions/updateFile/{id}` |
| 获取报销单接口描述 | GET | `/rest/data/v2.0/xobjects/expenseaccount/description` |
| 创建报销单 | POST | `/rest/data/v2.0/xobjects/expenseaccount` |
| 更新报销单 | PATCH | `/rest/data/v2.0/xobjects/expenseaccount/{id}` |
| 删除报销单 | DELETE | `/rest/data/v2.0/xobjects/expenseaccount/{id}` |
| 获取报销单信息 | GET | `/rest/data/v2.0/xobjects/expenseaccount/{id}` |
| 查询对象下提交给我的工作报告 | GET | `/rest/data/v2.0/social/workreport/list` |
| 查询工作报告详情 | GET | `/rest/data/v2.0/social/workreport/actions/detail` |
| 审批提交给我的工作报告 | POST | `/rest/data/v2.0/social/workreport/actions/marking` |
| 创建工作报告 | POST | `/rest/data/v2.0/xobjects/workReport` |
| 批量创建工作报告 | POST | `/rest/data/v2.0/xobjects/workReport/batch` |
| 更新工作报告 | PUT | `/rest/data/v2.0/xobjects/workReport` |
| 批量更新工作报告 | PATCH | `/rest/data/v2.0/xobjects/workReport/batch` |
| 删除工作报告 | DELETE | `/rest/data/v2.0/xobjects/workReport` |
| 批量删除工作报告 | DELETE | `/rest/data/v2.0/xobjects/workReport/batch` |
| 获取业务附件文件列表 | GET | `/rest/data/v2.0/social/commonFile/actions/getBySystemIdAndItemId` |
| 获取名片及附件 | GET | `/rest/data/v2.0/social/businessCard/{systemId}/{systemDataId}` |
| 文件URL签名 | POST | `/rest/file/v2.0/acl/generatePresignedUrl` |
| 按照视图 ID 查询视图元数据 | GET | `/rest/neobi/v2.0/bestpractices/queryViewMetadataById` |
| 按照筛选条件批量查询视图元数据 | POST | `/rest/neobi/v2.0/bestpractices/queryViewMetadatas` |
| 按照筛选条件查询视图数据 | POST | `/rest/neobi/v2.0/bestpractices/queryDataTask` |
| 按照异步查询的任务 ID 查询任务执行情况 | GET | `/rest/neobi/v2.0/bestpractices/queryAsyncTask` |
| 创建外部数据对象异步更新任务（JSON） | POST | `/rest/neobi/v2.0/datacloud/externalModels/{apikey}/actions/importJson` |
| 创建外部数据对象异步更新任务（CSV 文件） | POST | `/rest/neobi/v2.0/datacloud/externalModels/{apikey}/actions/importJsonCsv` |
| 获取外部数据对象异步任务执行结果 | GET | `/rest/neobi/v2.0/datacloud/externalModels/actions/queryImportTask` |
| 自定义 SQL 查询 | POST | `/rest/neobi/v2.0/query/queryByCustomSQL` |
| 获取业务数据接口描述 | GET | `/rest/data/v2.0/xobjects/{xObjectApiKey}/description` |
| 创建业务数据 | POST | `/rest/data/v2.0/xobjects/{xObjectApiKey}` |
| 更新业务数据 | PATCH | `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}` |
| 锁定自定义对象 | POST | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/locks?recordId={recordId}` |
| 解锁自定义对象 | DELETE | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/locks?recordId={recordId}` |
| 删除业务数据 | DELETE | `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}` |
| 转移自定义对象 | POST | `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transfers?recordId={recoredId}` |
| 获取业务数据信息 | GET | `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}` |
| 获取业务类型描述 | GET | `/rest/data/v2.0/xobjects/{xObjectApiKey}/busiType` |
| 归档数据XOQL查询 | POST | `/rest/data/v2.0/query/xoql-archived/xoql` |
| 查询对象列表 | GET | `/rest/metadata/v2.0/xobjects/filter` |
| 获取某一个对象的所有字段的字段依赖关系 | GET | `/rest/metadata/v2.0/xobjects//{xobjectApiKey}/itemDependencies/itemItems` |
| 根据对象和控制字段查询某一对依赖关系 | GET | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/controlItems/{controlItemApiKey}` |
| 根据对象、控制字段和被依赖字段 ID 查询某一对依赖关系 | GET | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/controlItems/{controlItemApiKey}/{dependentItemApiKey}` |
| 根据对象、控制字段和依赖字段查询依赖关系 | GET | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/label/{controlItemApiKey}/{dependentItemApiKey}` |
| 根据对象、控制字段和依赖字段全量更新选项依赖关系 | PATCH | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/label/{controlItemApiKey}/{dependentItemApiKey}` |
| 获取子对象的可用业务类型列表 | GET | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/busiTypes/{childXobjectApiKey}/{masterBusiTypeId}/childMappings` |
| 获取主对象的可用业务类型列表 | GET | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/busiTypes/{childXobjectApiKey}/{childBusiTypeId}/masterMappings` |
| 新建字段集 | POST | `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets` |
| 更新字段集 | PATCH | `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}` |
| 删除字段集 | DELETE | `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}` |
| 查询所有字段集 | GET | `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets` |
| 获取字段集信息 | GET | `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}` |
| 创建通用选项集 | POST | `/rest/metadata/v2.0/settings/globalPicks` |
| 更新通用选项集 | PATCH | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}` |
| 删除通用选项集 | DELETE | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}` |
| 获取指定通用选项集 | GET | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}` |
| 获取所有通用选项集 | GET | `/rest/metadata/v2.0/settings/globalPicks` |
| 新增通用选项集选项 | POST | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option` |
| 更新通用选项集选项 | PATCH | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option` |
| 启用/禁用通用选项集选项 | POST | `/rest/metadata/v2.0/settings/globalPicks/actions/enable` |
| 删除通用选项集选项 | DELETE | `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option` |
| 查询指定通用选项集所有选项依赖关系 | GET | `/rest/metadata/v2.0/settings/globalPicks/dependencies/label/{controlApiKey}/{dependentApiKey}` |
| 更新指定通用选项集所有选项依赖关系 | PATCH | `/rest/metadata/v2.0/settings/globalPicks/dependencies/label/{controlApiKey}/{dependentApiKey}` |
| 新增通用选项依赖关系 | /REST/METADATA/V2.0/SETTINGS/GLOBALPICKS/DEPENDENCIES/ACTIONS/DEPENDENTOPTIONSINCREMENT | `PATCH` |
| 更新指定通用选项依赖关系 | PATCH | `/rest/metadata/v2.0/settings/globalPicks/dependencies/actions/dependentOptions` |
| 删除指定通用选项依赖关系 | PATCH | `/rest/metadata/v2.0/settings/globalPicks/dependencies/actions/dependentOptionsDelete` |
| 调用指定自定义API | POST/GET | `/rest/data/v2.0/scripts/api/{customPath}` |
| 添加短信模板 | POST | `/rest/metadata/v2.0/flows/smsTemplate` |
| 更新短信模板 | PATCH | `/rest/metadata/v2.0/flows/smsTemplate/{templateId}` |
| 查询短信模板 | GET | `/rest/metadata/v2.0/flows/smsTemplate/list` |
| 启用短信模板 | POST | `/rest/metadata/v2.0/flows/smsTemplate/actions/enable` |
| 禁用短信模板 | POST | `/rest/metadata/v2.0/flows/smsTemplate/actions/disable` |
| 删除短信模板 | DELETE | `/rest/metadata/v2.0/flows/smsTemplate/{templateId}` |
| 短信事件列表 | GET | `/rest/data/v2.0/flows/events/list` |
| 短信事件实例 | GET | `/rest/data/v2.0/flows/sms/actions/getInstance` |
| 查询短信通知事件日志 | POST | `/rest/data/v2.0/creekflow/eventLog/sms` |
| 获取对象新建表单项信息 | GET | `/rest/data/v2.0/layouts/createForms?xobjectApiKey={xobjectApiKey}&busiTypeId={busiTypeId}` |
| 获取对象编辑表单项信息 | GET | `/rest/data/v2.0/layouts/updateForms?xobjectApiKey={xobjectApiKey}&busiTypeId={busiTypeId}&recordId={recordId}` |
| 获取表单实例接口描述 | GET | `/rest/data/v2.0/xobjects/formInstance/description` |
| 创建表单实例 | POST | `/rest/data/v2.0/xobjects/formInstance` |
| 更新表单实例 | PATCH | `/rest/data/v2.0/xobjects/formInstance/{id}` |
| 删除表单实例 | DELETE | `/rest/data/v2.0/xobjects/formInstance/{id}` |
| 获取表单实例信息 | GET | `/rest/data/v2.0/xobjects/formInstance/{id}` |
| 获取用户接口描述 | GET | `/rest/data/v2.0/xobjects/user/description` |
| 创建用户 | POST | `/rest/data/v2.0/xobjects/user` |
| 更新用户 | PATCH | `/rest/data/v2.0/xobjects/user/{id}` |
| 启用用户 | POST | `/rest/data/v2.0/xobjects/user/actions/enable` |
| 禁用用户 | POST | `/rest/data/v2.0/xobjects/user/actions/disable` |
| 删除用户 | DELETE | `/rest/data/v2.0/xobjects/user/{id}` |
| 获取用户信息 | GET | `/rest/data/v2.0/xobjects/user/{id}` |
| 查询用户角色 | GET | `/rest/data/v2.0/privileges/users/{userId}/roles` |
| 设置用户离职 | POST | `/rest/data/v2.0/xobjects/user/actions/departure` |
| 设置用户复职 | POST | `/rest/data/v2.0/xobjects/user/actions/reentry` |
| 用户分配license | POST | `/rest/data/v2.0/xobjects/user/{id}/licenseAssignments/{licenseID}` |
| 用户取消license | DELETE | `/rest/data/v2.0/xobjects/user/{id}/licenseAssignments/{licenseID}` |
| 查询license已授权的用户 | GET | `/rest/metadata/v2.0/privileges/licenses/{licenseId}/actions/assignUsers` |
| 查询用户已授权的license | GET | `/rest/data/v2.0/xobjects/user/{id}/actions/assignLicenses` |
| 查询当前租户（系统）的所有license | GET | `/rest/metadata/v2.0/privileges/licenses` |
| 用户分配角色 | POST | `/rest/data/v2.0/xobjects/user/{id}/roleAssignments/{roleId}` |
| 用户移除角色 | DELETE | `/rest/data/v2.0/xobjects/user/{id}/roleAssignments/{roleId}` |
| 用户激活接口 | POST | `/rest/data/v2.0/xobjects/user/actions/activate/batch` |
| 批量给用户授权license | PATCH | `/rest/data/v2.0/xobjects/user/assignLicences` |
| 查询某用户的所有职能 | GET | `/rest/data/v2.0/privileges/users/{userId}/responsibilities` |
| 更新用户数据部门 | PATCH | `/rest/data/v2.0/xobjects/user/actions/updateDataDepart` |
| 查询更新用户数据部门日志 | GET | `/rest/data/v2.0/xobjects/user/actions/updateDataDepartLog/{id}` |
| 获取某个用户某个对象的某些数据的数据权限 | POST | `/rest/data/v2.0/privileges/dataPrivileges` |
| 查询父子场景编辑权限 | POST | `/rest/data/v2.0/xobjects/{xobjectApiKey}/actions/canOpenCreate` |
| 查询用户权限日志 | POST | `/rest/data/v2.0/privileges/operationLog/query` |
| 新建团队成员 | POST | `/rest/data/v2.0/xobjects/teamMember` |
| 更新团队成员 | PATCH | `/rest/data/v2.0/xobjects/teamMember/{id}` |
| 删除团队成员 | DELETE | `/rest/data/v2.0/xobjects/teamMember/{id}` |
| 获取团队成员（单条） | GET | `/rest/data/v2.0/xobjects/teamMember?xObjectApiKey={xObjectApiKey}&recordId={recordId}&userId={userId}` |
| 查询某条数据所有成员 | GET | `/rest/data/v2.0/xobjects/teamMember/actions/list` |
| 获取职能列表 | GET | `/rest/metadata/v2.0/privileges/responsibilitys` |
| 创建职能 | POST | `/rest/metadata/v2.0/privileges/responsibility` |
| 更新职能 | PATCH | `/rest/metadata/v2.0/privileges/responsibility` |
| 职能明细 | GET | `/rest/metadata/v2.0/privileges/responsibility/{id}` |
| 删除职能 | DELETE | `/rest/metadata/v2.0/privileges/responsibility` |
| 查询某一职能的所有功能点 | GET | `/rest/metadata/v2.0/privileges/responsibility/{apiKey}/actions/assignResources/function` |
| 查询分配某一职能的所有用户 | GET | `/rest/metadata/v2.0/privileges/responsibility/{apiKey}/actions/users` |
| 获取角色列表 | GET | `/rest/metadata/v2.0/privileges/roles` |
| 查询分配某一角色的所有用户 | GET | `/rest/metadata/v2.0/privileges/roles/{apiKey}/actions/users` |
| 查询某一角色的数据权限设置 | GET | `/rest/metadata/v2.0/privileges/roles/{apiKey}/actions/dataPermissions/{dimensionType}` |
| 新建公共组 | POST | `/rest/metadata/v2.0/privileges/publicGroup` |
| 更新公共组 | PATCH | `/rest/metadata/v2.0/privileges/publicGroup/{apikey}` |
| 添加公共组成员 | PATCH | `rest/metadata/v2.0/privileges/publicGroup/addMembers` |
| 移除公共组成员 | PATCH | `/rest/metadata/v2.0/privileges/publicGroup/removeMembers` |
| 查询单个公共组 | GET | `/rest/metadata/v2.0/privileges/publicGroup/{apikey}` |
| 查询全部公共组 | GET | `/rest/metadata/v2.0/privileges/publicGroup` |
| 删除公共组 | DELETE | `/rest/metadata/v2.0/privileges/publicGroup/{apikey}` |
| 分页查询某一实体的所有共享规则 | GET | `/rest/v2.0/privileges/{objectApiKey}/sharerules?pageNo={pageNo}&pageSize={pageSize}` |
| 查询某一个共享规则 | GET | `/rest/v2.0/privileges/{objectApiKey}/sharerule/{ruleApiKey}` |
| 用户关联职能列表 | GET | `/rest/data/v2.0/xobjects/user/{id}/responsibilityAssignments` |
| 创建用户职能 | POST | `/rest/data/v2.0/xobjects/user/{id}/responsibilityAssignments/{responsibilityId}` |
| 更新用户职能 | POST | `/rest/data/v2.0/xobjects/user/{id}/actions/assignResponsibility` |
| 获取用户登录日志明细 | GET | `/rest/metadata/v2.0/privileges/loginlog/{id}` |
| 根据条件查询用户登录日志 | POST | `/rest/metadata/v2.0/privileges/loginlog` |
| 根据用户ID与搜索条件查询应用与菜单 | GET | `/rest/data/v2.0/applications?userId=12542525&&searchLabel=abc` |
| 获取下一步信息 | POST | `/rest/data/v2.0/creekflow/task/actions/preProcessor` |
| 审批操作 | POST | `/rest/data/v2.0/creekflow/task` |
| 查询审批历史 | GET | `/rest/data/v2.0/creekflow/history/filter` |
| 查询流程定义 | GET | `/rest/metadata/v2.0/creekflow/processDefinitions/filter` |
| 查询流程实例 | GET | `/rest/data/v2.0/creekflow/processInstances/filter` |
| 查询审批任务 | GET | `/rest/data/v2.0/creekflow/task/filter` |
| 获取当前节点操作权限及按钮 | POST | `/rest/data/v2.0/creekflow/task/actions/getPermission` |
| 触发自动流 | POST | `/rest/data/v2.0/creekflow/autoProcessInstances` |
| 修改label | PATCH | `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/items/{itemApiKey}/label` |
| 上传文件 | POST 以 MULTIPART/FORM-DATA 形式提交请求参数。 | `/rest/file/v2.0/file/batch` |
| 下载文件 | GET | `/rest/file/v2.0/file/actions/files?fileIds={fileId1,fileId2,fileId3...}&outType={outType}` |
| 批量上传图片 | POST | `/rest/file/v2.0/image` |
| 下载图片 | GET | `/rest/file/v2.0/image/actions/files?fileIds=1578967492378636,1486800316809249&outType=1` |
| 下载图片文件数据流 | GET | `/rest/file/v2.0/image/{fileId}` |
| 实体大数据量滚动查询 | POST | `/rest/data/v2/query/scroll` |
| 获取模板打印信息 | GET | `/rest/template/v2.0/{templateName}` |
| 获取模板打印数据 | GET | `/rest/template/v2.0/{apiKey}/{id}/{templatePrintId}` |
| 获取模板打印数据（指定输出文件格式） | GET | `/rest/template/v2.0/{apiKey}/{id}/{templatePrintId}/{exportType}?amount={amount}` |
| 批量模板打印 | POST | `/rest/template/v2.0/template/actions/patchPrint` |
| 全局搜索实体数据 | 同时支持 POST 和 GET 方式。 | `/rest/data/v2.0/query/xosl` |
| 获取系统设置日志 | POST | `/rest/data/v2.0/logs/actions/getSystemLog` |
| 实体数据变更明细操作日志查询 | POST | `/rest/data/v2.0/logs/xobjectFieldHistory/actions/query` |
| 获取目标接口描述 | GET | `/rest/data/v2.0/xobjects/goalPro/description` |
| 创建目标 | POST | `/rest/data/v2.0/xobjects/goalPro` |
| 更新目标 | PATCH | `/rest/data/v2.0/xobjects/goalPro/{id}` |
| 查询目标 | POST | `/rest/data/v2.0/xobjects/goalPro/query` |
| 锁定目标 | GET | `/rest/data/v2.0/xobjects/goalPro/actions/locks/{id}/lock` |
| 解锁目标 | DELETE | `/rest/data/v2.0/xobjects/goalPro/actions/locks/{id}/lock` |
| 删除目标 | DELETE | `/rest/data/v2.0/xobjects/goalPro/{id}` |
| 获取目标信息 | GET | `/rest/data/v2.0/xobjects/goalPro/{id}` |
| 获取目标模型接口描述 | GET | `/rest/data/v2.0/xobjects/goalModel/description` |
| 创建目标模型 | POST | `/rest/data/v2.0/xobjects/goalModel` |
| 更新目标模型 | PATCH | `/rest/data/v2.0/xobjects/goalModel/{id}` |
| 查询目标模型 | POST | `/rest/data/v2.0/xobjects/goalModel/query` |
| 删除目标模型 | DELETE | `/rest/data/v2.0/xobjects/goalModel/{id}` |
| 获取目标模型信息 | GET | `/rest/data/v2.0/xobjects/goalModel/{id}` |
| 文档锁定 | PUT | `/rest/data/v2.0/xobjects/twitterFile/actions/locks/{id}/lock` |
| 文档解锁 | DELETE | `/rest/data/v2.0/xobjects/twitterFile/actions/locks/{id}/lock` |
| 获取对象下文档列表 | GET | `/rest/data/v2.0/xobjects/twitterFile/actions/search-records` |
| 获取翻译资源列表 | POST | `/rest/data/v2.0/i18n/resources/actions/queryByKeyListLangCode` |
| 批量保存翻译资源 | POST | `/rest/data/v2.0/i18n/resources/actions/saveOrUpdateBatch` |
| 查询支持对象接口 | GET | `/rest/data/v2.0/xobjects` |
| 创建异步作业 | POST | `/rest/bulk/v2/job` |
| 更新异步作业 | PATCH | `/rest/bulk/v2/job/{jobId}` |
| 获取异步作业详细信息 | GET | `/rest/bulk/v2/job/{jobId}` |
| 获取所有异步作业详细信息 | GET | `/rest/bulk/v2/job` |
| 创建异步任务 | POST | `/rest/bulk/v2/batch` |
| 获取异步任务原始请求数据 | GET | `/rest/bulk/v2/batch/{batchId}/request` |
| 获取异步任务详细信息 | GET | `/rest/bulk/v2/batch/{batchId}` |
| 获取所有异步任务详细信息 | GET | `/rest/bulk/v2/batch` |
| 获取异步任务执行结果 | GET | `/rest/bulk/v2/batch/{batchId}/result` |

---

## API的使用方法

### 刷新令牌

- 请求方式: ``
- API 地址: `https://login.xiaoshouyi.com/auc/oauth2/token`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| access_token | String | 调用 Open API 的唯一凭证（令牌），与用户信息关联 |
| token_type | String | 返回值为 Bearer。
                在使用令牌调用 Open API 时，需要将此参数添加到令牌之前，并使用空格分隔。例如：Bearer 246d5caf0cfc0d8e85a |
| refresh_token | String | 刷新令牌。
                refresh token 不会改变，过期需要重新获取 |
| expires_in | Long | access token 过期时间，单位为秒 |
| scope | String | 授权范围。
                crm：crm 范围
                  prm：prm 范围
                  all：crm 和 prm 范围 |
| tenant_id | Long | 申请访问令牌的租户 ID |
| refresh_token_expires_in | Long | refresh token 过期时间，单位为秒 |
| login_type | String | 登录类型。
                web：网页端登录
                  mobile：移动端登录 |
| encryption_key | String | 加密 key |
| source | String | 认证来源。
                web：网页端认证
                  mobile：移动端认证
                  dingtalk：钉钉认证
                  wxmp，微信小程序认证
                  qywx：企微微信服务商认证
                  saml：saml 单点登录认证
                  oauth2：oauth2 单点登录认证
                  outlook：Outlook 认证
                  qiyeweixin：企业微信自建应用认证
                  feishu ：飞书认证
                  channelwxmp：渠道小程序认证 |
| client_id | String | 客户端 ID |
| passport_id | Long | 账号 ID（此参数通常不需要使用） |
| mobile_params | String | 移动端参数。
                移动端标准认证时，返回该值 |
| instance_uri | String | 所在租户的 API 域名，使用此域名调用 Open API |

### 获取指定用户的Access Token

获取被代理用户的 Access Token。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/oauth/token/actions/getDelegateToken`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| delegateUserId | 是 | Long | 被代理用户的 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| scode | String | 状态码 |
| error_msg | String | 错误信息 |
| result | JSON | 结果信息 |
| result.token_type | String | Token 类型 |
| result.access_token | String | Token 信息 |
| result.expires_in | Integer | Token 有效时间 |

### 获取当前用户信息

在通过授权码模式使用销售易账号登录第三方系统后，第三方系统可在获取 AccessToken
                后调用本接口，获取当前用户的详细身份信息。该信息可用于与第三方系统账号进行关联匹配，以支持后续的用户身份识别和业务处理。

- 请求方式: `GET`
- API 地址: `/rest/auc/v2.0/userInfo`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 否 | Long | 不传时，默认查当前调用 API 的用户 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态码 |
| result | JSON | 返回信息 |
| msg | String | 返回的数据 |
| ext | JSONArray | 附加信息 |

### 获取对象描述

获取对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{apiKey}/description`

### 创建对象

创建对象。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{apiKey}`

### 更新对象

更新对象信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/{apiKey}/{id}`

### 删除对象

删除对象。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/{apiKey}/{id}`

### 获取对象信息

获取指定对象的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{apiKey}/{id}`

---

## 销售云API接口

### 获取销售线索接口描述

获取销售线索对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/lead/description`

### 创建销售线索

创建一个销售线索。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/lead`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的线索ID（唯一标识） |

### 更新销售线索

更新销售线索信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/lead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售线索ID |

### 锁定销售线索

锁定销售线索。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售线索ID |

### 解锁销售线索

解锁销售线索。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售线索ID |

### 转换销售线索

销售线索转换。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/convert`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dimDepart | 是 | Long | 部门ID |
| accountName | 是 | String | 客户名称 |
| opportunityName | 否 | String | 销售机会名称 |
| money | 否 | double | 销售金额 |
| closeDate | 否 | Long | 结单日期 |
| contactConvert | 是 | String | 是否转换联系人true：是false：否 |
| newAccountName | 是 | String | 新的客户名称 |
| leadId | 是 | Long | 销售线索ID |
| highSeaId | 是 | Long | 公海ID |
| createOpportunityFlg | 是 | Integer | 是否创建销售机会0：是1：否 |
| createAccountFlg | 是 | Integer | 是否创建客户 |
| ruleId | 是 | Long | 转换规则ID |
| contactEntityTypeId | 是 | Long | 联系人业务类型ID |
| createContactFlg | 是 | Integer | 是否创建联系人 |
| accountTypeId | 是 | Long | 客户业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Code | 0：成功
                3101001：参数错误
                0000004：空指针
                100000：系统异常 |
| Msg | String | 成功或者失败的描述信息。 |

### 删除销售线索

删除指定销售线索。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/lead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售线索ID |

### 获取销售线索信息

查看指定销售线索详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/lead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售线索ID |

### 变更销售线索跟进状态

变更销售线索的跟进状态。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/setLeadStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadId | 是 | Long | 线索ID |
| status | 是 | Integer | 跟进状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 执行结果状态码 |
| msg | String | 执行失败信息 |

### 销售线索转换客户

提交线索转换的参数，进行线索转客户处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/saveConvert`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadId | 是 | Long | 线索 ID |
| createAccountFlg | 是 | Short | 创建客户标识1：新建2：合并已有客户 |
| newAccountName | 否 | String | 新建客户姓名 |
| accountEntityTypeId | 否 | Long | 客户业务类型 ID |
| accMustParamMap | 否 | String | 客户必填字段集 |
| highSeaId | 否 | Long | 客户公海池 ID |
| createContactFlg | 是 | Short | 创建联系人标识1：新建2：联系人已存在 |
| newContactName | 否 | String | 新建联系人姓名 |
| contactEntityTypeId | 否 | Long | 联系人业务类型ID |
| conMustParamMap | 否 | String | 联系人必填字段集 |
| accountId | 否 | Long | 合并客户 ID |
| createOpportunityFlg | 是 | Short | 创建商机标识0：创建商机1：不创建商机 |
| opportunityName | 否 | String | 新建商机名称 |
| opportunityTypeId | 否 | Long | 商机业务类型ID |
| oppMustParamMap | 否 | String | 商机必填字段集 |
| stageId | 否 | Long | 商机阶段 ID |
| contactConvert | 是 | Boolean | 是否创建联系人创建：true不创建：false |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| contactId | Long | 联系人 ID |
| accountId | Long | 客户 ID |

### 线索领取分配

提交线索领取或分配的参数，进行线索领取、分配处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/claimOrAssign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索 ID |
| targetUserId | 是 | Long | 目标用户 ID |
| type | 是 | Integer | 类型1：领取2：分配 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 线索回收

提交线索回收的参数，进行线索回收处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/recycle`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索ID |
| leadHighSeaId | 是 | Long | 线索公海池ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 线索退回公海池

提交线索退回公海池的参数，进行线索退回公海池处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/release`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索 ID |
| leadHighSeaId | 是 | Long | 线索公海池ID |
| releaseReason | 否 | String | 退回说明 |
| reasonType | 是 | Integer | 退回原因 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 废弃线索公海池里的线索

提交参数，进行线索公海池中线索的废弃处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/batchClose`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索ID |
| leadHighSeaId | 是 | Long | 线索公海池ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 线索详情页废弃线索

提交参数，进行线索的废弃处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/close`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadId | 是 | Long | 线索ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回值 |

### 线索恢复

提交线索恢复的参数，进行线索恢复处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/recover`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索ID |
| leadHighSeaId | 是 | Long | 线索公海池ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 公海池线索改变分组

提交参数，进行公海池线索改变分组处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/changeFromLeadHighSea`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索ID |
| leadHighSeaId | 是 | Long | 线索公海池ID |
| targetId | 是 | Long | 目标公海池分组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 用户私池线索改变分组

提交参数，进行用户私池线索改变分组处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/leadHighSea/actions/change`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| leadIdList | 是 | List | 线索 ID |
| leadHighSeaId | 是 | Long | 目标公海池分组 ID |
| isDealApplyDelayTime | 是 | Integer | 线索延期时间是否对新的分组生效1：是0：否 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 查询线索公海池分组

查询租户的所有线索公海池分组。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/lead/actions/getHighSeaList`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 执行结果状态码 |
| msg | String | 执行失败信息 |
| batchData | String | 公海池分组信息 |

### 公海池领取客户

从公海池中领取客户（领取人需在领取的客户所在的公海分组中）。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/highSea/account/claim`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountIdList | 是 | List | 客户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 公海池分配客户

公海池管理员将公海中的数据分组给用户。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/highSea/account/assign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountIdList | 是 | List | 客户ID |
| targetUserId | 是 | Long | 用户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| resultCount | String | 执行结果，成功、失败数量 |
| operateResult | String | 执行失败的具体信息 |

### 初始化公海池分组

给没有公海池的数据，初始化公海池分组。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/initHighSea`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jsonObject | 是 | JSON | 包含客户 ID 和目标公海池 ID 的 JSON |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | JSON | 结果信息 |

### 客户私池改变公海池分组

根据私池客户 ID 改变私池客户数据的公海池分组。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/change`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jsonObject | 是 | JSON | 包含客户 ID 和目标公海池 ID 的 JSON |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | JSON | 附加信息，默认为空 |
| data.count-all | Integer | 改变公海池分组的客户总数 |
| data.operateResult | JSONArray | 改变公海池分组失败的客户原因 |
| data.count-failed | Integer | 改变公海池分组失败的客户个数 |
| data.count-success | Integer | 改变公海池分组成功的客户个数 |

### 获取公海池列表

获取所有的公海池列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/getHighSeaList`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | JSONArray | 结果信息集合 |
| data | JSON | 公海池的信息 |
| data.id | Integer | 公海池 ID |
| data.name | String | 公海池名称 |

### 获取公海池退回原因列表

获取客户公海池退回原因。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/getHighSeaReleaseReasons`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | JSONArray | 结果信息 |
| data | JSON | 退回原因 |
| data.id | Integer | 退回原因 ID |
| data.parameterName | String | 退回原因名称 |

### 获取公海池操作日志列表

获取公海池的操作日志。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/getHighSeaOperateLogs`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | JSONArray | 公海池日志数据集合 |
| data | JSON | 公海池日志数据 |
| data.content | String | 退回原因备注 |
| data.reason | String | 退回原因 |
| data.type | Integer | 日志类型1：领取2：退回3：分配6：删除9：废弃10：回收12：自动解冻13：手动解冻 |
| data. highSeaId | Long | 公海池 ID |

### 区域公海领取

领取数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/claim`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 00、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海退回

将私池数据退回到公海池中。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/release`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |
| releaseReason | 否 | Integer | 退回原因 |
| releaseReasonContent | 否 | String | 退回原因详情 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海分配

分配数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/assign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |
| targetUserId | 是 | Integer | 目标用户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海回收

回收数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/recycle`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海废弃

废弃数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/close`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海删除

删除数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/delete`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200或0或null是成功，3101007是部分成功，其它是失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海解冻

解冻数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/unfreeze`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 区域公海恢复

恢复数据。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/recover`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 改变区域公海分组

改变数据所属公海池。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/change`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |
| ids | 是 | Array | 对象记录ids |
| targetHighSeaId | 是 | Integer | 目标公海ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，3101007表示部分成功，其它表示失败 |
| errorInfo | String | 错误信息 |
| dataList | Array | 操作结果为当前code的所有数据ID |
| count | Integer | 操作结果为当前code的数据数量 |

### 查询区域公海分组

查所有可领取公海。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/territory/actions/highSeaList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apikey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 200、0、null表示成功，其它表示失败 |
| msg | String | 错误信息 |
| id | Integer | 公海ID |
| name | String | 公海名称 |

### 获取销售机会接口描述

获取销售机会对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/description`

### 创建销售机会

创建销售机会。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的销售机会ID（唯一标识） |

### 更新销售机会

更新指定销售机会。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售机会ID |

### 锁定销售机会

锁定销售机会。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售机会ID |

### 解锁销售机会

解锁销售机会。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售机会ID |

### 合并销售机会

销售机会合并。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/merge`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tPid | 是 | Long | 主销售机会ID |
| oPid | 是 | Long | 被合并销售机会ID |
| paramMap | 否 | Map | 主销售机会上需要被更新的字段 |

### 删除销售机会

删除指定销售机会。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售机会ID |

### 获取销售机会信息

获取指定销售机会的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售机会ID |

### 商机输单

根据商机ID进行商机输单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/loseCheckApproval`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |

### 商机输单重启

根据商机ID进行商机输单重启。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/active`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |

### 商机阶段实例描述

商机阶段实例描述。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/oppProcess/description`

### 商机阶段停留时间描述

商机阶段停留时间描述。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/oppStagePeriod/description`

### 商机阶段轨迹描述

商机阶段轨迹描述。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stageTrack/description`

### 获取商机阶段关键信息

获取商机阶段关键信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getKeyinformationsByStageId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunity | 是 | Long | 商机 ID |
| stageId | 是 | Long | 商机阶段 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | stagese：阶段数组：id阶段 ID。
                    stageName阶段名称。
                    stageName_resourceKey阶段名称资源 Key。
                    keyinformations关键信息数组。
                    itemId字段 ID。
                    itemName字段名称。
                    apiKey字段 ApiKey。
                    order顺序。
                    isRequired是否必填。 |

### 获取商机来源选项信息

获取商机对象上机会来源字段的选项集，也可用于获取销售线索来源选项集。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getOpportunitySourceOptions`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据。
                id选项 ID。
                  parameterName选项名称。 |

### 获取商机阶段流程类型

获取本租户是否开通商机阶段复杂流程。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/oppProcess/actions/processType`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据。hasBusinessProcessFunction：是否开通商机阶段复杂流程。true：复杂流程false：简单流程 |

### 推进商机阶段

商机阶段推进。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/changeStage`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机数据ID |
| targetStageId | 是 | Long | 推进阶段ID |
| isUpdateCloseDate | 否 | Short | 是否更新结单日期，1 表示更新，0表示不更新 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |

### 批量查询商机阶段

根据商机阶段 ID 批量查询商机阶段。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/stages`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | String | 商机阶段ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据。id商机阶段 ID。
                  stageName商机阶段名称。
                  percent赢率。
                  order序号。
                  status状态。 |

### 根据商机业务类型查询商机阶段

根据商机业务类型的 ApiKey 查询该业务类型下的商机阶段属性。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getStageListByEntityTypeApiKey`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityTypeApiKey | 是 | String | 商机业务类型 ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据。id商机阶段 ID。
                  stageName商机阶段名称。
                  stageName_resouceKey商机阶段名称资源 Key。
                  percent赢率。
                  order序号。
                  status状态。 |

### 按业务类型分组查询商机阶段

查询当前租户所有的商机阶段，并按照业务类型进行分组。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/groupByEntity`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据。
                                tree阶段树。
                                    parent父节点ID。
                                    name商机阶段名称。
                                    name_resouceKey商机阶段名称资源Key。 |

### 获取商机阶段红绿灯状态

提交商机 ID 集合，返回商机当前阶段的红绿灯状态。（单次查询商机数量在 100 以内）。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/checkOpportunityTipsData`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | String | 商机 ID 集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 商机 ID |
| tipStatus | Integer | 商机阶段红绿灯状态：0 表示绿灯；1 表示黄灯；2 表示红灯；3
                                    表示赢单；4 表示输单。 |

### 商机输单保存

保存某一商机为输单，并填写输单原因，更新输单阶段上的关键信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/lose`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机ID |
| reason | 是 | Short | 输单原因 |
| reasonDesc | 否 | String | 输单原因描述 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据 |

### 获取商机阶段关键事件

获取某一商机下全部商机阶段下的所有关键事件。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/oppProcess/actions/listByOpp`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机ID |
| stageId | 否 | Long | 阶段ID阶段ID为选填，如果传阶段ID，则返回该商机下某阶段下的关键事件。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | code错误码。
                                    msg错误信息。
                                    mustUploadFile是否必须上传文件，0表示否，1表示是。
                                    percent赢率。
                                    activityId关键事件ID。
                                    opportunityId商机ID。
                                    stageId阶段ID。
                                    doneFlag是否完成，0表示否，1表示是。
                                    checkFlg是否可以上传文件，0表示否，1表示是。 |

### 选中或取消关键事件

商机关键事件勾选或取消勾选。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunity/actions/activitySet`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunityId | 是 | Long | 商机数据ID |
| targetStageId | 是 | Long | 关键事件所在阶段的阶段ID |
| activityCheckBoxId | 是 | Long | 关键事件ID |
| checkFlg | 是 | Sting | 是否选中，1表示选中，0表示取消选中 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |

### 获取商机阶段关键事件文件

获取某一商机下全部商机阶段下的关键事件下的所有文件。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getKeyFileByOpportunity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| opportunity | 是 | Long | 商机ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | activities关键事件分组。
                  activityName关键事件名称。
                  stageName阶段名称。
                  stageName_resourceKey阶段名称资源Key。
                  files文件分组。
                  fileName文件名称。
                  fileUrl文件路径。
                  size文件大小。
                  apiKey字段ApiKey。
                  order阶段顺序。 |

### 根据客户获取商机阶段关键事件文件数量

获取某一客户下所有商机下全部商机阶段下的关键事件下的所有文件数量。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getKeyFileCountByAccount`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 数量 |

### 根据客户获取商机阶段关键事件文件

获取某一客户下所有商机下全部商机阶段下的关键事件下的所有文件。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stage/actions/getKeyFileByAccount`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |
| keyword | 否 | String | 关键字 |
| pageNo | 否 | String | 页码，默认1 |
| pageSize | 否 | String | 每页大小，默认20 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | sectionList商机分组。
                  oppName商机名称。
                  documentList文件分组。
                  fileName文件名称。
                  fileUrl文件路径。
                  size文件大小。
                  id关键事件文件 ID。
                  createBy创建人。
                  createAt创建时间。
                  updateBy更新人。
                  updateAt更新时间。 |

### 删除关键事件文档

删除商机关键事件下的文档。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/oppProcess/actions/deleteKeyFileById`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 关键事件文档ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据 |

### 获取商机联系人接口描述

获取商机联系人对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegisterContact/description`

### 创建商机联系人

创建商机联系人。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegisterContact`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 更新商机联系人

更新商机联系人。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 更新的数据的信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 删除商机联系人

删除商机联系人。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 更新的数据的信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 获取商机联系人信息

查看指定商机联系人的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegisterContact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 实际查到的数据，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 获取商机报备接口描述

获取商机报备对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegister/description`

### 创建商机报备

创建商机报备。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegister`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 更新商机报备

更新商机报备。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegister/{id}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 删除商机报备

删除指定的商机报备。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegister/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 获取商机报备信息

查看指定商机报备的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/opportunityRegister/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 获取客户接口描述

获取客户对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/account/description`

### 创建客户

创建客户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/account`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的客户ID（唯一标识) |

### 更新客户

更新客户信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/account/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户ID |

### 锁定客户

锁定客户。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户ID |

### 解锁客户

解锁客户。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户ID |

### 合并客户

合并两条客户数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/merge`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| paramMap | 是 | Map | 合并客户，主客户需要被更新的客户字段信息 |
| tAId | 是 | Long | 合并客户数据 ID |
| oAId | 是 | Long | 被合并的客户数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 执行结果 |
| msg | String | 执行信息 |

### 废弃客户

根据客户 ID 废弃客户。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/close`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jsonObject | 是 | JSON | 包含客户 ID 的 JSON |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | JSON | 附加信息，默认为空 |

### 删除客户

删除客户。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/account/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户ID |

### 获取客户信息

获取指定客户的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/account/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户 ID |

### 客户退回公海池

根据客户 ID 列表批量退回公海池。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/release`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jsonObject | 是 | JSON | 包含客户 ID 和退回原因的 JSON |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | JSON | 结果信息 |
| data.count-all | Integer | 退回公海的客户总数 |
| data.operateResult | JSONArray | 退回失败的客户原因 |
| data.count-failed | Integer | 退回失败的客户个数 |
| data.count-success | Integer | 退回成功的客户个数 |

### 查询首页排行榜

根据条件查询客户查询首页排行榜。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/queryRank`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| state | 是 | String | 省份 |
| city | 是 | String | 市 |
| region | 是 | String | 区 |
| accountId | 是 | String | 客户数据ID |
| entityType | 是 | String | 客户业务类型 |
| memberSize | 是 | String | 会员总人数 |
| memberSizeApiKey | 是 | String | 会员总人数的API Key |

### 客户名称查重

客户名称查重，支持模糊匹配。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/queryByKeywords`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jsonObject | 是 | Object | 包含关键字keywords和所属部门dimDepart |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | Object | 结果信息集合 |
| data.count | Integer | 符合添加的数据总数 |
| data.records | Object | 查询的数据集 |
| data.records.engineDatas | Array | 查询出来的数据 |
| data.records.engineDatas.accountName | String | 客户名称 |

### 获取联系人接口描述

获取联系人对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contact/description`

### 创建联系人

创建联系人。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/contact`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | long | 新创建的联系人ID（唯一标识) |

### 更新联系人

更新联系人信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/contact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 联系人 ID |

### 锁定联系人

锁定联系人。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/contact/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 联系人ID |

### 解锁联系人

解锁联系人。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/contact/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 联系人ID |

### 删除联系人

删除联系人。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/contact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 联系人ID |

### 获取联系人信息

获取指定联系人的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 联系人 ID |

### 查询联系人名片

根据联系人 ID 查询联系人的名片。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contact/actions/getBusinessCardByContactId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| contactId | 是 | Long | 联系人ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | String | 返回需要名片url |

### 保存联系人名片

保存联系人名片。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/contact/actions/saveBusinessCard`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| contactId | 是 | String | 需要保存名片的联系人ID |
| fileLength | 是 | Integer | 文件长度 |
| cardImgUrl | 是 | String | 文件存在的url |
| cardFileFileName | 是 | String | 文件名字 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | String | 无返回数据 |

### 查询当前租户客户的状态是否符合自动创建客户

查询当前租户客户的状态是否符合自动创建客户。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contact/actions/isCreateAccount`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | String | 返回需要openFlag |

### 获取客户账户接口描述

获取客户账户对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount/description`

### 创建客户账户

创建客户账户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的客户账户ID（唯一标识) |

### 更新客户账户

修改客户账户信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户账户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码，200表示成功，其他表示失败 |
| msg | String | 返回信息 |
| data | JSON | 主要包含更新成功的客户账户的ID |
| errorInfo | String | 错误信息，正常情况为null |

### 锁定客户账户

锁定客户账户信息。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户账户ID |

### 解锁客户账户

解锁客户账户。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的客户账户ID |

### 获取客户账户信息

获取指定客户账户的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccount/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的客户账户ID |

### 获取客户账户明细接口描述

获取账户明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountDetail/description`

### 创建账户明细并更新账户数据

创建账户明细并更新账户数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountDetail/actions/save`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的账户明细ID（唯一标识) |

### 更新客户账户明细状态

更新修改客户账户明细状态信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountDetail/actions/updateStatus?id={id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户账户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码 200表示成功，其他表示失败 |
| msg | String | 返回信息 |
| data | JSON | 主要包含更新成功的客户账户的ID |
| errorInfo | String | 错误信息，正常情况为null |

### 获取账户明细信息

获取指定账户明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的账户明细ID |

### 获取账户配置接口描述

获取账户配置对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/description`

### 创建账户配置

创建账户配置。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的账户配置ID（唯一标识) |

### 更新账户配置

更新账户配置信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 账户配置ID |

### 锁定账户配置

锁定账户配置信息。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 账户配置 ID |

### 解锁账户配置

解锁账户配置。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的账户配置ID |

### 删除账户配置

删除账户配置。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的账户配置ID |

### 获取账户配置信息

获取指定账户配置的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/customerAccountSetting/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的账户配置ID |

### 获取账户转账接口描述

获取帐户转账对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/accountTransfer/description`

### 获取拜访计划接口描述

获取拜访计划对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/description`

### 创建拜访计划

创建拜访计划。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 拜访计划名称 |
| entityType | 是 | Long | 业务类型 |
| visitModel | 是 | Integer | 拜访模板 |
| repetitionRule | 是 | Integer | 重复规则 |
| visitorId | 是 | Long | 拜访人 |
| startDate | 否 | String | 开始日期 |
| endDate | 否 | String | 结束日期 |
| visitPlanStatus | 否 | Integer | 拜访计划状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的拜访计划ID（唯一标识) |

### 更新拜访计划

更新拜访计划信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 拜访计划ID |
| name | 是 | String | 拜访计划名称 |

### 锁定拜访计划

锁定拜访计划。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/actions/locks`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 拜访计划ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码 |
| msg | String | 返回信息 |
| data | JSON | 主要包含更新成功的客户账户的ID |
| errorInfo | String | 错误信息，正常情况为null |

### 解锁拜访计划

解锁拜访计划。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/actions/locks`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 拜访计划ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码 |
| msg | String | 返回信息 |
| data | JSON | 主要包含更新成功的客户账户的ID |
| errorInfo | String | 错误信息，正常情况为null |

### 删除拜访计划

删除拜访计划。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的拜访计划ID |

### 获取拜访计划信息

获取指定拜访计划的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要获取信息的拜访计划ID |

### 获取拜访路线接口描述

获取拜访路线对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitRoute/description`

### 创建拜访路线

创建拜访路线。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitRoute`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 拜访路线名称 |
| entityType | 是 | Long | 业务类型 |
| routeStatus | 否 | Integer | 路线状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的拜访路线ID（唯一标识) |

### 更新拜访路线

更新拜访路线信息。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/visitRoute/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 拜访路线ID |

### 删除拜访路线

删除拜访路线。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/visitRoute/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的拜访路线ID |

### 获取拜访路线信息

获取指定拜访路线的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitRoute/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的拜访路线ID |

### 获取拜访路线与客户关系接口描述

获取拜访路线与客户关系对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/visitRouteAccountRel/description`

### 创建拜访路线与客户关系

创建拜访路线与客户关系。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/visitRouteAccountRel`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的拜访路线与客户关系ID（唯一标识) |

### 删除拜访路线与客户关系

删除拜访路线与客户关系。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/visitRouteAccountRel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的拜访路线与客户关系ID |

### 获取拜访路线与客户关系信息

获取指定拜访路线与客户关系的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/visitRouteAccountRel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的拜访路线与客户关系ID |

### 查询拜访路线与客户关系列表

按指定拜访路线查询拜访路线与客户关系。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/visitRouteAccountRel/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| visitRouteId | 是 | Long | 拜访路线ID |

### 获取拜访计划与拜访路线关系接口描述

获取拜访计划与拜访路线关系对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/visitPlanRouteRel/description`

### 创建拜访计划与拜访路线关系

创建拜访计划与拜访路线关系。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/visitPlanRouteRel`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的拜访计划与拜访路线关系ID（唯一标识) |

### 删除拜访计划与拜访路线关系

删除拜访计划与拜访路线关系。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/visitPlanRouteRel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的拜访计划与拜访路线关系ID |

### 获取拜访计划与拜访路线关系信息

获取指定拜访计划与拜访路线关系的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/visitPlanRouteRel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的拜访计划与拜访路线关系ID |

### 获取拜访记录接口描述

获取拜访记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitRecord/description`

### 获取拜访记录信息

查看指定拜访记录详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要获取信息的拜访记录ID |

### 获取拜访日程接口描述

获取拜访日程对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/description`

### 创建拜访日程

创建拜访日程。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 拜访日程名称 |
| entityType | 是 | Long | 业务类型 |
| visitplanId | 是 | Long | 拜访计划名称 |
| visitObject | 是 | Long | 拜访对象 |
| visitModel | 是 | Integer | 拜访模板 |
| visitorId | 是 | Long | 拜访人 |
| visitRouteId | 是 | Long | 拜访路线 |
| visitPlanType | 是 | Integer | 拜访计划类型 |
| repetitionDay | 是 | String | 预计拜访日期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的拜访日程ID（唯一标识） |

### 更新拜访日程

更新拜访日程信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 拜访日程ID |

### 删除拜访日程

删除拜访日程。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的拜访日程ID |

### 获取拜访日程信息

获取指定拜访日程的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的拜访日程ID |

### 统计每天的拜访日程个数

统计每天的拜访日程个数。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/actions/countVisitDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 开始时间戳 |
| endDate | 是 | Long | 结束时间戳 |
| userId | 是 | Long | 用户ID |
| visitPlanId | 否 | Long | 拜访计划ID |
| visitCalendar | 是 | Boolean | 是否删除随访日程 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |

### 获取某一天的拜访日程

获取某一天的拜访日程。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/actions/listVisitDetailByDay`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 开始时间戳 |
| userId | 是 | Long | 用户ID |
| visitPlanId | 否 | Long | 拜访计划ID |
| visitCalendar | 是 | Boolean | 是否删除随访日程 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | String | 请求结果码 |

### 统计每天的拜访客次是否达标

统计每天的拜访客次是否达标。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/actions/statisticsVisit`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 开始时间戳 |
| endDate | 是 | Long | 结束时间戳 |
| userId | 是 | Long | 用户ID |
| visitPlanId | 否 | Long | 拜访计划ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |

### 统计拜访客次

根据拜访计划统计拜访客次。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/actions/getVisitCountByPlan`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| visitPlanId | 是 | Long | 拜访计划ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |

### 周边拜访对象搜索

获取周边拜访对象。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/visitPlanDetail/actions/searchAroundVisitObject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| latitude | 是 | Double | 查找位置纬度 |
| longitude | 是 | Double | 查找位置经度 |
| distance | 是 | Double | 查找范围（单位：公里） |
| searchObject | 是 | Long | 查找实体ID |
| searchLocation | 是 | String | 查找实体位置字段apikey（客户预制位置为：poi_location_p） |
| searchOrder | 否 | Integer | 0：升序 1：降序（默认：0） |
| searchKeyWords | 否 | String | 搜索关键字 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |

### 获取产品接口描述

获取产品对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/product/description`

### 创建产品

创建产品。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/product`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品ID（唯一标识） |

### 更新产品

更新指定产品。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/product/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品ID |

### 锁定产品

锁定产品。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/product/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品ID |

### 解锁产品

解锁产品。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/product/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品ID |

### 删除产品

删除指定产品。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/product/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品ID |

### 获取产品信息

获取指定的产品信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/product/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品ID |

### 获取产品需求接口描述

获取产品需求对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productRequirement/description`

### 创建产品需求

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productRequirement`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| requirementName | 是 | String | 主题 |
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 |
| accountId | 是 | Long | 客户ID |
| dimDepart | 是 | Long | 所属部门 |
| requirementPriority | 是 | Integer | 需求优先级 |
| requirementStatus | 是 | Integer | 处理状态 |
| description | 是 | String | 需求应用场景描述 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品需求ID（唯一标识) |

### 更新产品需求

更新产品需求信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productRequirement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品需求ID |

### 删除产品需求

删除产品需求。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productRequirement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品需求ID |

### 获取产品需求信息

获取指定产品需求的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productRequirement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品需求ID |

### 创建产品选项

创建产品选项。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productOption`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| optionNo | 是 | Integer | 产品选项序号 |
| featureId | 否 | Long | 所属产品功能 |
| configurableProduct | 是 | Long | 所属组合产品 |
| deliverySeperately | 否 | Bool【1/0】 | 是否独立交付 |
| bundled | 是 | Bool【1/0】 | 是否必选 |
| type | 是 | Picklist【组件/相关】 | 产品选项类型 |
| entityType | 是 | Long | 业务类型 |
| recommend | 否 | Bool【1/0】 | 是否推荐选择 |
| maxQuantity | 否 | Integer | 产品选项最大数量 |
| minQuantity | 否 | Integer | 产品选项最小数量 |
| defaultQuantity | 是 | Integer | 产品选项默认数量 |
| orderSeperately | 否 | Bool【1/0】 | 是否可以独立下单 |
| objectId | 是 | Long【433】 | 产品选项标志，常量 |
| userId | 是 | Long | 当前登录用户ID |
| optionProduct | 是 | Long | 产品名称 |
| quantityEditable | 否 | Bool【1/0】 | 数量可编辑 |
| dimDepart | 是 | Long | 所属部门 |
| notes | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品选项ID（唯一标识) |

### 更新产品选项

更新产品选项信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productOption/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 要更新的产品选项Id |
| optionNo | 是 | Integer | 产品选项序号 |
| featureId | 否 | Long | 所属产品功能 |
| configurableProduct | 是 | Long | 所属组合产品 |
| deliverySeperately | 否 | Bool【1/0】 | 是否独立交付 |
| bundled | 是 | Bool【1/0】 | 是否必选 |
| type | 是 | Picklist【组件/相关】 | 产品选项类型 |
| entityType | 是 | Long | 业务类型 |
| recommend | 否 | Bool【1/0】 | 是否推荐选择 |
| maxQuantity | 否 | Integer | 产品选项最大数量 |
| minQuantity | 否 | Integer | 产品选项最小数量 |
| defaultQuantity | 是 | Integer | 产品选项默认数量 |
| orderSeperately | 否 | Bool【1/0】 | 是否可以独立下单 |
| objectId | 是 | Long【433】 | 产品选项标志，常量 |
| userId | 是 | Long | 当前登录用户ID |
| optionProduct | 是 | Long | 产品名称 |
| quantityEditable | 否 | Bool【1/0】 | 数量可编辑 |
| dimDepart | 是 | Long | 所属部门 |
| notes | 否 | String | 备注 |

### 删除产品选项

删除产品选项。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productOption/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品选项ID |

### 获取产品选项信息

获取指定产品选项的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productOption/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品选项ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 产品选项名称 |
| entityType | Reference | 业务类型 |
| ownerId | Reference | 所有人 |
| dimDepart | Reference | 所属部门 |
| createdBy | Reference | 创建人 |
| createdAt | Date | 创建日期 |
| updatedBy | Reference | 修改人 |
| updatedAt | Date | 修改日期 |
| lockStatus | Picklist | 锁定状态 |
| applicantId | Reference | 审批提交人 |
| approvalStatus | Picklist | 审批状态 |
| workflowStageName | String | 工作流阶段名称 |
| optionNo | Integer | 序号 |
| featureId | Reference | 产品功能名称 |
| configurableProduct | Reference | 组合产品名称 |
| optionProduct | Reference | 产品名称 |
| type | Picklist | 产品选项类型 |
| bundled | Bool | 必选 |
| defaultQuantity | Float | 默认数量 |
| maxQuantity | Float | 最大数量 |
| minQuantity | Float | 最小数量 |
| quantityEditable | Bool | 数量可编辑 |
| recommend | Bool | 推荐选择 |
| orderSeperately | Bool | 可独立下单 |
| deliverySeperately | Bool | 可独立交付 |
| notes | Textarea | 备注 |
| priceUnit | Currency | 标准价格 |
| enableStatus | Currency | 启用状态 |

### 创建产品功能

创建产品功能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productFeature`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 产品功能名称 |
| entityType | 是 | Reference | 业务类型 |
| ownerId | 是 | Reference | 所有人 |
| createdBy | 是 | Reference | 创建人 |
| createdAt | 是 | Date | 创建日期 |
| updatedBy | 是 | Reference | 修改人 |
| updatedAt | 是 | Date | 修改日期 |
| lockStatus | 是 | Picklist | 锁定状态 |
| featureNo | 是 | Integer | 序号 |
| configurableProduct | 是 | Reference | 组合产品名称 |
| maxOptions | 否 | Integer | 最多产品选项 |
| minOptions | 否 | Integer | 最少产品选项 |
| category | 否 | String | 标签 |
| active | 是 | Picklist | 启用状态 |
| notes | 否 | Textarea | 备注 |

### 更新产品功能

更新产品功能信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productFeature/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品功能ID |
| name | 是 | String | 产品功能名称 |
| entityType | 是 | Reference | 业务类型 |
| ownerId | 是 | Reference | 所有人 |
| createdBy | 是 | Reference | 创建人 |
| createdAt | 是 | Date | 创建日期 |
| updatedBy | 是 | Reference | 修改人 |
| updatedAt | 是 | Date | 修改日期 |
| lockStatus | 是 | Picklist | 锁定状态 |
| featureNo | 是 | Integer | 序号 |
| cconfigurableProduct | 是 | Reference | 组合产品名称 |
| maxOptions | 否 | Integer | 最多产品选项 |
| minOptions | 否 | Integer | 最少产品选项 |
| category | 否 | String | 标签 |
| active | 是 | Picklist | 启用状态 |
| notes | 否 | Textarea | 备注 |

### 删除产品功能

删除产品功能。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productFeature/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品功能ID |

### 获取产品功能信息

获取指定产品功能的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productFeature/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品功能ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 产品功能名称 |
| entityType | Reference | 业务类型 |
| ownerId | Reference | 所有人 |
| dimDepart | Reference | 所属部门 |
| createdBy | Reference | 创建人 |
| createdAt | Date | 创建日期 |
| updatedBy | Reference | 修改人 |
| updatedAt | Date | 修改日期 |
| lockStatus | Picklist | 锁定状态 |
| applicantId | Reference | 审批提交人 |
| approvalStatus | Picklist | 审批状态 |
| workflowStageName | String | 工作流阶段名称 |
| featureNo | Integer | 序号 |
| configurableProduct | Reference | 组合产品名称 |
| maxOptions | Integer | 最多产品选项 |
| minOptions | Integer | 最少产品选项 |
| category | String | 标签 |
| active | Picklist | 启用状态 |
| notes | Textarea | 备注 |

### 创建产品约束

创建产品约束

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/optionConstraint`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 产品约束名称 |
| entityType | 是 | Reference | 业务类型 |
| ownerId | 是 | Reference | 所有人 |
| lockStatus | 是 | Picklist | 锁定状态 |
| configurableProduct | 是 | Reference | 组合产品名称 |
| constrainedOption | 是 | Reference | 被约束产品选项 |
| constrainingOption | 是 | Reference | 产品选项 |
| type | 是 | Picklist | 约束方式 |
| active | 是 | Picklist | 启用状态 |
| notes | 否 | Textarea | 备注 |

### 更新产品约束

更新产品约束信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/optionConstraint/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品约束ID |
| name | 是 | String | 产品约束名称 |
| entityType | 是 | Reference | 业务类型 |
| ownerId | 是 | Reference | 所有人 |
| lockStatus | 是 | Picklist | 锁定状态 |
| configurableProduct | 是 | Reference | 组合产品名称 |
| constrainedOption | 是 | Reference | 被约束产品选项 |
| constrainingOption | 是 | Reference | 产品选项 |
| type | 是 | Picklist | 约束方式 |
| active | 是 | Picklist | 启用状态 |
| notes | 否 | Textarea | 备注 |

### 删除产品约束

删除产品约束。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/optionConstraint/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品约束ID |

### 获取产品约束信息

获取指定产品约束的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/optionConstraint/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品约束ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 产品约束名称 |
| entityType | Reference | 业务类型 |
| ownerId | Reference | 所有人 |
| dimDepart | Reference | 所属部门 |
| createdBy | Reference | 创建人 |
| createdAt | Date | 创建日期 |
| updatedBy | Reference | 修改人 |
| updatedAt | Date | 修改日期 |
| lockStatus | Picklist | 锁定状态 |
| applicantId | Reference | 审批提交人 |
| approvalStatus | Picklist | 审批状态 |
| workflowStageName | String | 工作流阶段名称 |
| configurableProduct | Reference | 组合产品名称 |
| constrainedOption | Reference | 被约束产品选项 |
| constrainingOption | Reference | 产品选项 |
| type | Picklist | 约束方式 |
| active | Picklist | 启用状态 |
| notes | Textarea | 备注 |

### 获取产品目录接口描述

获取产品目录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/description`

### 创建产品目录

创建产品目录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productCategory`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 目录名称 |
| parentName | 是 | Long | 上级目录ID，如果是给-1则放到根目录下 |
| entityType | 是 | Long | 业务类型ID |
| sortedNo | 否 | Integer | 排序号，产品目录管理中节点在当前父节点下的排序 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 创建成功ID |

### 更新产品目录

更新指定产品目录。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品目录ID |
| name | 否 | String | 目录名称 |
| parentName | 否 | Long | 上级目录ID |
| sortedNo | 否 | Integer | 目录排序 |

### 删除产品目录

删除指定的产品目录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品目录ID |

### 获取产品目录信息

查看指定产品目录的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品目录ID |

### 获取产品目录树

获取完整的产品目录树，返回记录最多 5000 条，超出 5000 条返回错误代码5100001。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/actions/directoryTree`

### 获取产品目录列表

根据指定的条件获取产品目录列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productCategory/actions/directoryList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| parentId | 否 | Long | 上级目录ID，为空时默认为-1 |
| page | 否 | Integer | 分页页号，为空时，默认为1 |
| count | 否 | Integer | 为空时，默认为20，超过30时，最大取30 |

### 创建组合产品

创建组合产品，包括产品、产品选项、产品功能、产品约束关系。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/product/actions/importProductBundles`

### 获取合同接口描述

获取合同对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contract/description`

### 创建合同

创建合同。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/contract`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |
| amount | 是 | Double | 总金额 |
| dimDepart | 是 | Long | 所属部门 |
| entityType | 是 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| title | 是 | String | 标题 |
| campaignId | 否 | Long | 所属市场活动 |
| comment | 否 | Sting | 备注 |
| contractCode | 否 | Sting | 合同编号 |
| contractContent | 否 | Sting | 合同文本 |
| contractType | 否 | Integer | 合同类型 |
| startDate | 否 | Long | 开始日期 |
| customerSigner | 否 | String | 客户方签约人 |
| dimArea | 否 | Long | 所属区域 |
| dimBusiness | 否 | Long | 所属业务 |
| dimIndustry | 否 | Long | 所属行业 |
| dimProduct | 否 | Long | 所属产品线 |
| endDate | 否 | Long | 结束日期 |
| opportunityId | 否 | Long | 销售机会 |
| payMode | 否 | Integer | 付款方式 |
| signDate | 否 | Long | 签约日期 |
| signerId | 否 | Long | 我方签约人 |
| status | 否 | Integer | 合同状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的合同ID（唯一标识） |

### 更新合同

更新合同信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/contract/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |
| amount | 是 | Double | 总金额 |
| dimDepart | 是 | Long | 所属部门 |
| entityType | 是 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| title | 是 | String | 标题 |
| campaignId | 否 | Long | 所属市场活动 |
| comment | 否 | Sting | 备注 |
| contractCode | 否 | Sting | 合同编号 |
| contractContent | 否 | Sting | 合同文本 |
| contractType | 否 | Integer | 合同类型 |
| startDate | 否 | Long | 开始日期 |
| customerSigner | 否 | String | 客户方签约人 |
| dimArea | 否 | Long | 所属区域 |
| dimBusiness | 否 | Long | 所属业务 |
| dimIndustry | 否 | Long | 所属行业 |
| dimProduct | 否 | Long | 所属产品线 |
| endDate | 否 | Long | 结束日期 |
| opportunityId | 否 | Long | 销售机会 |
| payMode | 否 | Integer | 付款方式 |
| signDate | 否 | Long | 签约日期 |
| signerId | 否 | Long | 我方签约人 |
| status | 否 | Integer | 合同状态 |

### 锁定合同

锁定合同。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/contract/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要锁定的合同ID |

### 解锁合同

解锁合同。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/contract/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | long | 需要解锁的合同ID |

### 转移合同

转移合同。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/contract/actions/transfers`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要转移的合同ID |

### 删除合同

删除合同。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/contract/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的合同ID |

### 获取合同详细信息

获取指定合同的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contract/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的合同ID |

### 批量获取合同信息

根据合同 ids 批量获取合同信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/contract/actions/info/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | List<Long> | 需要查询的合同ID集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| products | JSONArray | 产品ID与产品名称的JSON数组 |

### 获取订单接口描述

获取订单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/description`

### 创建订单

创建订单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/order`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的订单ID（唯一标识） |

### 更新订单

更新指定订单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/order/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单ID |

### 锁定订单

锁定订单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单ID |

### 解锁订单

解锁订单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单ID |

### 删除订单

删除指定订单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/order/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单ID |

### 订单生效

订单状态从未生效变迁为已生效状态。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/activation?recordId={orderId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 订单、退货单或变更单唯一ID号。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 接口执行响应代码，200为成功，其他为失败。 |
| msg | String | 错误消息详细描述。 |
| batchData | List | 消息详情。 |

### 订单失效

订单从已生效状态变迁为未生效状态。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/deactivation?recordId={orderId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 订单、退货单或变更单唯一ID号。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 接口执行响应代码，200为成功，其他为失败。 |
| msg | String | 错误消息详细描述。 |
| batchData | List | 消息详情。 |

### 订单作废

订单从已生效状态变迁为作废状态。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/cancel?recordId={orderId}&cancelResonId={cancelReaSonId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 订单、退货单或变更单唯一ID号。 |
| cancelReasonId | 是 | Integer | 订单（退货单、变更）作废原因。
                1：单据变更导致作废
                2：单据重复导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 接口执行响应代码，200为成功，其他为失败。 |
| msg | String | 错误消息详细描述。 |
| batchData | List | 消息详情。 |

### 获取订单信息

获取指定订单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单ID |

### 同步订单明细至商机

根据指定订单 ID 将订单明细同步至关联的商机。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/syncOpportunity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 订单ID |

### 同步订单明细至报价单

根据指定订单 ID 将订单明细同步至关联的报价单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/syncQuote`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 订单ID |

### 查询当前订单业务类型是否支持合作伙伴自助下单

查询当前订单业务类型是否支持合作伙伴自助下单。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/isOrderType4PRM?busiTypeId={busiTypeId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| busiTypeId | 是 | Long | 订单业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| isOrderType4PRM | Boolean | 订单业务类型支持伙伴自助下单 |

### 查询订单新版 UI 开关是否打开

查询订单新版 UI 开关是否打开。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/breezeSwitch?deviceTypeId={deviceTypeId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| deviceTypeId | 是 | Long | 前端类型
                3：WEB
                0：APP |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| supportBreeze | Boolean | 订单breeze开关是否打开 |

### 判断客户字段是否可编辑

编辑订单弹框时，判断客户字段是否可编辑。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/validateAccount?orderId={orderId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| orderId | 是 | Long | 订单数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| canEdit | Boolean | 确定客户字段是否可编辑 |

### 判断订单明细是否可修改

商机生成订单或报价单生成订单时，订单明细是否可修改。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/canUpdateDetail?srcObjectApiKey={srcObjectApiKey}&srcObjectEntityType={srcObjectEntityType}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| srcObjectApiKey | 是 | String | 商机或报价单objectApiKey |
| srcObjectEntityType | 是 | Long | 商机或报价单的业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| orderProductCanUpdate | Boolean | 确定订单明细是否可修改 |

### 获取订单明细描述

获取订单明细对象的表结构，数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/description`

### 创建订单明细

创建订单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的订单ID（唯一标识） |

### 更新订单明细

更新指定订单明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单明细ID |

### 锁定订单明细

锁定订单明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单明细ID |

### 解锁订单明细

解锁订单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单明细ID |

### 复制订单明细

基于源订单对目标订单进行明细复制。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/actions/copyOrderProduct?scrOrderId={scrOrderId}&targetOrderId={targetOrderId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| scrOrderId | 是 | Long | 源订单ID |
| targetOrderId | 是 | Long | 目标订单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 订单明细 ID |
| objectApiKey | String | 订单明细 objectApiKey |
| busiType | Long | 订单明细业务类型 |
| name | Long | 订单明细序号 |

### 删除订单明细

删除指定订单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单明细ID |

### 获取订单明细信息

获取指定订单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 订单明细ID |

### 订单明细序号更新

批量更新订单明细的序号，重新整理序号格式以及断号处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/order/actions/batchReSort`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataIds | 是 | String | 主订单ID（最多不超过10个） |
| objectApikey | 是 | String | 子对象 ApiKey（orderProduct） |
| nameSeparator | 否 | String | 默认.也可以其它字符（最多不超过5个字符） |
| isOverlay | 否 | Boolean | 默认false是否强制更新，判断明细的序号是否为数字类型，如果不是数字类型且当前值传true，则会强制更新，也会更新为数字序号格式 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 接口执行结果状态 |
| Msg | String | 接口执行结果信息 |
| BatchData | List | 每一条数据的执行结果 |

### 获取订单支付关系接口描述

获取订单支付关系对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/description`

### 创建订单支付关系

创建订单支付关系。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 保存的数据的基本信息，包含ID，具体格式请参考返回示例。 |

### 更新订单支付关系

更新订单支付关系。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/{id}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 更新的数据的信息，包含ID，具体格式请参考返回示例 |

### 删除订单支付关系

删除指定订单支付关系。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 删除的数据的信息，包含ID，具体格式请参考返回示例 |

### 获取订单支付关系信息

查看指定订单支付关系的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 实际查到的数据，具体格式请参考返回示例 |

### 查询支付表单字段

查询支付表单字段。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/actions/getPaymentItems`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| deviceType | 是 | Short | 设备类型，可不传，默认为移动端0：移动端
                3：网页端 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| viewItems | JSON | 所有支付表单所需字段，详细格式见返回示例。 |
| allItems | JSON | 非必要信息，可与viewItems进行对照参考 |

### 查询订单支付关系

根据订单 ID 查询订单支付关系。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/orderPayment/actions/findByOrderId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| orderId | 是 | Long | 订单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | JSON | 查询到的数据信息，具体格式请参考返回示例。 |

### 获取价格表接口描述

获取价格表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/description`

### 创建价格表

创建价格表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/priceBook`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的价格表ID（唯一标识） |

### 更新价格表

更新指定价格表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表ID |

### 锁定价格表

锁定价格表。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表ID |

### 解锁价格表

解锁价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表ID |

### 删除价格表

删除指定价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表ID |

### 获取价格表信息

获取指定价格表的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceBook/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表ID |

### 获取价格表明细接口描述

获取价格表明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/description`

### 创建价格表明细

创建价格表明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的价格表明细ID（唯一标识） |

### 更新价格表明细

更新价格表明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表明细ID |

### 锁定价格表明细

锁定价格表明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表明细ID |

### 解锁价格表明细

解锁价格表明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表明细ID |

### 删除价格表明细

删除价格表明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表明细ID |

### 获取价格表明细信息

获取指定价格表明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceBookEntry/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 价格表明细ID |

### 获取阶梯价格表接口描述

获取阶梯价格表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceSchedule/description`

### 创建阶梯价格表

创建阶梯价格表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/priceSchedule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联 | 业务类型 |
| dimDepart | 是 | 关联 | 所属部门 |
| name | 是 | 文本 | 阶梯价格表名称 |
| priceType | 是 | 单选 | 定价方式 |
| active | 是 | 布尔 | 启用状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的阶梯价格表ID（唯一标识） |

### 更新阶梯价格表

更新指定阶梯价格表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/priceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要修改的阶梯价格表ID |
| entityType | 是 | 关联 | 业务类型 |
| dimDepart | 是 | 关联 | 所属部门 |

### 删除阶梯价格表

删除指定阶梯价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的阶梯价格表ID |

### 获取阶梯价格表信息

查看指定阶梯价格表详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的阶梯价格表ID |

### 获取阶梯价格表明细接口描述

获取阶梯价格表明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceTier/description`

### 创建阶梯价格表明细

创建阶梯价格表明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/priceTier`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联关系 | 业务类型 |
| dimDepart | 是 | 关联关系 | 所属部门 |
| priceScheduleId | 是 | 主子明细 | 阶梯价格表名称 |
| priceModel | 是 | 单选 | 定焦模型 |
| startingUnit | 是 | 浮点 | 起始数量 |
| endingUnit | 否 | 浮点 | 截止数量 |
| percentageAfterDiscount | 否 | 百分比 | 折扣 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的阶梯价格表明细ID（唯一标识） |

### 更新阶梯价格表明细

更新指定阶梯价格表明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/priceTier/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要修改的阶梯价格表明细ID |

### 删除阶梯价格表明细

删除指定阶梯价格表明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/priceTier/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的阶梯价格表明细ID |

### 获取阶梯价格表明细信息

查看指定阶梯价格表明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/priceTier/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的阶梯价格表明细ID |

### 获取产品阶梯价格表接口描述

获取产品阶梯价格表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productPriceSchedule/description`

### 创建产品阶梯价格表

创建产品阶梯价格表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productPriceSchedule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联关系 | 业务类型 |
| dimDepart | 是 | 关联关系 | 所属部门 |
| number | 是 | 整数 | 序号 |
| priceScheduleId | 是 | 主子明细 | 阶梯价格表名称 |
| productId | 是 | 关联关系 | 产品名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品阶梯价格表ID（唯一标识） |

### 更新产品阶梯价格表

更新指定产品阶梯价格表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要修改的产品阶梯价格表ID |
| number | 否 | 整数 | 序号 |
| priceScheduleId | 否 | 主子明细 | 阶梯价格表名称 |
| productId | 否 | 关联关系 | 产品名称 |

### 删除产品阶梯价格表

删除指定产品阶梯价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品阶梯价格表ID |

### 获取产品阶梯价格表信息

查看指定产品阶梯价格表详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品阶梯价格表ID |

### 获取产品选项阶梯价格表接口描述

获取产品选项阶梯价格表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productOptionPriceSchedule/description`

### 创建产品选项阶梯价格表

创建产品选项阶梯价格表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productOptionPriceSchedule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联关系 | 业务类型 |
| dimDepart | 是 | 关联关系 | 所属部门 |
| number | 是 | 整数 | 序号 |
| priceScheduleId | 是 | 主子明细 | 阶梯价格表名称 |
| productOptionId | 是 | 关联关系 | 产品选项编号 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品选项阶梯价格表ID（唯一标识） |

### 更新产品选项阶梯价格表

更新指定产品选项阶梯价格表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要修改的产品选项阶梯价格表ID |
| number | 否 | 整数 | 序号 |
| priceScheduleId | 否 | 主子明细 | 阶梯价格表名称 |
| productOptionId | 否 | 关联关系 | 产品选项编号 |

### 删除产品选项阶梯价格表

删除指定产品选项阶梯价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品选项阶梯价格表ID |

### 获取产品选项阶梯价格表信息

查看指定产品选项阶梯价格表详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productOptionPriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品选项阶梯价格表ID |

### 获取产品功能阶梯价格接口表描述

获取产品功能阶梯价格表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/description`

### 创建产品功能阶梯价格表

创建产品功能阶梯价格表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/productFeaturePriceSchedule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联关系 | 业务类型 |
| dimDepart | 是 | 关联关系 | 所属部门 |
| number | 是 | 整数 | 序号 |
| priceScheduleId | 是 | 主子明细 | 阶梯价格表名称 |
| productFeatureId | 是 | 关联关系 | 产品功能名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的产品功能阶梯价格表ID（唯一标识） |

### 更新产品功能阶梯价格表

更新指定产品功能阶梯价格表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要修改的产品功能阶梯价格表ID |
| number | 否 | 整数 | 序号 |
| priceScheduleId | 否 | 主子明细 | 阶梯价格表名称 |
| productFeatureId | 否 | 关联关系 | 产品功能名称 |

### 删除指定产品功能阶梯价格表

删除指定阶梯价格表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的产品功能阶梯价格表ID |

### 获取产品功能阶梯价格表信息

查看指定产品功能阶梯价格表详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/productFeaturePriceSchedule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的产品功能阶梯价格表ID |

### 复制产品价格规则

根据指定单个产品价格规则 ID 复制，包括规则下的规则条件和规则行为。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/cpqRule/actions/copy`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 产品价格规则ID |

### 复制规则组合

根据指定单个规则组合 ID 复制，包括规则组合下的产品价格规则以及规则下的规则条件和规则行为。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/ruleSet/actions/copy`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规则组合ID |

### 查询生效的产品价格规则

查询生效的产品价格规则。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/cpqRule/actions/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 主实体业务类型 |
| parentDataJson | 否 | JsonObject | 主数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| neoCalculation | Boolean | 是否走新计算包 |
| rules | List | 规则 |
| BuildExecutionSource | Boolean | 是否构建规则执行来源 |
| CpqRuleEvelMaxTime | Int | 规则执行最长时间 |
| executePromotionLimited | List | 限量限额 |
| PromotionLimitedLog | Map | 限量限额执行日志 |

### 获取报价单接口描述

获取报价单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/quote/description`

### 创建报价单

创建报价单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/quote`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | 关联类型 | 业务类型 |
| dimDepart | 是 | 关联类型 | 所属部门 |
| quotationEntityRelAccount | 是 | 关联类型 | 客户名称 |
| quoteTime | 是 | 时间类型 | 报价时间 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的报价单ID（唯一标识) |

### 更新报价单

更新报价单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/quote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 要修改的报价单ID |
| entityType | 是 | 关联类型 | 业务类型 |
| dimDepart | 是 | 关联类型 | 所属部门 |
| quotationEntityRelAccount | 是 | 关联类型 | 客户名称 |
| quoteTime | 是 | 时间类型 | 报价时间 |

### 删除报价单

删除报价单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/quote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 要删除的报价单ID，支持单条 |

### 获取报价单信息

获取指定报价单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/quote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的报价单ID |

### 同步报价单明细至商机

根据指定报价单 ID 将报价单明细同步至关联的商机。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/quote/actions/syncOpportunity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| quoteId | 是 | Long | 报价单ID |
| isCheckMainQuote | 否 | Boolean | 报价单同步至商机时，是否校验当前报价单为主报价单，如果不需要校验且当前报价单不是主报价单，则修改当前报价单为主报价单 |

### 获取报价单明细接口描述

获取报价单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/quoteLine/description`

### 创建报价单明细

创建报价单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/quoteLine`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | 字符串 | 序号 |
| entityType | 是 | 字符类型 | 业务类型 |
| dimDepart | 是 | 关联类型 | 所属部门 |
| quotationDetailEntityRelQuotationEntity | 是 | 关联类型 | 报价单编号 |
| quotationDetailEntityRelProduct | 是 | 关联类型 | 产品名称 |
| priceListId | 是 | 关联类型 | 价格表名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的报价单明细ID |

### 更新报价单明细

更新报价单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/quoteLine/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 要更新的报价单明细ID |
| entityType | 是 | 字符类型 | 业务类型 |
| dimDepart | 是 | 关联类型 | 所属部门 |
| quotationDetailEntityRelQuotationEntity | 是 | 关联类型 | 报价单编号 |
| quotationDetailEntityRelProduct | 是 | 关联类型 | 产品名称 |
| priceListId | 是 | 关联类型 | 价格表名称 |

### 复制报价单明细

将一个报价单内的报价单明细复制到另一个报价单中。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/quote/actions/copyQuoteLine`

### 删除报价单明细

删除报价单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/quoteLine/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 需要删除的报价单明细ID，支持单条 |

### 获取报价单明细信息

获取指定报价单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/quoteLine/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的报价单明细ID |

### 报价单明细序号更新

批量更新报价单明细的序号，重新整理序号格式以及断号处理。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/quote/actions/batchReSort`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataIds | 是 | String | 主报价单ID（最多不超过10个） |
| objectApikey | 是 | String | 子对象 ApiKey（quoteLine） |
| nameSeparator | 否 | String | 默认.也可以其它字符（最多不超过5个字符） |
| isOverlay | 否 | Boolean | 默认false是否强制更新，判断明细的序号是否为数字类型，如果不是数字类型且当前值传true，则会强制更新，也会更新为数字序号格式 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 接口执行结果状态 |
| Msg | String | 接口执行结果信息 |
| BatchData | List | 每一条数据的执行结果 |

### 创建应收

创建应收。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoice`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| type | 否 | Integer | 应收种类 |
| accountId | 是 | Long | 客户ID |
| companyName | 否 | String | 开票单位 |
| entityType | 是 | Long | 业务类型 |
| transactionDate | 是 | Long | 日期 |
| dimDepart | 是 | Long | 部门ID |
| contactPhone | 否 | String | 联系电话 |
| number | 否 | String | 票据号 |
| postcode | 否 | String | 邮编 |
| address | 否 | String | 邮寄地址 |
| description | 否 | String | 描述 |
| contactName | 否 | String | 联系人 |
| ownerId | 否 | Long | 所有人ID |
| status | 否 | Integer | 状态1：草稿2：生效3：已作废 |
| effectiveDate | 否 | Long | 生效日期 |
| cancellationDate | 否 | Long | 作废日期 |
| cancellationReason | 否 | Integer | 作废原因1：单据重复导致作废2：单据变更导致作废3：其他 |
| dueDate | 否 | Long | 收款截止日期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的应收数据ID（唯一标识) |

### 更新应收

更新应收信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoice/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 当前更新的应收数据ID |
| type | 否 | Integer | 应收种类 |
| accountId | 是 | Long | 客户ID |
| companyName | 否 | String | 开票单位 |
| entityType | 是 | Long | 业务类型 |
| transactionDate | 是 | Long | 日期 |
| dimDepart | 是 | Long | 部门ID |
| contactPhone | 否 | String | 联系电话 |
| number | 否 | String | 票据号 |
| postcode | 否 | String | 邮编 |
| address | 否 | String | 邮寄地址 |
| description | 否 | String | 描述 |
| contactName | 否 | String | 联系人 |
| ownerId | 否 | Long | 所有人ID |
| status | 否 | Integer | 状态1：草稿2：生效3：已作废 |
| effectiveDate | 否 | Long | 生效日期 |
| cancellationDate | 否 | Long | 作废日期 |
| cancellationReason | 否 | Integer | 作废原因1：单据重复导致作废2：单据变更导致作废3：其他 |
| dueDate | 否 | Long | 收款截止日期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 当前更新的应收数据ID |

### 删除应收

删除应收。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoice/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的应收数据ID |

### 创建应收明细

创建应收明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItem`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| invoiceId | 是 | Long | 应收单ID |
| objectApiKey | 是 | String | 应收明细对象的apiKey |
| ownerId | 否 | Long | 所有人ID |
| entityType | 是 | String | 应收明细业务类型 |
| dimDepart | 是 | String | 部门ID |
| transactionDate | 是 | String | 应收明细日期 |
| orderId | 是 | String | 订单ID |
| orderProductId | 是 | String | 订单明细ID |
| productId | 是 | String | 产品ID |
| amount | 是 | Double | 应收明细金额 |
| status | 否 | Integer | 应收明细状态1：草稿2：生效3：已作废 |
| dueDate | 否 | Long | 收款截止日期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的应收ID（唯一标识) |

### 更新应收明细

更新应收明细信息

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 应收明细ID |
| amount | 否 | Double | 指定要更新的应收明细金额 |
| transactionDate | 否 | Long | 应收明细日期 |
| status | 否 | Integer | 应收明细状态1：草稿2：生效3：已作废 |

### 删除应收明细

删除应收明细

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的应收明细ID |

### 创建应收变更单

创建应收变更单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| invoiceId | 是 | long | 应收ID |
| accountId | 是 | String | 客户 ID |
| objectId | 否 | Long | 应收变更单对象ID |
| entityType | 是 | Long | 应收变更单业务类型 |
| transactionDate | 是 | Long | 应收变更单日期 |
| dimDepart | 是 | String | 部门ID |
| contactPhone | 否 | String | 联系电话 |
| number | 否 | String | 票据号 |
| postcode | 否 | String | 邮编 |
| companyName | 否 | String | 应收单位 |
| address | 否 | String | 邮寄地址 |
| description | 否 | String | 应收变更单描述 |
| contactName | 否 | String | 联系人 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的应收变更单ID（唯一标识) |

### 更新应收变更单

更新应收变更单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| contactPhone | 否 | String | 联系电话 |
| id | 是 | Long | 当前更新的应收变更单数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 更新后的应收变更ID |

### 删除应收变更单

删除应收变更单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的应收变更单ID |

### 创建应收变更明细

创建应收变更明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItemAdjustment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| invoiceAdjustmentId | 是 | Long | 应收变更单ID |
| objectApiKey | 是 | String | 应收变更单明细对象的对象Key名称 |
| invoiceId | 是 | Long | 应收ID |
| invoiceItemId | 是 | Long | 应收明细 ID |
| entityType | 是 | Long | 变更单明细的业务类型 |
| dimDepart | 否 | Long | 部门ID |
| transactionDate | 是 | String | 应收变更单明细日期 |
| orderId | 是 | Long | 订单ID |
| productId | 是 | Long | 产品ID |
| ownerId | 是 | Long | 所有人ID |
| orderProductId | 是 | Long | 订单明细数据ID |
| amount | 是 | Double | 应收明细变更单明细金额 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的应收变更明细ID（唯一标识) |

### 更新应收变更明细

更新应收变更明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItemAdjustment/{id}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 更新后的应收变更明细ID |

### 删除应收变更明细

删除应收变更明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoiceItemAdjustment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的应收变更明细ID |

### 创建收款计划

创建收款计划。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplicationPlan`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 否 | Long | 客户ID |
| orderId | 订单合同二选一 | Long | 订单ID |
| contractId | 订单合同二选一 | Long | 合同ID |
| entityType | 否 | Long | 业务类型 |
| period | 否 | Integer | 收款期次 |
| stage | 否 | Integer | 收款阶段 |
| percentage | 否 | Long | 计划收款比例 |
| amount | 否 | Double | 计划收款金额 |
| transactionDate | 否 | Long | 计划收款日期 |
| dimDepart | 否 | Long | 所属部门ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的收款计划ID（唯一标识） |

### 更新收款计划

更新指定收款计划。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplicationPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 收款计划ID |
| stage | 否 | Integer | 收款阶段 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 更新后的收款计划数据 ID（唯一标识） |

### 删除收款计划

删除指定收款计划。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplicationPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 收款计划ID |

### 创建收款

创建收款。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | String | 客户 ID |
| entityType | 是 | Long | 收款业务类型 |
| ownerId | 否 | Long | 所有人 ID |
| dimDepart | 是 | String | 部门 ID |
| paymentMethod | 否 | String | 付款方式1：支票2：现金3：汇款4：其他 |
| transactionDate | 是 | String | 收款日期 |
| status | 否 | Integer | 收款状态1：草稿2：生效3：已作废 |
| effectiveDate | 否 | Long | 生效日期 |
| cancellationDate | 否 | Long | 作废日期 |
| cancellationReason | 否 | Integer | 作废原因1：单据重复导致作废2：单据变更导致作废3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新生成的收款数据 ID（唯一标识) |

### 更新收款

更新收款信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 待更新的收款数据ID |
| paymentMethod | 否 | String | 付款方式1：支票2：现金3：汇款4：其他 |
| transactionDate | 否 | String | 收款日期 |
| status | 否 | Integer | 收款状态1：草稿2：生效3：已作废 |
| effectiveDate | 否 | Long | 生效日期 |
| cancellationDate | 否 | Long | 作废日期 |
| cancellationReason | 否 | Integer | 作废原因1：单据重复导致作废2：单据变更导致作废3：其他 |

### 删除收款

删除收款

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的收款ID |

### 生成收款

根据合同/订单/应收单/收款计划等输入参数，其中收款计划用于校验，同时获取交易场景化配置，根据合同或订单场景，生成收款单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/actions/generatePayment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| invoiceIds | 否 | String | 应收单ID（逗号分隔的字符串） |
| orderIds | 否 | String | 订单ID（逗号分隔的字符串） |
| contractIds | 否 | String | 合同ID（逗号分隔的字符串） |
| paymentApplicationPlanId | 否 | Long | 收款计划ID |
| amount | 否 | Double | 金额 |
| rate | 否 | Double | 比例（场景化配置为合同场景，此参数不起作用，按amount收款或全额收款） |
| model | 否 | Integer | 计算方式1：按金额或比例均摊，默认方式2：按应收及明细创建时间顺序收款 |
| entityType | 否 | Long | 收款业务类型 |
| accountId | 否 | Long | 客户 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| paymentMethod | 否 | Integer | 收款方式 |
| transactionDate | 否 | Long | 收款日期 |
| currencyUnit | 否 | Integer | 币种 |
| currencyRate | 否 | Double | 汇率 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 收款数据ID（唯一标识） |

### 创建收款明细

创建收款明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/paymentItem`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 收款明细的 ApiKey |
| invoiceId | 是 | Long | 应收数据 ID |
| paymentId | 是 | Long | 收款数据 ID |
| ownerId | 否 | Long | 所有人 ID |
| invoiceItemId | 是 | Long | 应收明细 ID |
| entityType | 是 | String | 收款明细业务类型 |
| transactionDate | 是 | String | 收款明细日期 |
| productId | 是 | String | 产品 ID |
| amount | 是 | Long | 订单明细金额 |
| orderProductId | 是 | String | 订单明细数据ID |
| dimDepart | 是 | String | 部门 ID |
| orderId | 是 | String | 订单 ID |
| status | 否 | Integer | 收款明细状态1：草稿2：生效3：已作废 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的收款明细 ID（唯一标识) |

### 更新收款明细

更新收款明细信息

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/paymentItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 要更新的收款明细ID |
| amount | 否 | String | 指定要更新的收款明细字段 |
| transactionDate | 否 | String | 收款明细日期 |
| status | 否 | Integer | 收款明细状态1：草稿2：生效3：已作废 |

### 删除收款明细

删除收款明细

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/paymentItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的收款明细ID |

### 创建退款

创建退款。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/refund`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |
| objectId | 否 | Long | 退款对象ID |
| entityType | 是 | Long | 业务类型 |
| dimDepart | 否 | Long | 部门ID |
| transactionDate | 是 | Long | 退款日期 |
| reason | 是 | Long | 退款原因 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的退款ID（唯一标识) |

### 更新退款

更新退款信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/refund/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 退款ID |
| objectId | 否 | Long | 退款对象ID |
| transactionDate | 否 | Long | 退款日期 |
| dimDepart | 否 | Long | 部门ID |

### 删除退款

删除退款。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/refund/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的退款ID |

### 创建退款明细

创建退款明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/refundItem`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectapiKey | 否 | String | 退款明细的apiKey |
| invoiceId | 否 | Long | 发票变更单数据ID |
| paymentId | 否 | Long | 退款数据ID |
| ownerId | 否 | Long | 所有人ID |
| invoiceItemId | 否 | Long | 发票变更单明细ID |
| entityType | 是 | Long | 退款明细业务类型 |
| transactionDate | 是 | Long | 退款明细日期 |
| productId | 否 | Long | 产品ID |
| amount | 是 | Double | 订单明细金额 |
| objectId | 否 | Long | 退款明细对象ID |
| orderProductId | 否 | Long | 订单明细数据ID |
| dimDepart | 否 | Long | 部门ID |
| orderId | 否 | Long | 订单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的退款明细ID（唯一标识) |

### 更新退款明细

更新退款明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/refundItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 退款明细ID |
| amount | 是 | Double | 退款明细金额 |

### 删除退款明细

删除退款明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/refundItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的退款明细ID |

### 获取交付记录接口描述

获取交付记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/description`

### 创建交付记录

创建交付记录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | String | 业务类型 |
| ownerId | 否 | String | 所有人 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| deliveryStatus | 是 | Integer | 收货状态 |
| accountId | 是 | Long | 客户 |
| deliveryDate | 否 | Date | 交货日期 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 交付记录ID |
| objectApiKey | String | 交付记录ApiKey |
| busiType | Long | 业务类型 |

### 更新交付记录

更新指定交付记录。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 更新的交付记录ID |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| deliveryDate | 否 | Date | 交货日期 |
| comment | 否 | String | 备注 |

### 锁定交付记录

锁定交付记录。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 交付记录ID |

### 解锁交付记录

解锁交付记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 交付记录ID |

### 删除交付记录

删除指定交付记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的交付记录ID |

### 获取交付记录信息

查看指定交付记录详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 需要查看信息的交付记录ID |

### 交付记录确认收货

交付记录确认收货。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecord/actions/confirmReceipt?recordId={id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 交付记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 交付记录ID |

### 获取交付记录明细接口描述

获取交付记录明细对象的表结构，数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecordDetail/description`

### 创建交付记录明细

创建交付记录明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecordDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 编号 |
| entityType | 否 | String | 业务类型 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| deliveryRecordId | 是 | Long | 交付记录名称 |
| orderId | 是 | Long | 订单 |
| productId | 是 | Long | 产品 |
| orderProductId | 是 | Long | 订单明细 |
| quantityDelivered | 是 | Integer | 交付数量 |
| settleStatus | 是 | Integer | 结清 |
| contactName | 否 | String | 联系人 |
| contactTel | 否 | String | 联系电话 |
| contactAddress | 否 | String | 收货地址 |
| comment | 否 | String | 备注 |
| parentLine | 否 | Long | 上级明细 |
| superLine | 否 | Long | 所属明细 |
| optionLevel | 否 | Integer | 明细层级 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 交付记录明细ID |
| objectApiKey | String | 交付记录明细ApiKey |
| busiType | Long | 交付记录明细业务类型 |

### 更新交付记录明细

更新指定的交付记录明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 更新的交付记录明细ID |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| deliveryRecordId | 否 | Long | 交付记录名称 |
| quantityDelivered | 否 | Integer | 交付数量 |
| settleStatus | 否 | Integer | 结清 |
| contactName | 否 | String | 联系人 |
| contactTel | 否 | String | 联系电话 |
| contactAddress | 否 | String | 收货地址 |
| comment | 否 | String | 备注 |
| optionLevel | 否 | Integer | 明细层级（CPQ必须项） |

### 删除交付记录明细

删除指定交付记录明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 删除的交付记录明细ID |

### 获取交付记录明细信息

查看指定的交付记录明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/deliveryRecordDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 交付记录明细ID |

### 创建发票

创建发票。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/receipt`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户 ID |
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 ID |
| dimDepart | 是 | Long | 部门 ID |
| type | 是 | Integer | 发票种类
                                1：增值税发票
                                2：普通发票 |
| transactionDate | 是 | Long | 发票日期 |
| effectiveDate | 否 | Long | 生效日期 |
| contactPhone | 否 | String | 联系电话 |
| number | 否 | String | 票据号 |
| postcode | 否 | String | 邮编 |
| companyName | 否 | String | 开票单位 |
| address | 否 | String | 邮寄地址 |
| description | 否 | String | 发票描述 |
| contactName | 否 | String | 联系人 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的发票ID（唯一标识) |

### 更新发票

更新发票信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receipt/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | long | 发票ID |
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人ID |
| dimDepart | 是 | Long | 部门ID |
| type | 是 | Integer | 发票种类
                1：增值税发票
                2：普通发票 |
| transactionDate | 是 | Long | 发票日期 |
| effectiveDate | 否 | Long | 生效日期 |
| contactPhone | 否 | String | 联系电话 |
| number | 否 | String | 票据号 |
| postcode | 否 | String | 邮编 |
| companyName | 否 | String | 开票单位 |
| address | 否 | String | 邮寄地址 |
| description | 否 | String | 发票描述 |
| contactName | 否 | String | 联系人 |

### 生成发票

根据合同/订单/应收单/收款计划等输入参数，其中收款计划用于校验，同时获取交易场景化配置，根据合同或订单场景，生成发票。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/receipt/actions/generateReceipt`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| invoiceIds | 否 | String | 应收单ID（逗号分隔的字符串） |
| orderIds | 否 | String | 订单ID（逗号分隔的字符串） |
| contractIds | 否 | String | 合同ID（逗号分隔的字符串） |
| paymentApplicationPlanId | 否 | Long | 收款计划ID |
| amount | 否 | Double | 金额 |
| rate | 否 | Double | 比例（场景化配置为合同场景，此参数不起作用，按amount开票或全额开票） |
| model | 否 | Integer | 计算方式1：按金额或比例均摊，默认方式2：按应收及明细创建时间顺序收款 |
| entityType | 否 | Long | 发票业务类型 |
| accountId | 否 | Long | 客户 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| contactPhone | 否 | String | 联系电话 |
| companyName | 否 | String | 开票单位 |
| number | 否 | String | 票据号 |
| address | 否 | String | 邮寄地址 |
| postcode | 否 | String | 邮编 |
| type | 否 | Integer | 发票种类 |
| transactionDate | 否 | Long | 发票日期 |
| description | 否 | String | 发票描述 |
| contactId | 否 | Long | 联系人 |
| currencyUnit | 否 | Integer | 币种 |
| currencyRate | 否 | Double | 汇率 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 发票数据ID（唯一标识） |

### 删除发票

删除发票。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receipt/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的发票ID |

### 创建发票明细

创建发票明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/receiptItem`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 发票明细的apiKey |
| invoiceId | 是 | Long | 应收单数据ID |
| receiptId | 是 | Long | 发票数据ID |
| ownerId | 是 | Long | 所有人ID |
| invoiceItemId | 是 | Long | 应收单明细ID |
| entityType | 是 | Long | 业务类型 |
| transactionDate | 是 | Long | 明细日期 |
| productId | 是 | Long | 产品ID |
| amount | 是 | Double | 发票明细金额 |
| orderProductId | 是 | Long | 订单明细ID |
| dimDepart | 是 | Long | 部门ID |
| orderId | 否 | Long | 订单ID |
| objectId | 否 | Long | 发票明细对象ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的发票明细ID（唯一标识) |

### 更新发票明细

更新发票明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receiptItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | long | 发票明细ID |
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人ID |
| transactionDate | 否 | Long | 发票明细日期 |
| amount | 否 | Double | 发票明细金额 |
| objectApiKey | 否 | String | 发票明细对象ApiKey |

### 删除发票明细

删除发票明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receiptItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的发票明细ID |

### 生成应收单

应收单生效。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoice/actions/generateInvoice`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| orderIds | 否 | Long | 订单ID（逗号分隔的字符串） |
| contractId | 否 | String | 合同ID |
| amount | 否 | Double | 金额 |
| rate | 否 | Long | 比例 |
| model | 否 | Integer | 计算方式：1：按金额或比例均摊，默认方式2：按订单及明细创建时间顺序收款 |
| description | 否 | String | 描述 |
| transactionDate | 否 | Long | 应收日期 |
| type | 否 | Integer | 种类 |
| dimDepart | 否 | Long | 所属部门 |
| number | 否 | String | 票据号 |
| dueDate | 否 | Long | 收款截止日期 |
| contactPhone | 否 | String | 联系电话 |
| companyName | 否 | String | 开票单位 |
| address | 否 | String | 邮寄地址 |
| postcode | 否 | String | 邮编 |
| contactId | 否 | Long | 联系人 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据ID（唯一标识） |

### 应收单生效

应收单生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoice/actions/activation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收单数据ID（唯一标识） |

### 应收单失效

应收单失效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoice/actions/deactivation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收单数据ID（唯一标识） |

### 应收单作废

应收单作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoice/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |
| cancelReasonId | 是 | Long | 1：单据重复导致作废
                2：单据变更导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收单数据ID（唯一标识） |

### 收款单生效

收款单生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/actions/activation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 收款单数据ID（唯一标识） |

### 收款单失效

收款单失效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/actions/deactivation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 收款单数据ID（唯一标识） |

### 收款单作废

收款单作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/paymentApplication/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |
| cancelReasonId | 是 | Long | 1：单据重复导致作废
                2：单据变更导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 收款单数据ID（唯一标识） |

### 应收变更单生效

应收变更单生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/activation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收变更单数据ID（唯一标识） |

### 应收变更单失效

应收变更单失效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/deactivation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收变更单数据ID（唯一标识） |

### 应收变更单作废

应收变更单作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceAdjustment/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |
| cancelReasonId | 是 | Long | 1：单据重复导致作废
                2：单据变更导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收变更单数据ID（唯一标识） |

### 退款生效

退款生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/refund/actions/activation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 退款数据ID（唯一标识） |

### 退款失效

退款失效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/refund/actions/deactivacanceltion`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 退款数据ID（唯一标识） |

### 退款作废

退款作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/refund/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |
| cancelReasonId | 是 | Long | 1：单据重复导致作废
                2：单据变更导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 退款数据ID（唯一标识） |

### 发票生效

发票生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receipt/actions/activation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 发票数据ID（唯一标识） |

### 发票失效

发票失效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receipt/actions/deactivation`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 发票数据ID（唯一标识） |

### 发票作废

发票作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receipt/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 数据ID |
| cancelReasonId | 是 | Long | 1：单据重复导致作废
                2：单据变更导致作废
                3：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 发票数据ID（唯一标识） |

### 创建货币设置

创建货币设置。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 是 | String | 货币名称 |
| unit | 是 | String | 货币单位 |
| symbol | 是 | String | 货币符号 |
| rate | 是 | Double | 货币汇率 |
| remark | 否 | String | 备注信息 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 货币设置数据量 |
| data.[count] | Integer | 货币设置数据量 |
| data.[records].[apiKey] | String | 货币设置 apiKey |
| data.[records].[result] | Bool | 成功返回 true，失败返回 false |

### 更新货币设置

根据 ApiKey 更新指定货币设置。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies/currencyUnit1`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 否 | String | 货币名称 |
| unit | 否 | String | 货币单位 |
| symbol | 否 | String | 货币符号 |
| rate | 否 | Double | 货币汇率 |
| remark | 否 | String | 备注信息 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 货币设置数据量 |
| data.[count] | Integer | 货币设置数据量 |
| data.[records].[result] | Bool | 成功返回 true，失败返回 false |

### 删除货币设置

通过 ApiKey 删除指定货币设置。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies/currencyUnit2`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ApiKey | 是 | String | 货币设置 ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 货币设置数据量 |
| data.[count] | Integer | 货币设置数据量 |
| data.[records].[result] | Bool | 成功返回 true，失败返回 false |

### 获取指定货币设置信息

通过 ApiKey，查看指定货币设置详细信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies/{ApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ApiKey | 是 | String | 货币设置 ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 货币设置数据量 |
| data.[count] | Integer | 货币设置数据量 |
| data.[records].[id] | Long | 货币设置ID |
| data.[records].[label] | String | 货币设置名称 |
| data.[records].[apikey] | String | 货币设置 apikey |
| data.[records].[unit] | String | 货币单位 |
| data.[records].[symbol] | String | 货币设置符号 |
| data.[records].[rate] | Double | 货币汇率 |
| data.[records].[symbol] | String | 货币设置符号 |
| data.[records].[remarkl] | String | 备注信息 |
| data.[records].[active] | Bool | 是否启用 |
| data.[records].[domestic] | Bool | 是否开通多货币 |

### 获取所有货币设置

获取所有货币设置对象的描述、对应选型等信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 货币设置数据量 |
| data.[count] | Integer | 货币设置数据量 |
| data.[records].[id] | Long | 货币设置ID |
| data.[records].[label] | String | 货币设置名称 |
| data.[records].[apikey] | String | 货币设置 apikey |
| data.[records].[unit] | String | 货币单位 |
| data.[records].[symbol] | String | 货币设置符号 |
| data.[records].[rate] | Double | 货币汇率 |
| data.[records].[symbol] | String | 货币设置符号 |
| data.[records].[remarkl] | String | 备注信息 |
| data.[records].[active] | Bool | 是否启用 |
| data.[records].[domestic] | Bool | 是否开通多货币 |

### 启用单个货币设置

根据货币的 APIKEY （currencyApiKey）启用单个货币设置。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies/{currencyApiKey}/enableStatus`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 响应结果码  
                0：成功  
                其他值：错误码 |
| msg | String | 响应结果描述 |

### 禁用单个货币设置

根据货币的 APIKEY （currencyApiKey）禁用单个货币设置。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/settings/systemSettings/currencies/{currencyApiKey}/enableStatus`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 响应结果码
                0：成功
                其他值：错误码 |
| msg | String | 响应结果描述 |

### 获取促销累加接口描述

获取促销累加对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotionCounter/description`

### 获取市场活动接口描述

获取市场活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaign/description`

### 创建市场活动

创建市场活动。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/campaign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 市场活动名称 |
| entityType | 是 | Long | 业务类型 |
| startDate | 是 | Long | 开始日期 |
| endDate | 是 | Long | 结束日期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的市场活动ID（唯一标识) |

### 更新市场活动

更新指定的市场活动。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/campaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 市场活动ID |

### 删除市场活动

删除指定的市场活动。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/campaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的市场活动ID |

### 获取市场活动信息

查看指定的市场活动详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的市场活动ID |

### 获取活动成员总数

按照查询条件获取营销线索总数。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/actions/count`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| conditionSql | 否 | String | sql查询条件片段（值用问号代替） |
| paramList | 否 | Array | 查询条件中参数值列表 |

### 获取活动成员列表信息

按照查询条件获取活动成员列表信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/actions/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| conditionSql | 否 | String | sql查询条件片段（值用问号代替） |
| paramList | 否 | Array | 查询条件中参数值列表 |
| pageNo | 否 | integer | 分页当前页 |
| pageSize | 否 | integer | 分页条数 |
| sortList | 否 | array | 排序列 |

### 活动成员注册

用于市场活动下活动成员注册。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/actions/register`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| campaignId | 是 | Long | 需要注册的市场活动的ID |
| name | 是 | String | 姓名 |
| mobile | 是 | String | 移动电话 |
| email | 否 | String | 邮箱 |
| companyName | 否 | String | 公司名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| leadType | Integer | 如果线索不存在，则为注册成功后，新创建的线索的类  
                型。如果线索已经存在，则返回查询出的线索的类型。1 - ML; 2 - SL; 3 - Contact |
| leadId | Long | 如果线索不存在，则为注册成功后，新创建的线索的id。如果线索已经存在，则返回查询出的线索的id。 |
| campaignId | Long | 市场活动id |
| registerToken | String | 注册成功时生成的注册令牌 |
| companyName | String | 公司名称，根据实际情况返回 |

### 活动成员签到

市场活动签到。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/actions/checkin`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| campaignId | 是 | Long | 需要签到的市场活动的ID |
| name | 是 | String | 姓名 |
| mobile | 是 | String | 移动电话 |
| email | 否 | String | 邮箱 |
| companyName | 否 | String | 公司名称 |
| registerToken | 否 | String | 注册令牌，取注册成功时返回的registerToken |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| leadType | Integer | 签到成功后，新创建的线索的类型，1 - ML; 2 - SL; 3 - Contact |
| leadId | Long | 签到成功后，新创建的线索的ID |
| campaignId | Long | 市场活动ID |
| companyName | String | 公司名称，根据实际情况返回 |

### 创建活动记录

创建活动记录。

- 请求方式: `POST（APPLICATION/JSON）`
- API 地址: `/rest/data/v2.0/xobjects/activityrecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 活动记录所属对象 |
| itemId | 是 | Long | 对象数据ID |
| groupId | 否 | Long | 对象数据的groupId |
| content | 否 | String | 活动记录内容 |
| type | 是 | Long | 活动记录类型 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据ID |
| objectApiKey | String | 对象apikey |
| busiType | Long | 业务类型 |

### 更新活动记录

更新活动记录。

- 请求方式: `PUT（APPLICATION/JSON）`
- API 地址: `/rest/data/v2.0/xobjects/activityrecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 活动记录ID |
| content | 否 | String | 活动记录内容 |
| deleteFiles | 否 | String | 要删掉的图片和附件的ID串，例如：996929990033422,996929990033423 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据ID |

### 删除活动记录

删除单条活动记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/activityrecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 活动记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | Object | 包含ID的JSON对象 |
| errorInfo | String | 错误信息 |

### 获取不同业务类型活动记录的图片上传方式

获取活动记录不同业务类型允许的图片上传方式。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/activity/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | Array | 结果信息集合 |
| data.imageUploadType | JSON | Key：业务类型ID
                Value：允许的图片上传方式（0：全部；1：拍照；2：图库） |

### 获取销售业绩拆分接口描述

获取销售业绩拆分对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/description`

### 创建销售业绩拆分

创建销售业绩拆分。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 记录ID |

### 更新销售业绩拆分

更新销售业绩拆分信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 记录ID |
| opportunityId | 否 | Long | 销售机会 |
| benificialMember | 否 | Long | 受益成员 |
| dimDepart | 否 | Long | 部门 |
| splitMethod | 否 | Long | 拆分方式 |
| splitPercentage | 是 | double | 比例 |
| amount | 是 | double | 金额 |
| active | 是 | Long | 启用 |
| objectId | 是 | Long | 对象ID |
| entityType | 否 | Long | 业务类型 |

### 锁定销售业绩拆分

锁定销售业绩拆分。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要锁定的记录ID |

### 解锁销售业绩拆分

解锁销售业绩拆分。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的记录ID |

### 删除销售业绩拆分

删除销售业绩拆分。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的记录ID |

### 获取销售业绩拆分信息

获取指定销售业绩拆分的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPerformanceSplit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的记录ID |

### 查询线索公海池日志

查询指定线索的公海池日志。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/highSea/lead/log/{recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 线索 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| batchData | 数组 | 公海池日志数据集合 |
| data | 对象 | 公海池日志数据 |
| data.content | String | 退回原因备注 |
| data.reason | String | 退回原因 |
| data.type | Integer | 日志类型1：领取2：退回3：分配6：删除9：废弃10：回收12：自动解冻13：手动解冻 |
| data.highSeaId | Long | 公海池 ID |

### 获取应收单后台设置

获取应收及明细，保存即生效设置，默认 false。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/invoice/`

### 获取收款单后台设置

获取收款单相关后台设置。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/paymentApplication/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| paymentApplicationAmountSettings | Boolean | 是否打开收款记录金额与明细必须同时存在的开关，默认 false |
| paymentApplicationEffective | Boolean | 收款及明细,保存即生效设置，默认 false |
| paymentApplicationFractionalVerification | Boolean | 交易管理的收款单核销是否支持分次核销，默认 false当 paymentAmountSettings 为
                  true时，这个设置恒为 false |

### 获取应收变更单后台设置

获取应收变更单及明细，保存即生效设置，默认 false。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/invoiceAdjustment/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| invoiceadjustmentEffective | Boolean | 应收变更单及明细,保存即生效设置，默认false |

### 获取退款单后台设置

获取退款单及明细，保存即生效设置，默认 false。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/refund/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| refundEffective | Boolean | 退款及明细,保存即生效设置，默认false |

### 获取发票后台设置

获取发票及明细，保存即生效设置，默认 false。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/receipt/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| receiptEffective | Boolean | 发票及明细,保存即生效设置，默认false |

### 获取交付记录后台设置

获取交付记录对订单影响的设置，默认 false。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/deliveryRecord/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| validateReturnQuantity | Boolean | true：订单退货单受已交付数量影响，订单的产品退货数量不能大于已交付数量。false：订单退货单不受已交付数量影响。 |
| cannotChangeIfDelivered | Boolean | true：订单修改/变更受已交付影响，已存在交付记录的订单明细不能修改。false：订单修改/变更不受已交付影响。 |

### 客户后台业务设置接口

获取客户后台的业务设置。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/businessSettings/account/`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | Array | 结果信息集合 |
| data.closeBusinessInfoFlg | Boolean | 工商信息是否关闭的标识
                true：关闭，不使用工商信息功能
                false：开启，使用工商信息功能 |
| data.enableMobileDefaultState | Boolean | 省市区根据当前位置自动生成默认值（移动端）true：开启false：未开启 |
| data.accountBusiTypeSetting | Array | 客户创建规则，客户的各个业务类型可单独设置规则true：手工录入或者按照工商信息选填false：仅按工商信息选填 |
| data.accountBusiTypeSetting.busiTypeId | Integer | 业务类型 ID |
| data.accountBusiTypeSetting.accountNameRulesFlg | Boolean | 客户创建规则 |

### 查询前台实体列表页导出记录

查询前台实体列表页的导出记录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/exportLog/actions/list?belongId={belongId}&startTime={startTime}&endTime={endTime}&pageNo={pageNo}&pageSize={pageSize}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 实体ID |
| startTime | 否 | Long | 开始时间 |
| endTime | 否 | Long | 截止时间 |
| pageNo | 否 | Integer | 页码 |
| pageSize | 否 | Integer | 每页查询条数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 返回码，200表示成功 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                                    fileName文件名称。 |

### 查询前台实体列表页单个导出记录

查询前台实体列表页的单个导出记录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/exportLog/actions/query?id={id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 导出记录 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 返回码 3101001：系统错误 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                  fileUrl文件名称。 |

### 获取促销活动接口描述

获取促销活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/description`

### 更新促销活动

更新促销活动。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/{id}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 提示信息 |
| data | Json | 更新的数据的信息，包含ID，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 锁定促销活动

锁定促销活动。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 促销活动ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 解锁促销活动

解锁促销活动。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 促销活动ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取促销活动信息

查看指定促销活动的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为错误情况 |
| msg | String | 返回提示信息 |
| data | Json | 实际查到的数据，具体格式参见返回示例 |
| errorInfo | String | 错误信息 |

### 更新促销活动生效状态

更新促销活动生效状态。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/actions/updateStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 促销活动ID |
| status | 是 | Integer | 生效状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取应收发票接口描述

获取应收发票对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoiceReceipt/description`

### 创建应收发票

创建应收发票。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoiceReceipt`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | String | 业务类型 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| receiptId | 是 | String | 发票ID |
| receiptAmount | 是 | double | 开票金额 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收发票ID |
| objectApiKey | String | 应收发票Apikey |
| busiType | Long | 对象的业务类型 |

### 更新应收发票

更新指定的应收发票。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoiceReceipt/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 更新的应收发票ID |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| receiptId | 是 | String | 发票ID |
| receiptAmount | 是 | double | 开票金额 |

### 删除应收发票

删除指定的应收发票。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoiceReceipt/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 删除的应收发票ID |

### 获取应收发票信息

获取应收发票信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoiceReceipt/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 应收发票ID |

### 获取应收收款接口描述

获取应收收款对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoicePayment/description`

### 创建应收收款

创建应收收款。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoicePayment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | String | 业务类型 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| paymentId | 是 | String | 收款单ID |
| paymentAmount | 是 | Doubel | 收款金额 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收收款ID |
| objectApiKey | String | 应收收款Apikey |
| busiType | Long | 业务类型 |

### 更新应收收款

更新应收收款。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoicePayment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 更新的应收收款ID |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| paymentId | 是 | String | 收款单ID |
| paymentAmount | 是 | Doubel | 收款金额 |

### 删除应收收款

删除应收收款。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoicePayment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 删除的应收收款ID |

### 获取应收收款信息

查看指定的应收收款详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoicePayment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 应收收款ID |

### 获取应收收款退款接口描述

获取应收收款退款对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoicePaymentRefund/description`

### 创建应收收款退款

创建应收收款退款。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/invoicePaymentRefund`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | String | 业务类型 |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| paymentId | 是 | String | 收款单ID |
| paymentAmount | 是 | Double | 收款金额 |
| refundId | 是 | String | 退款ID |
| refundAmount | 是 | Double | 退款金额 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 应收收款退款ID |
| objectApiKey | String | 应收收款退款Apikey |
| busiType | Long | 业务类型 |

### 更新应收收款退款

更新应收收款退款。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 更新的应收收款退款ID |
| dimDepart | 否 | String | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| dimProduct | 否 | String | 所属产品 |
| dimIndustry | 否 | String | 所属行业 |
| dimBusiness | 否 | String | 所属业务线 |
| invoiceId | 是 | String | 应收单ID |
| paymentId | 是 | String | 收款单ID |
| paymentAmount | 是 | Double | 收款金额 |
| refundId | 是 | String | 退款ID |
| refundAmount | 是 | Double | 退款金额 |

### 删除应收收款退款

删除指定的应收收款退款。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | String | 删除的应收收款退款ID |

### 获取应收收款退款信息

获取指定的应收收款退款信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/invoicePaymentRefund/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 应收收款退款ID |

### 查询团队成员继承

查询某个实体是否支持团队成员继承以及返回团队成员数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/groupMemberExtends/actions/getGroupmemberExtendsParam`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityId | 是 | Long | 实体ID |
| referObjectId | 是 | Long | 新建实体ID |
| recordId | 是 | Long | 记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示消息 |
| data | String | 团队成员数据 |
| errorInfo | String | 错误信息 |

### 查询用户级CPQ license

通过该接口，可以查询到用户是否有cpqlicense权限。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/quote/actions/checkUserCPQLicense`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200：成功 |
| msg | String | 成功或失败提示消息 |
| data | String | 是否有用户级cpqlicense |
| errorInfo | String | 失败的详细描述信息 |

### 查询实体导入记录

导入记录查询。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/import/record/actions/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 否 | Long | 实体ID |
| platform | 否 | Integer | 0：后台
                                1：前台 |
| userId | 否 | Long | 用户ID |
| startTime | 否 | Long | 开始时间 |
| endTime | 否 | Long | 截止时间 |
| pageNo | 否 | Integer | 页码 |
| pageSize | 否 | Integer | 每页查询条数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                                    fileName文件名称。 |

### 查询实体单个导入记录

单个导入记录查询。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/import/record/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                                    fileName文件名称。 |

### 查询实体导出记录

导出记录查询。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/export/record/actions/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 否 | Long | 实体ID |
| platform | 否 | Integer | 0：后台
                                1：前台 |
| userId | 否 | Long | 用户ID |
| startTime | 否 | Long | 开始时间 |
| endTime | 否 | Long | 截止时间 |
| pageNo | 否 | Integer | 页码 |
| pageSize | 否 | Integer | 每页查询条数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                                    fileName文件名称。 |

### 查询实体单个导出记录

单个导出记录查询。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/export/record/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 错误码 |
| Msg | String | 成功或失败提示信息 |
| Data | JSON | 结果信息集合 |
| data.records | Array | fileUrl下载链接。
                                    fileName文件名称。 |

### 获取单位接口描述

获取单位对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/unit/description`

### 创建单位

创建单位。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/unit`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 单位名称 |
| active | 是 | Boolean | 启用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 单位 ID |
| objectApiKey | String | 单位 ApiKey |
| busiType | Long | 业务类型 |

### 更新单位

更新指定的单位。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/unit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 单位名称 |
| active | 是 | Boolean | 启用 |

### 锁定单位

锁定单位。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/unit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 单位 ID |

### 解锁单位

解锁单位。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/unit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 单位 ID |

### 删除单位

删除指定的单位。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/unit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的单位ID |

### 获取单位信息

查看指定的单位详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/unit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 单位 ID |

### 获取规格接口描述

获取规格对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/specification/description`

### 创建规格

创建规格。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/specification`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 规格名称 |
| productSpecificationValueItem | 是 | String | 产品规格值字段 |
| active | 是 | Boolean | 启用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 规格 ID |
| objectApiKey | String | 规格 ApiKey |
| busiType | Long | 业务类型 |

### 更新规格

更新指定的规格。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/specification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 规格名称 |
| productSpecificationValueItem | 是 | String | 产品规格值字段 |
| active | 是 | Boolean | 启用 |

### 锁定规格

锁定规格。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/specification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格 ID |

### 解锁规格

解锁规格。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/specification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格 ID |

### 删除规格

删除指定的规格。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/specification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的规格 ID |

### 获取规格信息

查看指定规格的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/specification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格 ID |

### 获取规格值接口描述

获取规格值对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/description`

### 创建规格值

创建规格值。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 规格值名称 |
| specification | 是 | Long | 规格 |
| active | 是 | Boolean | 启用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 规格值ID |
| objectApiKey | String | 规格值ApiKey |
| busiType | Long | 业务类型 |

### 更新规格值

更新指定的规格值。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 规格值名称 |
| specification | 是 | Long | 规格 |
| active | 是 | Boolean | 启用 |

### 锁定规格值

锁定规格值。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格值ID |

### 解锁规格值

解锁规格值。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格值 ID |

### 删除规格值

删除指定的规格值。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的规格值 ID |

### 获取规格值信息

查看指定规格值的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/specificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 规格值 ID |

### 获取商品接口描述

获取商品对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goods/description`

### 创建商品

创建商品。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goods`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 商品名称 |
| baseUnit | 是 | Long | 基础单位 |
| Category | 是 | Long | 目录 |
| multiUnit | 是 | Boolean | 开启多单位 |
| multiSpecification | 是 | Boolean | 开启多规格 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 商品 ID |
| objectApiKey | String | 商品 ApiKey |
| busiType | Long | 业务类型 |

### 更新商品

更新指定的商品。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goods/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 业务类型 |
| ownerId | 否 | Long | 所有人 |
| dimDepart | 否 | Long | 所属部门 |
| dimArea | 否 | String | 所属区域 |
| name | 是 | String | 商品名称 |
| baseUnit | 是 | Long | 基础单位 |
| Category | 是 | Long | 目录 |
| multiUnit | 是 | Boolean | 开启多单位 |
| multiSpecification | 是 | Boolean | 开启多规格 |

### 锁定商品

锁定商品。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/goods/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品 ID |

### 解锁商品

解锁商品。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goods/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品 ID |

### 删除商品

删除指定的商品。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goods/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的商品 ID |

### 获取商品信息

查看制定商品的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goods/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品 ID |

### 获取商品单位接口描述

获取商品单位对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/description`

### 创建商品单位

创建商品单位。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| goods | 是 | Long | 商品 |
| unit | 是 | Long | 单位 |
| conversionRate | 是 | Double | 换算比例 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 商品单位 ID |
| objectApiKey | String | 商品单位 ApiKey |
| busiType | Long | 业务类型 |

### 更新商品单位

更新指定的商品单位。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| conversionRate | 是 | Double | 换算比例 |

### 锁定商品单位

锁定商品单位。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品单位 ID |

### 解锁商品单位

解锁商品单位。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品单位 ID |

### 删除商品单位

删除指定的商品单位。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的商品单位ID |

### 获取商品单位的信息

查看指定商品单位的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsUnit/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品单位 ID |

### 获取商品规格接口描述

获取商品规格的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/description`

### 创建商品规格

创建商品规格。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| goods | 是 | Long | 商品 |
| specification | 是 | Long | 单位 |
| productSpecificationValueItem | 是 | String | 产品规格值字段 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 商品规格 ID |
| objectApiKey | String | 商品 ApiKey |
| busiType | Long | 业务类型 |

### 更新商品规格

更新指定的商品规格。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productSpecificationValueItem | 是 | String | 产品规格值字段 |

### 锁定商品规格

锁定商品规格。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品规格 ID |

### 解锁商品规格

解锁商品规格。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品单位 ID |

### 删除商品规格

删除指定的商品规格。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的商品规格ID |

### 获取商品规格信息

查看指定商品规格的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品规格 ID |

### 获取商品规格值接口描述

获取商品规格值对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/description`

### 创建商品规格值

创建商品规格值。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| goods | 是 | Long | 商品 |
| specification | 是 | Long | 规格 |
| specificationValue | 是 | Long | 规格值 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 商品规格值 ID |
| objectApiKey | String | 商品规格值 ApiKey |
| busiType | Long | 业务类型 |

### 更新商品规格值

更新指定的商品规格值。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| specification | 是 | Double | 规格 |

### 锁定商品规格值

锁定商品规格值。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品规格值ID |

### 解锁商品规格值

解锁商品规格值。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品规格值ID |

### 删除商品规格值

删除指定的商品规格值。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的商品规格值ID |

### 获取商品规格值信息

查看指定的商品规格值信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goodsSpecificationValue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 商品规格值 ID |

### 精准查询工商信息

根据公司名称、公司ID或统一社会信用代码，查询基础工商信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/info`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| companyId | String | 公司ID |
| name | String | 公司名称 |
| legalPersonName | String | 法人名称 |
| regNumber | String | 注册号 |
| regLocation | String | 注册地址 |
| estiblishTime | String | 成立日期 |
| fromTime | String | 营业期限开始日期 |
| toTime | String | 营业期限终止日期 |
| businessScope | String | 经营范围 |
| regInstitute | String | 登记机关 |
| approvedTime | String | 核准日期 |
| regStatus | String | 企业状态 |
| regCapital | String | 注册资金 |
| actualCapital | String | 实收注册资金 |
| currency | String | 币种 |
| orgNumber | String | 组织机构代码 |
| creditCode | String | 统一社会信用代码 |
| phoneNumber | String | 电话 |
| email | String | 邮箱 |
| postalAddress | String | 通信地址 |
| postcode | String | 邮政编码 |
| website | String | 网站 |
| province | String | 省份 |
| prefecture | String | 地市 |
| county | String | 区县 |
| domDistrict | String | 行政区划代码 |
| type | String | 机构类型 |
| industry | String | 行业 |

### 模糊查询工商信息

根据关键词查询公司名称，返回包含该关键词的公司列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 公司名称关键词 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| companyId | String | 公司ID |
| name | String | 公司名称 |
| creditCode | String | 统一社会信用代码 |

### 查询变更信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业变更信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/changeInfo`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| changeTime | String | 变更日期 |
| changeItem | String | 变更事项 |
| contentBefore | String | 变更前内容 |
| contentAfter | String | 变更后内容 |

### 查询股东信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业股东信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/investor`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 股东名称 |
| investorTypeName | String | 股东类型 |
| capital | String | 认缴金额（万） |
| investorId | String | 股东公司ID |

### 查询企业对外投资信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业对外投资信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/ investment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| invName | String | 被投资企业名称 |
| invId | String | 被投资企业id |
| capital | String | 认缴金额（万） |

### 查询企业分支机构信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业分支机构。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/branch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| branchId | String | 分支机构ID |
| branchName | String | 分支机构名称 |

### 查询行政处罚信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业行政处罚。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/punishment`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| penDecIssDate | String | 处罚日期 |
| penDecNo | String | 决定文书号 |
| caseReason | String | 处罚事由 |
| IllegFact | String | 主要违法事实 |
| penResult | String | 处罚结果 |
| penExeSt | String | 处罚执行情况 |
| content | String | 处罚内容 |
| penAuthName | String | 处罚单位 |

### 查询经营异常信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业经营异常。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/abnormal`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| inDate | String | 列入异常名录日期 |
| inReason | String | 列入异常名录原因 |
| yrRegOrg | String | 决定列入异常名录部门（做出决定机关） |
| outDate | String | 移除异常名录日期 |
| outReason | String | 移除异常名录原因 |
| ycRegOrg | String | 决定移除异常名录部门 |

### 查询严重违法失信信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业严重违法失信。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/illegal`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| inDate | String | 列入日期 |
| inReason | String | 列入原因 |
| inOrg | String | 列入决定机关 |
| outDate | String | 列出日期 |
| outReason | String | 列出原因 |
| outOrg | String | 列出决定机关 |

### 查询企业主要人员信息

根据公司名称、公司 ID 或统一社会信用代码，查询企业主要人员。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/dataproduct/company/staff`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 公司名称 |
| companyId | 否 | Long | 公司ID |
| uniscid | 否 | String | 统一社会信用代码 |
| pageNum | 否 | Long | 页数，从0开始，默认为0 |
| pageSize | 否 | Long | 每页数量，默认为10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 姓名 |
| staffTypeName | String | 职务 |

### 获取限量限额接口描述

获取限量限额对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/description`

### 创建限量限额

创建限量限额。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 限量限额编号 |
| entityType | 否 | Long | 业务类型 |
| salesPromotionId | 否 | Long | 促销活动 |
| cpqRuleId | 否 | Long | 产品价格规则 |
| productId | 否 | Long | 产品 |
| limitedDimension | 是 | Short | 限量维度 |
| limitedType | 是 | Short | 限量类型 |
| limitedQuantity | 是 | Double | 限量值 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 限量限额 ID |
| objectApiKey | String | 限量限额 ApiKey |
| busiType | Long | 业务类型 |

### 更新限量限额

更新指定限量限额。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| salesPromotionId | 否 | Long | 促销活动 |
| cpqRuleId | 否 | Long | 产品价格规则 |
| productId | 否 | Long | 产品 |
| limitedDimension | 否 | Short | 限量维度 |
| limitedType | 否 | Short | 限量类型 |
| limitedQuantity | 否 | Double | 限量值 |
| status | 否 | Boolean | 启用状态 |

### 锁定限量限额

锁定指定限量限额。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 限量限额 ID |

### 解锁限量限额

解锁指定限量限额。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 限量限额 ID |

### 删除限量限额

删除指定限量限额。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 删除的限量限额 ID |

### 获取限量限额信息

查看指定限量限额详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/promotionLimited/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 限量限额 ID |

---

## 服务云API接口

### 获取资产接口描述

获取资产对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/asset/description`

### 创建资产

创建资产。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/asset`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| region | 是 | String | 区 |
| address | 是 | String | 地址 |
| status | 是 | Integer | 状态 |
| city | 是 | String | 市 |
| state | 是 | String | 省 |
| productName | 是 | Long | 产品名称，产品唯一标识ID |
| assetAccountId | 是 | Long | 客户名称，客户唯一标识ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的资产ID（唯一标识) |

### 更新资产

更新资产信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/asset/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 资产ID |

### 删除资产

删除资产。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/asset/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的资产ID |

### 获取资产信息

获取指定资产的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/asset/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的资产ID |

### 获取仓库接口描述

获取仓库对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/warehouse/description`

### 创建仓库

创建仓库。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/warehouse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 仓库名称 |
| warehouseType | 是 | Integer | 仓库类型 |
| status | 是 | Integer | 状态 |
| ownerType | 是 | Integer | 仓库归属 |
| warehouseContactName | 是 | String | 联系人姓名 |
| contactTelephone | 是 | String | 联系人电话 |
| state | 是 | String | 省 |
| city | 是 | String | 市 |
| region | 是 | String | 区 |
| shippingAddress | 是 | String | 装运地址 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的仓库ID（唯一标识) |

### 更新仓库

更新仓库信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/warehouse/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 仓库ID |

### 删除仓库

删除仓库。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/warehouse/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的仓库ID |

### 获取仓库信息

获取指定仓库的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/warehouse/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的仓库ID |

### 获取仓库明细接口描述

获取仓库明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/warehouseDetail/description`

### 创建仓库明细

创建仓库明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/warehouseDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productId | 是 | Long | 产品名称 |
| warehouseId | 是 | Long | 仓库名称 |
| quantity | 是 | Long | 数量 |
| safetyMinQty | 是 | Long | 安全库存下限 |
| safetyMaxQty | 是 | Long | 安全库存上限 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的仓库明细ID（唯一标识) |

### 更新仓库明细

更新仓库明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/warehouseDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 仓库明细ID |

### 删除仓库明细

删除仓库明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/warehouseDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的仓库明细ID |

### 获取仓库明细信息

获取指定仓库明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/warehouseDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的仓库明细ID |

### 获取入库单接口描述

获取入库单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockIn/description`

### 创建入库单

创建入库单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockIn`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| warehouseId | 是 | Long | 仓库名称 |
| status | 是 | Integer | 状态 |
| type | 是 | Integer | 入库类型 |
| operator | 是 | Long | 操作人 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的入库单ID（唯一标识) |

### 更新入库单

更新入库单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockIn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 入库单ID |

### 删除入库单

删除入库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockIn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的入库单ID |

### 获取入库单信息

获取指定入库单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockIn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的入库单ID |

### 确认入库

确认入库。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockIn/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的入库单ID |

### 获取入库单明细接口描述

获取入库单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockInDetail/description`

### 创建入库单明细

创建入库单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockInDetail`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的入库单明细ID（唯一标识) |

### 更新入库单明细

更新入库单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockInDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 入库单明细ID |

### 删除入库单明细

删除入库单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockInDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的入库单明细ID |

### 获取入库单明细信息

获取指定入库单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockInDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的入库单明细ID |

### 获取出库单接口描述

获取出库单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockOut/description`

### 创建出库单

创建出库单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockOut`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| warehouseId | 是 | Long | 仓库名称 |
| type | 是 | Integer | 出库类型 |
| receivingAddress | 是 | String | 接收地址 |
| contactName | 是 | String | 收货人 |
| returnedBy | 是 | Long | 领料人员 |
| operator | 是 | Long | 操作人 |
| operatedOn | 是 | Long | 操作时间 |
| export | 是 | Integer | 是否出境 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的出库单ID（唯一标识) |

### 更新出库单

更新出库单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockOut/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 出库单ID |

### 删除出库单

删除出库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockOut/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的出库单ID |

### 获取出库单信息

获取指定出库单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockOut/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的出库单ID |

### 确认出库

确认出库。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockOut/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的出库单ID |

### 获取出库单明细接口描述

获取出库单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockOutDetail/description`

### 创建出库单明细

创建出库单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockOutDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| stockOutId | 是 | Long | 出库单编号 |
| warehouseId | 是 | Long | 仓库名称 |
| productId | 是 | Long | 产品名称 |
| quantity | 是 | Long | 出库数量 |
| unit | 是 | String | 单位 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的出库单明细ID（唯一标识) |

### 更新出库单明细

更新出库单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockOutDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 出库单明细ID |

### 删除出库单明细

删除出库单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockOutDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的出库单明细ID |

### 获取出库单明细信息

获取指定出库单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockOutDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的出库单明细ID |

### 获取移库单接口描述

获取移库单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockTransfer/description`

### 创建移库单

创建移库单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockTransfer`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fromWarehouse | 是 | Long | 移除仓库 |
| toWarehouse | 是 | Long | 移入仓库 |
| status | 是 | Integer | 状态 |
| operator | 是 | Long | 操作人 |
| operatedOn | 是 | Long | 操作时间 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的移库单ID（唯一标识) |

### 更新移库单

更新移库单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 移库单ID |

### 删除移库单

删除移库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的移库单ID |

### 获取移库单信息

获取指定移库单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的移库单ID |

### 确认移库

确认移库。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTransfer/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的移库单ID |

### 获取移库单明细接口描述

获取移库单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockTransfer/description`

### 创建移库单明细

创建移库单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/stockTransferDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productId | 是 | Long | 产品名称 |
| stockTransferNo | 是 | Long | 移库单编号 |
| unit | 是 | String | 单位 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的移库单明细ID（唯一标识) |

### 更新移库单明细

更新移库单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/stockTransferDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 移库单明细ID |

### 删除移库单明细

删除移库单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/stockTransferDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的移库单明细ID |

### 获取移库单明细信息

获取指定移库单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/stockTransferDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的移库单明细ID |

### 获取盘库单接口描述

获取盘库单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/description`

### 创建盘库单

创建盘库单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| warehouseName | 是 | Long | 仓库ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单ID |

### 批量创建盘库单

批量创建盘库单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| warehouseName | 是 | Long | 仓库ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单ID |

### 更新盘库单

更新指定盘库单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量更新盘库单

批量更新指定盘库单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 锁定盘库单

锁定指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量锁定盘库单

批量锁定指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/locks/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 解锁盘库单

解锁指定盘库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量解锁盘库单

批量解锁指定盘库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/locks/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 删除盘库单

删除指定盘库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量删除盘库单

批量删除指定盘库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 获取盘库单信息

查看指定盘库单详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量获取盘库单信息

批量查看指定盘库单详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/batch/ids`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 关注盘库单

关注指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量关注盘库单

批量关注指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/follows/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 取消关注盘库单

取消关注指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量取消关注盘库单

批量取消关注指定盘库单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/follows/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 转移盘库单

转移指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 批量转移盘库单

批量转移指定盘库单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/transfers/{targetUserId}/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 开始盘库

更新盘库单状态为盘点中，并记录开始盘库时间、盘库人等。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/startStockTaking/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 结束盘库

更新盘库单状态为盘点完成，并记录结束盘库时间、是否一致等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/completeStockTaking/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 确认调整

更新盘库单状态为已调整，并根据差异，生成对应的入库单或出库单，调整仓库的库存明细与实际一致。当盘库单状态不是盘点完成或盘库单不存在差异时，确认调整按钮不会显示。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/confirm/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 检查账面数量

检查盘库单明细账面数量和仓库明细数量是否一致。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/checkBookQuantity/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 修改账面数量

修改盘库单明细的账面数量和仓库明细数量保持一致。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/actions/updateBookQuantity/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单ID |

### 创建盘库单主子明细

盘库单主子明细保存接口。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| master | 是 | Object | 主记录盘库单数据对象 |
| details | 否 | Array | 子记录盘库单明细数据对象 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单明细ID |

### 更新盘库单主子明细

盘库单主子明细保存接口。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| master | 是 | Object | 主记录盘库单数据对象 |
| details | 否 | Array | 子记录盘库单明细数据对象 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 盘库单明细ID |

### 获取盘库单明细描述

获取盘库单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/description`

### 创建盘库单明细

创建盘库单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| productName | 是 | Long | 产品ID |
| bookQuantity | 是 | Integer | 账面数量 |
| countedQuantity | 是 | Integer | 盘点数量 |
| stockTaking | 是 | Long | 盘库单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单明细ID |

### 批量创建盘库单明细

批量创建盘库单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| productName | 是 | Long | 产品ID |
| bookQuantity | 是 | Integer | 账面数量 |
| countedQuantity | 是 | Integer | 盘点数量 |
| stockTaking | 是 | Long | 盘库单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单明细ID |

### 更新盘库单明细

更新指定盘库单明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 批量更新盘库单明细

更新指定盘库单明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 删除盘库单明细

删除指定盘库单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 批量删除盘库单明细

批量删除指定盘库单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 获取盘库单明细信息

查看指定盘库单明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 批量获取盘库单明细信息

查看指定盘库单明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/actions/batch/ids`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 盘库单明细ID |

### 创建盘库单明细主子明细

盘库单明细主子明细保存接口。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTakingDetail/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| master | 是 | Object | 主记录盘库单数据对象 |
| details | 否 | 数组 | 子记录盘库单明细数据对象 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单明细ID |

### 更新盘库单明细主子明细

盘库单主子明细保存接口。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/stockTaking/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| master | 是 | Object | 主记录盘库单数据对象 |
| details | 否 | 数组 | 子记录盘库单明细数据对象 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的盘库单明细ID |

### 获取个人库物料转移接口描述

获取个人库物料转移对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/description`

### 创建个人库物料转移

创建个人库物料转移。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| fromPersonalWarehouse | 是 | Long | 发送员工个人库 |
| toPersonalWarehouse | 是 | Long | 接收员工个人库 |
| fromPersonalWarehouseDetail | 是 | Long | 发送员工个人库明细 |
| transferQuantity | 是 | Integer | 转移数量 |
| reason | 否 | String | 理由 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的个人库物料转移ID |

### 更新个人库物料转移

更新指定个人库物料转移。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 删除个人库物料转移

删除指定个人库物料转移。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 获取个人库物料转移信息

查看指定个人库物料转移详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 锁定个人库物料转移

锁定指定个人库物料转移。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 解锁个人库物料转移

解锁指定个人库物料转移。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 关注个人库物料转移

关注指定个人库物料转移。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 取消关注个人库物料转移

取消关注指定个人库物料转移。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 转移个人库物料转移

转移指定个人库物料转移详细信息。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 接收个人库物料转移

接收指定个人库物料转移。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/accept`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 拒绝个人库物料转移

拒绝指定个人库物料转移。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/refuse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 批量接收个人库物料转移

批量接收指定个人库物料转移。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/acceptBatch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 批量拒绝个人库物料转移

批量拒绝指定个人库物料转移。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalMaterialTransfer/actions/refuseBatch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人库物料转移ID |

### 获取领料单接口描述

获取领料单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialRequisition/description`

### 创建领料单

创建领料单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialRequisition`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| workOrderNo | 是 | Long | 派工单主题 |
| comment | 是 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的领料单ID（唯一标识) |

### 更新领料单

更新领料单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/materialRequisition/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单ID |

### 删除领料单

删除领料单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/materialRequisition/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的领料单ID |

### 获取领料单信息

获取指定领料单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialRequisition/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的领料单ID |

### 领料全流程

领料全流程，自动创建领料单、领料单明细，自动确认领料，自动创建出库单、出库单明细，自动确认出库，自动更新仓库明细库存信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialRequisition/actions/materialRequisitionWholeProcess`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| warehouseId | 是 | Long | 仓库ID |
| warehouseStaff | 是 | Long | 库管 |
| requisitionOrg | 是 | Integer | 人员部门 |
| telephone | 是 | String | 领料人员电话 |
| requisitionedBy | 是 | Long | 领料人员 |
| requisitionedOn | 是 | Long | 领料时间 |
| planRequisitionOn | 是 | Long | 计划领料时间 |
| status | 是 | Integer | 状态1：新建:2：已领料3：已拒绝 |
| depotRepair | 是 | Long | 返修单主题 |
| ownerId | 是 | Long | 所有人 |
| comment | 是 | String | 备注 |
| entityType | 是 | Long | 业务类型 |
| unit | 是 | String | 单位 |
| quantity | 是 | Integer | 数量 |
| warehouseId | 是 | Long | 仓库ID |
| comment | 是 | String | 备注 |

### 确认领料

确认领料。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialRequisition/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的领料单ID |

### 冻结库存

员工预领料时，需要冻结仓库的库存，防止被挪作他用。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialRequisition/actions/freeze/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据ID |

### 取消冻结

员工领料冻结后，可以根据需要通过“取消冻结”释放冻结的库存。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialRequisition/actions/unfreeze/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据ID |

### 确认出库

领料单确认领料流程包含两个步骤：确认出库、确认接收。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialRequisition/actions/confirmOut/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据ID |

### 确认接收

领料单确认领料流程包含两个步骤：确认出库、确认接收。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialRequisition/actions/confirmReceive/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据ID |

### 获取领料单明细接口描述

获取领料单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialRequisitionDetail/description`

### 创建领料单明细

创建领料单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialRequisitionDetail`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | Long | 新创建的领料单明细ID（唯一标识) |

### 更新领料单明细

更新领料单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/materialRequisitionDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单明细ID |

### 删除领料单明细

删除领料单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/materialRequisitionDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的领料单明细ID |

### 获取领料单明细信息

获取指定领料单明细的信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/materialRequisitionDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的领料单明细ID |

### 获取退料单接口描述

获取退料单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialReturn/description`

### 创建退料单

创建退料单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialReturn`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | long | 新创建的退料单ID（唯一标识) |

### 更新退料单

更新退料单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/materialReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 退料单ID |

### 删除退料单

删除退料单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/materialReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的退料单ID |

### 获取退料单信息

获取指定退料单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的退料单ID |

### 确认退料

确认退料。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialReturn/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的退料单ID |

### 退料全流程

退料全流程，自动创建退料单、退料单明细，自动确认退料，自动创建入库单、入库单明细，自动确认入库，自动更新仓库明细库存信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialReturn/actions/materialReturnWholeProcess`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| warehouseId | 是 | Long | 仓库ID |
| warehouseStaff | 是 | Long | 库管 |
| returnOrg | 是 | Integer | 人员部门 |
| telephone | 是 | String | 退料人员电话 |
| returnedBy | 是 | Long | 退料人员 |
| returnedOn | 是 | Long | 退料时间 |
| status | 是 | Integer | 状态1：新建2：已退料3：已拒绝 |
| depotRepair | 是 | Long | 返修单主题 |
| ownerId | 是 | Long | 所有人 |
| comment | 是 | String | 备注 |
| entityType | 是 | Long | 业务类型 |
| unit | 是 | String | 单位 |
| quantity | 是 | Integer | 数量 |
| warehouseId | 是 | Long | 仓库ID |
| comment | 是 | String | 备注 |

### 获取退料单明细接口描述

获取退料单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialReturnDetail/description`

### 创建退料单明细

创建退料单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/materialReturnDetail`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | Long | 新创建的退料单明细ID（唯一标识) |

### 更新退料单明细

更新退料单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/materialReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 退料单明细ID |

### 删除退料单明细

删除退料单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/materialReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的退料单明细ID |

### 获取退料单明细信息

获取指定退料单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/materialReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的退料单明细ID |

### 撤销入库

已入库的入库单支持执行“撤销入库”操作。如果入库单存在关联单据（如退料单字段不为空），需要从关联的退料单发起撤销操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockIn/actions/reverse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 入库单数据 ID |

### 撤销出库

已出库的出库单支持执行“撤销出库”操作。如果出库单存在关联单据（如领料单字段不为空），需要从关联的领料单发起撤销操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockOut/actions/reverse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 入库单数据 ID |

### 撤销移库

已完成的移库单支持执行“撤销移库”操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/stockTransfer/actions/reverse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 入库单数据 ID |

### 撤销领料

已出库或已领料的领料单支持执行“撤销领料”操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/materialRequisition/actions/reverse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据 ID |

### 撤销退料

个人库已出库或已退料的退料单支持执行“撤销退料”操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/materialReturn/actions/reverse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 领料单数据 ID |

### 获取采购退货接口描述

获取采购退货对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/description`

### 创建采购退货

创建采购退货。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| purchaseOrder | 否 | Long | 采购订单名称 |
| returnWarehouse | 否 | Long | 退货仓库 |
| vendorId | 是 | Long | 供应商名称 |
| vendorContact | 否 | String | 供应商联系人 |
| vendorContactTel | 否 | String | 供应商联系电话 |
| state | 否 | Integer | 省 |
| city | 否 | Integer | 市 |
| region | 否 | Integer | 区 |
| address | 否 | String | 地址 |
| reason | 否 | String | 退货原因 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的采购退货ID |

### 批量创建采购退货

批量创建采购退货。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| purchaseOrder | 否 | Long | 采购订单名称 |
| returnWarehouse | 否 | Long | 退货仓库 |
| vendorId | 是 | Long | 供应商名称 |
| vendorContact | 否 | String | 供应商联系人 |
| vendorContactTel | 否 | String | 供应商联系电话 |
| state | 否 | Integer | 省 |
| city | 否 | Integer | 市 |
| region | 否 | Integer | 区 |
| address | 否 | String | 地址 |
| reason | 否 | String | 退货原因 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的采购退货ID |

### 更新采购退货

更新指定采购退货。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量更新采购退货

更新指定采购退货。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的发运单ID |

### 删除采购退货

删除指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的发运单ID |

### 批量删除采购退货

批量删除指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 获取采购退货信息

查看指定采购退货详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量获取采购退货信息

查看指定采购退货详细信息。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/batch/ids`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 锁定采购退货

锁定指定采购退货。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量锁定采购退货

批量锁定指定采购退货。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 解锁采购退货

解锁指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量解锁采购退货

批量解锁指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/locks/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 关注采购退货

关注指定采购退货。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量关注采购退货

批量关注指定采购退货。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 取消关注采购退货

取消关注指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 批量取消关注采购退货

批量取消关注指定采购退货。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/follows/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 转移采购退货

转移指定采购退货详细信息。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 确认生效采购退货

确认生效采购退货。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/confirm`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 作废采购退货

作废指定采购退货。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturn/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货ID |

### 获取采购退货明细接口描述

获取采购退货明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/description`

### 创建采购退货明细

创建采购退货明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| purchaseReturnNo | 是 | Long | 采购订单 |
| productId | 是 | Long | 产品名称 |
| quantity | 是 | Long | 退货数量 |
| unitPrice | 是 | Real | 采购单价 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的采购退货明细ID |

### 批量创建采购退货明细

批量创建采购退货明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | Long | 新创建的采购退货明细ID |

### 更新采购退货明细

更新指定采购退货明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 批量更新采购退货明细

更新指定采购退货明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 删除采购退货明细

删除指定采购退货明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 批量删除采购退货明细

批量删除指定采购退货明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 获取采购退货明细信息

查看指定采购退货明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 批量获取采购退货明细信息

查看指定采购退货明细详细信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseReturnDetail/actions/batch/ids`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购退货明细ID |

### 获取发运单接口描述

获取发运单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/description`

### 创建发运单

创建发运单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| shipFromInv | 否 | Long | 发运仓库 |
| shipFromAddr | 是 | String | 发运地址 |
| shipTo | 否 | Long | 收货客户 |
| shipToInv | 否 | Long | 收货仓库 |
| shipToAddr | 是 | String | 收货地址 |
| receiver | 是 | String | 收货人 |
| receiverMobile | 是 | String | 收货人电话 |
| planShipOn | 否 | Long | 计划发运时间 |
| shipCarrier | 否 | Integer | 承运商 |
| wayBillNo | 否 | String | 物流编号 |
| shipVia | 否 | Integer | 运输方式 |
| expectArrivalDate | 否 | Long | 预计到达日期 |
| export | 否 | Integer | 是否出境 |
| shippingOn | 否 | Long | 发运时间 |
| shippedMobile | 否 | String | 发运人电话 |
| dimPart | 否 | Long | 所属部门 |
| description | 否 | String | 描述 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的发运单ID（唯一标识) |

### 更新发运单

更新发运单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| shipFromInv | 否 | Long | 发运仓库 |
| shipFromAddr | 是 | String | 发运地址 |
| shipTo | 否 | Long | 收货客户 |
| shipToInv | 否 | Long | 收货仓库 |
| shipToAddr | 是 | String | 收货地址 |
| receiver | 是 | String | 收货人 |
| receiverMobile | 是 | String | 收货人电话 |
| planShipOn | 否 | Long | 计划发运时间 |
| shipCarrier | 否 | Integer | 承运商 |
| wayBillNo | 否 | String | 物流编号 |
| shipVia | 否 | Integer | 运输方式 |
| expectArrivalDate | 否 | Long | 预计到达日期 |
| export | 否 | Integer | 是否出境 |
| shippingOn | 否 | Long | 发运时间 |
| shippedMobile | 否 | String | 发运人电话 |
| dimPart | 否 | Long | 所属部门 |
| description | 否 | String | 描述 |

### 锁定发运单

锁定发运单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 发运单ID |

### 解锁发运单

解锁发运单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 发运单ID |

### 删除发运单

删除发运单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的发运单ID |

### 获取发运单信息

获取指定发运单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的发运单ID |

### 确认发运

确认发运。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/actions/confirmShip`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认的发运单ID |

### 确认出库并发运

发运单确认出库并发运。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNote/actions/stockOutAndConfirmShip`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认出库并发运的发运单ID |

### 获取发运单明细接口描述

获取发运单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNoteDetail/description`

### 创建发运单明细

创建发运单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNoteDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productName | 是 | Long | 产品 |
| quantity | 否 | Double | 数量 |
| shippingNo | 是 | Long | 发运单编号 |
| comments | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的发运单明细ID（唯一标识) |

### 更新发运单明细

更新发运单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productName | 是 | Long | 产品 |
| quantity | 否 | Double | 数量 |
| shippingNo | 否 | Long | 发运单编号 |
| comments | 否 | String | 备注 |

### 删除发运单明细

删除发运单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的发运单明细ID |

### 获取发运单明细信息

获取指定发运单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/dispatchNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的发运单明细ID |

### 获取装箱单接口描述

获取装箱单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/packingList/description`

### 创建装箱单

创建装箱单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/packingLIst`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| shippingNo | 是 | Long | 发运单编号 |
| status | 是 | Integer | 状态（默认为新建）1：新建2：已装箱3：验货中4：验货完成 |
| length | 否 | Double | 长度 |
| width | 否 | Double | 宽度 |
| height | 否 | Double | 高度 |
| netWeight | 否 | Double | 净重 |
| grossWeight | 否 | Double | 毛重 |
| packingType | 否 | Integer | 包装类别（纸箱、木箱、托盘、集装箱、卡车） |
| packingPciture | 否 | Array | 装箱照片 |
| examinResult | 否 | Integer | 验货结果 |
| examineComments | 否 | String | 验货备注 |
| comments | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的装箱单ID（唯一标识) |

### 更新装箱单

更新装箱单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/packingList/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| height | 否 | Double | 高度 |
| netWeight | 否 | Double | 净重 |
| grossWeight | 否 | Double | 毛重 |
| packingType | 否 | Integer | 包装类别（纸箱、木箱、托盘、集装箱、卡车） |
| packingPciture | 否 | Array | 装箱照片 |
| examinResult | 否 | Integer | 验货结果 |
| examineComments | 否 | String | 验货备注 |
| comments | 否 | String | 备注 |

### 删除装箱单

删除装箱单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/packingList/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的装箱单ID |

### 获取装箱单信息

获取指定装箱单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/packingList/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的装箱单ID |

### 确认装箱/取消装箱

确认或者取消装箱。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/packingList/actions/changePac`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要确认或者取消的装箱单ID |

### 开箱验货

装箱单开箱验货。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/packingList/actions/packingCheck`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要开箱验货的装箱单ID |

### 完成验货

完成验货。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/packingList/actions/confirmExamine`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 完成验货的装箱单ID |
| examineStatus | 否 | Integer | 验货结果 |
| examineComments | 否 | String | 验货说明 |

### 获取装箱单明细接口描述

获取装箱单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/packingListDetail/description`

### 创建装箱单明细

创建装箱单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/packingListDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productName | 是 | Long | 产品 |
| netWeight | 否 | Double | 净重 |
| grossWeight | 否 | Double | 毛重 |
| quantity | 否 | Double | 数量 |
| caseNo | 否 | Long | 装箱单编号 |
| comments | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的装箱单明细ID（唯一标识) |

### 更新装箱单明细

更新装箱单明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/packingListDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productName | 是 | Long | 产品 |
| netWeight | 否 | Double | 净重 |
| grossWeight | 否 | Double | 毛重 |
| quantity | 否 | Double | 数量 |
| caseNo | 否 | Long | 装箱单编号 |
| comments | 否 | String | 备注 |

### 删除装箱单明细

删除装箱单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/packingListDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的装箱单明细ID |

### 获取装箱单明细信息

获取指定装箱单明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/packingListDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的装箱单明细ID |

### 获取接收接口描述

获取接收对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/description`

### 创建接收

创建接收。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| receivedInventory | 是 | Long | 接收仓库ID |
| receivedAddress | 是 | String | 接收地址 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的接收ID（唯一标识) |

### 更新接收

更新接收信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要更新的接收ID |

### 锁定接收

锁定指定接收。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要锁定的接收ID |

### 解锁接收

解锁指定接收。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的接收ID |

### 删除接收

删除接收。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的接收ID |

### 获取接收信息

获取指定接收的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/receiveNote/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的接收ID |

### 获取接收明细接口描述

获取接收明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/description`

### 创建接收明细

创建接收明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| receivingNo | 是 | Long | 接收ID |
| productId | 是 | Long | 产品ID |
| receivedQty | 是 | Long | 接收数量 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的接收明细ID（唯一标识) |

### 更新接收明细

更新接收明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要更新的接收明细ID |

### 锁定接收明细

锁定指定接收明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要锁定的接收明细ID |

### 解锁接收明细

解锁指定接收明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的接收明细ID |

### 删除接收明细

删除接收明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的接收明细ID |

### 获取接收明细信息

获取指定接收明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/receiveNoteDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的接收明细ID |

### 获取派工单接口描述

获取派工单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/description`

### 创建派工单

创建派工单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 派工单主题 |
| address | 是 | String | 地址 |
| status | 是 | Integer | 状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的派工单ID（唯一标识) |

### 更新派工单

更新派工单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 派工单ID |

### 删除派工单

删除派工单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的派工单ID |

### 结束派工单

结束派工单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/finish`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fieldJobId | 是 | Long | 需要结束的派工单ID |
| finishType | 是 | Integer | 是否完成1：已完成
                0：未完成 |
| remark | 否 | String | finishType为0时必填此字段信息 |

### 取消派工单

取消派工单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fieldJobId | 是 | Long | 派工单ID |
| remark | 是 | String | 问题描述 |

### 获取派工单信息

获取指定派工单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的派工单ID |

### 获取最近的服务网点

输入批量服务网点的地理位置信息、派工单的地理位置信息，找到最近的服务网点并返回。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/getLatestSite`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| origin | 是 | String | 派工单地理位置 |
| sites | 是 | Array | 服务网点地理位置 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| site | String | 最近的服务网点 |
| distance | Double | 距离 |

### 查询派工池

查询后台设置派工池数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/queryPoolsByStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| status | 是 | Integer | 派工池状态 |
|  |  |  | 0：全部 |
|  |  |  | 1：禁用 |
|  |  |  | 2：启用 |

### 分配派工单

完成派工单分配功能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/assign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| keepOwnerAsGroupMember | 是 | Integer | 负责人是否保留为团队成员：0：否1：是默认值为0 |
| targetId | 是 | Long | 转移目标ID |
| isFromMap | 否 | Integer | 是否从地图页面发起：0：否1：是默认值为0 |
| isConfirm | 否 | Integer | 用户是否已经确认，当isFromMap=1时有效：0：否1：是默认值为0 |
| fieldJobIds | 是 | List<Long> | 派工单ID集 |

### 分配派工单（多人派工模式）

在派工流程设置中，启用多人派工后，使用该接口分配派工单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/fieldJob/actions/changeServiceTeamMember`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fieldJobIdList | 是 | List<Long> | 派工单ID集 |
| serviceTeamList | 是 | List<JSONObject> | 工程师数据集 |
| userId | 是 | Long | 用户ID |
| teamRole | 是 | Integer | 1表示负责人，2表示辅助工程师 |
| plannedStartTime | 否 | Long | 计划开始时间 |
| plannedEndTime | 否 | Long | 计划结束时间 |
| keepGroupMember | 否 | boolean | 是否保留【原工程师】为团队成员，默认为否 |

### 获取派工单检查项接口描述

获取派工单检查项对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/fieldJobCheckItem/description`

### 创建派工单检查项

创建派工单检查项。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/fieldJobCheckItem`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fieldJobId | 是 | Long | 派工单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的派工单检查项ID（唯一标识) |

### 更新派工单检查项

更新派工单检查项信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/fieldJobCheckItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 派工单检查项ID |

### 删除派工单检查项

删除派工单检查项。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/fieldJobCheckItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的派工单检查项ID |

### 获取派工单检查项信息

获取指定派工单检查项的信息。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/fieldJobCheckItem/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的派工单检查项ID |

### 获取返修单接口描述

获取返修单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/description`

### 创建返修单

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 返修单主题 |
| faultDescription | 是 | String | 故障描述 |
| priority | 是 | Integer | 优先级1：最高2：高3：中4：低 |
| depotAccountName | 是 | Long | 客户名称 |
| productName | 是 | Long | 产品名称 |
| dispatchMethod | 是 | Integer | 分配方式
                1：系统自动分配
                2：指定分配 |
| underGuaranteeStatus | 是 | Integer | 在保状态1：保内
                2：保外 |
| ownerId | 是 | Long | 所有人 |
| status | 是 | Long | 状态1：待分配2：待处理3：处理中4：已取消5：已完成6：已暂停7：未完成 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的返修单ID（唯一标识) |
| objectApiKey | String | apiKey |
| busiType | Long | 业务类型 |

### 更新返修单

更新指定返修单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |

### 删除返修单

删除指定返修单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的返修单ID |

### 获取返修单信息

获取指定返修单详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的返修单ID |

### 分配返修单

分配单个返修单至指定的 owner。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/assign`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |
| targetId | 是 | Long | 需要分配给的用户ID |
| keepOwnerAsGroupMember | 否 | Integer | 是否保存当前所有人至团队成员0：否1：是如果该参数未传值则默认为1 |

### 取消返修单

取消返修单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/cancel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |
| endComments | 否 | String | 备注 |

### 开始维修

开始维修返修单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/startRepair`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |

### 暂停/恢复

暂停、恢复返修单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/pauseOrResume`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |

### 结束维修

结束维修返修单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/finish`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返修单ID |
| isFinished | 是 | Integer | 是否完成0：未完成
                1：已完成 |
| remark | 否 | String | 备注 |

### 类似于页面弹出picker

类似于页面弹出 picker。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/lookupSearchCustomizForFsc`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| referObjectId | 是 | Long | 关联对象ID |

### 从维修项模板添加维修项记录

从维修项模板添加维修项记录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/addFromTemplate`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| depotRepairId | 是 | Long | 返修单ID |
| templateId | 是 | Integer | 维修项模板ID |

### 安装

安装。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/install`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| depotRepairId | 是 | Long | 返修单 ID |
| personalWarehouseDetailId | 否 | Long | 个人备件库明细 ID（未开启个人备件库不传） |
| warehouseDetailId | 否 | Long | 仓库明细 ID（开启个人备件库不传） |
| quantity | 否 | String | 数量 |
| confirmAsset | 否 | Integer | 确认使用资产（1：是） |
| warehouseId | 否 | Long | 仓库 ID（开启个人备件库不传） |
| newAssetSn | 否 | Long | 新件序列号（备件情况不传） |
| partOrWhole | 是 | Integer | 备件/整机（1/2) |

### 替换

结束维修返修单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/depotRepair/actions/replace`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| depotRepairId | 是 | Long | 返修单 ID |
| personalWarehouseDetailId | 否 | Long | 个人备件库明细 ID（未开启个人备件库不传） |
| warehouseDetailId | 否 | Long | 仓库明细 ID（开启个人备件库不传） |
| quantity | 否 | Integer | 新件数量 |
| replacedQuantity | 否 | Integer | 旧件数量 |
| replacedProductId | 否 | Long | 旧产品 ID |
| confirmAsset | 否 | Integer | 确认使用资产（1：是） |
| warehouseId | 否 | Long | 仓库 ID（开启个人备件库不传） |
| newAssetSn | 否 | Long | 新件序列号（备件情况不传） |
| partOrWhole | 是 | Integer | 备件/整机（1/2） |
| defectiveWarehouseId | 否 | Long | 坏件仓库 ID，开启个人备件库不传 |
| replacedAssetSn | 否 | Long | 旧件序列号（可为空）备件情况不传 |

### 获取收费接口描述

获取收费对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/charge/description`

### 创建收费

创建收费。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/charge`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| status | 是 | Integer | 状态 |
| totalAmount | 是 | Float | 总金额 |
| price | 是 | Long | 价格表 |
| fieldJobId | 是 | Long | 派工单 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的收费ID（唯一标识) |

### 更新收费

更新收费信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/charge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 收费ID |

### 删除收费

删除收费。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/charge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的收费ID |

### 获取收费信息

获取指定收费的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/charge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的收费ID |

### 获取收费明细接口描述

获取收费明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/chargeDetail/description`

### 创建收费明细

创建收费明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/chargeDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| guaranteeStatus | 是 | Integer | 在保状态，默认值为1 |
| priceTotal | 是 | Float | 总价 |
| discount | 是 | Float | 折扣 |
| quantity | 是 | Long | 数量 |
| servicePrice | 是 | Float | 服务价格 |
| productName | 是 | Long | 产品名称 |
| productId | 是 | Long | 产品编码 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的收费明细ID（唯一标识) |

### 更新收费明细

更新收费明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/chargeDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 收费明细ID |

### 删除收费明细

删除收费明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/chargeDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的收费明细ID |

### 获取收费明细信息

获取指定收费明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/chargeDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的收费明细ID |

### 获取访客接口描述

获取访客对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitor/description`

### 创建访客

创建访客。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitor`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 |
| dimDepart | 是 | Long | 所属部门 |
| identificationState | 否 | Integer | 客户识别状态1：未识别2：识别出一个3：识别出多个 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的访客ID（唯一标识） |

### 更新访客

更新指定访客。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitor/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 访客ID |

### 获取访客信息

查看指定访客详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitor/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的访客ID |

### 获取客户评价接口描述

获取客户评价对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/evaluation/description`

### 删除客户评价

删除客户评价。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/evaluation/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的客户评价ID |

### 获取客户评价信息

获取指定客户评价的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/evaluation/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的客户评价ID |

### 获取客户评价数据

获取客户评价数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/evaluation/actions/queryEvaluationInfo`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 对象数据ID |
| relationEntityId | 是 | Long | 对象编号（例如，458,556,501） |
| relationBusiTypeId | 是 | Long | 对象数据的业务类型ID |
| sourceChannel | 是 | String | 来源渠道1：扫码评价2：电话回访3：微信评价 |

### 提交客户评价数据

提交客户评价数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/evaluation/actions/submitEvaluateData`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dataId | 是 | Long | 对象数据ID |
| relationEntityId | 是 | Long | 对象编号（例如，458,556,501） |
| relationBusiTypeId | 是 | Long | 对象数据的业务类型ID |
| evaluateItemId | 是 | String | 评价项ID，多个评价项ID以英文逗号隔开 |
| starCount | 是 | String | 星级数，多个星级数以英文逗号隔开 |
| selectedStarTags | 否 | String | 多个评价项以英文逗号隔开，同一评价项的多个标签以英文竖线符号隔开 |
| comprehensiveScore | 是 | Integer | 综合评分 |
| comprehensiveEvaluation | 是 | String | 综合评价 |
| evaluationTemplate | 是 | String | 评价模板，需要从“获取客户评价数据”接口中获取 |
| sourceChannel | 是 | String | 来源渠道1：扫码评价2：电话回访3：微信评价 |
| feedback | 否 | String | 意见反馈 |

### 获取评价项接口描述

获取评价项对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/evaluationDetail/description`

### 删除评价项

删除评价项。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/evaluationDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的评价项ID |

### 获取评价项信息

获取指定评价项的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/evaluationDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的评价项ID |

### 获取评价接口描述

获取评价对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEvaluation/description`

### 获取评价信息

查看指定评价详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEvaluation/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的评价ID |

### 获取维保计划接口描述

获取维保计划对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/preventiveMaintenance/description`

### 创建维保计划

创建维保计划。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/preventiveMaintenance`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 计划名称 |
| status | 是 | Integer | 1：新建2：已发布3：已失效 |
| startTime | 是 | Long | 开始时间（时间戳） |
| generateType | 是 | Integer | 1：自动生成2：手动生成 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的维保计划 ID（唯一标识) |

### 更新维保计划

更新维保计划信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/preventiveMaintenance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 维保计划ID |

### 删除维保计划

删除维保计划。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/preventiveMaintenance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的维保计划ID |

### 获取维保计划信息

获取指定维保计划的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/preventiveMaintenance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的维保计划ID |

### 获取维保计划明细接口描述

获取维保计划明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/preventiveMaintenanceDetail/description`

### 创建维保计划明细

创建维保计划明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/preventiveMaintenanceDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pmId | 否 | Long | 维保计划ID |
| assetNo | 否 | Long | 资产编号 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的维保计划明细ID（唯一标识) |

### 更新维保计划明细

更新维保计划明细信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 维保计划明细ID |

### 删除维保计划明细

删除维保计划明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的维保计划明细ID |

### 获取维保计划明细信息

获取指定维保计划明细的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/preventiveMaintenanceDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的维保计划明细ID |

### 获取服务项目接口描述

获取服务项目对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceProject/description`

### 创建服务项目

创建服务项目。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/serviceProject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 服务项目的名称 |
| priority | 是 | Integer | 优先级1：最高2：高3：中4：低 |
| status | 是 | Integer | 状态1：新建2：进行中3：已完成 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的服务项目ID（唯一标识) |

### 更新服务项目

更新服务项目信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/serviceProject/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务项目ID |

### 删除服务项目

删除服务项目。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/serviceProject/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的服务项目ID |

### 获取服务项目信息

获取指定服务项目的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceProject/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的服务项目ID |

### 获取服务阶段接口描述

获取服务阶段对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceStage/description`

### 创建服务阶段

创建服务阶段。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/serviceStage`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 服务阶段的名称 |
| serviceProjectId | 是 | Long | 服务项目的ID |
| status | 是 | Integer | 状态1：新建2：进行中3：已完成 |

### 更新服务阶段

更新服务阶段信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/serviceStage/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务阶段ID |

### 删除服务阶段

删除服务阶段。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/serviceStage/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的服务阶段ID |

### 获取服务阶段信息

获取指定服务阶段的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceStage/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的服务阶段ID |

### 获取服务任务接口描述

获取服务任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceTask/description`

### 创建服务任务

创建服务任务。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/objects/serviceTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| serviceStageId | 是 | Long | 服务阶段的ID |
| priority | 是 | Integer | 优先级1：最高2：高3：中4：低 |
| positionNo | 是 | Integer | 顺序位 |
| status | 是 | Integer | 状态1：待处理2：处理中3：已完成 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的服务任务 ID（唯一标识) |

### 更新服务任务

更新服务任务信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2/objects/serviceTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务任务ID |

### 删除服务任务

删除服务任务。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2/objects/serviceTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的服务任务ID |

### 获取服务任务信息

获取指定服务任务的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2/objects/serviceTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的服务任务ID |

### 获取服务工单接口描述

获取服务工单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceCase/description`

### 创建服务工单

创建服务工单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceCase`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| name | 是 | String | 工单主题 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的服务工单ID（唯一标识) |

### 更新服务工单

更新服务工单信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceCase/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务工单ID |

### 删除服务工单

删除服务工单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceCase/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的服务工单ID |

### 获取服务工单信息

获取指定服务工单的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceCase/{id}`

### 获取服务邮件接口描述

获取服务邮件对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/description`

### 更新服务邮件

更新指定服务邮件。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件ID |

### 锁定服务邮件

锁定服务邮件。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件ID |

### 解锁服务邮件

解锁服务邮件。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件ID |

### 删除服务邮件

删除指定服务邮件。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件ID |

### 获取服务邮件信息

查看指定服务邮件详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件ID |

### 录入服务邮件

录入服务邮件，模拟邮件接收。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/mockReceive`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| emailSource | 否 | String | 邮件源文件，如eml文件内容，此参数存在则其他邮件属性参数全部失效，邮件主题、发件人等等全部以源文件内属性为主。 |
| subject | 是 | String | 邮件主题 |
| from | 是 | String | 发件人邮箱 |
| fromName | 否 | String | 发件人名称 |
| to | 否 | String | 收件人收件人与抄送人必填其一，纯邮箱格式，多个以分号相隔，例如a1@neocrm.com;a2@neocrm.com; |
| cc | 否 | String | 抄送人收件人与抄送人必填其一，纯邮箱格式，多个以分号相隔，例如a1@neocrm.com;a2@neocrm.com; |
| bodytext | 是 | String | 邮件内容，Html格式 |
| attachs | 否 | Array | 邮件附件 |
| attachs.filename | 否 | String | 附件名称，附件存在则必填 |
| attachs.fileurl | 否 | String | 附件地址，销售易文件地址，附件存在则必填 |
| attachs.filelength | 否 | Long | 附件大小，单位字节，附件存在则必填 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | String | 邮件处理状态seen：接收成功
                                    none：无客服暂不处理
                                    delete：错误删除
                                    invalid：无效邮件
                                    blacklist：黑名单邮件 |
| serviceEmailId | Long | 服务邮件ID |
| serviceEmailDetailId | Long | 服务邮件明细ID |

### 发送服务邮件

发送服务邮件，适用于客服向访客发送邮件。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/communication/send`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| senderEmail | 是 | String | 发件人，必须为后台配置的服务邮箱 |
| senderEmailId | 否 | Long | 发件人服务邮箱 ID |
| recipients | 是 | String | 收件人，多个收件人之间使用英文分号进行分隔，例如：liming@neocrm.com;hanmeimei@neocrm.com |
| cc | 否 | String | 抄送人，多个抄送人之间使用英文分号进行分隔 |
| bcc | 否 | String | 密送人，多个密送人之间使用英文分号进行分隔 |
| emailTitle | 是 | String | 邮件主题，最大长度 300 字符 |
| emailContent | 是 | String | 邮件内容，HTML 格式 |
| attachments | 否 | List | 附件，需使用销售易文件上传的 URL 地址资源，格式请参考请求示例 |
| emailType | 否 | Integer | 邮件类型，参考服务邮件明细实体邮件类型字段选项，默认为客服发送 |
| replyId | 否 | Long | 回复的邮件明细 ID，基于哪一封服务邮件明细回复，为空则表示新建服务邮件 |
| caseId | 否 | Long | 服务工单 ID，发送的服务邮件关联到此工单下，若工单已关联服务邮件，则基于关联的服务邮件回复发送 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| serviceEmailId | Long | 服务邮件 ID |
| serviceEmailDetailId | Long | 服务邮件明细 ID |
| caseId | Long | 服务工单 ID |

### 邮件标记已读

将单封或者多封邮件标记为已读。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/communication/read`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | List | 邮件明细 ID List |

### 邮件标记未读

将单封或者多封邮件标记为未读。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/communication/unread`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
|  |  |  |  |
| ids | 是 | List | 邮件明细 ID List |

### 添加邮件黑名单

添加邮件黑名单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmail/blackList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| email | 是 | String | 黑名单邮箱地址 |
| desc | 是 | String | 添加黑名单原因 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 黑名单记录 ID |

### 获取服务邮件明细接口描述

获取服务邮件明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/description`

### 更新服务邮件明细

更新指定服务邮件明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件明细ID |

### 锁定服务邮件明细

锁定服务邮件明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件明细ID |

### 解锁服务邮件明细

解锁服务邮件明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件明细ID |

### 删除服务邮件明细

删除指定服务邮件明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件明细ID |

### 获取服务邮件明细信息

查看指定服务邮件明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 服务邮件明细ID |

### 获取服务邮件明细正文内容

获取指定服务邮件明细的邮件正文全部内容。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceEmailDetail/getEmailContent`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| emailContentId | 否 | Long | 服务邮件明细邮件内容ID，emailContentId与id两者必填其一，优先使用emailContentId |
| id | 否 | Long | 服务邮件明细ID |

### 获取知识条目接口描述

获取知识条目对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/description`

### 创建知识条目

创建知识条目。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 知识条目标题 |
| knowledgeContent | 是 | String | 知识条目内容 |
| classify | 是 | Long | 知识条目分类ID |
| dimDepart | 是 | Long | 所属部门 |
| isKnowledgeOrCatalog | 是 | Integer | 必须为0，0表示是知识条目 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的知识条目ID（唯一标识) |

### 更新知识条目

更新知识条目信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 知识条目ID |

### 删除知识条目

删除知识条目。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的知识条目ID |

### 获取知识条目信息

获取指定知识条目的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的知识条目ID |

### 创建知识条目分类

创建知识条目分类。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/actions/createCatalog`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | Long | 新创建的知识条目分类ID（唯一标识) |

### 更新知识条目分类

更新知识条目分类信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/actions/updateCatalog`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 知识条目分类ID |

### 删除知识条目分类

删除知识条目分类。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/actions/deleteCatalog`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的知识条目分类ID |

### 获取知识条目分类列表

获取指定知识条目分类列表信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceKnowledge/actions/getCatalogList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 知识条目分类ID |

### 获取语音接口描述

获取语音接口对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceCall/description`

### 创建语音

创建语音。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceCall`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 |
| dimDepart | 是 | Long | 所属部门 |
| accountId | 否 | Long | 客户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的语音ID（唯一标识) |

### 更新语音

更新语音信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceCall/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 语音ID |

### 删除语音

删除语音。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceCall/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的语音ID |

### 获取语音信息

获取指定语音的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceCall/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 语音ID |

### 获取会话接口描述

获取会话对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceChat/description`

### 创建会话

创建会话。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceChat`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 |
| dimDepart | 是 | Long | 所属部门 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的会话ID（唯一标识) |

### 更新会话

更新会话信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceChat/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 会话ID |

### 删除会话

删除会话。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/serviceChat/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的会话ID |

### 获取会话信息

获取指定会话的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceChat/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的会话ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| latestChatLog | Array | 最近100条会话记录 |
| messageType | Integer | 1：客户
                2：坐席 |
| name | String | messageType为1时表示访客名称messageType为2时表示坐席名称 |
| sTime | String | 会话产生时间戳 |
| content | String | 会话内容，文本消息时为具体会话内容，图片/文件消息值为[图片]/[文件] |
| fPath | String | 图片/文件地址，消息为图片/文件消息时有此参数 |
| fName | String | 图片/文件名称，消息为图片/文件消息时有此参数 |

### 获取互动历史接口描述

获取互动历史对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitHistory/description`

### 创建互动历史

创建互动历史。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitHistory`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| ownerId | 是 | Long | 所有人 |
| dimDepart | 是 | Long | 所属部门 |
| lastCustomerServiceType | 否 | Integer | 1：人工客服
                2：机器人 |
| channelType | 否 | Integer | 1：语音
                2：web
                3：留言
                4：app
                5：邮件
                6：微信
                7：微博
                99：其他 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的互动历史 ID（唯一标识） |

### 更新互动历史

更新互动历史信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitHistory/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 互动历史ID |

### 获取互动历史信息

获取指定互动历史的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/serviceVisitHistory/{id}`

### 查询其所在技能组

根据客服员 ID 查询其所在技能组。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/im/agentInfo/querySkillInfoByAgentId/{agentId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| agentId | 是 | Number | 客服员ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| skillType | Number | 技能组类型1：默认
                                2：自定义 |
| msg | String | 提示信息 |
| Status | Number | 0标识成功 |

### 获取技能组列表

获取系统设置 > 客服设置 > 技能组设置菜单下配置的所有技能组列表，主动邀请技能组除外。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/im/skillsetInfo/querySkillsetList`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| skillId | Long | 技能组ID |
| skillName | String | 技能组名称 |

### 获取技能组成员信息

获取系统设置 > 客服设置 > 技能组设置菜单下配置的某个技能组的成员信息。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/im/agentInfo/queryAgentInfoBySkillId/{skillId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| skillId | 是 | Long | 技能组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| tenantId | Long | 租户ID |
| id | Long | 数据ID |
| skillsetId | Long | 技能组ID |
| userId | Long | 技能组成员用户ID |
| profileId | Long | 技能组成员编号ID |

### 获取技能组成员名称

获取系统设置 > 客服设置 > 技能组设置菜单下配置的某个技能组下的成员 ID 及名称信息。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/im/agentInfo/queryAgentsBySkillId/{skillId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| skillId | 是 | Long | 技能组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| agentId | Long | 技能组成员编号 |
| agentName | String | 技能组成员姓名 |

### 获取现场人员工作时间

在指定的开始时间和结束时间区间内，根据工作时间设置和扣除的时间范围，获取现场人员可用的工作时间。

- 请求方式: `POST`
- API 地址: `/rest/sc/v1.0/timeSchedule/getAvailableWorkTime`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| workTimeId | 是 | Long | 工作时间管理 ID |
| startTime | 是 | Long | 开始时间 |
| endTime | 是 | Long | 结束时间 |
| userIdList | 是 | List<Long> | 现场人员 ID 集合 |
| deduction | 是 | List<Long> | 扣除时间范围，仅支持日程（31）和服务团队（847） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| deductWorkTime | JSONObject | 扣除的时间段，键是现场人员 ID，值是由开始时间和结束时间构成的集合 |
| scheduleWorkTime | JSONObject | 工作时间管理设置的时间段，键是现场人员 ID，值是由开始时间和结束时间构成的集合 |
| availableWorkTime | JSONObject | 可用的工作时间段，键是现场人员 ID，值是由开始时间和结束时间构成的集合 |

### 访客识别

将访客与客户、联系人、销售线索或其他实体进行绑定。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/workbench/associateAccountToVisitor/{id}/{accountContactType}/{visitorId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户/联系人/其他实体数据ID |
| accountContactType | 是 | Integer | 实体belongId，如客户是1 |
| visitorId | 是 | Long | 访客ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| statusCode | Integer | 状态值，0代表成功 |
| message | String | 状态信息 |
| data | Object | 返回的数据信息 |

### 查询客户/联系人信息

根据手机号码或客户名称或联系人名称查询联系人或者客户信息。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/workbench/queryAccountAndContact/{queryInfo}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| queryInfo | 是 | String | 查询条件 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| statusCode | Integer | 状态值，0代表正常 |
| message | String | 状态信息 |
| data | Object | 查询到的客户或联系人信息 |

### 获取用户坐席账号信息

获取当前用户配置的坐席账号信息。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/userSeatInfo/getSeatInfoByUserId/{userId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态值，200代表正常 |
| msg | String | 状态信息 |
| data | Object | 坐席账号信息 |
| userId | Long | 用户ID |
| callCenterAccount | String | 呼叫中心账号 |
| callCenterBindPhone | String | 绑定电话 |
| propertyExt | String | 额外属性 |

### 获取授权微信服务号列表

获取可用于发送微信模板消息的且已授权给销售易微信开放平台的微信服务号列表。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/weChatTemplate/getWeChatAccountList`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态值，200代表成功 |
| msg | String | 状态信息 |
| data | Object | 返回的公众号列表信息 |
| appid | String | 微信公众号appid |
| nickName | String | 微信公众号昵称 |

### 获取微信模板消息触发事件（旧）

获取微信消息模板触发事件（旧）列表。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/weChatTemplate/getWeChatTemplateEventList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| appid | 是 | String | 微信公众号appid |
| objectId | 否 | Long | 对象 objectId |
| busiTypeId | 否 | Long | 对象业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态值，200代表正常 |
| msg | String | 状态信息 |
| data | Object | 查询到的微信模板消息触发事件信息 |

### 发送微信模板消息

向微信用户发送微信模板消息。

- 请求方式: `POST`
- API 地址: `/rest/sc/v1.0/weChatTemplate/sendWeChatTemplateAsync`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| eventId | 是 | Long | 微信模板消息触发事件ID |
| dataId | 是 | Long | 数据ID |
| openIdList | 是 | Array | openId的集合 |
| content | 否 | Object | 模板消息内容 |
| templateUrl | 否 | String | 模板消息链接 |
| miniprogramInfo | 否 | Object | 模板消息跳转小程序信息 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态值，200代表正常 |
| msg | String | 状态信息 |
| data | Object | 返回数据 |

### 创建个人备件库

创建一条个人备件库数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalWarehouse`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| employeeName | 是 | Long | 员工的用户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的个人备件库ID |

### 删除个人备件库

删除一条个人备件库数据。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/personalWarehouse/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人备件库ID |

### 个人备件库明细入库

根据产品名称和库存类型判断个人备件库明细中是否已经存在对应的产品。如果不存在对应的产品，则创建一条人备件库明细数据；如果已经存在对应的产品，则增加该产品的库存数量。创建个人备件库明细成功或更新库存数量成功，都会创建个人备件出入库记录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalWarehouseDetail/actions/stockIn`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| personalWarehouse | 是 | Long | 个人备件库 ID |
| productName | 是 | Long | 产品 ID |
| inventoryType | 是 | Integer | 库存类型
                                1：好件  
                                2：坏件 |
| quantity | 是 | Long | 数量 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的个人备件库明细 ID |

### 个人备件库明细出库

根据产品名称和库存类型判断个人备件库明细中是否已经存在对应的产品。如果不存在对应的产品，则提示未找到个人备件库明细；对于已经存在的产品，如果库存数量小于出库数量，则提示库存不足，如果库存充足则扣减该产品的库存数量，同时创建个人备件出入库记录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/personalWarehouseDetail/actions/stockOut`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| personalWarehouse | 是 | Long | 个人备件库ID |
| productName | 是 | Long | 产品ID |
| inventoryType | 是 | Integer | 库存类型1：好件
                2：坏件 |
| quantity | 是 | Long | 数量 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的个人备件库明细ID |

### 删除个人备件库明细

删除一条个人备件库明细数据。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/personalWarehouseDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 个人备件库明细ID |

### 获取采购订单接口描述

获取采购订单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/description`

### 创建采购订单

创建采购订单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 采购订单名称 |
| fState | 否 | Short | 省 |
| fCity | 否 | Short | 市 |
| fDistrict | 否 | Short | 区 |
| shipAddress | 否 | String | 货运地址 |
| entityType | 是 | Long | 业务类型 |
| shippingMethod | 否 | Short | 送货方式1：陆运2：空运3：海运 |
| expectedArrivalDate | 否 | Long | 预计到货日期 |
| expectedPaymentDate | 否 | Long | 预计付款日期 |
| freight | 否 | Double | 运费 |
| orderer | 否 | String | 订货人 |
| ordererTel | 否 | String | 订货电话 |
| cancelReason | 否 | Short | 作废理由1：单据变更导致作废2：单据重复导致作废3：其他 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的采购订单 ID |

### 更新采购订单

更新指定采购订单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 删除采购订单

删除指定采购订单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 获取采购订单信息

查看指定采购订单详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 采购订单确认生效

修改采购订单的状态为已生效。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/actions/confirm/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 完成采购订单

修改采购订单的状态为已完成。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/actions/finish/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 作废采购订单

修改采购订单的状态为作废。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrder/actions/cancel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单ID |

### 获取采购订单明细接口描述

获取采购订单明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrderDetail/description`

### 创建采购订单明细

创建采购订单明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrderDetail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| purchaseOrder | 是 | String | 采购订单名称 |
| productId | 是 | Short | 产品名称 |
| unitPrice | 是 | Double | 采购单价 |
| quantity | 是 | Integer | 数量 |
| entityType | 是 | Long | 业务类型 |
| parentPurchaseOrderItem | 否 | Long | 父采购订单明细 |
| salesOrderItem | 否 | Long | 订单明细 |
| comment | 否 | String | 备注 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的采购订单明细ID |

### 更新采购订单明细

更新指定采购订单明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单明细ID |

### 删除采购订单明细

删除指定采购订单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单明细ID |

### 获取采购订单信息明细

查看指定采购订单明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/purchaseOrderDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 采购订单明细ID |

### 创建表单

创建表单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/formInstance/actions/create`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 表单名称（没有时使用表单模板名称） |
| formName | 是 | Long | 业务表单ID |
| relateEntity | 否 | Long | 关联业务实体 |
| relateEntity_data | 否 | Long | 关联业务记录 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的表单ID |
| userCase | Short | 使用场景（1：对内，2：支持外部） |
| belongId | Long | ID所属实体（对内时存在） |
| url | String | 对方业务表单的访问链接 |

### 触发对象映射规则创建目标实体数据

传入对象映射规则 ID 和源主对象实体数据 ID，根据对象映射规则中配置的对象映射和字段映射信息，创建目标对象实体数据保存到数据库。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/createObjectByMapRule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象映射规则源主对象实体apikey |
| ruleId | 是 | Long | 对象映射规则ID |
| dataId | 是 | Long | 来源实体数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Array | 新建的实体记录ID |
| objectApiKey | String | 新建的实体ApiKey |

### 触发对象映射规则查询实体数据

传入对象映射规则 ID 和源主对象实体数据 ID，根据对象映射规则中配置的对象映射和字段映射信息，组装目标对象实体数据返回给客户端。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transformObjectByMapRule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象映射规则源主对象实体apikey |
| ruleId | 是 | Long | 对象映射规则ID |
| dataId | 是 | Long | 来源实体数据ID |

### 查询对象映射规则

根据源主对象实体 apikey 和目标主对象实体 apikey 查询对象映射规则。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/queryMapRuleByTargetApiKey`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象映射规则源主对象实体apikey |
| targetApiKey | 是 | String | 对象映射规则目标主对象实体apikey |

### 根据对象映射规则转换实体数据

传入对象映射规则 ID 和需要转换的源对象实体数据 JSON，根据对象映射规则中配置的对象映射和字段映射信息，将源对象实体数据转换成目标对象实体数据返回给客户端。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transformObjectByMapRule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象映射规则源主对象实体apikey |
| ruleId | 是 | Long | 对象映射规则id |

### 获取时间表接口描述

获取时间表对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/timeSheet/description`

### 创建时间表

创建时间表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/timeSheet`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 时间表名称 |
| entityType | 是 | Long | 业务类型 |
| week | 是 | Short | 周 |
| dateRange | 是 | String | 日期范围 |
| serviceProjectId | 否 | String | 服务项目 |
| monday | 否 | Double | 周一 |
| tuesday | 否 | Double | 周二 |
| wednesday | 否 | Double | 周三 |
| thursday | 否 | Double | 周四 |
| friday | 否 | Double | 周五 |
| saturday | 否 | Double | 周六 |
| sunday | 否 | Double | 周日 |
| theBillingState | 是 | Double | 计费状态 |
| totalTime | 否 | String | 总计时间 |
| weekStartTime | 否 | Long | 开始日期 |
| weekEndTime | 否 | Long | 结束日期 |
| employeeId | 是 | Long | 员工 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的时间表ID |

### 更新时间表

更新指定的时间表。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/timeSheet/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 时间表ID |

### 删除时间表

删除时间表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/timeSheet/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 时间表ID |

### 获取时间表信息

获取指定的时间表信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/timeSheet/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 时间表ID |

### 获取质保接口描述

获取质保对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssurance/description`

### 创建质保

创建质保。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssurance`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 质保名称 |
| entityType | 是 | Long | 业务类型 |
| startDateType | 是 | Short | 起始日期类型 |
| warrantyType | 否 | Short | 类型 |
| description | 否 | String | 描述 |
| duration | 是 | Short | 时长（天） |
| coverCostOfExpense | 否 | Short | 含其他花销 |
| coverCostOfPart | 否 | Short | 含备件费 |
| coverCostOfTransportation | 否 | Short | 含运输费 |
| coverCostOfLabor | 否 | Short | 含人工费 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的质保ID |

### 更新质保

更新指定质保。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssurance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保ID |

### 删除质保

删除质保。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssurance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保ID |

### 获取质保信息

获取指定质保详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssurance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保ID |

### 获取质保产品接口描述

获取质保产品对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceProduct/description`

### 创建质保产品

创建质保产品。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceProduct`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| productId | 是 | Long | 产品ID |
| warrantyId | 是 | Long | 质保ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的质保产品ID |

### 更新质保产品

更新指定质保产品。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保产品ID |

### 删除质保产品

删除指定的质保产品。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保产品ID |

### 获取质保产品信息

获取指定的质保产品信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceProduct/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保产品ID |

### 获取质保档案接口描述

获取质保档案对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceFile/description`

### 创建质保档案

创建质保档案。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceFile`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| qualityAsset | 是 | Long | 资产编号 |
| startDate | 是 | Long | 起始日期 |
| endDate | 否 | Long | 结束日期 |
| warranty | 是 | Long | 质保 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的质保档案ID |

### 更新质保档案

更新指定的质保档案。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保档案ID |

### 删除质保档案

删除质保档案。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保档案ID |

### 获取质保档案信息

获取质保档案信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qualityAssuranceFile/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 质保档案ID |

### 获取外呼目标接口描述

获取外呼目标对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/description`

### 创建外呼目标

创建外呼目标。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| outboundTaskPool | 是 | Long | 外呼目标池 ID |
| account | 否 | Long | 客户 ID |
| lead | 否 | Long | 线索 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的外呼目标 ID |

### 更新外呼目标

更新指定的外呼目标。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 锁定外呼目标

锁定指定的外呼目标。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 解锁外呼目标

解锁指定的外呼目标。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 删除外呼目标

删除指定的外呼目标。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 获取外呼目标信息

查看指定的外呼目标的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 关注外呼目标

关注指定的外呼目标。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 取消关注外呼目标

取消关注指定的外呼目标。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 转移外呼目标

转移指定的外呼目标。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskRecord/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标 ID |

### 获取外呼目标池接口描述

获取外呼目标池对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/description`

### 创建外呼目标池

创建外呼目标池。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| recordType | 是 | Integer | 目标类型 |
| followTimes | 是 | Integer | 可跟进次数 |
| definitionOfDone | 是 | Array | 完成标准 |
| serviceSummary | 否 | JSON | 服务总结模板 |
| formTemplate | 否 | Long | 表单模板 |
| name | 是 | String | 外呼目标池名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的外呼目标池 ID |

### 更新外呼目标池

更新指定的外呼目标池。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 锁定外呼目标池

锁定指定的外呼目标池。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 解锁外呼目标池

解锁指定的外呼目标池。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 删除外呼目标池

删除指定的外呼目标池。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 获取外呼目标池信息

查看指定的外呼目标池的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 关注外呼目标池

关注指定的外呼目标池。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 取消关注外呼目标池

取消关注指定的外呼目标池。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | True | Long | 外呼目标池 ID |

### 转移外呼目标池

转移指定的外呼目标池。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTaskPool/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼目标池 ID |

### 获取外呼任务接口描述

获取外呼任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/description`

### 创建外呼任务

创建外呼任务。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 是 | Long | 业务类型 |
| outboundTaskPool | 是 | Long | 外呼目标池 ID |
| startTime | 是 | Long | 开始时间 |
| displayRule | 是 | Integer | 外显规则 |
| displayNumber | 否 | String | 外显号码 |
| distributionMethod | 否 | Integer | 分配方式 |
| distributionRule | 否 | Integer | 分配规则 |
| csrSet | 是 | String | 分配客服 |
| reminderMode | 否 | Array | 提醒方式 |
| name | 是 | String | 外呼任务名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新建的外呼任务 ID |

### 更新外呼任务

更新指定的外呼任务。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | True | Long | 外呼任务 ID |

### 锁定外呼任务

锁定指定的外呼任务。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 解锁外呼任务

解锁指定的外呼任务。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 删除外呼任务

删除指定的外呼任务。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 获取外呼任务信息

查看指定的外呼任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 关注外呼任务

关注指定的外呼任务。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 取消关注外呼任务

取消关注指定的外呼任务。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/actions/follows/{id}/follow`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 转移外呼任务

转移指定的外呼任务。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/outboundTask/actions/transfers/{targetUserId}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 外呼任务 ID |

### 获取排队数据

根据技能组ID获取当日截至当前排队类数据信息。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/imMonitor/getPresentQueueDataBySkillId/{skillId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| skillId | 是 | Long | 技能组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 状态值，0表示成功 |
| msg | String | 状态信息 |
| abandon | int | 技能组当日排队后放弃人数 |
| inqueue | int | 技能组当前正在排队人数 |

### 获取会话数据

根据技能组的ID获取当日截至当前会话类数据。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/imMonitor/getPresentChatDataBySkillId/{skillId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| skillId | 是 | Long | 技能组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 状态值，0表示成功 |
| msg | String | 状态信息 |
| totalDuration | int | 技能组当日截至当前全部会话时长总和 |
| totalRound | int | 技能组当日截至当前全部会话总回合数 |
| amount | int | 技能组当日截至当前总会话数 |
| effectiveChatAmount | int | 技能组当日截至当前有效会话数 |
| totalFirstRespTime | int | 技能组当日截至当前全部会话首响总时长。单位：毫秒 |
| totalRespTime | int | 技能组当日截至当前全部会话响应总时长。单位：毫秒 |

### 获取坐席数据

根据技能组ID获取坐席状态汇总数据情况。

- 请求方式: `GET`
- API 地址: `/rest/sc/v1.0/imMonitor/getPresentAgentDataBySkillId/{skillId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| skillId | 是 | Long | 技能组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 状态值，0表示成功 |
| msg | String | 状态信息 |
| offline | int | 技能组当前离线坐席数量 |
| online | int | 技能组当前在线坐席数量 |
| onbusy | int | 技能组当前忙碌坐席数量 |

### 获取员工技能接口描述

获取员工技能对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/description`

### 创建员工技能

创建员工技能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fieldJobSkillId | 是 | Long | 技能 |
| employeeId | 是 | Long | 员工 |
| skillScoreId | 是 | Long | 评分 |
| employeeSkillDesc | 否 | String | 备注 |
| validPeriod | 否 | Long | 有效期 |
| validStatus | 否 | Integer | 有效状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | 是 | Long |

### 更新员工技能

更新指定员工技能。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定员工技能

锁定员工技能。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁员工技能

解锁员工技能。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除员工技能

删除指定员工技能。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取员工技能信息

查看指定员工技能详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/employeeSkill/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取WhatsApp消息模板发送记录接口描述

获取 WhatsApp 消息模板发送记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/description`

### 更新WhatsApp消息模板发送记录

更新指定 WhatsApp 消息模板发送记录。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定WhatsApp消息模板发送记录

锁定 WhatsApp 消息模板发送记录。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁WhatsApp消息模板发送记录

解锁 WhatsApp 消息模板发送记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除WhatsApp消息模板发送记录

删除指定 WhatsApp 消息模板发送记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取WhatsApp消息模板发送记录信息

查看指定 WhatsApp 消息模板发送记录详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/whatsAppMTSendingRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 发送WhatsApp模板消息

向 WhatsApp 用户发送模板消息。

- 请求方式: `POST`
- API 地址: `/rest/sc/v1.0/whatsapp/template/send/trigger/message`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| senderNumber | 是 | String | 发送号码，需在后台配置 |
| toNumber | 是 | String | 接收号码 |
| templateId | 是 | String | 消息模板 ID |
| type | 是 | String | 消息模板类型 |
| variables | 是 | Object | 消息变量 |
| triggerEventObjectKey | 否 | String | 消息关联实体 KEY |
| triggerEventObjectDataId | 否 | Long | 消息关联实体数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| recordId | Long | WhatsApp 消息模板发送记录 ID |
| messageId | String | WhatsApp 第三方消息 ID |

---

## 伙伴云API接口

### 获取电子券接口描述

获取电子券对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/coupon/description`

### 获取电子券信息

获取指定电子券的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/coupon/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | long | 需要查看的电子券ID |

### 查询电子券列表

查询电子券列表信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/coupon/actions/queryList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| receiveAccount | 否 | Long | 领取客户ID |
| couponStatus | 否 | Integer | 电子券状态 |
| pageNo | 否 | Integer | 当前页码 |
| pageSize | 否 | Integer | 每页个数 |
| couponCode | 否 | Long | 券码 |
| closureContact | 否 | Long | 核销联系人 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 返回码（200表示成功，其他为失败） |
| msg | String | 返回信息 |
| batchData | JSON | 返回数据（包括coupon的数据ID、apikey等） |

### 领取电子券

领取电子券。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/coupon/actions/couponReceive`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| couponIssueId | 是 | Long | 电子券方案ID |
| accountId | 是 | Long | 领取客户ID |
| fState | 否 | Integer | 省 |
| fCity | 否 | Integer | 市 |
| fDistrict | 否 | Integer | 区 |

### 核销电子券

核销电子券。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/coupon/actions/couponClosure`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要核销的电子券ID |
| contactId | 是 | Long | 核销人ID |
| accountId | 是 | Long | 核销客户ID |

### 发行电子券（异步）

发行电子券。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/coupon/actions/publish`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| code | Integer | 返回编码 |
| msg | String | 返回信息 |
| data | Integer | 电子券成功发行数量 |

### 删除电子券

删除电子券。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/coupon/{ids}/batch/interim`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | String | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 返回码（200表示成功，其他为失败） |
| msg | String | 返回信息 |
| batchData | JSON | 返回数据（包括成功删除 coupon 的数据 ID 等） |

### 获取电子券方案接口描述

获取电子券方案对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue/description`

### 创建保存电子券方案

保存电子券方案业务数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 返回码（200表示成功，其他为失败） |
| msg | String | 返回信息 |
| success | Boolean | 是否成功 |
| data | JSON | 返回数据（包括生产的数据ID，APIkey等） |

### 查询电子券方案列表

查询电子券方案列表信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue/actions/queryList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Integer | 领取客户ID |
| fState | 否 | Integer | 省 |
| fCity | 否 | Integer | 市 |
| fDistrict | 否 | Integer | 区 |

### 获取电子券方案信息

获取指定电子券方案详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的电子券方案ID |

### 查询电子券方案领取客户和核销客户条件

查询 couponIssue 领取客户和核销客户条件。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue/actions/getCouponIssueRules`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| itemApiKey | 是 | String | 客户类型 drawAccountType：领取客户closureAccountType：核销客户 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| entityType | Long | 返回的为客户类型 ID（客户类型进行特殊说明，详情可以查看返回示例） |

### 变更电子券方案状态

变更电子券方案状态。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/couponIssue/actions/changeStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 电子券方案 ID |
| status | 是 | Integer | 状态2：已生效3：已发行4：暂停领取5：已作废 |

### 获取电子券追加接口描述

获取电子券追加对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/description`

### 创建电子券追加

创建电子券追加。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| 返回字段 | 类型 | 说明 |
| id | Long | 新创建的电子券追加ID（唯一标识） |

### 更新电子券追加

更新电子券追加。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 电子券追加ID |

### 锁定电子券追加

锁定电子券追加。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 电子券追加ID |

### 解锁电子券追加

解锁电子券追加。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 电子券追加ID |

### 删除电子券追加

删除电子券追加。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 电子券追加ID |

### 获取电子券追加信息

获取指定电子券追加信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/couponAppend/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据ID |

### 通过外部部门ID获取经销商客户

通过外部部门 ID 查询关联的经销商客户。

- 请求方式: `POST`
- API 地址: `/rest/prm/v1.0/account/getAccountByDepartId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| departId | 是 | Long | 部门ID |

### 通过外部用户ID获取经销商客户

通过外部用户 ID 查询所属的经销商客户。

- 请求方式: `POST`
- API 地址: `/rest/prm/v1.0/account/getAccountByUserId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |

### 查询周边客户

查询周边客户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/account/actions/around`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityType | 否 | Long | 客户类型 |
| latitude | 是 | Integer | 纬度 |
| longitude | 是 | Integer | 经度 |
| distance | 是 | Integer | 距离 |
| filterString | 否 | String | 过滤条件（使用ES queryString语法） |

### 获取促销累加明细接口描述

获取促销累加明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/description`

### 创建促销累加明细

创建促销累加明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotionCounterDetail`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的促销累加明细ID（唯一标识） |

### 批量创建促销累加明细

批量创建促销累加明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/batch`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的促销累加明细ID（唯一标识） |

### 获取促销累加明细信息

查看指定的促销累加明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotionCounterDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 促销累加明细ID |

### 根据客户获取符合条件的促销活动

根据客户获取符合条件的促销活动。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/query/findAllWithAccount`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户 ID |
| entityType | 否 | Long | 促销活动业务类型 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | Integer | 状态码 |
| data | JSON | 促销活动数据 |

### 根据促销活动获得符合条件的客户

根据促销活动获得符合条件的客户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/salesPromotion/query/findAccountByPromotion`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| salesPromotionId | 是 | Long | 促销活动 ID |
| pagenum | 是 | Integer | 页码 |
| pagesize | 是 | Integer | 单页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | Integer | 状态码 |
| data | JSON | 客户 JSON 数据 |

### 获取返利规则接口描述

获取返利规则对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebateRule/description`

### 获取返利规则信息

查看指定的返利规则的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebateRule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返利规则 ID |

### 获取返利方案接口描述

获取返利方案对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/description`

### 创建返利方案

创建返利方案。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| applicationCondition | 是 | String | 投放范围，使用过滤器格式，可以在页面新建相关配置，抓取该参数 |
| details.rebateSchedule | 是 | JSON | 方案执行档期，会生成相应的档期数据 |
| details.ruleCondition | 否 | JSON | 规则满足条件，获取方式同 applicationCondition |
| details.rebateValue | 是 | JSON | 返利方式数据，获取方式同 applicationCondition |

### 更新返利方案

更新指定的返利方案。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |
| details.[update/delete].id | 是 | Long | 子对象 ID，更新或删除时必传 |
| 其他更新字段 | 否 | - | 参考创建返利方案的请求参数说明 |

### 锁定返利方案

锁定返利方案。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |

### 解锁返利方案

解锁返利方案。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |

### 删除返利方案

删除指定的返利方案。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |

### 获取返利方案信息

查看指定的返利方案的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |

### 生效或中止返利方案

生效或中止返利方案。仅可从以下三种方式单向改变返利方案的状态：未生效 > 生效。
                        未生效 > 中止。
                        生效 > 中止。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/actions/updateStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 方案 ID |
| status | 是 | Integer | 2：生效3：中止 |

### 查询返利方案投放范围

查询方案覆盖的客户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/actions/applicationAccounts`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| filter | 是 | Long | 投放范围配置的过滤条件 |
| pageNum | 是 | Integer | 当前页数 |
| pageSize | 是 | Integer | 每页条数 |
| paramData | 是 | JSON | 当前返利方案的数据 |
| filterItemApiKey | 否 | String | 过滤器字段：applicationCondition |
| filterObjectId | 是 | Long | 过滤器配的实体：1086 |
| referObjectId | 是 | Long | 过滤目标实体 ID（客户实体：1） |
| recordSortList | 否 | JSON | 排序字段 |

### 查询返利方案档期设置

查询返利方案档期设置。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/rebatePlan/actions/fiscalSetting`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| start | 是 | Long | 方案开始时间 |
| end | 是 | Integer | 方案结束时间 |
| type | 是 | Integer | 档期类型1：月2：季3：年 |

### 获取返利核销单接口描述

获取返利核销单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebateVerification/description`

### 更新返利核销单

更新指定的返利核销单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/rebateVerification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返利核销单 ID |
| status | 否 | Integer | 参考描述接口 |
| quantity | 否 | Integer | 产品数量 |
| rebate | 否 | Double | 确认核销金额 |
| accountName | 否 | Long | 核销账户 |

### 锁定返利核销单

锁定返利核销单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/rebateVerification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返利核销单 ID |

### 解锁返利核销单

解锁返利核销单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/rebateVerification/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返利核销单 ID |

### 获取返利核销单信息

查看指定的返利核销单的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/rebateVerification/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 返利核销单 ID |

### 获取对账单接口描述

获取对账单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/description`

### 创建对账单

创建对账单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| customer | 是 | Long | 客户 |
| reconciliationConfiguration | 是 | Long | 手动类型对账配置 |
| year | 是 | String | 年 |
| quarter | 否 | Integer | 季度 |
| month | 否 | Integer | 月 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的对账单ID（唯一标识） |

### 更新对账单

更新指定对账单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账单ID |
| 其他更新字段 |  |  | 含义和新建相同 |

### 锁定对账单

锁定指定对账单。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/actions/locks/{id}/lock`

### 解锁对账单

解锁指定对账单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/actions/locks/{id}/lock`

### 删除对账单

删除指定对账单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账单ID |

### 获取对账单信息

查看指定对账单详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationStatement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账单ID |

### 获取对账单明细接口描述

获取对账单明细对象的表结构、数据类型等信息。

- 请求方式: `/REST/DATA/V2.0/XOBJECTS/RECONCILIATIONDETAILS/DESCRIPTION`
- API 地址: `GET`

### 锁定对账单明细

锁定指定对账单明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationDetails/actions/locks/{id}/lock`

### 解锁对账单明细

解锁指定对账单明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationDetails/actions/locks/{id}/lock`

### 获取对账单明细信息

查看指定对账单明细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationDetails/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账单明细ID |

### 获取对账配置接口描述

获取对账配置对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/description`

### 创建对账配置

创建对账配置。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| applicableCustomers | 否 | String | 投放范围，使用过滤器格式，可以在页面新建相关配置，抓取该参数 |
| schedule | 否 | JSON | 配置执行档期，会生成相应的档期数据 |
| formula | 是 | String | 公式设置参数，获取方式同applicableCustomers |
| ruleCondition | 否 | String | 条件设置，获取方式同
                                applicableCustomers |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的对账配置ID（唯一标识） |

### 更新对账配置

更新指定对账配置。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账配置ID |
| schedule.[add/delete] | 否 | Json | 档期修改 |
| 其他更新字段 | 否 |  | 含义和新建相同 |

### 锁定对账配置

锁定指定对账配置。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/actions/locks/{id}/lock`

### 解锁对账配置

解锁指定对账配置。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/actions/locks/{id}/lock`

### 删除对账配置

删除指定对账配置。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账配置ID |

### 获取对账配置信息

查看指定对账配置详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/reconciliationConfiguration/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 对账配置ID |

### 获取申诉记录接口描述

获取对账单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/description`

### 创建申诉记录

创建申诉记录。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| statementNo | 是 | Long | 对账单 |
| complaintObject | 是 | Long | 申诉对象 |
| occurrenceDate | 是 | String | 发生时间 |
| actualAmount | 是 | Integer | 实际发生金额 |
| presentArguments | 否 | Integer | 申诉理由 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的申诉记录ID（唯一标识） |

### 更新申诉记录

更新指定申诉记录。

- 请求方式: `PATCH`
- API 地址: `/data/v2.0/xobjects/statementRecord/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 申诉记录ID |
| 其他更新字段 |  |  | 含义和新建相同 |

### 锁定申诉记录

锁定指定申诉记录。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/actions/locks/{id}/lock`

### 解锁申诉记录

解锁指定申诉记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/actions/locks/{id}/lock`

### 删除申诉记录

删除指定申诉记录。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 申诉记录ID |

### 获取申诉记录信息

查看指定申诉记录详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/statementRecord/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 申诉记录ID |

### 获取可售范围接口描述

获取可售范围对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/description`

### 创建可售范围

创建可售范围。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 可售范围开始时间 |
| endDate | 是 | Long | 可售范围结束时间 |
| status | 否 | Integer | 1：启用
                                2：禁用 |
| accountScopeType | 是 | Integer | 1：全部
                                2：条件客户
                                3：指定客户 |
| accountScopeCond | 否 | String | accountScopeType 为 2 时该字段参考平台过滤器格式，为 3 时该字段保存用户
                                id，eg:[2302290303680538,2205689367052295] |
| productScopeType | 是 |  | 1：全部
                                2：条件产品
                                3：已选价格表
                                4：指定产品 |
| productScopeCond | 否 | String | productScopeType 为 2 时该字段参考平台过滤器格式，为 4 时该字段保存用户
                                    id，eg:[2302290303680538,2205689367052295]
                                productScopeType 其它值时为空 |
| priceBookScopeIds | 是 | String | 可售范围使用的价格表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新可售范围

更新指定可售范围。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |
| startDate | 是 | Long | 可售范围开始时间 |
| endDate | 是 | Long | 可售范围结束时间 |
| status | 否 | Integer | 1：启用
                                2：禁用 |
| accountScopeType | 是 | Integer | 1：全部
                                2：条件客户
                                3：指定客户 |
| accountScopeCond | 否 | String | accountScopeType 为 2 时该字段参考平台过滤器格式，为 3 时该字段保存用户
                                id，eg:[2302290303680538,2205689367052295] |
| productScopeType | 是 |  | 1：全部
                                2：条件产品
                                3：已选价格表
                                4：指定产品 |
| productScopeCond | 否 | String | productScopeType 为 2 时该字段参考平台过滤器格式，为 4 时该字段保存用户
                                    id，eg:[2302290303680538,2205689367052295]
                                productScopeType 其它值时为空 |
| priceBookScopeIds | 是 | String | 可售范围使用的价格表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 锁定可售范围

锁定指定可售范围。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 解锁可售范围

解锁指定可售范围。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 删除可售范围

删除指定可售范围。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 获取可售范围信息

查看指定可售范围详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| accountScopeCondDes | String | 适用客户的描述信息 |
| productScopeCondDes | String | 产品授权的描述信息 |
| startDate | Long | 可售范围开始时间 |
| endDate | Long | 可售范围结束时间 |
| status | Integer | 1：启用
                                2：禁用 |
| accountScopeType | Integer | 1：全部
                                2：条件客户
                                3：指定客户 |
| accountScopeCond | String | accountScopeType 为 2 时该字段参考平台过滤器格式，为 3 时该字段保存用户
                                id，eg:[2302290303680538,2205689367052295] |
| productScopeType | Integer | 1：全部
                                2：条件产品
                                3：已选价格表
                                4：指定产品 |
| productScopeCond | String | productScopeType 为 2 时该字段参考平台过滤器格式，为 4 时该字段保存用户
                                    id，eg:[2302290303680538,2205689367052295]
                                productScopeType 其它值时为空 |
| priceBookScopeIds | String | 可售范围使用的价格表 |

### 是否开启可售范围

判断是否开启可售范围。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/isOpenSaleableScope`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| openSaleableScope | Integer | 租户是否开启可售范围。
                                0：未开启
                                1：开启 |

### 获取客户可售范围

获取客户可售范围。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/saleableScopes`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 可售范围 ID |
| name | String | 可售范围名称 |

### 获取客户可售产品

基于可售范围查询客户可以购买的产品。当启用可售范围优先级时，返回最高优先级可售范围对应的产品，否则返回所有可售范围产品的并集。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/saleableProducts`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountId | 是 | Long | 客户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| supportAllProduct | Boolean | 为 true 时，saleableProducts 为空，所有产品可售
                                为 false 时，saleableProducts 返回的产品 ID 集合可售 |
| saleableProducts | JsonArray | 可售产品 ID 集合 |

### 获取产品价格表关系

基于可售范围，查询客户购买产品时应该使用的价格表和可售范围。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/saleableScope/actions/{accountId}/productsPriceBook`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| productIds | 是 | JsonArray | 查询的产品 ID 集合 |
| saleableScopeIds | 否 | JsonArray | 查询的可售范围 ID 集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| productId | Long | 产品 ID |
| priceBookId | Long | 价格表 ID |
| saleableScopeId | Long | 可售范围 ID |

### 获取渠道协议接口描述

获取渠道协议对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/description`

### 创建渠道协议

创建渠道协议。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 渠道协议开始时间 |
| endDate | 是 | Long | 渠道协议结束时间 |
| status | 否 | Integer | 1：启用
                                2：禁用 |
| productAuthType | 是 | Integer | 1：选择产品
                                2：选择价格表 |
| dealer | 是 | Long | 经销商 ID |
| partyA | 是 | 多态字段 | 甲方 |
| priceBook | 是 | Long | 协议对应的价格表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新渠道协议

更新指定渠道协议。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |
| startDate | 是 | Long | 渠道协议开始时间 |
| endDate | 是 | Long | 渠道协议结束时间 |
| status | 否 | Integer | 1：启用
                                2：禁用 |
| productAuthType | 是 | Integer | 1：选择产品
                                2：选择价格表 |
| dealer | 是 | Long | 经销商 ID |
| partyA | 是 | 多态字段 | 甲方 |
| priceBook | 是 | Long | 协议对应的价格表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 锁定渠道协议

锁定指定渠道协议。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 解锁渠道协议

解锁指定渠道协议。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 删除渠道协议

删除指定渠道协议。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |

### 获取渠道协议信息

获取指定渠道协议详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/channelAgreement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分方案接口描述

获取积分方案对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/description`

### 创建积分方案

创建积分方案。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 积分方案名称 |
| beginDate | 是 | Long | 开始日期 |
| endDate | 是 | Long | 结束日期 |
| notes | 否 | String | 备注 |
| status | 是 | Integer | 状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新积分方案

更新指定积分方案。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定积分方案

锁定积分方案。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁积分方案

解锁积分方案。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除积分方案

删除指定积分方案。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分方案详细信息

查看指定积分方案详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取客户积分方案

获取客户可以参加的有效积分方案。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/{accountId}/availablePointPlans`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 客户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| notes | String | 备注 |
| name | String | 积分方案名称 |

### 计算积分

只获取积分计算结果，不生成对应的积分明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/pointPlan/actions/pointCalculate`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| actionType | 是 | JSON Field | 1：新增
                                2：修改 |
| data | 新增时必填 | JSON Object | 新增业务数据 |
| oldData | 修改时必填 | JSON Object | 修改前业务数据 |
| newData | 修改时必填 | JSON Object | 修改后业务数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| pointValue | Long | 积分值 |
| pointPlan | Long | 积分方案 |
| pointRule | Long | 积分规则 |
| expireDate | Long | 积分过期时间 |
| account | Long | 获取积分客户 |

### 获取积分规则接口描述

获取积分规则对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/description`

### 创建积分规则

创建积分规则。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 积分规则名称 |
| pointPlan | 是 | Long | 积分方案 |
| status | 是 | Integer | 状态 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新积分规则

更新指定积分规则。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定积分规则

锁定积分规则。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁积分规则

解锁积分规则。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除积分规则

删除指定积分规则。

- 请求方式: `DELETE`
- API 地址: `rest/data/v2.0/xobjects/pointRule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分规则详细信息

查看指定积分规则详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointRule/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分明细接口描述

获取积分明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/description`

### 创建积分明细

创建积分明细。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| account | 是 | Long | 客户 |
| pointPlan | 是 | Long | 积分方案 |
| pointValue | 是 | Double | 积分值 |
| pointRule | 是 | Long | 积分规则 |
| rebateSchedule | 否 | Long | 执行档期 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新积分明细

更新指定积分明细。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定积分明细

锁定积分明细。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁积分明细

解锁积分明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除积分明细

删除指定积分明细。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分明细详细信息

查看指定积分明细详细详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分来源接口描述

获取积分来源对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/description`

### 创建积分来源

创建积分来源。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pointDetail | 是 | Long | 积分明细 |
| pointValue | 是 | Integer | 积分值 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新积分来源

更新指定积分来源。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定积分来源

锁定积分来源。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁积分来源

解锁积分来源。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除积分来源

删除指定积分来源。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取积分来源详细信息

查看指定积分来源详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/pointDetailSource/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取预算调整接口描述

获取预算调整对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/description`

### 创建预算调整

创建预算调整。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| adjustBudgetPool | 是 | Long | 要调整的预算池 |
| additionalAmount | 是 | Double | 追加的预算金额 |
| name | 是 | String | 预算调整的名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的数据 ID（唯一标识） |

### 更新预算调整

更新指定预算调整。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/masterdetails`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 锁定预算调整

锁定预算调整。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 解锁预算调整

解锁预算调整。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 删除预算调整

删除指定预算调整。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

### 获取预算调整详细信息

查看指定预算调整详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/budgetAdjustment/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 数据 ID |

---

## SCRM API接口

### 好友关系关联业务对象

将某条好友关系记录关联到某个业务对象上（仅限客户、联系人、线索）。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/qwSidebar/actions/updateQwSidebarRelateEntity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 好友关系 ID |
| dataId | 是 | Long | 业务对象 ID |
| objectApiKey | 是 | String | account，contact 或 lead |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| msg | String | 成功为 OK |

### 分页获取主体下聊天记录

根据明文或密文的 corpId 分页获取该主体下的聊天记录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/qywx/chatRecord/actions/fetch?corpId={corpId}&pageNo={pageNo}&pageSize={pageSize}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 是 | String | 企业ID，明文或者密文 |
| pageNo | 是 | Integer | 当前请求页的页码，有效范围：1 ~ N，N为 Integer 的最大值 |
| pageSize | 是 | Integer | 当前请求也的记录数，有效范围 1 ~ 1000，最少 1 条，最大 1000 条 |
| seq | 否 | Integer | 消息编号 |
| startTime | 否 | Long | 开始时间戳，含义为不早于startTime |
| endTime | 否 | Long | 结束时间戳，含义为不晚于endTime |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| msg | String | 成功为 OK |
| data | JSONObject | 分页聊天记录数据 |
| data.pageNo | Integer | 当前页号 |
| data.pageSize | Integer | 当前页最大记录数 |
| data.pageCount | Integer | 当前页记录数 |
| data.dataCount | Integer | 记录总数 |
| data.records | JSONArray | 聊天记录 |

### 上传素材资源

将对应资源上传，获取到资源文件ID。

- 请求方式: `MULTIPART/FORM-DATA POST`
- API 地址: `/rest/mc/v2.0/cms/api/action/uploadFile`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| file | 是 | File | 资源文件 |
| isVideo | 否 | Boolean | 是否为视频类文件；默认：false |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | JSON | 返回数据 |
| fileId | Long | 已上传的素材文件ID |
| coverFileDto | Object | 素材封面图片，当上传文件为视频时返回该值； |
| coverFileDto.fileId | Long | 素材封面图片文件ID，仅当isVideo为true时返回 |

### 创建素材

创建指定类型的素材。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/action/createMaterial`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpName | 是 | String | 素材所属企微主体名称 |
| materialType | 是 | Integer | 素材类型：2：图片
                                    5：视频
                                    6：文件
                                    7：小程序
                                    31：自建网页
                                    32：转载其他外链
                                    33：转载公众号图文 |
| categoryName | 是 | String | 素材所属分类名称多级分类格式：父分类名称/子分类名称 |
| title | 是 | String | 素材名称 |
| fileId | 否 | Long | 已上传的素材文件ID当素材类型为图片、视频、文件时，该参数为必填 |
| enableStatus | 否 | Integer | 是否启用；0：未启用
                                    1：已启用默认值：0 |
| sendingText | 否 | String | 配文文本 |
| enableCardTemplateStatus | 否 | Integer | 是否开启素材名片模板；0：未启用
                                    1：已启用仅网页、图片、视频素材有效，其他类型传值无效 |
| notifyRange | 否 | Array[String] | 1：进入页面
                                    2：停留时长
                                    3：浏览到底部
                                    4：转发页面
                                    5：进入名片
                                    6：扫描名片二维码
                                图片、视频、转载其他外链，素材取值范围：["1","2","5","6"]，其中当参数【enableCardTemplateStatus】不为空时可设置["5","6"]
                                转载公众号图文、自建网页，素材取值范围：["1","2","3"，"4",5","6"]，其中当参数【enableCardTemplateStatus】不为空时可设置["5","6"] |
| stayPushTime | 否 | Long | 停留时长，其中当参【notifyRange】中包含值["2"]时有效，单位秒，取值：【20,30,60,120】；默认值：20 |
| disturbFlg | 否 | Boolean | 是否开启通知免打扰；true：开启
                                    false：不开启默认值：false |
| summary | 否 | String | 摘要，仅当视频，网页类素材时有效 |
| coverFileId | 否 | Long | 封面图片ID素材类型为视频、网页-其他外链类时有效 |
| content | 否 | String | 素材类型为网页-自建网页类型时有效且必传 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | JSON | 返回数据 |
| id | Long | 创建素材的ID |

### 更新素材

修改素材库中现有素材的相关属性。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/action/updateMaterial/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 必须 | Long | 素材 ID |
| categoryName | 是 | String | 素材所属分类名称。
                                多级分类格式：父分类名称/子分类名称 |
| title | 是 | String | 素材名称 |
| fileId | 否 | Long | 已上传的素材文件 ID。
                                当素材类型为图片、视频、文件时，该参数为必填 |
| enableStatus | 否 | Integer | 是否启用。
                                0：未启用
                                    1：已启用
                                默认值：0 |
| sendingText | 否 | String | 配文文本 |
| enableCardTemplateStatus | 否 | Integer | 是否开启素材名片模板。
                                0：未启用
                                    1：已启用
                                仅网页、图片、视频素材有效，其他类型传值无效 |
| notifyRange | 否 | Array[String] | 1：进入页面
                                    2：停留时长
                                    3：浏览到底部
                                    4：转发页面
                                    5：进入名片
                                    6：扫描名片二维码
                                图片、视频、转载其他外链，素材取值范围：["1","2","5","6"]，其中当参数“enableCardTemplateStatus”不为空时可设置["5","6"]
                                转载公众号图文、自建网页，素材取值范围：["1","2","3"，"4",5","6"]，其中当参数“enableCardTemplateStatus”不为空时可设置["5","6"] |
| stayPushTime | 否 | Long | 停留时长，其中当参数“notifyRange”中包含值["2"]时有效，单位为秒，取值：【20,30,60,120】。默认值：20 |
| disturbFlg | 否 | Boolean | 是否开启通知免打扰。
                                true：开启
                                    false：不开启
                                默认值：false |
| summary | 否 | String | 摘要，仅当视频，网页类素材时有效 |
| coverFileId | 否 | Long | 封面图片 ID
                                素材类型为视频、网页-其他外链类时有效 |
| content | 否 | String | 素材类型为网页-自建网页类型时有效且必填 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | JSON | 返回数据 |

### 查询素材列表

根据条件查询素材列表。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/material-center/material/queryAll`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| key | string | 否 | 关键字，模糊匹配素材标题、名称 |
| enableStatus | Int | 否 | 启用状态
                                0：未启用
                                1：启用
                                2：停用 |
| materialTypes | array | 否 | 素材类型
                                2：图像
                                3：网页
                                5：视频
                                6：文件
                                7：小程序
                                8：海报
                                举例:[3,5] |
| categoryIds | string | 否 | 素材分类ID，多个以逗号分割
                                举例：2273761880540363，123 |
| categoryName | Int | 否 | 返回集中是否需要带素材分类名称
                                1：是
                                0或不填：否 |
| webType | int | 否 | 网页类型，当materialTypes包含3时生效。1：自建网页2：一般外链3：图文外链 |
| webUrl | String | 否 | 外链地址 |
| createdBegin | String | 否 | 创建时间起,格式：yyyy-MM-dd |
| createdEnd | String | 否 | 创建时间止,格式：yyyy-MM-dd |
| updatedBegin | String | 否 | 更新时间起,格式：yyyy-MM-dd |
| updatedEnd | String | 否 | 更新时间止,格式：yyyy-MM-dd |
| userId | long | 否 | 创建人ID |
| from | Int | 是 | 客户端标记，固定为0 |
| pageNo | Int | 否 | 分页参数：页数，默认是1 |
| pageSize | int | 否 | 分页参数：每页数据条数，默认最多10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |
| startNo | Int | 起始编号，一般为0 |
| pageSize | Int | 每页条数 |
| pageNo | Int | 当前页 |
| pageCount | Int | 总页数 |
| dataCount | Int | 总数据量 |
| currentPageDatas | Json | 实际素材数据 |
| author | String | 作者、分享人 |
| behaviorTrackSwitch | int | 访客行为跟踪，1：跟踪0：不跟踪 |
| behaviorNotify | int | 行为通知，1通知，0不通知 |
| notifyRange | Array | 行为通知范围， |
| autoTagFlg | int | 是否自动打标签
                                1：是
                                0：否 |
| categoryId | int | 分类编号 |
| createTime | long | 创建时间戳 |
| createdBy | long | 创建人 |
| category | String | 分类名称 |
| enableStatus | int | 启用状态0：未启用1：启用2：停用 |
| materialType | int | 素材类型1：文本2：图像3：网页4：音频5：视频6：文件7：小程序8：海报 |
| title | String | 素材标题，名称 |
| sendingText | String | 配文文本 |
| summary | String | 摘要 |
| content | String | 正文 |
| url | String | 外链 |
| fileDto.url | String | 封面图 |
| videoFileDto.url | String | 视频地址 |
| baseFileDto.url | String | 海报地址 |
| coverFileDto.url | String | 小程序封面 |
| tagList | Json | 标签列表 |
| type | int | 网页分类1：自建网页2：一般外链3：图文外链 |
| downloadCount | int | （海报）初始下载量 |
| category | String | 分类名称 |
| id | long | 素材ID |

### 修改素材状态

修改素材状态。

- 请求方式: `PUT`
- API 地址: `/rest/mc/v2.0/cms/material-center/material/batchUpdateStatus/{status}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| status | Int | 是 | URL参数，该参数拼在url最后面
                                1：启用
                                2：禁用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 创建素材分类

创建素材分类。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/category/action/create`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpName | String | 是 | 素材所属企微主体名称 |
| categoryName | String | 是 | 素材所属分类名称；多级分类格式：父分类名称/子分类名称 |
| parentId | long | 否 | 父分类ID |
| order | int | 否 | 分类排序 |
| categoryApiPermissions | Object | 否 | 使用权限参数 |
| categoryApiPermissions.relationType | int | 否 | 0：部门；1：成员 |
| categoryApiPermissions.systemRelatedDataId | long | 否 | 部门ID或用户ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 更新素材分类

素材分类名称修改。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/category/action/update`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpName | String | 是 | 素材所属企微主体名称 |
| id | long | 是 | 分类ID |
| categoryName | String | 是 | 素材分类名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 查询素材分类列表

查询素材分类列表。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/category/action/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpName | String | 是 | 素材所属企微主体名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |
| Id | long | 素材分类的ID |
| categoryName | String | 素材分类的名称 |
| parentId | long | 父ID |
| order | int | 分类排序 |
| categoryApiPermissions | Object | 分类使用权限 |
| childrens | Object | 子分类 |

### 删除素材分类

删除素材分类。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/category/action/delete`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpName | String | 是 | 素材所属企微主体名称 |
| id | long | 是 | 待删除ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取素材发送行为记录接口描述

获取素材发送行为记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialForward/description`

### 获取素材发送行为记录信息

获取素材发送行为记录的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialForward/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 素材发送行为记录 ID |

### 获取素材访客行为记录接口描述

获取素材访客行为记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialVisitorBehavior/description`

### 获取素材访客行为记录信息

获取素材访客行为记录的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialVisitorBehavior/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 素材访客行为记录 ID |

### 获取素材行为用户信息接口描述

获取素材行为用户信息对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialVisitor/description`

### 获取素材行为用户信息的信息

获取素材行为用户信息的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/materialVisitor/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 素材行为用户信息 ID |

### 素材访客信息上报

上报发生素材访问行为的用户信息，通常为公众号用户或者小程序用户。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/buried-point/saveBehaviorUser`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| appId | 是 | String | 公众号或小程序的 appId |
| 其他信息 | 是 | String | 参考公众号或小程序的访问用户信息 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Long | 创建的动态 ID |

### 素材访问行为上报

上报素材访问行为信息。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/api/buried-point/pushEvent`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| occurredAt | 是 | String | 行为发生时间 |
| eventType | 是 | String | enterPage：访问
                                forwardPage：转发
                                stay：停留
                                browseToBottom：浏览到底部 |
| materialType | 是 | String | 素材类型。
                                2：图片
                                3：网页
                                4：语音
                                5：视频
                                6：文件
                                7：小程序 |
| forwardRecordId | 是 | String | 素材发送记录 ID |
| openId | 是 | String | 公众号或小程序用户的 openId |
| duration | 否 | Long | 事件时间 |
| uniqueCode | 否 | String | 8 位随机字符串，标记一次访问，每次打开重新生成，同一次访问传相同的值 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Long | 创建的动态 ID |

### 查询素材访客信息

查询素材访问行为的用户信息，通常为公众号用户或者小程序用户。

- 请求方式: `GET`
- API 地址: `/rest/mc/v2.0/cms/api/buried-point/queryBehaviorUser`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| appId | 否 | String | 公众号或小程序的 appId |
| openid | 否 | String | 公众号或小程序的 openid |
| unionId | 否 | String | 公众号或小程序的 unionId |
| createdBefore | 否 | Long | 访客创建时间起始 |
| createdEnd | 否 | Long | 访客创建时间结束 |
| pageNo | 是 | Int | 分页参数页码 |
| pageSize | 是 | Int | 分页参数页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Object | 公众号或小程序用户相关信息 |

### 查询发送和转发素材记录

查询在 SCRM 中员工发送或者微信用户转发素材的记录。

- 请求方式: `GET`
- API 地址: `/rest/mc/v2.0/cms/api/buried-point/queryForwardRecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 否 | String | 企微主体 ID |
| type | 否 | String | 发送场景。
                                1：单聊
                                2：群聊
                                3：转发（销售人员发送时区分单聊或群发，访客转发时一律记录为转发）
                                4：客户朋友圈
                                5：群发
                                6：名片小程序
                                7：分享 |
| sendUserId | 否 | Long | 发送素材员工 ID（SCRM 中员工 ID） |
| receiveUser | 否 | String | 企微好友的 ID，员工从企微发送素材给好友时存在 |
| parentId | 否 | Long | 转发时存在，转发素材的前一步的发送 ID |
| indexId | 否 | Long | 转发时存在，转发素材的第一步的发送 ID |
| materialId | 否 | Long | 素材 ID |
| openid | 否 | String | 公众号或小程序的 openid |
| createdBefore | 否 | Long | 发送记录创建时间起始 |
| createdEnd | 否 | Long | 发送记录创建时间结束 |
| pageNo | 是 | Int | 分页参数页码 |
| pageSize | 是 | Int | 分页参数页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Object | 相关属性参考请求参数 |

### 查询素材访问行为记录

查询微信用户访问素材的时发生的行为。

- 请求方式: `GET`
- API 地址: `/rest/mc/v2.0/cms/api/buried-point/queryBehaviorRecord`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| forwardRecordId | 否 | String | 素材发送的 ID |
| eventType | 否 | Int | 1：访问
                                2：停留
                                3：浏览到底部
                                4：转发 |
| openid | 否 | String | 公众号或小程序的 openid |
| createdBefore | 否 | Long | 访问行为记录创建时间起始 |
| createdEnd | 否 | Long | 访问行为记录创建时间结束 |
| pageNo | 是 | Int | 分页参数页码 |
| pageSize | 是 | Int | 分页参数页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Object | 相关属性参考请求参数 |

### 查询话术或问答

查询话术或问答。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/speechLibrary/queryAll`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| key | String | 否 | 关键字，模糊匹配素话术/问答标题或内容 |
| status | Int | 否 | 启用状态
                                1：启用
                                2：停用
                                3：未启用 |
| type | int |  | 类型
                                1：话术
                                2：问答 |
| categoryIds | String | 否 | 分类ID，多个以逗号分割
                                举例：2273761880540363，123 |
| categoryName | String | 否 | 分类名称，模糊匹配（不能跟categoryIds同时传入，同时传入时以categoryIds为准） |
| needCategory | int | 否 | 返回集中是否需要带分类名称
                                1：是
                                0或不填：否 |
| createdBegin | String | 否 | 创建时间起,格式：yyyy-MM-dd |
| createdEnd | String | 否 | 创建时间止,格式：yyyy-MM-dd |
| updatedBegin | String | 否 | 更新时间起,格式：yyyy-MM-dd |
| updatedEnd | String | 否 | 更新时间止,格式：yyyy-MM-dd |
| userId | long | 否 | 创建人ID |
| pageNo | int | 否 | 分页参数：页数，默认是1 |
| pageSize | int | 否 | 分页参数：每页数据条数，默认最多10 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |
| entries | Json | 实际查询到的数据 |
| pageInfo | Json | 分页信息 |
| id | long | 数据ID |
| name | String | 问答标题或话术场景 |
| category | int | 类型
                                1：话术
                                2：问答 |
| categoryId | long | 分类ID |
| categoryName | String | 分类名称 |
| content | String | 问答答案（只有一个答案时）/话术内容 |
| answers | json | 问答答案（全部）/话术内容；可遍历列表取其中的content |
| status | int | 1：启用
                                2：停用
                                3：未启用 |
| tenantId | long | 租户ID |

### 修改话术或问答状态

修改话术或问答状态。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/cms/speechLibrary/updateStatus`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| category | String | 是 | 类型
                                1：话术
                                2：问答 |
| id | long | 是 | 话术或问答数据ID |
| status | int | 是 | 要改为的状态
                                1：启用
                                2：停用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取营销线索接口描述

获取营销线索对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/description`

### 创建营销线索

创建营销线索。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 营销线索姓名 |
| entityType | 是 | Long | 业务类型 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的营销线索 ID（唯一标识） |

### 更新营销线索

更新指定营销线索。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 营销线索ID |

### 删除营销线索

删除指定营销线索。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 营销线索ID |

### 获取营销线索信息

查看指定营销线索详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的营销线索ID |

### 获取营销线索总数

按照查询条件获取营销线索总数。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/actions/count`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| conditionSql | 否 | String | sql查询条件片段（值用问号代替） |
| paramList | 否 | Array | 查询条件中参数值列表 |

### 获取营销线索列表信息

按照查询条件获取营销线索列表信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/marketingLead/actions/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| conditionSql | 否 | String | sql查询条件片段（值用问号代替） |
| paramList | 否 | Array | 查询条件中参数值列表 |
| pageNo | 否 | Integer | 分页当前页 |
| pageSize | 否 | Integer | 分页条数 |
| sortList | 否 | Array | 排序列 |

### 营销线索升级

营销线索升级为销售线索。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/xobjects/marketingLead/actions/convert`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| mcLeadId | 是 | Long | 需要升级的营销线索ID |
| highSeaId | 否 | Long | 公海池ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| sLeadId | Long | 如果成功升级成为销售线索，则返回销售线索的ID |

### 获取营销任务接口描述

获取营销任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTask/description`

### 获取营销任务信息

获取营销任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 营销任务 ID |

### 获取营销任务内容接口描述

获取营销任务内容对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTaskContent/description`

### 获取营销任务内容信息

获取营销任务内容的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTaskContent/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 营销任务内容 ID |

### 获取营销任务执行明细接口描述

获取营销任务执行明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTaskDetail/description`

### 获取营销任务执行明细信息

获取营销任务执行明细的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/mcTaskDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 营销任务执行明细 ID |

### 获取销售SOP接口描述

获取销售 SOP 对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOP/description`

### 获取销售SOP信息

获取销售 SOP 的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOP/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售 SOP ID |

### 获取销售SOP任务执行记录接口描述

获取销售 SOP 任务执行记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOPInstanceTask/description`

### 获取销售SOP任务执行记录信息

获取销售 SOP 任务执行记录的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOPInstanceTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售 SOP 任务执行记录 ID |

### 获取销售SOP执行实例接口描述

获取销售 SOP 执行实例对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOPInstance/description`

### 获取销售SOP执行实例信息

获取销售 SOP 执行实例的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/salesSOPInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 销售 SOP 执行实例 ID |

### 查询标签列表

查询标签列表。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/tagGroup/list?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 是 | String | 企业 ID |
| wxTagId | 否 | String | 标签 ID |
| wxGroupId | 否 | String | 标签组 ID |
| sharingStatus | 是 | Integer | 0：只查共享标签
                                1：查全部
                                默认查全部 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 批量增量打个人标签

批量增量打个人标签。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/markTag/batch/personal?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | List<Long> | 实体记录 ID 集合 |
| objectId | 是 | Long | 实体 ID |
| addTags | 否 | List<String> | 添加的标签 |
| deleteTags | 否 | List<String> | 删除的标签 |
| corpId | 是 | String | 企业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 批量增量打共享标签

批量增量打共享标签。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/markTag/batch/shared?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | List<Long> | 实体记录 ID 集合 |
| objectId | 是 | Long | 实体 ID |
| addTags | 否 | List<String> | 添加的标签 |
| deleteTags | 否 | List<String> | 删除的标签 |
| corpId | 是 | String | 企业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取个人标签数据

根据实体记录 ID 获取个人标签数据。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/tagRecord/list/personal?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 否 | List<Long> | 实体记录 ID 集合 |
| objectId | 否 | Long | 实体 ID |
| corpId | 否 | String | 企业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 获取共享标签数据

根据实体记录 ID 获取共享标签数据。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/tagRecord/list/shared?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 否 | List<Long> | 实体记录 ID 集合 |
| objectId | 否 | Long | 实体 ID |
| corpId | 否 | String | 企业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| data | Json | 返回数据 |

### 新建标签组

创建企微标签组，并可同时创建并指定该标签组下的标签。

- 请求方式: `POST`
- API 地址: `/rest/qywx/v2.0/api/customer/tagGroup/create`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 是 | String | 企业 ID，从接口中提取 |
| groupSort | 是 | Integer | 标签组序号，取值范围为 0～100。 |
| sharingStatus | 是 | Integer | 是否为共享标签组
                                0：共享
                                1：非共享 |
| wxGroupName | 是 | String | 标签组名称，不能与已有标签组重名 |
| createTime | 是 | Long | 标签组的创建时间 |
| tagList | 是 | JSONArray | 标签组中包含的标签集合（列表） |
| tagList.wxTagName | 是 | String | 标签名称，同一标签组下的标签名称不能重复 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| msg | String | 成功为OK |
| data | Long | 标签组的记录 ID |
| success | String | API 执行结果
                                true：成功
                                false：失败 |

### 修改标签组

修改企微标签组，并可同时修改该标签组下的标签。

- 请求方式: `PUT`
- API 地址: `/rest/qywx/v2.0/api/customer/tagGroup/update`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 是 | String | 企业 ID，从接口中提取 |
| groupSort | 否 | Integer | 标签组序号，取值范围为 0～100。 |
| sharingStatus | 否 | Integer | 是否为共享标签组
                                0：共享
                                1：非共享 |
| wxGroupName | 是 | String | 标签组名称，不能与已有标签组重名。
                                如果标签组名称发生修改，将会创建一个新的标签组 |
| wxGroupId | 是 | String | 标签组 ID，注意此项不是标签组的记录 ID |
| tagList | 是 | JSONArray | 标签组中包含的标签集合（列表） |
| tagList.wxTagName | 是 | String | 标签名称，同一标签组下的标签名称不能重复 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| msg | String | 成功为OK |
| data | Long | 标签组的记录 ID |
| success | String | API 执行结果
                                true：成功
                                false：失败 |

### 获取多企微群发接口描述

获取多企微群发对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwMassSend/description`

### 获取多企微群发信息

获取多企微群发的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwMassSend/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 多企微群发 ID |

### 获取多企微任务接口描述

获取多企微任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwTask/description`

### 获取多企微任务信息

获取多企微任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 多企微任务 ID |

### 获取多企微任务明细接口描述

获取多企微任务明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwTaskDetail/description`

### 获取多企微任务明细信息

获取多企微任务明细的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/multiQwTaskDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 多企微任务明细 ID |

### 获取企微联系人接口描述

获取企微联系人对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwContact/description`

### 获取企微联系人信息

获取企微联系人的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwContact/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微联系人 ID |

### 获取企微标签关系接口描述

获取企微标签关系对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwTagRelation/description`

### 获取企微标签关系信息

获取企微标签关系的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwTagRelation/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微标签关系 ID |

### 获取企微好友关系接口描述

获取企微好友关系对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwSidebar/description`

### 获取企微好友关系信息

获取企微好友关系的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwSidebar/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微好友关系 ID |

### 获取企微群接口描述

获取企微群对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroup/description`

### 获取企微群信息

获取企微群信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroup/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微群 ID |

### 获取企微群成员接口描述

获取企微群成员对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroupMember/description`

### 获取企微群成员信息

获取企微群成员的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroupMember/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微群成员 ID |

### 获取企微群发任务接口描述

获取企微群发任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTask/description`

### 获取企微群发任务信息

获取企微群发任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微群发任务 ID |

### 获取企微群发任务内容接口描述

获取企微群发任务内容对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTaskContent/description`

### 获取企微群发任务内容信息

获取企微群发任务内容的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTaskContent/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微群发任务内容 ID |

### 获取企微群发结果明细接口描述

获取企微群发结果明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTaskDetail/description`

### 获取企微群发结果明细信息

获取企微群发结果明细的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/massSendTaskDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微群发结果明细 ID |

### 获取群标签日志接口描述

获取群标签日志对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroupTagLog/description`

### 获取群标签日志信息

获取群标签日志的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwGroupTagLog/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 群标签日志 ID |

### 获取群SOP接口描述

获取群 SOP 对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/groupSop/description`

### 获取群SOP信息

获取群SOP的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/groupSop/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 群 SOP ID |

### 获取群SOP实例任务接口描述

获取群 SOP 实例任务对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/groupSopInstanceTask/description`

### 获取群SOP实例任务信息

获取群 SOP 实例任务的详细信息。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/groupSopInstanceTask/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 群 SOP 实例任务 ID |

### 获取群SOP执行实例接口描述

获取群 SOP 执行实例对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/groupSopInstance/description`

### 获取群SOP执行实例信息

获取群 SOP 执行实例的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/groupSopInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 群 SOP 执行实例 ID |

### 获取微信访客接口描述

获取微信访客对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/wxVisitor/description`

### 获取微信访客信息

获取微信访客的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/wxVisitor/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 微信访客 ID |

### 获取敏感词监控接口描述

获取敏感词监控对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/sensitiveWordInstance/description`

### 获取敏感词监控信息

获取敏感词监控的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/sensitiveWordInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 敏感词监控 ID |

### 获取企微直播接口描述

获取企微直播对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/living/description`

### 获取企微直播信息

获取企微直播的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/living/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微直播 ID |

### 获取企微直播明细接口描述

获取企微直播明细对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/livingDetail/description`

### 获取企微直播明细信息

获取企微直播明细的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/livingDetail/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 企微直播明细 ID |

### 获取报名留资活动接口描述

获取报名留资活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/offlineCampaign/description`

### 获取报名留资活动信息

获取报名留资活动的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/offlineCampaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 报名留资活动 ID |

### 获取市场活动接口描述

获取市场活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaign/description`

### 获取市场活动信息

获取市场活动的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 市场活动 ID |

### 获取市场活动影响力接口描述

获取市场活动影响力对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignInfluence/description`

### 获取市场活动影响力信息

获取市场活动影响力的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignInfluence/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 市场活动影响力 ID |

### 获取会议活动接口描述

获取会议活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/conferenceCampaign/description`

### 获取会议活动信息

获取会议活动的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/conferenceCampaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 会议活动 ID |

### 获取活动成员接口描述

获取活动成员对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/description`

### 获取活动成员信息

获取活动成员的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignMember/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 活动成员 ID |

### 获取活动短信记录接口描述

获取活动短信记录对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignSmsLog/description`

### 获取活动短信记录信息

获取活动短信记录的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/campaignSmsLog/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 活动短信记录 ID |

### 获取内容传播活动接口描述

获取内容传播活动对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contentCampaign/description`

### 获取内容传播活动信息

获取内容传播活动的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/contentCampaign/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 内容传播活动 ID |

### 获取易企秀中奖名单接口描述

获取易企秀中奖名单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxWinner/description`

### 获取易企秀中奖名单信息

获取易企秀中奖名单的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxWinner/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 易企秀中奖名单 ID |

### 获取易企秀游戏排名接口描述

获取易企秀游戏排名对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxGameRank/description`

### 获取易企秀游戏排名信息

获取易企秀游戏排名的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxGameRank/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 易企秀游戏排名 ID |

### 获取易企秀参与抽奖名单接口描述

获取易企秀参与抽奖名单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxParticipant/description`

### 获取易企秀参与抽奖名单信息

获取易企秀参与抽奖名单的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/eqxParticipant/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 易企秀参与抽奖名单 ID |

### 创建常规任务

创建常规任务。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/wxkits/guide/actions/createTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 任务名称 |
| description | 否 | String | 任务说明 |
| needReview | 是 | Integer | 完成后需要审核 |
| type | 是 | Integer | 任务类型，固定为 6 |
| isCreateSchedule | 否 | Integer | 是否创建日程 |
| startTime | 是 | Long | 有效开始时间 |
| endTime | 是 | Long | 有效结束时间 |
| isRemind | 否 | Boolean | 是否提醒，创建日程时使用 |
| remindBeforeEventSecs | 否 | Long | 提前多久提醒，创建日程时使用。
                                单位：秒 |
| member[0].systemId | 是 | Long | ID，部门 ID 或者人员 ID |
| member[0].name | 是 | String | 名称，部门名称或者人员名称 |
| member[0].isDept | 是 | Boolean | 是否为部门
                                部门：true
                                人员：false |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| data | Long | 任务 ID |
| msg | String | 错误描述，为固定字符串 "success" |
| success | Boolean | 是否成功 |

### 企微API调用适配器

根据主体 ID 和 API 参数通过销售易系统调用企业微信 API。

- 请求方式: `POST`
- API 地址: `/rest/mc/v2.0/wxkits/qwapi/actions/invoke?corpId={corpId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| corpId | 是 | String | 企业 ID，corpId 明文 |
| requestMethod | 是 | String | GET 或者 POST |
| requestUrl | 是 | String | 企业微信 API 的全路径，可直接从 API 文档中把请求地址完整拷贝过来 |
| urlParams | 否 | requestUrl 后需要替换的参数 | ACCESS_TOKEN 可以不用提供，后台会自动处理，其它需要替换的参数组织成 map 放到 urlParams
                                里 |
| postJson | 否 | POST 请求的 body体 | 企业微信 POST 类型 API 的 body 体 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码，200 表示成功 |
| msg | String | 成功为 OK |
| data | JSONObject | 企业微信返回结果的 JSON 格式 |
| success | String | TRUE：API 执行成功
                                FALSE：API 执行失败 |

### 企业微信聊天记录查询

企业微信聊天记录查询。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/wxwork/actions/queryChatRecords`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startTime | 否 | Long | 开始时间 |
| endTime | 否 | Long | 截止时间 |
| pageSize | 否 | Integer | 每页记录数（最大10000） |
| pageNum | 否 | Integer | 页码 |
| keyWord | 否 | String | 内容关键字 |
| msgId | 否 | String | 消息ID |
| msgType | 否 | String | 消息类型 |
| from | 否 | String | 消息发送人 |
| activityRecordId | 否 | Long | 活动记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| from | String | 聊天对象A |
| to | String | 聊天对象B |
| roomName | String | 群聊名称 |
| dataCount | Long | 记录总数 |
| chatRecordList | Array | 聊天记录 |

### 企业微信群发消息

添加企业微信群发任务。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/qywxMsg/actions/batchSendMsg`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户ID |
| source | 是 | Integer | 数据开源1-API 2-营销云 |
| corpId | 否 | String | 企业微信ID |
| appId | 否 | String | 企业微信自建应用ID |
| sender | 否 | String | 企业微信联系人 |
| externalList | 否 | List<String> | 企业微信外部联系集合 |
| senderList | 否 | List<String> | 企业微信内部联系人集合 |
| senderAndExternalList | 否 | JSONArray | 企业微信外部联系人和内部联系人集合 |
| sender | 是 | String | senderAndExternalList中字段 |
| externalList | 是 | List<String> | senderAndExternalList中字段 |
| msg | 是 | JSONObject | 发送消息内容 |
| text.content | 否 | String | 消息文本内容，最多4000个字节 |
| image.media_id | 是 | String | 图片media_id |
| link.title | 是 | String | 图文消息标题 |
| link.picurl | 否 | String | 图文消息封面url |
| link.desc | 否 | String | 图文消息描述最多512个字节 |
| link.url | 是 | String | 图文消息链接 |
| miniprogram.title | 是 | String | 小程序消息标题最多64个字节 |
| miniprogram.pic_media_id | 是 | String | 小程序封面media_id |
| miniprogram.appid | 是 | String | 小程序appId |
| miniprogram.page | 是 | String | 小程序page路径 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 返回码 |
| msg | String | 错误消息 |
| data.msgId | String | 消息ID |

### 企业微信根据时间范围更新群发任务结果

根据时间范围更新群发任务结果。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/qywxMsg/actions/updateMsgResult`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 否 | String | 开始日期 |
| endDate | 否 | String | 结束日期 |
| tenantId | 是 | Long | 租户ID |
| msgId | 否 | String | 任务消息ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 返回码 |
| msg | String | 返回信息 |

### 获取企业微信联系人接口描述

获取企业微信联系人对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwContact/description`

### 获取企业微信联系人信息

根据外部联系人 ID 获取企业微信联系人，crm 数据不存在时，会和微信服务器进行一次同步。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwContact/actions/getByExternalUserId?externalUserId={externalUserId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| externalUserId | 是 | String | 微信外部联系人ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为异常 |
| msg | String | 错误信息 |
| data | object | 具体格式参见返回示例 |

### 查询对象与企业微信联系人手动同步规则

根据对象 ID、实体业务类型 ID 查询实体与企业微信联系人手动方式的字段映射规则。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/qwContact/actions/getManualSyncRule`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 映射对象ID |
| belongTypeId | 否 | Long | 对象业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 200为正常，其他为异常 |
| msg | String | 错误信息 |
| data | object | 具体格式请参考返回示例。返回结果表示crm联系人与企业微信联系人之间的字段映射，其中主要有用的信息在syncMappings数组中：
                其中targetItem表示crm联系人的字段
                  apiKey，sourceType=1时，sourceValue表示对应的企业微信联系人的字段apiKey，sourceType=2时，crm联系人的targetItem
                  字段取值为固定的值，即是sourceValue的值；formula、syncConditions、syncCences暂不用 |

### 查询CRM系统用户ID和第三方用户ID的关系

查询 UserId 和第三方账号的关系。

- 请求方式: `GET`
- API 地址: `/rest/auc/v2.0/third-party/actions/id-mapping`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户ID |
| userIds | 是 | String | CRM系统用户ID，多个用户ID之间用逗号分隔 |
| source | 否 | Long | 三方认证来源企业微信：qywx微信：weixin如不填该参数，则默认附加企业微信参数查询 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| third_uid | String | 第三方用户ID |
| user_id | Long | CRM系统用户ID |
| corpid | Long | 企业ID |

### 将CRM系统用户ID和第三方用户ID绑定

将三方用户 IDs 与销售易 CRM 用户 IDs 进行绑定，如果绑定的三方用户 ID 已经关联了对应的 CRM UserID，则更新绑定关系。

- 请求方式: `POST`
- API 地址: `/rest/auc/v2.0/third-party/actions/id-mapping`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户ID |
| idMapping | 是 | JSONArray | CRM UserID和三方用户ID的绑定数据集 |
| source | 是 | String | 三方认证来源
                企业微信：qywx
                微信：weixin |
| corpid | 否 | Long | 企业ID |

### 将CRM系统用户ID和第三方用户ID解除绑定

将销售易 CRM 用户 IDs 与三方用户 IDs 进行解绑，如果传入的 CRM 用户 ID 没有与三方用户的绑定，则默认返回成功。

- 请求方式: `DELETE`
- API 地址: `/rest/auc/v2.0/third-party/actions/id-mapping`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户ID |
| userIds | 是 | Long | CRM用户ID，多个用逗号分隔 |
| source | 否 | String | 三方认证来源企业微信：qywx微信：weixin可不填，默认为企业微信参数查询。如果传入参数”all”，则清除该用户下所有 |

### 企业微信最近访问列表

记录某条实体数据到系统中，用于实现用户最近访问列表。

- 请求方式: `POST`
- API 地址: `/data/v2.0/social/recentAccess`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 实体API key |
| dataId | 是 | Long | 记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| success | Boolean | 为true表示成功，false表示失败 |
| code | Integer | 错误码，200表示成功 |
| msg | String | 成功是为success，错误是为错误信息 |
| data | String | JSON对象 |

### 获取租户安装应用列表

根据租户 ID 获取安装应用的 suiteId 列表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/qywx/actions/getSuiteIdsByTenantId?tenantId={tenantId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户ID，不能为空 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| success | Boolean | true：成功false：失败 |
| code | Integer | 错误码，200表示成功 |
| msg | String | 成功是为success，错误是为错误信息 |
| data | String | suiteId列表 |

### 企业微信会话列表查询

查询和某人聊过天的人和群列表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/wxwork/actions/queryChatSessionsByUserId?userId={userId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 否 | Long | 开始时间 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | String | 当 groupChatFlag 为 true 时为群 ID，当 groupChatFlag 为 false 时为 userId |
| avatar | String | JSON 格式头像信息，groupChatFlag 为 true 时不返回 |
| name | String | 当 groupChatFlag 为 true 时为群聊名称，当 groupChatFlag 为 false 时为人昵称 |
| groupChatFlag | String | 群聊标识，为 true 表示群信息，为 false 表示人员信息 |

### 生成企微自定义主页地址

生成企微自定义主页地址。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/inner/wxApps/actions/generator-url`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| tenantId | 是 | Long | 租户 ID |
| bizType | 是 | Integer | 默认 2 |
| mainUrl | 是 | String | 生成的地址不带域名 |
| agentId | 是 | String | 企微自建 agentId |
| corpId | 是 | String | 企微 corpId |
| appType | 是 | Integer | 应用类型 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| scode | String | 错误码信息200：成功 |
| error_msg | String | 错误信息 |
| result | String | 成功时返回主页 url |

---

## 协同API接口

### 创建日程

创建日程。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/schedule/actions/createScheduleWithMember`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| startDate | 是 | Long | 日程开始时间，如果是重复日程，必须是日程首次发生的开始时间 |
| endDate | 是 | Long | 日程结束时间，如果是重复日程，必须是日程首次发生的结束时间 |
| Interval | 否 | Integer | 重复间隔（例如：每两天） |
| name | 是 | String | 日程名称 |
| description | 否 | String | 日程描述 |
| address | 否 | String | 地址 |
| isAllDay | 是 | Integer | 是否为全天
                0：否
                1：是 |
| isRecur | 是 | Integer | 是否重复事件
                0：否
                1：是 |
| frequency | 否 | Integer | 重复频率
                0：否
                1：按天重复
                2：按周重复
                3：按月重复
                4：按年重复 |
| recurStopCo | 否 | Integer | 中止条件
                0：无
                1：永不截止
                2：按时间截止 |
| recurStopValue | 否 | Long | 中止条件值 |
| entityBelongId | 否 | Long | 关联对象 ID |
| entityObjectId | 否 | Long | 关联数据 ID |
| isPrivate | 否 | Integer | 是否私密
                0：否
                1：是 |
| type | 否 | Long | 日程类型 ID |
| finalFinishTime | 否 | Long | 最终结束时间 |
| reminder | 否 | Long | 日程开始提醒时间（距离开始时间的秒值） |
| members | 是 | String | 日程成员 ID，半角逗号分隔 |
| allowJoin | 否 | Integer | 是否允许成员邀请参与人
                0：否
                1：是 |
| day | 否 | String | 每月 X 号发生（例如，每月 10 号重复：“10”），按日/年重复时必填 |
| week | 否 | String | 每周 X 发生（例如，每周三重复：“3”），按周重复时必填 |
| month | 否 | String | 每年 X 月 Y 日发生（例如，每年 1 月 1 日重复：“1”），按年重复时必填 |
| customItem123_c | 否 | X | 自定义字段，类型由具体的自定义字段决定 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码（200 为成功） |
| msg | String | 返回消息 |
| result | JSON | 返回结果，内含日程 ID |

### 合并日程

合并日程。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/schedule/actions/transferRelationObject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象 ID |
| fromRecordId | 是 | Long | from 数据 ID |
| toRecordId | 是 | Long | to 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 错误码 |
| msg | String | 结果说明 |
| ext | JSONArray | 扩展数据 |
| result | Object | 业务结果 |

### 删除日程

根据需要删除单个日程，当前日程、当前以及未来日程、全部日程等。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/schedule/actions/deleteSplitNoCheck`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| scheduleId | 是 | Long | 需要删除的日程 ID |
| updateType | 是 | Integer | 日程类型：
                                单个日程
                                    当前日程
                                    当前以及未来日程
                                    全部日程 |
| queryDate | 是 | String | 当前日期（例如：2020-1-17） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | Object | 附加信息，默认为空 |

### 查询对象下的日程

查询对象下的日程。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/schedule/actions/getScheduleByObjectInfo?objectId={objectId}&recordId={recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象 ID |
| recordId | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 结果码 |
| msg | String | 结果说明 |
| ext | JSONArray | 扩展数据 |
| result | Object | 业务结果 |

### 获取日程成员信息

获取日程成员的详细信息。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/xobjects/schedule/getScheduleMember/{scheduleId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| scheduleId | 是 | Long | 日程数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 成功返回值为200，失败时为对应的错误码说明 |
| msg | String | 执行信息 |
| ext | JSONArray | 额外信息，Array中每个对象都是一JSONObject |
| result | JSONObject | 实际信息 |

### 创建任务

创建任务。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/task/actions/createTaskWithMember`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| taskName | 是 | String | 任务名称 |
| planFinishDate | 是 | Long | 计划完成时间 |
| planStartDate | 是 | Long | 计划开始时间 |
| ownerId | 是 | Long | 任务所属人ID |
| startReminder | 否 | Long | 开始提醒时间 |
| finishReminder | 否 | Long | 结束提醒时间 |
| entityBelongId | 否 | Long | 业务类型ID |
| entityObjectId | 否 | Long | 对象ID（与belongId成对出现） |
| description | 否 | String | 任务描述 |
| memberIds | 否 | String | 任务成员ID（多个成员时，用半角逗号分隔） |
| customItem123_c | 否 | X | 自定义字段，类型由具体的自定义字段决定 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码（200为成功） |
| msg | String | 返回消息 |
| result | JSON | 返回结果，内含任务ID |

### 更新任务数据

更新任务数据接口。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/{api_key}/actions/update?dataId=`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| api_key | 是 | String | 对象名称 |
| dataId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 成功返回值为200，失败时为对应的错误码说明 |
| msg | String | 返回信息 |
| ext | JSONArray | 额外信息，Array中每个对象都是一个JSONObject |
| result | JSONObject | 实际信息 |

### 删除任务数据

删除单条任务数据。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/task/actions/deleteNoCheck`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 任务数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 成功时返回值为200，失败时返回值为对应的错误码 |
| msg | String | 执行信息 |
| ext | JSONArray | 额外信息，Array中每个对象都是一JSONObject |
| result | JSONObject | 实际信息 |

### 获取任务元数据详情

查询获取元数据数据列表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{api_key}/description`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| api_key | 是 | String | 任务（task）/日程（schedule） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| apikey | String | 字段属性 |
| label | String | 字段名称 |
| type | String | 数据库字段类型 |
| itemType | String | Java类型 |
| defaultValue | Integer | 字段默认值 |
| enabled | Integer | 是否可用 |
| required | Integer | 是否必填 |
| createable | Integer | 能创建 |
| updateable | Integer | 能更新 |
| sortable | Integer | 可排序 |
| minLength | Integer | 最小长度 |
| maxLength | Integer | 最大长度 |
| dependentPropertyName | String | 依赖属性名称 |
| unique | Integer | 是否唯一 |
| selectitem | Array | 单选数组值 |
| checkitem | Array | 多选数组值 |
| records | Object | 字段属性list |

### 查询获取任务分页列表数据

获取分页列表数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{api_key}/actions/pagination?pageNo={pageNo}&pageSize={pageSize}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pageNo | 否 | Integer | 第几页 |
| api_key | 是 | String | 对象名称 |
| pageSize | 否 | Integer | 页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Data | String | 发送成功提示语 |
| Msg | String | 成功还是异常 |

### 查询对象下的任务

查询对象下的任务。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/task/actions/getTaskByObjectInfo?objectId={objectId}&recordId={recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象 ID |
| recordId | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 错误码 |
| msg | String | 结果说明 |
| ext | JSONArray | 扩展数据 |
| result | Object | 业务结果 |

### 合并任务

合并任务。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/task/actions/transferRelationObject/`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象 ID |
| fromRecordId | 是 | Long | from 数据 ID |
| toRecordId | 是 | Long | to 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 结果码 |
| msg | String | 结果说明 |
| ext | JSONArray | 扩展数据 |
| result | Object | 业务结果 |

### 查询待办

查询人员待办数据。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/todo/actions/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 查询指定人待办 |
| todoTypes | 是 | Array | 查询待办类型["apply","task","schedule","weekreport"] |
| pageNo | 是 | Integer | 页码 |
| pageSize | 是 | Integer | 页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| schedule | Object | 待办日程对象 |
| task | Object | 待办任务对象 |
| apply | Object | 待办审批对象 |
| weekreport | Object | 待办工作报告对象 |
| dataCount | Integer | 数据数量 |
| todoType | String | 待办类型 |
| hasMore | Boolean | 是否还有数据 |
| list | Array | 待办数据数组 |
| createdAt | Long | 创建时间 |
| createdBy | Long | 创建人 |
| name | String | 待办名称 |
| id | Long | 待办ID |
| applyId | Long | 审批ID（审批待办） |
| belongId | Long | 关联业务ID |
| title | String | 审批标题（审批待办） |
| reportDate | Long | 报告日期（工作报告待办） |

### 查询通知列表

查询通知列表数据。

- 请求方式: `GET`
- API 地址: `/rest/notice/v2.0/notice/actions/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户 ID |
| pageNo | 是 | Integer | 页码 |
| pageSize | 是 | Integer | 页大小（默认20条） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| content | String | 列表通知条目的title |
| notice | Object | 通知对象 |
| Id | Long | 通知ID |
| sourceId | Long | 发起通知人ID |
| typeFlg | Integer | 新旧通知标识（0、null表示旧，表示是新） |
| systemId | Integer | 通知系统ID |
| hasMore | Boolean | 是否还有数据 |
| targetId | Long | 接收通知ID |
| operateId | Long | 对象下条目ID |
| noticeType | Integer | 通知类型 |
| content | String | 通知数据库存储数据（需要多样化通知形式需要解析它） |
| appType | Integer | 来自应用通知类型 |
| applyId | Long | 审批ID（审批待办） |
| belongId | Long | 关联业务ID |
| tenantId | Long | 租户ID |
| status | Long | 通知状态 |
| dataCount | Integer | 总数 |
| group | Object | 群组或者团队成员部门group信息 |
| groupurl | String | 有group信息就有跳转的group的URL |
| user | Object | 发起通知人的信息 |
| currentUser | Object | 登录人信息 |

### 发送通知（支持新消息体结构）

新消息体结构发送通知。

- 请求方式: `POST`
- API 地址: `/rest/notice/v2.0/newNotice`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| publisherId | 否 | Long | 发送人ID，为空的时候默认取当前用户ID
                （在JSON中和belongId同级） |
| noticeType | 否 | Integer | 通知类型0：系统通知1：提醒（默认是0） |
| belongId | 否 | Long | 关联对象ID |
| objectId | 否 | Long | 关联对象itemId |
| content | 是 | String | 消息内容 |
| mergeFieldsIndex | 否 | Integer | 是从mergeFileds选取下标（从0开始）跳转标识 |
| receivers | 是 | Array | 接收通知的List |
| id | 是 | Long | 接收消息的ID |
| receiverType | 是 | Integer | 接收消息的类型（人，部门，群组）类型 |
| mergeFields | 是 | Object | 填充消息体参数结构 |
| type | 是 | Integer | 跳转链接类型1：关联对象2：内部链接3：外部链接 |
| label | 是 | String | 自定义超链显示的名称 |
| customLink | 否 | String | type为2、3时必填
                type为2代表销售易系统内部链接
                type为3代表外部链接 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Data | String | 发送成功提示语 |
| Msg | String | 成功还是异常 |

### 查询考勤统计记录

根据全公司、个人或者部门来查询考勤统计记录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/attendance/actions/getAttendanceStatistics`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| type | 是 | Integer | 1：全公司
                                2：个人
                                3：部门 |
| id | 否 | Long | 查全公司不传，查个人传用户ID，查部门传部门ID |
| startTime | 是 | Long | 开始时间 |
| endTime | 是 | Long | 结束时间（最大不超多90天） |
| pageNo | 否 | Integer | 分页码 |
| pageSize | 否 | Integer | 分页大小（最大 20，超过 20 按 20 计算） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Integer | 考勤记录总数 |
| count | Integer | 当前页数量 |
| id | Long | 考勤记录ID |
| userId | Long | 用户ID |
| recordDate | Long | 打卡日期 |
| workingBegin | Long | 上班时间 |
| workingEnd | Long | 下班时间 |
| lateReason | String | 迟到原因 |
| earlyReason | String | 早退原因 |
| recordBegin | Long | 打卡开始 |
| recordEnd | Long | 打卡结束 |
| errorState | String | 打卡状态1：正常2：迟到3：早退4：不完整打卡5：外勤6：设备异常7：缺勤8：拜访客户 |
| approvalReason | String | 审批原因 |
| approvalStatus | Short | 审批状态1：审批中2：同意3：拒绝 |
| approva | Long | 审批 |
| approvalTime | Long | 审批时间 |
| timezone | String | 时区 |
| workBeginAddr | Map | 上班打卡位置 |
| workEndAddr | Map | 下班打卡位置 |
| longitude | Double | 经度 |
| latitude | Double | 纬度 |
| location | String | 位置 |

### 查询打卡记录

查询个人的打卡记录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/attendance/actions/getAttendanceRecords`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |
| startTime | 是 | Long | 开始时间 |
| endTime | 是 | Long | 结束时间（最小颗粒度是天，最大不超过 90 天） |
| pageNo | 否 | Integer | 分页码 |
| pageSize | 否 | Integer | 分页大小（最大 20， 超过 20 按 20 计算） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Integer | 考勤记录总数 |
| count | Integer | 当前页数量 |
| id | Long | 考勤记录ID |
| userId | Long | 用户ID |
| recordDate | Long | 打卡日期 |
| recordTime | Long | 打卡时间 |
| longitude | Double | 经度 |
| latitude | Double | 纬度 |
| location | String | 位置 |
| equipmentNumber | String | 设备编号 |
| areaFlag | Short | 是否在考勤点 |

### 公告类别接口

查询公告的类别，包括部门公告、伙伴公告、默认部门公告。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/announcement/actions/getTypeList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| isPartner | 否 | Integer | 是否伙伴公告类型
                                0：部门公告
                                1：伙伴公告 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 分类名称 |
| id | Long | 分类ID |

### 公告列表接口

根据条件分页查询公告的列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/announcement/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| departId | 否 | Long | 伙伴ID |
| userId | 否 | Long | 伙伴用户ID |
| type | 否 | Long | 公告类型 |
| title | 否 | String | 标题 |
| pageNo | 否 | Integer | 页码 |
| pageSize | 否 | Integer | 页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 分类名称 |
| title | String | 标题 |
| summary | String | 摘要 |
| annoStatus | Integer | 状态
                0：草稿
                1：已发布 |
| typeId | Long | 公告类型 |
| stick | Integer | 是否置顶
                0：否
                1：是 |
| createdAt | Long | 创建时间 |
| createdBy | Long | 创建人 |
| publishAt | Long | 发布时间 |
| publishName | String | 发布人 |
| imgUrl | String | 图片 |
| annoType | Integer | 公告类别
                0：部门公告
                1：伙伴公告 |

### 公告详情

根据公告 ID 查询公告详情。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/announcement/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 公告ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 分类名称 |
| title | String | 标题 |
| summary | String | 摘要 |
| annoStatus | Integer | 状态
                0：草稿
                1：已发布 |
| typeId | Long | 公告类型 |
| stick | Integer | 是否置顶
                0：否
                1：是 |
| createdAt | Long | 创建时间 |
| createdBy | Long | 创建人 |
| publishAt | Long | 发布时间 |
| publishName | String | 发布人 |
| files | Array | 附件 |
| content | String | 公告内容富文本 |

### 关注业务对象

关注业务对象，可以在首页工作圈收到业务对象下的动态。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/follow/action/batchFollowObjects`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 对象ID |
| dataId | 是 | Long | 对象数据ID，和belongId组合表示业务对象的一条数据 |
| userId | 否 | Long | 用户ID。为空时，默认为当前用户（此用户必须有对象的访问权限） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态信息 |

### 取消对业务对象的关注

取消对业务对象的关注，首页工作圈不再收业务对象下的动态。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/social/follow/action/batchUnfollowObjects`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 对象ID |
| dataId | 是 | Long | 对象数据ID，和belongId组合表示业务对象的一条数据 |
| userId | 否 | Long | 用户ID。为空时，默认为当前用户（此用户必须有对象的访问权限） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态信息 |

### 获取对象下动态列表

获取对象下动态列表。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/social/story/actions/getObjectFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 对象实体ID |
| objectId | 是 | Long | 对象数据ID |
| page | 否 | Integer | 页码，默认1 |
| size | 否 | Integer | 每页条数，默认20 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态消息 |
| data | Long | 创建的动态ID |

### 查询关注的所有对象

根据 userId 查询关注的所有对象。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/follow/actions/getUserFollowGroups`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户实体ID |
| startTime | 否 | Long | 开始关注时间，默认0 |
| endTime | 否 | Integer | 结束关注时间，默认当前时间值 |
| page | 否 | Integer | 页码，默认1 |
| size | 否 | Integer | 每页条数，默认5000 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态消息 |
| result | Long | 结果数据集 |
| isEntity | Long | 0：非标准实体，1：标准实体 |
| belongId | Long | 业务ID |
| objectId | Long | 对象ID |

### 获取费用接口描述

获取费用对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/expense/description`

### 创建费用

创建费用。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/expense`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| expenseName | 是 | String | 费用名称 |
| money | 是 | Double | 金额 |
| entityType | 是 | Long | 业务类型 |
| status | 是 | Short | 状态 |
| expenseType | 是 | Long | 费用类型ID |
| occurrenceDate | 是 | Long | 发生日期时间戳 |
| comment | 否 | String | 备注 |
| relateEntity | 否 | Long | 关联业务的类型 |
| relateEntity_data | 否 | Long | 关联业务的数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 费用ID（唯一标识） |
| objectApiKey | String | 对象Apikey |
| busiType | Long | 对象的业务类型 |
| name | String | 对象的主字段名称 |

### 更新费用

更新费用。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/expense/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 费用ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 费用ID（唯一标识） |

### 删除费用

删除费用。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/expense/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 费用ID |

### 获取费用信息

获取费用信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/expense/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 费用ID |

### 动态收藏

收藏动态。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/addFavorite`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| storyId | 是 | Long | 动态ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 取消动态收藏

取消动态收藏。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/deleteFavorite`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| storyId | 是 | Long | 动态ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 我的关注

我关注的动态。

- 请求方式: `POST`
- API 地址: `rest/data/v2.0/social/story/actions/indexFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 我的收藏

我收藏的动态。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/favoritesFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 我的部门

我部门的动态。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/groupFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |
| groupId | 是 | Long | 群组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 我的发布

我发布的动态。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/profileFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |
| objectId | 是 | Long | 群组ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 我的公开

我公开的动态。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/companyFeeds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 动态评论列表

查询动态评论。

- 请求方式: `GET`
- API 地址: `rest/data/v2.0/social/story/actions/commentList`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 大小 |
| objectId | 是 | Long | 动态ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| result | String | 响应 |
| ext | String | 扩展信息 |

### 工作圈和对象下发送动态

通过接口实现在工作圈和对象下发送动态信息（文本、图片、文件），文件和图片需要先通过文件上传接口上传。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/story`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 否 | Long | 对象 ID，为空时表示在工作圈发送动态 |
| objectId | 否 | Long | 对象数据 ID
                                和 belongId 组合表示在对象下发送动态。
                                为空时表示在工作圈发送动态 |
| userId | 否 | Long | 动态发送人 |
| content | 是 | String | 动态内容 |
| uploadFileType | 否 | Integer | 空：纯文本
                                0：普通文件
                                1：图片 |
| fileDescription | 否 | String | 当发送文件和图片动态时，描述文件 |
| fileInfo | 否 | Object | uploadFileType=0 时，上传的文件 JSON 对象，每次发送一个文件。关于 JSON
                                结构的详细信息请参考请求示例 |
| imageFiles | 否 | Array | uploadFileType=1 时，上传多个图片信息的 JSON 数组，每次最多可以发送 9 张。关于 JSON
                                    结构的详细信息请参考请求示例 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态消息 |
| data | Long | 创建的动态 ID |

### 获取评论列表

查询对象下的评论列表，支持按时间戳、用户 ID 等维度进行查询。

- 请求方式: `GET`
- API 地址: `/rest/comment/v2.0/query/comments/{systemId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| systemItemId | 否 | Long | 业务的数据 ID，例如动态等 |
| userId | 否 | Long | 用户 ID |
| startCreateTime | 否 | Long | 开始时间，单位精确到秒 |
| endCreateTime | 否 | Long | 结束时间，单位精确到秒 |
| page | 否 | Integer | 页码 |
| size | 否 | Integer | 每页显示条数 |
| systemId | 是 | Integer | 评论的 systemId 为 607 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码 |
| msg | String | 编码信息 |
| data | JSON | 响应数据 |

### 查询公司通讯录

查询公司通讯录。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/colleague/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userType | 否 | Integer | 0：内部
                                1：外部 |
| pageNo | 是 | Integer | 页码 |
| pageSize | 是 | Integer | 分页大小 |
| key | 否 | Long | 检索关键字 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Integer | 考勤记录总数 |
| count | Integer | 当前页数量 |
| userId | Long | 用户ID |
| userName | Long | 用户名 |
| departId | Long | 部门ID |
| departName | Long | 部门名称 |
| pinyin | Long | 姓名拼音 |
| icon | String | 图像URL |
| smallIcon | String | 小图像URL |
| positionName | Long | 职位 |
| phone | Long | 电话 |
| telephone | String | 手机号码 |
| userType | String | 内外部标识 |
| personalEmail | Short | 电子邮箱 |

### 创建文档目录

在知识库中创建文档目录。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/createDirectory`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| dataId | 是 | Long | 数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| parentId | 否 | Long | 父目录 ID，对应查询接口中的 source_id |
| directoryName | 是 | string | 文档目录名 |
| visibility | 否 | Int | 是否可见
                                0：全部可见
                                1：部分可见
                                默认值 1 |
| upload | 否 | Int | 是否允许上传
                                0：允许
                                1：不允许
                                默认值 0 |
| download | 否 | Int | 是否允许下载
                                0：允许
                                1：不允许
                                默认值 0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 新建的文档目录 ID |

### 文档目录授权

将知识库中已有的文档目录授权给指定人员，不校验文档操作权限。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/directoryAuthUser`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| directoryId | 是 | Long | 文档目录 ID，对应查询接口中的 source_id |
| userId | 是 | Long | 人员 ID |
| upload | 否 | Int | 是否允许上传
                                0：允许
                                1：不允许
                                默认值 0 |
| download | 否 | Int | 是否允许下载
                                0：允许
                                1：不允许
                                默认值 0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 文档目录 ID |

### 转移文档目录

转移知识库中的文档目录，不校验当前用户的操作权限。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/transferDirectory`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fromBelongId | 是 | Long | 原业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| fromDataId | 是 | Long | 原数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| directoryId | 是 | Long | 文件目录 ID，对应查询接口中的 source_id |
| toBelongId | 是 | Long | 目标业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| toDataId | 是 | Long | 目标数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| toParentId | 否 | Long | 目标父目录 ID
                                为空时，转移到目标知识库根目录下 |
| fromBelongId | 是 | Long | 原业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 文档目录 ID |

### 删除文档目录

删除知识库中的文档目录，不校验当前用户的操作权限。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/document/actions/deleteDirectory`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| directoryId | 是 | Long | 文件 ID，对应查询接口中的 source_id |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 文档目录 ID |

### 上传文档

上传文档文件，并关联到知识库或者业务对象的文档组件下，默认同步显示在个人知识库。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/batchUploadAndBindObject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| files | 是 | File | 可以上传多个 file，最多不超过 10 个，每个文件不超过 200 M |
| belongId | 否 | Long | 业务对象 belongId
                                用户：70
                                部门：50
                                群组：40
                                公共知识库：0
                                belongId 和 dataId 为空时，上传到当前用户的个人知识库 |
| dataId | 否 | Long | 业务数据 ID，用户 ID，部门 ID，群组 ID；公共知识库
                                ID（-1001-公司知识库，-1002-伙伴知识库【额外附带-1003-所有伙伴】） |
| directoryId | 否 | Long | 上传到目录下，对应查询接口中的 source_id |
| accessRole | 否 | Int | 访问角色
                                1：查看者
                                2：编辑者
                                默认值：1 |
| visibility | 否 | Int | 是否可见
                                0：全部可见
                                1：部分可见
                                默认值：0 |
| download | 否 | Int | 是否允许下载
                                0：允许下载
                                1：不允许下载
                                默认值：0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |
| fileId | Long | 上传的知识库文档 ID，对应查询接口中的 source_id |

### 文档授权

将知识库中已有的文档授权给指定人员，不校验文档操作权限。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/fileAuthUser`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fileId | 是 | Long | 文件 ID，对应查询接口中的 source_id |
| userId | 是 | Long | 人员 ID |
| accessRole | 否 | Int | 访问角色
                                1：查看者
                                2：编辑者
                                默认值 1 |
| download | 否 | Int | 是否允许下载
                                0：允许
                                1：不允许
                                默认值 0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |

### 转移文档

转移知识库中的文档，不校验当前用户的操作权限。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/transferFile`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fromBelongId | 是 | Long | 原业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| fromDataId | 是 | Long | 原数据 ID
                                业务数据 ID，用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| fileId | 是 | Long | 知识库文档 ID，对应查询接口中的 source_id |
| toBelongId | 是 | Long | 目标业务 ID
                                业务对象belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| toDataId | 是 | Long | 目标数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |

### 删除文档

删除知识库中的文档，不校验当前用户的操作权限。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/document/actions/deleteFile`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fileId | 是 | Long | 知识库文档 ID，对应查询接口中的 source_id |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |

### 查询文档和文档目录

根据条件查询知识库中的文档及文档目录数据。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/document/actions/getDocuments`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 否 | Long | 业务 ID
                                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| dataId | 否 | Long | 数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| directoryId | 否 | Long | 文档目录，表示查询一个目录下的文档，对应查询接口中的 source_id |
| displayType | 否 | Long | 1：个人知识库（文件上传人）
                                0：非个人知识库
                                值为空时，查询知识库下所有数据，返回的结果需要根据source_id去重。
                                        值为空时，当belongId=70，dataId=用户 ID
                                            表示查询个人知识库文档和授权给用户的文档。
                                        值为 0 时，当 belongId=70，dataId=用户 ID 表示查询授权给用户的文档。 |
| sourceType | 否 | Long | 0：文档
                                1：文件夹 |
| pageNo | 是 | int | 页码 |
| pageSize | 是 | int | 页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 新建的文档目录 ID |
| sourceId | Long | 文档 ID 或文件夹 ID |
| sourceType | int | 0：文档
                                1：文件夹 |
| accesRole | int | 访问角色
                                0：无
                                1：查看者
                                2：协作者
                                3：所有者 |
| authorType | int | 权限类型默认
                                0：内部
                                1：合作伙伴 |
| specialSet | int | 特殊设置
                                0：允许下载
                                1：不允许下载 |
| specialSet2 | int | 文件夹是否允许上传
                                0：允许
                                1：不允许 |
| disObjType | int | 1：个人知识库
                                0：其他对象 |
| visibolity | int | 可见性
                                0：全部可见
                                1：部分可见 |
| entityBelongId | Long | 关联业务 |
| entityObjectId | Long | 关联业务数据 |
| dirId | Long | 父文件夹 ID |
| file | object | 文档 |
| file.filename | string | 文档名 |
| file.filetype | int | 文档类型
                                0：文件
                                1：图片
                                2：音频
                                3：视频 |
| file.fileurl | string | 文档地址 |
| file.filelength | Long | 文档大小 |
| file.content | string | 上传文旦附带信息 |
| file.viewTimes | int | 浏览数 |
| file.downloadTimes | int | 下载数 |
| file.starRate | int | 关注数 |
| file.status | int | 文档状态（文档转换的中间状态） |
| file.shareFlag | int | 是否允许互联网分享
                                0：不允许
                                1：允许
                                默认值 0 |
| file.shareDownload | int | 分享出去是否允许下载
                                1：不允许
                                0：允许
                                默认值 0 |
| file.fileMetaId | Long | 文档元文件 ID |
| file.syncStatus | int | 是否同步素材库
                                0：未同步
                                1：同步 |
| file.id | Long | 文档 ID |
| directory | object | 文档目录 |
| directory.id | Long | 文档目录 ID |
| directory.directoryName | string | 文档目录名称 |
| directory.syncStatus | int | 是否同步素材库
                                0：未同步
                                1：同步 |

### 文档绑定到对象

将知识库中已有的文档绑定到其他业务对象。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/bindObject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 业务 ID
                                业务对象belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| dataId | 是 | Long | 数据 ID
                                业务数据 ID、用户 ID、部门 ID、群组 ID、公共知识库
                                    ID（-1001-公司知识库，-1002-伙伴知识库【额外附带-1003-所有伙伴】） |
| fileId | 是 | Long | 文件 ID，对应查询接口中的 source_id |
| directoryId | 否 | Long | 绑定的父文件夹，根目录设置为-1，对应查询接口中的 source_id |
| accessRole | 否 | Int | 访问角色
                                1：查看者
                                2：编辑者
                                默认值 1 |
| visibility | 否 | Int | 是否可见
                                0：全部可见
                                1：部分可见
                                默认值 0 |
| download | 否 | Int | 是否允许下载
                                0：允许
                                1：不允许
                                默认值 0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |
| dealCount | Int | 删除数量，删除则为 1 |

### 文档解绑业务对象

将知识库中已有的文档从业务对象中移除。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/unbindObject`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 业务 ID
                业务对象 belongId，用户-70，部门-50，群组-40，0-公共知识库 |
| dataId | 是 | Long | 数据 ID
                业务数据 ID、用户 ID、部门 ID，群组 ID、公共知识库 ID（-1001-公司知识库，-1002-伙伴知识库，-1003-所有伙伴） |
| fileId | 是 | Long | 文件ID，对应查询接口中的 source_id |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |

### 批量下载对象下文档

批量下载一个对象下的多个对象关联的所有文档，异步下载，成功后给用户发送通知。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/document/actions/batchDownloadByObjects`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 是 | Long | 对象的belongId |
| objectIds | 是 | String | 对象ID（多个以英文逗号分隔） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码 |
| msg | String | 状态消息 |

### 对象下知识库锁定

根据对象的 objectId 和 dataId，锁定对象下知识库，控制上传及其他操作。

- 请求方式: ``
- API 地址: `/rest/data/v2.0/social/twitterFile/actions/lockByEntity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象ID |
| dataId | 是 | Long | 对象数据ID |

### 对象下知识库解除锁定

根据对象的 objectId 和 dataId，解除锁定对象下知识库。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/social/twitterFile/actions/lockByEntity`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectId | 是 | Long | 对象ID |
| dataId | 是 | Long | 对象数据ID |

### 批量打包下载文件

根据元文件 ID 批量打包下载文件，异步下载，完成后会在通知中提醒，请在通知中下载打包好的文件。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/batchDownloadByMetaFileIds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | List<Long> | 文件ID数组 |
| jobName | 否 | String | 打包的任务名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 错误码 |
| msg | String | 错误信息 |

### 通过文fileMetaId分层级压缩下载文件

通过文件 fileMetaIdList 分层级压缩下载文件，完成后会在通知中提醒，请在通知下载打包好的文件。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/batchDownloadFolderByMetaFileIds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| zipName | 是 | String | 压缩包名称，字符串中只包含中文、字母、数字、下划线、横线，否则会进行替换 |
| firstLevelFolders | 是 | Array | 一层目录列表 |
| name | 是 | String | 目录名称，字符串中只包含中文、字母、数字、下划线、横线，否则会进行替换 |
| ids | 是 | List<Long> | 文件ID列表 |
| secondaryFolders | 否 | Array | 二层目录列表，当三级目录存在时必须存在 |
| thirdLevelFolders | 否 | Array | 三层目录列表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 错误码 |
| msg | String | 错误信息 |

### 打包下载文档

根据文档 ID 批量打包下载文档。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/document/actions/batchDownloadByFileIds`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| ids | 是 | Long | 知识库中文档ID |
| userId | 是 | Long | 接收压缩包的用户ID |

### 更新知识库文档

更新知识库文档。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/twitterFile/actions/updateFile/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 待更新的文件 ID |
| updateReason | 否 | String | 更新原因 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 请求结果码 |
| msg | String | 请求结果信息 |
| result | JSON | 返回数据 |
| fileId | long | 更新的文件 ID |

### 获取报销单接口描述

获取报销单对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/expenseaccount/description`

### 创建报销单

创建报销单。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/expenseaccount`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| title | 是 | String | 标题 |
| money | 是 | Double | 金额 |
| entityType | 是 | Long | 业务类型 |
| status | 是 | Short | 状态 |
| comment | 否 | String | 备注 |
| relateEntity | 否 | Long | 关联业务的类型 |
| relateEntity_data | 否 | Long | 关联业务的数据ID |
| relateApplyType | 否 | Long | 审批单的类型 |
| relateApplyId | 否 | Long | 审批单的ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 报销单ID（唯一标识） |
| objectApiKey | String | 对象Apikey |
| busiType | Long | 对象的业务类型 |
| name | Long | 对象的主字段名称 |

### 更新报销单

更新报销单。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/expenseaccount/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 报销单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 报销单ID（唯一标识） |

### 删除报销单

删除报销单。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/expenseaccount/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 报销单ID |

### 获取报销单信息

获取报销单信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/expenseaccount/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 报销单ID |

### 查询对象下提交给我的工作报告

查询对象下提交给我的工作报告列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/workreport/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| workReportType | 是 | Integer | 工作报告类型1：日报2：为周报3：为月报 |
| pageNo | 否 | Integer | 分页码 |
| pageSize | 否 | Integer | 分页大小 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| report_count | Integer | 工作报告总数 |
| date | String | 日期 |
| fileName | String | 关联文件名 |
| entityObjectId | Long | 对象ID |
| timezone | String | 时区 |
| entityBelongId | Long | 业务ID |
| type | Long | 类型 |
| content | String | 内容 |
| score | Integer | 分数 |
| createdAt | Integer | 创建时间 |
| createdBy | Long | 创建人 |
| updatedAt | Long | 更新时间 |
| updatedBy | Long | 更新人 |
| draft | Integer | 草稿标志 |
| fileUrl | String | 文件URL |
| id | Long | 工作报告ID |
| plan | String | 计划 |
| currencyUnit | String | 货币单位 |
| submitAt | Long | 提交时间 |
| deleteFlg | Short | 是否删除 |
| tenantId | Long | 租户ID |
| recipient | Long | 抄送人 |
| currencyRate | Double | 货币汇率 |
| status | Short | 状态 |
| dbcDate1 | String | 自定义字段 |
| dbcTextarea1 | String | 自定义字段 |

### 查询工作报告详情

查询工作报告详情。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/workreport/actions/detail`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| reportId | 是 | Long | 工作报告ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| copyUsers | String | 抄送人 |
| isFav | Boolean | 是否收藏 |
| id | Long | 关联的对象ID |
| name | String | 关联的对象名字 |
| date | String | 日期 |
| fileName | String | 关联文件名 |
| entityObjectId | Long | 对象ID |
| timezone | String | 时区 |
| entityBelongId | Long | 业务ID |
| type | Long | 类型 |
| content | String | 内容 |
| score | Integer | 分数 |
| createdAt | Integer | 创建时间 |
| createdBy | Long | 创建人 |
| updatedAt | Long | 更新时间 |
| updatedBy | Long | 更新人 |
| draft | Integer | 草稿标志 |
| fileUrl | String | 文件URL |
| id | Long | 工作报告ID |
| plan | String | 计划 |
| currencyUnit | String | 货币单位 |
| submitAt | Long | 提交时间 |
| deleteFlg | Short | 是否删除 |
| tenantId | Long | 租户ID |
| recipient | Long | 抄送人 |
| currencyRate | Double | 货币汇率 |
| status | Short | 状态 |
| dbcDate1 | String | 自定义字段 |
| dbcTextarea1 | String | 自定义字段 |
| CheckValueStrMap | Map<Long,String> | 自定义多选框内容 |
| checkValueIdMap | Map<Long,Integer> | 自定义多选框ID |
| fileValueMap | Map<String,List<FileInfo>> | 文件数据map |
| fileValuesMap | Map<Long,List<FileInfo>> | 文件数据map |
| checkValueMap | Map<String,CheckBoxValueBase> | 自定义多选框内容 |
| attachments | Object | 附件 |
| fileId | Long | 文件ID |
| fileName | String | 文件名字 |

### 审批提交给我的工作报告

审批提交给我的工作报告。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/social/workreport/actions/marking`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| reportId | 是 | Long | 工作报告ID |

### 创建工作报告

创建工作报告。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/workReport`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 工作报告名称 |
| entityType | 是 | Long | 业务类型ID |
| ownerId | 否 | Long | 所有人ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| data | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 批量创建工作报告

批量创建工作报告。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/workReport/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 工作报告名称 |
| entityType | 是 | Long | 业务类型ID |
| ownerId | 否 | Long | 所有人ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 更新工作报告

更新工作报告。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/workReport`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 工作报告ID |
| name | 否 | String | 工作报告名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 批量更新工作报告

批量更新工作报告。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/workReport/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 工作报告ID |
| name | 否 | String | 工作报告名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 删除工作报告

删除工作报告。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/workReport`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 工作报告ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 批量删除工作报告

批量删除工作报告。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/workReport/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 工作报告ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | String | 工作报告数据 |
| errorInfo | String | 错误信息 |

### 获取业务附件文件列表

日程、任务、公告报告、活动记录等业务的附件文件列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/commonFile/actions/getBySystemIdAndItemId`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| systemId | 是 | Long | 业务标识601：工作报告606：任务607：活动记录608：日程 |
| itemId | 是 | Long | 业务数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | String | 分类名称 |
| name | Long | 分类ID |
| fileType | Integer | 类型，0-文件，1-图片 |
| fileLength | Integer | 文件大小（字节） |
| fileUrl | String | 文件url |
| imgUrl | String | 首页图片文件url |
| picUrl | String | 图片文件url |
| swfUrl | String | 对应swf格式文件url |
| createdBy | Long | 上传人 |
| createdAt | Long | 上传时间 |

### 获取名片及附件

根据 systemId 和 systemDataId 获取名片及附件。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/social/businessCard/{systemId}/{systemDataId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| systemId | 是 | Long | 业务数据的类型（518：联系人；522：线索） |
| systemDataId | 是 | Long | 业务数据的ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 名片ID |
| systemId | Long | 业务数据的类型（518：联系人；522：线索） |
| systemItemId | Long | 业务数据的ID |
| commonFileId | String | 附件ID |
| loginStatus | Integer | 登录状态 |
| updateBy | Long | 更新人 |
| createAt | Long | 创建时间 |
| createBy | Long | 创建人 |
| fileUrl | String | 附件地址 |
| lpicurl | String | 大图地址 |
| spicurl | String | 小图地址 |

### 文件URL签名

针对私有读的 URL，提供针对 URL 签名的方式，使用户可以暂时获得 URL 对应文件的访问权限。公有读的文件 URL 需要调用此接口获得签名。

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/acl/generatePresignedUrl`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| url | String | 是 | 存储桶中文件 URL |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| url | String | 输入的文件 URL |
| presignedUrl | String | 签名后的 URL |
| expiration | Long | 签名过期时间 |

---

## 智能分析云API接口

### 按照视图 ID 查询视图元数据

按照视图 ID，获取视图的名称、所属空间、创建人、创建时间和默认筛选条件等信息。

- 请求方式: `GET`
- API 地址: `/rest/neobi/v2.0/bestpractices/queryViewMetadataById`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| viewId | 是 | Long | 视图 ID |
| userld | 是 | Long | 用户 ID |
| type | 是 | String | 固定填写为：sync |
| Header | 是 | String | 固定填写为：application/x-www-form-urlencoded |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Json | 视图元数据 |
| status | Integer | 0：成功
                                其他：失败 |
| message | String | 执行结果描述 |

### 按照筛选条件批量查询视图元数据

按照筛选条件对视图元数据进行批量分页查询。

- 请求方式: `POST`
- API 地址: `/rest/neobi/v2.0/bestpractices/queryViewMetadatas`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| filter | 是 | Json | 视图的筛选条件 |
| page | 否 | Integer | 分页，第一页是 0，默认是 0 |
| pageSize | 否 | Integer | 每页条数，默认是 10 |
| Header | 是 | String | 固定填写为：application/x-www-form-urlencoded |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Json | 视图元数据 |
| status | Integer | 0：成功
                                其他：失败 |
| message | String | 执行结果描述 |
| pageInfo | Json | 分页信息 |

### 按照筛选条件查询视图数据

按照筛选条件对指定视图进行同步或异步的数据查询。

- 请求方式: `POST`
- API 地址: `/rest/neobi/v2.0/bestpractices/queryDataTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| viewId | 是 | Long | 视图 ID |
| filter | 否 | Json | 视图的筛选条件，可以替换视图元数据里的筛选，不填默认为视图元数据的筛选。 |
| userId | 是 | Long | 视图查询人 |
| type | 是 | String | 视图查询类型
                                sync：同步
                                async：异步 |
| Header | 是 | String | 固定填写为：application/x-www-form-urlencoded |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Json | 查询结果 |
| status | Integer | 0：成功
                                其他：失败 |
| message | String | 执行结果描述 |
| overflow | Integer | 同步查询时返回 0 为没有溢出，返回 1 为有溢出。同步查询上限 3000 行，溢出代表该筛选条件下实际结果超过 3000
                                行。 |
| taskId | Long | 异步查询时返回，之后可以根据该 ID 查询该任务对应的执行情况和结果。 |

### 按照异步查询的任务 ID 查询任务执行情况

按照异步查询任务的 ID，查询该任务执行状态和结果。

- 请求方式: `GET`
- API 地址: `/rest/neobi/v2.0/bestpractices/queryAsyncTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| taskId | 是 | Long | 异步任务 ID |
| Header | 是 | String | 固定填写为：application/x-www-form-urlencoded |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Json | 任务执行结果 |
| status | Integer | 查询状态
                                0：成功
                                其他：失败 |
| message | String | 执行结果描述 |
| data.status | String | 任务执行状态
                                1：待执行
                                2：执行中
                                3：成功
                                4：失败 |
| data.url | String | 任务执行成功后，数据文件 url |

### 创建外部数据对象异步更新任务（JSON）

接收 JSON 格式数据，创建用于对指定外部数据对象数据执行创建、更新、删除操作的异步任务。

- 请求方式: `POST`
- API 地址: `/rest/neobi/v2.0/datacloud/externalModels/{apikey}/actions/importJson`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apikey | 是 | String | 外部数据实体的 apikey |
| operateType | 是 | Int | 操作类型
                                1 modify 新建和更新
                                2 delete 删除 |
| data | 是 | String | 数据，json 集合格式 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | int | 状态码
                                0：成功
                                1：失败 |
| message | String | 状态消息 |
| taskId | Long | 离线任务 ID |

### 创建外部数据对象异步更新任务（CSV 文件）

该接口接收 csv 格式数据文件（UTF-8 无 BOM 格式编码），创建用于对指定外部数据对象数据执行创建、更新、删除操作的异步任务。

- 请求方式: `POST`
- API 地址: `/rest/neobi/v2.0/datacloud/externalModels/{apikey}/actions/importJsonCsv`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apikey | 是 | String | 外部数据实体的apikey |
| operateType | 是 | Int | 操作类型
                                1 modify 新建和更新
                                2 delete 删除 |
| syncType | 是 | Int | 1：增量
                                2：全量 |
| file | 是 | MultipartFile | Csv文件 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | int | 状态码
                                0：成功
                                1：失败 |
| message | String | 状态消息 |
| taskId | Long | 离线任务 ID |

### 获取外部数据对象异步任务执行结果

获取指定异步任务的执行状态和结果。

- 请求方式: `GET`
- API 地址: `/rest/neobi/v2.0/datacloud/externalModels/actions/queryImportTask`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 任务 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | int | 状态码 |
| msg | String | 状态消息 |
| data | Object | 相关属性参考请求参数 |

### 自定义 SQL 查询

根据指定查询条件，在指定对象上执行查询，并返回符合条件的数据。

- 请求方式: `POST`
- API 地址: `/rest/neobi/v2.0/query/queryByCustomSQL`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| sqlObject | 是 | String | 查询语句，最多支持 20000 个字符 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Number | 成功返回 200，失败返回错误码 |
| msg | String | 成功返回 success，失败返回错误说明信息 |
| data | Array | 实际信息
                                本次查询返回的数据条数 |
| header | Array | 本次查询返回的数据标题 |

---

## PaaS平台API接口

### 获取业务数据接口描述

获取业务数据对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/description`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | string | 对象对应apiKey |

### 创建业务数据

创建业务数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| dimDepart | 是 | Long | 所属部门 |
| entityType | 是 | Long | 业务类型 |
| name | 是 | String | 业务数据名称 |
| userId | 是 | Long | 用户ID |
| objectId | 是 | Long | 对象ID |
| xObjectApiKey | 是 | String | 对象对应apiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的业务数据ID（唯一标识) |

### 更新业务数据

更新业务数据信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象对应的apiKey |
| id | 是 | Long | 更新的业务数据ID |

### 锁定自定义对象

锁定自定义对象数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/locks?recordId={recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | Long | 自定义对象ID |
| recordId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | Integer | 标识是否转移成功
                0：转移成功
                非0：转移失败 |

### 解锁自定义对象

解锁自定义对象数据。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/locks?recordId={recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | Long | 自定义对象ID |
| recordId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| status | Integer | 标识是否转移成功
                0：转移成功
                非0：转移失败 |

### 删除业务数据

删除业务数据。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象对应的apiKey |
| id | 是 | Long | 删除的业务数据ID |

### 转移自定义对象

转移指定自定义对象给另一个用户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/actions/transfers?recordId={recoredId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象APIKey |
| targetUserId | 是 | Long | 对象ID |
| recordId | 是 | Long | 数据ID |
| keepMember | 否 | Boolean | 是否保留团队成员，默认不保留 |
| keepOwner | 否 | Boolean | 保留的团队成员是否有编辑权限，只有keepMember=true时才生效，默认无编辑权限 |

### 获取业务数据信息

获取指定业务数据的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象对应的apiKey |
| id | 是 | Long | 需要查看的业务数据ID |

### 获取业务类型描述

查询对象业务类型。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xObjectApiKey}/busiType`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 对象对应的apiKey |

### 归档数据XOQL查询

查询归档数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/query/xoql-archived/xoql`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xoql | 是 | String | XOQL 格式的查询语句，具体格式请参考《XOQL》文档。 |
| useSimpleCode | 否 | Boolean | 单选、多选类型字段选项列表值的返回形式：
                                true：返回选项列表值的code值。
                                false：返回选项列表值的具体内容。
                                默认值为 false。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 响应结果码200：成功其他值为错误码 |
| msg | String | 错误信息，当成功时返回 null |
| errorInfo | String | 格式返回，暂时未用到，可忽略，一般返回 null |
| data | JSON | 具体返回的数据内容，结构请参考返回 result 的格式定义 |
| totalSize | Integer | 目前和 count 一样表示当前返回记录数 |
| count | Integer | 当前查询返回的记录数 |
| records | JSONArray | 实际信息
                                totalSize 和 count 都为本次查询返回的数据条数，目前 totalSize=count |

### 查询对象列表

查询租户下的对象列表，支持条件过滤。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/filter`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 正确返回 0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| data.[totalSize] | Integer | 返回数据的总数 |
| data.[count] | Integer | 返回数据的总数 |
| data.[records].[apiKey] | String | 实体apiKey |
| data.[records].[custom] | Boolean | 是否为自定义实体，true为自定义实体，false 为标准实体 |
| data.[records].[active] | Boolean | 实体的启用状态，true为启用，false为禁用 |
| data.[records].[detail] | Boolean | 是否是明细实体 |
| data.[records].[description] | String | 实体描述 |
| data.[records].[label] | String | 实体标签 |
| data.[records].[objectId] | Long | 实体ID |

### 获取某一个对象的所有字段的字段依赖关系

获取某一个对象的所有字段 - 字段联动依赖关系。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects//{xobjectApiKey}/itemDependencies/itemItems`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段依赖关系ID |
| objectApiKey | String | 对象apiKey |
| controlItemApiKey | String | 控制字段apiKey |
| dependentItemApiKey | String | 依赖字段apiKey |
| itemDependencyDetailAOs | List | 字段的选项依赖关系 |

### 根据对象和控制字段查询某一对依赖关系

根据对象和控制字段查询某一对字段依赖关系。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/controlItems/{controlItemApiKey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段依赖关系ID |
| objectApiKey | String | 对象apiKey |
| controlItemApiKey | String | 控制字段apiKey |
| dependentItemApiKey | String | 依赖字段apiKey |
| itemDependencyDetailAOs | List | 字段的选项依赖关系 |

### 根据对象、控制字段和被依赖字段 ID 查询某一对依赖关系

根据对象、控制字段和被依赖字段 ID 查询某一对字段依赖关系。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/controlItems/{controlItemApiKey}/{dependentItemApiKey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段依赖关系ID |
| objectApiKey | String | 对象apiKey |
| controlItemApiKey | String | 控制字段apiKey |
| dependentItemApiKey | String | 依赖字段apiKey |
| itemDependencyDetailAOs | List | 字段的选项依赖关系 |

### 根据对象、控制字段和依赖字段查询依赖关系

根据对象、控制字段和依赖字段查询依赖关系，选项用 label 表示。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/label/{controlItemApiKey}/{dependentItemApiKey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段依赖关系ID |
| objectApiKey | String | 实体apiKey |
| controlItemApiKey | String | 控制字段apiKey |
| dependentItemApiKey | String | 依赖字段apiKey |
| itemDependencyDetailAOs | List | 字段的选项依赖关系 |
| controlLabel | String | 控制选项label |
| dependentLabelList | String | 依赖选项label列表 |

### 根据对象、控制字段和依赖字段全量更新选项依赖关系

根据对象、控制字段和依赖字段全量更新选项依赖关系，选项用 label 表示。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/itemDependencies/itemItems/label/{controlItemApiKey}/{dependentItemApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| itemDependencyDetailAOs | 是 | List | 字段的选项依赖关系 |
| controlLabel | 是 | String | 控制选项label |
| dependentLabelList | 是 | String | 依赖选项label列表 |

### 获取子对象的可用业务类型列表

根据主子业务类型映射关系，获取子对象的可用业务类型列表。如无映射，则取所有。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/busiTypes/{childXobjectApiKey}/{masterBusiTypeId}/childMappings`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 业务类型ID |
| businessFlg | Short | 初始化标志 |
| visible | Boolean | 是否可见 |
| objectId | Long | 对象ID |
| labelKey | String | 业务类型标签Key |
| active | Boolean | 启用标记 |
| label | String | 业务类型标签 |
| apiKey | String | 业务类型ApiKey |
| busiTypeOrder | Short | 业务类型序号 |
| custom | Boolean | 是否定制业务类型 |

### 获取主对象的可用业务类型列表

根据主子业务类型映射关系，获取主对象的可用业务类型列表。如无映射，则取所有。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/busiTypes/{childXobjectApiKey}/{childBusiTypeId}/masterMappings`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 业务类型ID |
| businessFlg | Short | 初始化标志 |
| visible | Boolean | 是否可见 |
| objectId | Long | 对象ID |
| labelKey | String | 业务类型标签Key |
| active | Boolean | 启用标记 |
| label | String | 业务类型标签 |
| apiKey | String | 业务类型ApiKey |
| busiTypeOrder | Short | 业务类型序号 |
| custom | Boolean | 是否定制业务类型 |

### 新建字段集

创建实体字段集。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 实体ApiKey |
| jsonObject | 是 | RequestBean<JSONObject> | 字段集数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段集ID |
| apiKey | String | 字段集ApiKey |

### 更新字段集

修改实体字段集信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象 ApiKey |
| fieldSetApiKey | 是 | String | 字段集ApiKey |
| jsonObject | 是 | RequestBean<JSONObject> | 字段集数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段集ID |
| apiKey | String | 字段集ApiKey |

### 删除字段集

删除实体字段集。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 实体ApiKey |
| fieldSetApiKey | 是 | String | 字段集ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| fieldSetApiKey | String | 字段集ApiKey |
| objectApiKey | String | 实体ApiKey |

### 查询所有字段集

查询实体所有字段集，可以根据 filter 过滤。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象 ApiKey |
| filter | 是 | String | 过滤条件，示例：{key1} eq{value1} and {key2} eq{value1} and {key2}
                  eq{value3，value4，value5} |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| apiKey | String | 字段集ApiKey |
| label | String | 字段集标签名称 |

### 获取字段集信息

根据 ApiKey 获取对应的字段集信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/fieldsets/{fieldSetApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 实体ApiKey |
| fieldSetApiKey | 是 | String | 字段集ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 字段集ID |
| apiKey | String | 字段集ApiKey |
| label | String | 字段集标签名称 |
| labelKey | String | 字段集标签Key（规则
                :XdMDFieldSet.[object.apiKey].[apiKey]） |
| fieldSetOrder | Integer | 排序字段 |
| objectId | Long | 字段集归属的实体ID |
| customFlag | Boolean | true：租户自定义
                false：系统级预制 |
| description | String | 描述 |
| displayedFields | List<ItemAO> | 当前XFieldSet包含的所有XFieldSetItem |

### 创建通用选项集

创建通用选项集。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 是 | String | 通用选项集名称 |
| description | 否 | String | 通用选项集描述 |
| pickOptionData | 是 | JSONArray | 选项信息 |
| optionCode | 是 | String | 选项值编码 |
| optionLabel | 是 | String | 选项值标签 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| totalSize | Integer | 通用选项集数据量 |
| count | Integer | 通用选项集数据量 |
| apiKey | String | 通用选项集 apiKey |
| result | Bool | 成功返回 true，失败返回 false |

### 更新通用选项集

更新通用选项集信息。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 是 | String | 通用选项集名称 |
| description | 否 | String | 通用选项集描述 |
| pickOptionData | 是 | Jsonarray | 选项信息 |
| optionCode | 是 | String | 选项值编码 |
| optionLabel | 是 | String | 选项值标签 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| totalSize | Integer | 通用选项集数据量 |
| count | Integer | 通用选项集数据量 |
| result | Bool | 成功返回 true，失败返回 false |

### 删除通用选项集

删除通用选项集。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| globalPickApiKey | 是 | String | 需要删除的通用选项集apiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| totalSize | Integer | 通用选项集数据量 |
| count | Integer | 通用选项集数据量 |
| result | Bool | 成功返回 true，失败返回 false |

### 获取指定通用选项集

获取指定通用选项集的信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| globalPickApiKey | 是 | String | 通用选项集apiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| totalSize | Integer | 通用选项集属性的个数 |
| count | Integer | 通用选项集属性的个数 |
| apikey | String | 通用选项集apikey |
| custom | Bool | 是否自定义 |
| optionLabel | String | 选项名称 |
| isActive | String | 选项状态（启用/禁用） |
| Description | String | 描述 |

### 获取所有通用选项集

获取所有通用选项集对象的描述、对应选型等信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| Code | String | 正确返回0 |
| msg | String | 返回信息 |
| errorInfo | String | 错误信息 |
| totalSize | Integer | 通用选项集数据量 |
| count | Integer | 通用选项集数据量 |
| id | Long | 通用选项集ID |
| label | String | 通用选项集标签 |
| apikey | String | 通用选项集apikey |
| custom | Bool | 是否自定义 |
| optionLabel | String | 选项名称 |
| optionCode | Integer | 选项编码 |

### 新增通用选项集选项

根据通用选项集 ApiKey 插入对应选项数据。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| globalPickApiKey | 是 | String | 通用选项集 ApiKey |
| pickOptionData | 是 | JSONArray | 选项信息 |
| optionLabel | 是 | String | 选项值标签 |
| optionApiKey | 否 | String | 选项值ApiKeyoptionApiKey 不填写时根据 optionApiKey 递增 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | JSON | 结果数据 |

### 更新通用选项集选项

根据通用选项集 optionCode 更新对应选项数据。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| globalPickApiKey | 是 | String | 通用选项集 ApiKey |
| pickOptionData | 是 | JSONArray | 选项信息 |
| optionCode | 是 | String | 选项值编码 |
| optionLabel | 是 | String | 选项值标签 |
| optionApiKey | 否 | String | 选项值 ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | JSON | 结果数据 |

### 启用/禁用通用选项集选项

根据选项optionCode和optionApiKey启用或者禁用对应选项。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/actions/enable`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pickOptionData | 是 | JSONArray | 选项信息 |
| globalPickApiKey | 是 | String | 通用选项集apiKey |
| active | 是 | Boolean | 选项状态（true启用/false禁用） |
| optionCode | 否 | String | 选项值编码 |
| optionApiKey | 否 | String | 选项值ApiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | Json | 结果数据 |

### 删除通用选项集选项

根据通用选项集 optionCode 删除对应选项数据。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/{globalPickApiKey}/option`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| globalPickApiKey | 是 | String | 通用选项集 Apikey |
| pickOptionData | 是 | JSONArray | 选项信息 |
| optionCode | 是 | String | 选项值编码 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | JSON | 结果数据 |

### 查询指定通用选项集所有选项依赖关系

通过控制选项集和依赖选项集查询某个通用选项集依赖关系的所有选项依赖关系，选项用 label 表示。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/dependencies/label/{controlApiKey}/{dependentApiKey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 通用选项集依赖关系ID |
| controlItemApiKey | String | 控制通用选项集apiKey |
| dependentItemApiKey | String | 依赖通用选项集apiKey |
| itemDependencyDetailAOs | List | 通用选项集的选项依赖关系 |
| controlLabel | String | 控制选项label |
| dependentLabelList | String | 依赖选项label列表 |

### 更新指定通用选项集所有选项依赖关系

全量更新某个通用选项集依赖关系的选项依赖关系，选项用 label 表示。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/dependencies/label/{controlApiKey}/{dependentApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| itemDependencyDetailAOs | 是 | List | 通用选项集的选项依赖关系 |
| controlLabel | 是 | String | 控制选项label |
| dependentLabelList | 是 | String | 依赖选项label列表 |

### 新增通用选项依赖关系

根据选项controlLabel或者controlItemCode增量新增对应选项的依赖关系。

- 请求方式: `/REST/METADATA/V2.0/SETTINGS/GLOBALPICKS/DEPENDENCIES/ACTIONS/DEPENDENTOPTIONSINCREMENT`
- API 地址: `PATCH`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| controlApiKey | 是 | String | 控制选项的通用选项集APIKEY |
| dependentApiKey | 是 | String | 依赖选项的通用选项集APIKEY |
| useLabel | 否 | Boolean | 使用Label匹配选项更新，默认为true，为true时请求报文参数用controlLabel和dependentLabelList更新，为false时请求参数用controlItemCode和dependentItemCodeList更新 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | Json | 结果数据 |

### 更新指定通用选项依赖关系

根据选项controlLabel或者controlItemCode更新指定选项的依赖关系。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/dependencies/actions/dependentOptions`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| controlApiKey | 是 | String | 控制选项的通用选项集APIKEY |
| dependentApiKey | 是 | String | 依赖选项的通用选项集APIKEY |
| replaceUpdate | 否 | Boolean | 覆盖更新，默认为true，true根据报文选项集删除依赖控制选项再新增，false删除所有对应选项依赖，再新增报文选项依赖 |
| useLabel | 否 | Boolean | 使用Label匹配选项更新，默认为true，true请求报文参数用controlLabel和dependentLabelList更新，false时请求参数用controlItemCode和dependentItemCodeList更新 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | Json | 结果数据 |

### 删除指定通用选项依赖关系

根据选项controlLabel或者controlItemCode删除对应选项的依赖关系。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/settings/globalPicks/dependencies/actions/dependentOptionsDelete`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| controlApiKey | 是 | String | 控制选项的通用选项集APIKEY |
| dependentApiKey | 是 | String | 依赖选项的通用选项集APIKEY |
| useLabel | 否 | Boolean | 使用Label匹配选项更新，默认为true，为true时请求报文参数用controlLabel和dependentLabelList更新，为false时请求参数用controlItemCode和dependentItemCodeList更新 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误消息 |
| data | Json | 结果数据 |

### 调用指定自定义API

调用指定自定义 API。

- 请求方式: `POST/GET`
- API 地址: `/rest/data/v2.0/scripts/api/{customPath}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| csutomPath | 是 | String | 定义来自业务逻辑代码API的实现类，是由@RestApi.baseUrl和@RestMapping两部分组成，csutomPath支持多层路径 |
| request | 是 | 自定义 | 来自于自定义API实现类的 RestQueryParam 或 RestBeanParam 的注解定义
                                request为需要传入自定义API的参数。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| response | 自定义 | 字段值来自于实现类自定义返回值
                                response为自定义API返回的值。 |

### 添加短信模板

添加新建的短信模板数据。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 模板名称 |
| content | 是 | String | 模板内容 |
| providerId | 否 | Long | 供应商ID（默认1000000L） |
| description | 否 | String | 模板描述信息 |
| reportId | 否 | String | 模板报备ID |

### 更新短信模板

对已经添加的模板数据进行修改操作。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate/{templateId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| templateId | 是 | Long | 模板ID |
| name | 否 | String | 模板名称 |
| content | 否 | String | 模板内容 |
| description | 否 | String | 模板描述信息 |
| reportId | 否 | String | 模板报备ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Boolean | true：成功false：失败 |

### 查询短信模板

查找指定的短信模板。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| templateId | 否 | Long | 模板ID |
| templateName | 否 | String | 模板名称 |
| pageNum | 是 | Integer | 第几页 |
| pageSize | 是 | Integer | 每页记录条数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Object | 返回的数据 |
| currentPageNum | Integer | 当前页数 |
| pageSize | Integer | 每页记录数 |
| totalNum | Integer | 总记录数 |
| totalPage | Integer | 总页数 |
| smsTemplatelist | List<Object> | 模板列表数据 |
| id | Long | 模板id |
| name | String | 模板名称 |
| content | String | 模板内容 |
| providerId | Long | 供应商ID |
| status | Short | 模板状态
                1：启用
                0：禁用 |
| delFlg | Short | 模板删除标记
                1：已删除
                0：未删除 |
| description | String | 模板描述信息 |
| reportId | String | 模板备案ID |

### 启用短信模板

启用指定的短信模板。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate/actions/enable`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 模板ID |
| status | 是 | Short | 模板状态
                1：启用
                0：禁用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Boolean | true：成功false：失败 |

### 禁用短信模板

禁用指定的短信模板。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate/actions/disable`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 模板ID |
| status | 是 | Short | 模板状态
                1：启用
                0：禁用 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Boolean | true：成功false：失败 |

### 删除短信模板

删除指定的短信模板。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/flows/smsTemplate/{templateId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| templateId | 是 | Long | 模板ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Boolean | true：成功false：失败 |

### 短信事件列表

配置了短信模板的短信事件列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/flows/events/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象apiKey |
| busiTypeId | 是 | Long | 业务类型ID |
| pageNum | 是 | Integer | 第几页 |
| pageSize | 是 | Integer | 每页记录条数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Object | 返回的数据 |
| currentPageNum | Integer | 当前页数 |
| pageSize | Integer | 每页记录数 |
| totalNum | Integer | 总记录数 |
| totalPage | Integer | 总页数 |
| currentPageDatas | List<Object> | 当前页数据列表 |
| id | Long | 短信事件ID |
| eventName | String | 短信事件名称 |
| type | String | 事件类型 |
| templateId | Long | 模板ID |
| content | String | 事件内容 |

### 短信事件实例

根据短信事件 ID 获取具体发送短信内容的实例。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/flows/sms/actions/getInstance`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| eventId | 是 | Long | 短信事件ID |
| recordId | 是 | Long | 数据记录ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码
                0：成功
                其他值：失败 |
| msg | String | 提示信息 |
| data | Object | 返回的数据 |
| templateId | Long | 模板ID |
| content | String | 短信内容 |
| phones | List<String> | 接收短信的手机号列表 |
| smsTemplateConfig | Object | 模板配置信息 |
| tempalteId | String | 模板备案ID |
| templateParams | List<String> | 模板参数列表 |

### 查询短信通知事件日志

查询短信通知事件日志信息。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/creekflow/eventLog/sms`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pageNo | 是 | Integer | 页数 |
| pageSize | 是 | Integer | 每页查询数目，最大支持500条 |
| startTime | 是 | Long | 日志查询开始时间，时间戳毫秒。
                                日志最大查询日期：一周 |
| endTime | 是 | Long | 日志查询结束时间，时间戳毫秒。
                                日志最大查询日期：一周 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回状态，200表示成功 |
| msg | String | 查询结果提示信息 |
| data | Object | 返回查询结果数据 |
| data.searchCondition | Object | 本次查询条件 |
| data.count | Integer | 符合条件的总数量 |
| data.logDataList | Array | 短信触发日志数组 |
| data.logDataList.Object.status | Integer | 执行状态
                                1：成功
                                2：失败 |
| data.logDataList.Object.entityId | Long | 实体ID |
| data.logDataList.Object.userId | Long | 事件执行人ID |
| data.logDataList.Object.recordId | Long | 数据ID |
| data.logDataList.Object.executeTime | Long | 事件执行时间，时间戳毫秒 |
| data.logDataList.Object.eventName | String | 事件名称 |
| data.logDataList.Object.phone | String | 接收手机号码 |
| data.logDataList.Object.content | String | 短信内容 |
| data.logDataList.Object.errorMsg | String | 错误日志 |

### 获取对象新建表单项信息

获取新建表单布局信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/layouts/createForms?xobjectApiKey={xobjectApiKey}&busiTypeId={busiTypeId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象的API Key |
| busiTypeId | 是 | Long | 业务类型ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态码 |
| msg | String | 状态信息 |
| data | JSON | 返回的数据信息 |

### 获取对象编辑表单项信息

获取编辑表单布局信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/layouts/updateForms?xobjectApiKey={xobjectApiKey}&busiTypeId={busiTypeId}&recordId={recordId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象的API Key |
| busiTypeId | 是 | Long | 业务类型ID |
| recordId | 是 | Long | 数据ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态码 |
| msg | String | 状态信息 |
| data | JSON | 返回的数据信息 |

### 获取表单实例接口描述

获取表单实例对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/formInstance/description`

### 创建表单实例

创建表单实例。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/formInstance`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | String | 表单实例名称 |
| entityType | 是 | Long | 业务类型 |
| formName | 是 | Long | 表单ID |
| fieldJobName | 否 | Long | 派工单ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的表单实例ID（唯一标识) |

### 更新表单实例

更新指定表单实例。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/formInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 表单实例ID |

### 删除表单实例

删除指定表单实例。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/formInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的表单实例ID |

### 获取表单实例信息

查看指定表单实例详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/formInstance/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的表单实例ID |

### 获取用户接口描述

获取用户对象相关的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/user/description`

### 创建用户

创建一个销售易用户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| accountType | 否 | Integer | 登录账户类型0：邮箱作为登录账号1：手机号作为登录账号默认采用邮箱作为登录账号 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的用户ID（唯一标识） |

### 更新用户

更新指定用户。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户ID |

### 启用用户

启用已被禁用的用户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/enable`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 否 | Long | 用户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 禁用用户

禁用在职用户。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/disable`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 否 | Long | 用户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 删除用户

删除指定用户。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户ID |

### 获取用户信息

查看指定用户的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户ID |

### 查询用户角色

根据用户ID查询用户的角色。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/privileges/users/{userId}/roles`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |

### 设置用户离职

设置用户离职。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/departure`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 否 | Long | 用户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 设置用户复职

设置用户复职。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/reentry`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| recordId | 是 | Long | 用户 ID |
| selectEmailFlag | 是 | String | 是否使用邮箱作为账号
                                1：是
                                0：否，使用手机号作为账号 |
| phone | 否 | String | 用户手机号 |
| email | 否 | String | 用户邮箱 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 用户分配license

用户分配 license。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/licenseAssignments/{licenseID}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| licenseID | 是 | Long | license ID |
| isNotice | 否 | Boolean | 是否发邮件/短信 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 用户取消license

用户取消 license。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/licenseAssignments/{licenseID}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| licenseID | 是 | Long | license ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的用户个数 |
| count | Long | 处理的用户个数 |
| records | Long | 处理结果 |

### 查询license已授权的用户

根据license ID查询此已授权此license的所有用户。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/licenses/{licenseId}/actions/assignUsers`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 用户ID |
| name | String | 用户姓名 |

### 查询用户已授权的license

根据用户ID查询此用户已授权的license。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/actions/assignLicenses`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | license ID |
| licenseName | String | license 名称 |

### 查询当前租户（系统）的所有license

查询当前租户（系统）的所有license。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/licenses`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | license ID |
| licenseName | String | license 名称 |
| userNum | Integer | 用户数 |
| space | Long | 存储空间容量（MB） |

### 用户分配角色

用户分配角色接口。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/roleAssignments/{roleId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| roleId | 是 | Long | 角色 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |

### 用户移除角色

用户移除角色接口。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/roleAssignments/{roleId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| roleId | 是 | Long | 角色 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |

### 用户激活接口

发送激活通知。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/activate/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userIds | 是 | String | 用户 ID |
| sendNoticeMail | 是 | String | 是否发送提醒邮件/短信
                                True：发送
                                False：不发送 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |

### 批量给用户授权license

批量给用户授权 Licence，覆盖更新。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/user/assignLicences`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userIds | 是 | List<Long> | 用户ID列表 |
| licenceIdList | 是 | List<Long> | Licence ID列表 |

### 查询某用户的所有职能

根据用户ID查询此用户已分配的所有职能。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/privileges/users/{userId}/responsibilities`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 职能ID |
| name | String | 职能名称 |
| apiKey | String | 职能apiKey |

### 更新用户数据部门

更新用户数据部门。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/updateDataDepart`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userIds | 是 | List<Long> | 用户 ID |
| objectApiKeys | 是 | List<String> | 转移数据的实体范围。
                                可转移的实体范围如下：
                                部分标准实体（实体 ID 小于 400）。
                                    全部自定义标准实体（实体 ID 在 400 至 2000 之间，不包含团队成员实体和明细实体）。
                                    全部自定义实体（不包含审批单实体和明细实体）。 |
| fromDepartId | 是 | Long | 源部门 ID |
| toDepartId | 是 | Long | 目标部门 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码
                                200：发送成功
                                其他：发送失败 |
| msg | String | 状态信息 |
| LogId | Long | 更新用户数据部门日志 ID，用于查询本次更新的数据处理状态 |

### 查询更新用户数据部门日志

查询更新用户数据部门的日志。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/user/actions/updateDataDepartLog/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 更新用户数据部门日志 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码
                                200：发送成功
                                其他：发送失败 |
| msg | String | 状态信息 |
| id | Long | 转移用户数据日志 ID |
| userIds | List<Long> | 用户ID 列表 |
| objectApiKeys | List<String> | 要转移的实体 Apikeys |
| fromDepartId | Long | 原部门 ID |
| targetDepartId | Long | 新部门 ID |
| status | Short | 主任务状态。1：处理中:2：已完成3：失败 |
| details | List | 明细日志集合 |
| status | Short | 单个实体数据处理状态
                                1：待处理
                                2：处理中
                                3：已完成
                                4：失败 |
| needTransferCount | Long | 需要处理的数据量 |
| alreadyTransferredCount | Long | 已处理的数据量 |
| objectApikey | String | 实体 Apikey |
| errorMsg | String | 错误信息 |

### 获取某个用户某个对象的某些数据的数据权限

获取某个用户某个对象某些数据的数据权限。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/privileges/dataPrivileges`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |
| xobjectApiKey | 是 | String | 对象apiKey |
| recordIds | 是 | List<Long> | 数据ID |

### 查询父子场景编辑权限

打开子对象的创建页面时，如果当前用户没有对父对象的编辑权限，则权限返回为false。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/{xobjectApiKey}/actions/canOpenCreate`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 对象apiKey |
| relationId | 是 | Long | 父对象数据ID |
| relationBelongId | 是 | Long | 父对象ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | Array | 返回数据 |

### 查询用户权限日志

查询用户权限日志。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/privileges/operationLog/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pageSize | 否 | Integer | 页面尺寸 |
| pageNo | 否 | Integer | 页码 |
| operatorIds | 否 | List<Long> | 操作者 |
| operationType | 否 | Short | 操作类型 |
| logObjectType | 否 | Long | 对象类型 |
| logObjectIds | 否 | List<Long> | 对象数据集合 |
| startOperationTime | 否 | Long | 起始时间 |
| endOperationTime | 否 | Long | 结束时间 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Integer | 状态码
                                200：发送成功
                                其他：发送失败 |
| msg | String | 状态信息 |
| errorInfo | String | 错误信息 |
| totalCount | Integer | 返回数据的总数 |
| pageCount | Integer | 返回当前页数据的总数 |
| pageNo | Integer | 当前页数 |
| records | List | 返回的数据信息 |
| id | Long | 日志 ID |
| operatorId | Long | 操作者用户 ID |
| operatorName | String | 操作者名称 |
| operationType | String | 操作类型 |
| logObjectType | String | 对象类型 |
| logObjectId | Long | 对象数据 ID |
| logObjectName | String | 对象数据名称 |
| operationTime | String | 操作时间 |
| ip | String | IP 地址 |
| terminal | String | 终端内核 |
| entrustUserId | Long | 委托用户 ID |
| entrustUserName | String | 委托用户名称 |
| operationDetail | String | 操作详情 |

### 新建团队成员

新建团队成员。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/teamMember`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户 ID |
| ownerFlag | 是 | Integer | 是否有编辑权限
                                1：有编辑权限
                                2：无编辑权限 |
| recordFrom | 是 | Long | 对象 ID |
| recordFrom_data | 是 | Long | 对象数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 团队成员ID |

### 更新团队成员

更新团队成员。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/teamMember/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 团队成员ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 团队成员ID |

### 删除团队成员

删除团队成员。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/teamMember/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 团队成员ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 团队成员ID |

### 获取团队成员（单条）

获取团队成员（单条）。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/teamMember?xObjectApiKey={xObjectApiKey}&recordId={recordId}&userId={userId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |
| xObjectApiKey | 是 | String | 对象 apiKey |
| recordId | 是 | Long | 数据 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 团队成员 ID |
| ownerFlag | Integer | 是否有编辑权限
                1：有编辑权限
                2：无编辑权限 |
| memberAttr | Integer | 是否为团队负责人
                1：负责人
                2：普通成员 |
| userId | JSON | 用户相关信息 |

### 查询某条数据所有成员

查询某条数据所有成员。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/teamMember/actions/list`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xObjectApiKey | 是 | String | 实体apiKey |
| recordId | 是 | Long | 实体数据ID |
| status | 是 | String | 成员用户状态（value=all） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 团队成员ID |
| ownerFlag | Integer | 是否有编辑权限
                                1：有
                                2：无 |
| memberAttr | Integer | 是否为团队负责人
                                1：负责人
                                2：普通成员 |
| userId | JSON | 用户相关信息 |

### 获取职能列表

获取所有职能列表。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/responsibilitys`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| tenantId | Long | 租户 ID |
| createdAt | Long | 职能创建时间 |
| createdBy | Long | 职能创建人 |
| updatedAt | Long | 职能修改时间 |
| updatedBy | Long | 职能修改人 |
| id | Long | 职能 ID |
| code | String | 职能编码 |
| name | String | 职能名称 |
| responsibilityType | String | 职能类型 |
| description | String | 职能描述 |
| delFlg | String | 逻辑删除标识
                                0：未删除
                                1：已删除 |
| isExternal | String | 外部职能标识
                                0：内部职能
                                1：外部职能 |
| accessType | String | 职能访问类型 |
| external | Boolean | 是否外部职能
                                False：否
                                True：是 |

### 创建职能

创建一个新的职能。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 否 | String | 职能名称 |
| description | 否 | String | 职能描述 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | String | 返回结果标识
                                0：成功
                                其他：失败 |

### 更新职能

修改特定职能的信息。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 职能编码（接口中返回的
                                code） |
| name | 否 | String | 职能名称 |
| description | 否 | String | 职能描述 |
| accessType | 否 | Short | 可见范围
                                0：公共
                                1：资源组 |
| external | 否 | Boolean | 是否外部职能，true 或者 false |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | String | 返回结果标识
                                0：成功
                                其他：失败 |

### 职能明细

获取特定职能的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 职能 ID（接口中返回的
                                id） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 职能 ID |
| name | String | 职能名称 |
| description | String | 职能描述 |
| accessType | Long | 职能访问类型
                                0：公共
                                1：资源组 |

### 删除职能

删除特定职能。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 职能 ID（接口中返回的
                                id） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | String | 返回结果标识
                                0：成功
                                其他：失败 |

### 查询某一职能的所有功能点

根据职能编码查询此职能的所有功能点。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility/{apiKey}/actions/assignResources/function`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 职能编码（接口中返回的
                                code） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 功能点ID |
| name | String | 功能点名称 |
| parentId | Long | 父功能点ID |

### 查询分配某一职能的所有用户

根据职能编码查询分配此职能的所有用户。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/responsibility/{apiKey}/actions/users`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 职能编码（接口中返回的
                                code） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 用户ID |
| name | String | 用户姓名 |

### 获取角色列表

获取所有角色列表。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/roles`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | Long | 操作结果标识
                                0：成功
                                其他：失败 |
| msg | String | 返回的系统消息 |
| errorInfo | String | 返回的错误消息 |
| totalSize | String | 处理的数据个数 |
| count | Long | 处理的数据个数 |
| id | Long | 角色 ID |
| code | String | 角色编码 |
| name | String | 角色名称 |
| roleType | String | 角色类型 |
| description | String | 角色描述 |
| delFlg | String | 逻辑删除标识
                                0：未删除
                                1：已删除 |

### 查询分配某一角色的所有用户

根据角色编码查询分配此角色的所有用户。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/roles/{apiKey}/actions/users`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 角色编码（接口中返回的 code） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 用户ID |
| name | String | 用户姓名 |

### 查询某一角色的数据权限设置

根据角色编码查询数据权限设置。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/roles/{apiKey}/actions/dataPermissions/{dimensionType}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 角色编码（接口中返回的 code） |
| dimensionType | 是 | Short | 权限维度：
                                1：部门
                                    6：区域 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| view | String | 查看数据权限 |
| update | String | 编辑数据权限 |
| delete | String | 删除数据权限 |
| transfer | String | 转移数据权限 |

### 新建公共组

新建公共组，仅支持单条创建。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 是 | String | 公共组名称 |
| apiKey | 是 | String | 公共组 apiKey |
| upShareFlg | 是 | Integer | 是否基于角色自动共享
                                0：否
                                1：是 |
| members | 是 | Object | 公共组成员 |
| members 字段内容 | users | 否 | Array | 用户 ID 集合 |
| departs | 否 | Array | 部门 ID 集合 |
| publicGroups | 否 | Array | 公共组 ID 集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| apikey | String | 公共组 apiKey |

### 更新公共组

根据 apiKey，更新公共组基本信息，不处理公共组成员。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup/{apikey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| label | 否 | String | 公共组名称 |
| upShareFlg | 否 | Integer | 是否基于角色自动共享
                                0：否
                                1：是 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| apikey | String | 公共组 apiKey |

### 添加公共组成员

新增公共组成员，不更新公共组基本信息。

- 请求方式: `PATCH`
- API 地址: `rest/metadata/v2.0/privileges/publicGroup/addMembers`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 公共组apikey |
| members | - | 是 | Object | 公共组成员 |
| members 字段内容 | users | - | Array | 用户 ID 集合 |
| departs | - | Array | 部门 ID 集合 |
| publicGroups | - | Array | 公共组 ID集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| apikey | String | 公共组 apiKey |

### 移除公共组成员

移除公共组成员，不更新公共组基本信息。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup/removeMembers`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 公共组 apiKey |
| members | 是 | Object | 公共组成员 |
| members 字段内容 | users | - | Array | 用户 ID 集合 |
| departs | - | Array | 部门 ID 集合 |
| publicGroups | - | Array | 公共组 ID 集合 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| apikey | String | 公共组 apiKey |

### 查询单个公共组

根据 apiKey 查询公共组，并返回公共组成员信息。数据不存在时，data 返回 null。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup/{apikey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| label | String | 公共组名称 |
| apiKey | String | 公共组 apiKey |
| upShareFlg | Integer | 是否基于角色自动共享
                                0：否
                                1：是 |
| members | Object | 公共组成员 |
| members 字段内容 | users | Array |
| departs | Array | 部门 ID 集合 |
| publicGroups | Array | 公共组 ID 集合 |

### 查询全部公共组

查询租户下所有公共组，不返回公共组成员信息。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| label | String | 公共组名称 |
| apiKey | String | 公共组 apiKey |
| upShareFlg | Integer | 是否基于角色自动共享
                                0：否
                                1：是 |

### 删除公共组

根据 apiKey 删除公共组。

- 请求方式: `DELETE`
- API 地址: `/rest/metadata/v2.0/privileges/publicGroup/{apikey}`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 公共组 ID |
| apikey | String | 公共组 apiKey |

### 分页查询某一实体的所有共享规则

根据对象 apiKey 查询此对象的所有共享规则。

- 请求方式: `GET`
- API 地址: `/rest/v2.0/privileges/{objectApiKey}/sharerules?pageNo={pageNo}&pageSize={pageSize}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apiKey |
| pageNo | 否 | Int | 默认为 1 |
| pageSize | 否 | Int | 默认为 1000，最大为 1000 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 共享规则 ID |
| objectApikey | String | 对象 apiKey |
| apikey | String | 共享规则 apiKey |
| label | String | 共享规则名称 |
| description | String | 共享规则描述 |
| shareTypeCode | String | 共享类型，owner 或者 condition |
| shareTypeLabel | String | 共享类型 shareTypeCode  的返回值含义。
                                owner：基于数据负责人
                                condition：基于条件 |
| fromTypeCode | String | 源类型，publicGroup、depart、departAndSub、departAndSubWithoutOutter、subDepart
                                或者 subDepartWithoutOutter |
| fromTypeLabel | String | 源类型 fromTypeCode 的返回值含义。
                                publicGroup：公共组
                                Depart：本部门
                                departAndSub：本部门及下级
                                departAndSubWithoutOutter：本部门及下级不包含外部部门
                                subDepart：下级部门
                                subDepartWithoutOutter：下级部门不包含外部部门 |
| fromId | Long | 源目标 ID |
| fromLabel | String | 源目标名称 |
| toTypeCode | String | 目标类型（同 fromTypeCode） |
| toTypeLabel | String | 目标类型 toTypeCode 的返回值含义（同 fromTypeLabel） |
| toId | Long | 目标 ID |
| toLabel | String | 目标名称 |
| criteriaLogic | String | 高级条件 |
| scopeCode | String | 访问权限，read 或者 write |
| scopeLabel | String | 访问权限 scopeCode 的返回值含义。
                                read：只读
                                write：读写 |
| conditions | List<Object> | 只有 shareTypeCode = condition 时才有返回值 |

### 查询某一个共享规则

根据共享规则 apiKey 查询指定共享规则的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/v2.0/privileges/{objectApiKey}/sharerule/{ruleApiKey}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| objectApiKey | 是 | String | 对象 apiKey |
| ruleApiKey | 是 | String | 共享规则 apiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 共享规则 ID |
| objectApikey | String | 对象 apiKey |
| apikey | String | 共享规则 apiKey |
| label | String | 共享规则名称 |
| description | String | 共享规则描述 |
| shareTypeCode | String | 共享类型，owner 或者 condition |
| shareTypeLabel | String | 共享类型 shareTypeCode 的返回值含义。
                                owner：基于数据负责人
                                condition：基于条件 |
| fromTypeCode | String | 源类型，publicGroup、depart、departAndSub、departAndSubWithoutOutter、subDepart
                                或者 subDepartWithoutOutter |
| fromTypeLabel | String | 源类型 fromTypeCode 的返回值含义。
                                publicGroup：公共组
                                Depart：本部门
                                departAndSub：本部门及下级
                                departAndSubWithoutOutter：本部门及下级不包含外部部门
                                subDepart：下级部门
                                subDepartWithoutOutter：下级部门不包含外部部门 |
| fromId | Long | 源目标 ID |
| fromLabel | String | 源目标名称 |
| toTypeCode | String | 目标类型（同 fromTypeCode） |
| toTypeLabel | String | 目标类型 toTypeCode 的返回值含义（同 fromTypeLabel） |
| toId | Long | 目标 ID |
| toLabel | String | 目标名称 |
| criteriaLogic | String | 高级条件 |
| scopeCode | String | 访问权限，read 或者 write |
| scopeLabel | String | 访问权限 scopeCode 的返回值含义。
                                read：只读
                                write：读写 |
| conditions | List<Object> | 只有 shareTypeCode = condition 时才有返回值 |

### 用户关联职能列表

用户关联职能列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/responsibilityAssignments`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Long | 返回的数据总数 |
| count | Long | 返回的数据总数 |
| id | Long | 用户和职能的关联 ID |
| userId | Long | 用户 ID |
| responsibilityId | Long | 职能 ID |
| isPrimary | Boolean | 是否主职能
                                True：是
                                False：否 |

### 创建用户职能

创建用户职能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/responsibilityAssignments/{responsibilityId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| responsibilityId | 是 | Long | 职能 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Long | 操作结果标识
                                0：成功
                                其他：失败 |

### 更新用户职能

更新用户职能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/user/{id}/actions/assignResponsibility`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 用户 ID |
| addResponsibilitys | 是 | String | 待添加的角色列表 |
| removeResponsibilitys | 是 | String | 待删除的角色列表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| data | Long | 操作结果标识
                                0：成功
                                其他：失败 |

### 获取用户登录日志明细

获取用户登录日志明细。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/privileges/loginlog/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 日志记录 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Long | 返回的记录总数 |
| count | Long | 返回的记录总数 |
| total | String | 返回的记录总数 |
| createdAt | Long | 创建时间 |
| loginResult | Long | 登录结果 |
| terminalVersion | String | 终端版本 |
| createdBy | Long | 创建人 |
| ip | String | 登录的 IP |
| id | Long | 登录日志 ID |
| userId | Long | 登录用户 ID |
| device | Long | 登录设备 |
| softwareVersion | String | 软件版本 |
| systemVersion | String | 系统版本 |

### 根据条件查询用户登录日志

根据条件查询用户登录日志。

- 请求方式: `POST`
- API 地址: `/rest/metadata/v2.0/privileges/loginlog`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| departId | 是 | Long | 部门 ID |
| pageNo | 是 | Long | 页码 |
| pageCount | 是 | Long | 每页数量 |
| current | 是 | Long | 部门下的用户范围
                                0：当前部门的用户
                                1：当前部门下直属子部门的用户
                                2：当前部门下所有子部门的用户 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Long | 总页数 |
| count | Long | 总数量 |
| createdAt | Long | 创建时间 |
| loginResult | Long | 登录信息 |
| terminalVersion | String | 终端版本 |
| createdBy | Long | 创建人 |
| ip | String | IP 地址 |
| IMEI | String | 移动设备识别码 |
| id | Long | 主键 ID |
| userId | Long | 用户 ID |
| device | Long | 设备类型 |
| softwareVersion | String | 软件版本 |
| systemVersion | String | 系统版本 |

### 根据用户ID与搜索条件查询应用与菜单

根据用户 ID 与搜索条件查询应用与菜单。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/applications?userId=12542525&&searchLabel=abc`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| userId | 是 | Long | 用户ID |
| searchLabel | 否 | String | 搜索参数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的发运单ID（唯一标识) |

### 获取下一步信息

用来获取流程下一执行节点的相关信息，例如节点名称、节点办理人等，一般都与审批操作接口结合使用。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/creekflow/task/actions/preProcessor`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityApiKey | 是 | String | 对象apikey |
| dataId | 是 | Long | 数据ID |
| action | 是 | String | 操作类型submit：提交reject：拒绝agree：同意 |
| srcProcInstId | 否 | Long | 源流程实例ID
                                在哪个阶段流程实例上启动的审批流，旧的阶段审批固定传 -1 |
| srcTaskDefKey | 否 | String | 阶段key通过此参数是否为空，区分是否为阶段审批流，对应旧的阶段审批COMPONENT_ID（阶段Id）参数 |
| srcProcType | 否 | Integer | 源流程类型阶段审批：1：自动化流程2：审批流3：工作流4：可视化流程商机老阶段推进传4实体审批：不传此参数或传0 |
| usertaskLogId | 否 | Long | 当前任务ID同意或拒绝时必填来源于审批历史接口中的id或查询审批任务接口中的id |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| procInstId | Long | 流程实例ID |
| commentEmptyFlag | Integer | 意见是否必填 |
| ccFlag | Integer | 是否抄送 |
| defaultCcs | Array | 缺省的抄送人列表Long型数组 |
| defaultCcUser | Array | 缺省的抄送人列表
                                包括人员的属性：ID、name |
| nextUsertaskType | Integer | 下一任务节点类型1：单人任务2：任签任务3：并行会签4：串行会签 |
| nextTaskDefName | String | 下一节点名字 |
| nextTaskDefKey | String | 下一节点的key |
| nextAdjustAssigneeFlag | Boolean | 下一任务为多人会签审批时，是否允许当前审批人自由增减下级审批人 |
| optionalChooseApprover | Boolean | 是否可以自选审批人 |
| chooseApprover | Array | 下一任务候选办理对象列表包括人员的属性：ID、name |
| nextEndNodeFlag | boolean | 下一节点是否结束节点 |
| submitType | Integer | 提交类型1：初次提交2：重新提交3：提交到退回节点 |
| priority | Integer | 流程优先级
                                50：一般
                                90：紧急 |
| procdefId | Long | 流程定义ID |
| taskHandleResult | Integer | 如果执行指定的“审批操作”后，节点的办理结果1：已提交2：通过3：回退4：未完成5：已撤回6：已跳转 |
| returnTargetType | Integer | 回退目标类型1：初始节点2：当前节点之前任意节点3：上一节点4：退回初始节点（修改完毕后提交到退回节点） |
| returnableTaskDefKeyNamePairs | Array | 回退的节点列表（reject时返回此属性）包括的节点属性：key、value，用于审批时拒绝后的目标节点（targetTaskDefKey） |

### 审批操作

提交、同意、拒绝等审批操作。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/creekflow/task`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityApiKey | 是 | String | 对象apiKey |
| action | 是 | String | 动作submit：提交agree：同意reject：拒绝withdraw：撤回plussign：加签singleRegain：单步收回turn：转办taskSuspend：暂不处理taskUnsuspend：恢复处理end：结束流程仅支持流程管理员结束流程。 |
| dataId | 是 | Long | 数据ID |
| procdefId | 否 | Long | 流程定义ID
                action 为 submit 时必须。 |
| usertaskLogId | 否 | Long | 任务ID
                action 为 agree、reject、plussign、singleRegain、trun、taskSuspend、taskUnsuspend
                  时必须。
                action为 singleRegain 时，usertaskLogId 指已经审批完成的上一个任务 ID。 |
| targetTaskDefKey | 否 | String | 拒绝后目标节点
                action 为 reject 时必须（来源于接口中的
                  returnableTaskDefKeyNamePairs 参数）。 |
| nextTaskDefKey | 否 | String | 下一节点定义 KEY
                action 为 submit、agree（还有下级审批节点）时必须。
                接口中 nextEndNodeFlag 为 false 时必须。 |
| nextAssignees | 否 | Array | 下一节点办理人列表（Long 型数组）
                action 为 submit、agree（还有下级审批节点）时必须。
                接口中 nextEndNodeFlag 为 false 时必须。 |
| ccs | 否 | Array | 抄送人列表（Long型数组）
                action 为 submit、agree 时可选。 |
| assignee | 否 | Long | 转办人
                action 为 turn 时必须。 |
| comment | 否 | String | 提交意见
                是否必填可以配置。 |
| priority | 否 | Integer | 优先级
                action 为 submit 时使用。
                50：一般
                90：紧急 |
| srcProcInstId | 否 | Long | 源流程实例ID
                商机老阶段推进固定传 -1 |
| srcTaskDefKey | 否 | String | 阶段key
                商机老阶段推进传 COMPONENT_ID |
| srcProcType | 否 | Integer | 源流程类型1：自动化流程2：审批流3：工作流4：可视化流程商机老阶段推进传
                4 |
| plussignUserIds | 否 | Array | 加签人（Long型数组）
                action 为 plussign 时必须。 |
| submitter | 否 | Long | 提交人
                action 为 submit 时使用。 |
| procInstId | 否 | Long | 流程实例ID
                action 为 withdraw、end 时必须。 |

### 查询审批历史

获取当前数据的审批历史。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/creekflow/history/filter`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityApiKey | 是 | String | 对象 apiKey |
| dataId | 是 | Long | 数据 ID |
| stageFlg | 是 | Bool | 是否为阶段审批 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| assigneeId | Long | 处理人ID |
| attachments | String | 附件 |
| cancelledFlag | Integer | 任务是否已作废
                1：是
                2：否 |
| cancelledReason | String | 作废原因 |
| createdAt | Long | 创建时间 |
| createdBy | Long | 创建人 |
| endAt | Long | 结束时间 |
| id | Long | 任务 ID |
| initiateLogId | Long | 发起新任务的流水 ID |
| logType | Integer | 1：流水类型提交任务2：普通审批任务3：加签审批任务4：转办审批任务5：委托审批任务99：其它非任务流水 |
| operateTargetUsers | String | 操作的目标用户ID，多个ID使用半角逗号分隔。例如加签操作，这里将记录被加签人 |
| operateType | Integer | 1：提交
                2：同意
                3：拒绝
                4：转办
                5：委托
                6：抄送
                7：加签
                8：单步收回
                9：加签收回
                10：暂不处理
                11：取消暂不处理
                12：跳转
                13：超时
                14：完成
                15：撤回
                16：退回
                17：终止
                18：流程终止（重新提交走新版本）
                19：管理员结束
                20：删除 |
| opinion | String | 办理意见 |
| procInstId | Long | 流程实例ID |
| status | Integer | 1：待提交
                2：待重新提交
                3：待提交到退回节点
                4：已提交
                5：待办理
                6：已同意
                7：已拒绝
                8：已转办
                9：已抄送
                10：加签挂起
                11：任务挂起
                12：已收回
                13：已移交
                14：已委托
                99：无需办理 |
| usertaskInstId | Long | 节点实例 ID |
| usertaskInstStatus | Integer | 1：办理中
                2：已完成
                3：退回提交节点
                4：已撤回
                5：流程挂起
                6：退回非提交节点
                7：已收回
                8：流程中止
                9：已跳转 |

### 查询流程定义

查询流程定义。

- 请求方式: `GET`
- API 地址: `/rest/metadata/v2.0/creekflow/processDefinitions/filter`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| procType | 是 | Integer | 流程类型1：自动化流程2：审批流3：工作流4：可视化流程 |
| entityApiKey | 否 | String | 对象apikey |
| bizTypeId | 否 | Long | 对象业务类型 |
| nodeProcFlag | 否 | Integer | 是否为节点启动的流程标识
                1：是
                2：否 |
| status | 否 | Integer | 流程状态1：启用2：禁用3：设计中4：删除 |
| ids | 否 | Array | 流程定义 ID 整数数组 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| name | String | 流程名称 |
| procId | Long | 流程ID |
| procApiKey | String | 流程定义ApiKey |
| id | Long | 流程定义ID |
| status | Integer | 状态1：启用2：禁用3：设计中9：删除 |
| version | Integer | 版本号 |
| withdrawFlag | Integer | 是否允许撤回
                1：是
                2：否 |
| singleStepWithdrawFlag | Integer | 是否允许单步收回
                1：是
                2：否 |
| submitExpressionId | Long | 初始提交条件
                只有满足条件才可以提交（用于审批流）。默认值为0，表示没有设置提交条件 |
| defaultTitleFlag | Integer | 是否默认主题
                1：是
                2：否 |
| titleExpressionId | Long | 自定义标题表达式 |
| description | String | 描述 |
| labelKey | String | 流程定义名称 |
| errorMessage | String | 初始条件自定义错误提示 |
| errorMessageKey | String | 错误提示多语音key |
| defaultErrorMessageFlag | Integer | 初始条件错误提示设置
                1：是
                2：否 |

### 查询流程实例

查询流程实例。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/creekflow/processInstances/filter`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| status | 是 | String | 状态processed：办理中stop：中止pass：通过默认为 processed |
| submitterIds | 否 | String | 提交人
                默认为当前登录人 |
| ids | 否 | String | 流程实例 ID |
| dataIds | 否 | String | 数据 ID |
| pagesize | 否 | Integer | 每页显示记录数 |
| pageNum | 否 | Integer | 页码，第一页为 1 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 流程实例 ID |
| procId | Long | 流程 ID |
| procdefId | Long | 流程定义 ID |
| status | Integer | 流程状态1：处理中2：已完成3：退回提交人4：已撤回5：已挂起6：已终止 |
| entityId | Long | 对象 ID |
| entityApikey | String | 对象 ApiKey |
| procType | Integer | 流程类型1：自动化流程2：审批流3：工作流4：可视化流程 |
| bizTypeId | Long | 业务类型 ID |
| dataId | Long | 数据 ID |
| title | String | 主题 |
| priority | Integer | 优先级别
                50：一般
                90：紧急 |
| endAt | Long | 结束时间 |
| submitterId | Long | 提交人 |
| submitAt | Long | 提交时间 |

### 查询审批任务

根据人员查询审批任务。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/creekflow/task/filter`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| assigneeIds | 否 | String | 申请人
                多个时用半角逗号分隔，默认为当前登录人 |
| status | 是 | String | 状态approved：已办pending：待办copy：抄送suspend：暂不处理 |
| sortDataField | 否 | String | 排序字段createdAt：创建时间endAt：完成时间默认按任务的创建时间 |
| sortOrder | 否 | String | 排序顺序sc：升序desc：降序默认为desc |
| pageSize | 否 | Integer | 每页显示记录数，默认20条 |
| pageNum | 否 | Integer | 页码
                第一页为1 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 任务ID |
| procId | Long | 流程ID |
| procdefId | Long | 流程定义ID |
| procInstId | Long | 流程实例ID |
| usertaskInstId | Long | 节点实例ID |
| entityApikey | String | 对象apikey |
| instTitle | String | 流程实例标题 |
| dataId | Long | 数据ID |
| entityId | Long | 实体ID |
| entityTypeId | Long | 业务类型ID |
| assigneeId | Long | 处理人ID |
| submitterId | Long | 任务提交人ID |
| submitAt | Long | 任务提交时间 |
| priority | Integer | 优先级别
                50：一般
                90：紧急 |
| createdAt | Long | 任务创建时间 |
| endAt | Long | 任务完成时间 |
| status | Integer | 任务状态1：待提交2：待重新提交3：待提交到退回节点4：已提交5：待办理6：已同意7：已拒绝8：已转办9：已抄送10：加签挂起11：任务挂起12：已收回13：已移交14：已委托99：无需办理 |

### 获取当前节点操作权限及按钮

根据当前登录人，获取当前节点待办任务的按钮权限以及可编辑字段列表。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/creekflow/task/actions/getPermission`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| entityApiKey | 是 | String | 对象apikey |
| dataId | 是 | Long | 数据ID |
| srcProcInstId | 否 | Long | 源流程实例ID，在哪个阶段流程实例上启动的审批流，旧的阶段审批固定传 -1 |
| srcTaskDefKey | 否 | String | 阶段key通过此参数是否为空，区分是否为阶段审批流，对应旧的阶段审批COMPONENT_ID（阶段ID）参数 |
| srcProcType | 否 | Integer | 源流程类型阶段审批：1：自动化流程2：审批流3：工作流4：可视化流程商机老阶段推进传4对象审批：不传此参数或传0 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| task | Object | 节点对象 |
| taskId | Long | 当前用户需要办理的任务ID |
| editableFields | Array | 当前节点可编辑字段itemApiKey：对象的字段apiKey
                editable：是否可编辑（true表示可编辑，false表示不可编辑）
                required：是否必须输入（true表示必须输入，false表示非必须输入） |
| actions | Object | 审批动作权限列表 |
|  |  | submit：提交 |
|  |  | agree：同意 |
|  |  | reject：拒绝 |
|  |  | withdraw：撤回 |
|  |  | plussign：加签 |
|  |  | singleStepCancel：收回 |
|  |  | permission：是否有权限（true表示有权 |
|  |  | 限，false表示无权限） |

### 触发自动流

触发自动流。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/creekflow/autoProcessInstances`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| processDefinitionApiKey | 是 | String | 流程定义ApiKey |
| entityApiKey | 是 | String | 实体ApiKey |
| dataId | 是 | Long | 数据ID |
| dataBeforeChange | 否 | Object | 变更前的数据对象，在自动流执行方式为新建或者编辑时，如果是变更情况下需要传递这个参数 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回状态，200代表成功。流程启动后，异步执行，执行结果在系统管理后台> 流程中心>
                                流程监控中查询结果 |
| msg | String | 错误信息，目前空值 |
| data | Object | 返回业务数据，目前空值 |

### 修改label

修改 label。

- 请求方式: `PATCH`
- API 地址: `/rest/metadata/v2.0/xobjects/{xobjectApiKey}/items/{itemApiKey}/label`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| xobjectApiKey | 是 | String | 修改的实体apikey |
| itemApiKey | 是 | String | 修改的字段apikey |
| Entity | 是 | ItemAO | 修改字段数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回码 |
| Msg | String | 返回描述 |

### 上传文件

文件上传。

- 请求方式: `POST 以 MULTIPART/FORM-DATA 形式提交请求参数。`
- API 地址: `/rest/file/v2.0/file/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| files | 是 | File | 要上传的文件 |
| isImage | 是 | Boolean | false |
| needFileId | 是 | Boolean | true |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| fileName | String | 文件名 |
| fileUrl | String | 文件URL |
| fileLength | Long | 文件大小 |
| fileId | Long | 文件ID |

### 下载文件

销售易提供了文件类型字段的支持，在 API 调用时，返回数据为文件的 ID，为方便业务线或第三方能够根据文件 ID 来下载文件，销售易提供一个文件下载接口来承载相关功能。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/file/actions/files?fileIds={fileId1,fileId2,fileId3...}&outType={outType}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fileIds | 是 | String | 以逗号分割的文件ID字符串。
                当输出模式为文件流时，仅支持一个文件ID；当输出模式为JSON时，最多支持50个文件ID。 |
| outType | 否 | 输出类型 | outType=0，不传该参数输出二进制文件流；outType=1，输出JSON对象。 |

### 批量上传图片

- 请求方式: `POST`
- API 地址: `/rest/file/v2.0/image`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| files | 是 | File | Body中，以form-data传输，可以有多个files |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| fileId | Number | 文件ID，上传图片对应的ID |

### 下载图片

销售易提供了图片类型字段的支持，在 API 调用时，返回数据为图片的 ID，为方便业务线或第三方能够根据 ID 来下载图片文件，销售易提供一个图片文件下载接口来承载相关功能。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/image/actions/files?fileIds=1578967492378636,1486800316809249&outType=1`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fileIds | 是 | String | 以逗号分割的文件ID字符串。
                当输出模式为文件流时，仅支持一个文件ID；当输出模式为JSON时，最多支持50个文件ID。 |
| outType | 否 | 输出类型 | outType=0，不传该参数输出二进制文件流；outType=1，输出JSON对象。 |

### 下载图片文件数据流

根据图片的数据 ID 下载图片文件的数据流，然后用户根据数据流来进行图片文件的本地保存和 HTML 中的展示（访问需要 Token 认证）。

- 请求方式: `GET`
- API 地址: `/rest/file/v2.0/image/{fileId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| fileId | 是 | Number | 文件ID |

### 实体大数据量滚动查询

滚动查询接口，用于解决大数据量深度分页查询慢的问题，以提高查询效率。

- 请求方式: `POST`
- API 地址: `/rest/data/v2/query/scroll`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| q | 是 | String | 查询表达式，字段使用apikey表示。支持逻辑表达式，但不支持排序、limit 以及 id 作为查询条件 |
| queryLocator | 否 | String | 条件语句加第一次查询的指针,加当前查询数据量的加密编码 |
| batchCount | 是 | Long | 整数，取值范围[0,1000] ；默认值为1000 |
| scrollParam | 是 | boolean | true为深度分页查询，false或者空为普通query查询 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| totalSize | Integer | 数据总数 |
| count | Integer | 当前获取的数据条数 |
| records | Array | 数据记录集 |
| queryLocator | String | 查询指针 |
| hasMore | boolean | 返回数据是否完成。如果为true，表示未完成，还需要进行下一次查询。如果为false，那么queryLocator为空 |

### 获取模板打印信息

根据模板名称获取模板 ID、系统 ID 等模板配置信息。

- 请求方式: `GET`
- API 地址: `/rest/template/v2.0/{templateName}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| templateName | 是 | String | 模板名称 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 成功或失败提示信息 |
| batchData | 对象数组 | 模板配置信息数组 |
| batchData[0].code | String | 模板配置错误码 |
| batchData[0].msg | String | 模板配置信息获取成功或失败提示信息 |
| batchData[0].data | 对象 | 模板配置对象 |
| batchData[0].data.updateBy | Long | 更新用户ID |
| batchData[0].data.id | Long | 模板ID |
| batchData[0].data.updateAt | Long | 更新时间 |
| batchData[0].data.createAt | Long | 创建时间 |
| batchData[0].data.status | Integer | 模板启用状态，1为启用，0为未启用 |
| batchData[0].data.fileName | String | 后台上传模板文件名称 |
| batchData[0].data.businessType | Long | 业务类型 |
| batchData[0].data.systemId | Long | 系统ID |
| batchData[0].data.createBy | Long | 创建用户ID |

### 获取模板打印数据

根据模板 ID 和对象信息，生成需要打印的模板文件内容，内容以二进制形式返回。

- 请求方式: `GET`
- API 地址: `/rest/template/v2.0/{apiKey}/{id}/{templatePrintId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 业务记录ID |
| apiKey | 是 | String | 对象apikey |
| templatePrintId | 是 | Long | 模板打印ID，模板ID获取方法请参考 获取模板打印信息。 |

### 获取模板打印数据（指定输出文件格式）

根据模板 ID 和对象信息并指定打印文件输出格式来生成需要打印的模板文件内容，内容以二进制形式返回。

- 请求方式: `GET`
- API 地址: `/rest/template/v2.0/{apiKey}/{id}/{templatePrintId}/{exportType}?amount={amount}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| templatePrintId | 是 | String | 打印模板 ID |
| id | 是 | Long | 业务记录 ID |
| apiKey | 是 | Long | 对象 apiKey |
| exportType | 是 | Integer | 打印输出文件格式
                0：excel/word（与模板文件类型一致）
                1：PDF |
| amount | 否 | Long | 表示链接生成后的有效时长，不填表示永久有效，单位为秒。（当前参数配置仅支持基于 S3 存储的文件） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| url | String | 输出文件 url 地址 |
| data | String | 输出文件二进制字符串 |

### 批量模板打印

批量打印，内容以二进制形式返回，可指定打印文件输出格式。

- 请求方式: `POST`
- API 地址: `/rest/template/v2.0/template/actions/patchPrint`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| apiKey | 是 | String | 对象apiKey |
| dataId | 是 | Long | 业务记录ID |
| templatePrintId | 是 | Long | 打印模板ID |
| exportType | 否 | Integer | 打印输出文件格式0：excel/word（与模板文件类型一致）1：PDF如果缺少该参数，则打印输出文件格式类型取后台打印模板设置中配置的打印输出格式 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | Sting | 成功或失败提示信息 |
| data | JSONArray | 打印文件的字节流数组 |

### 全局搜索实体数据

对指定实体数据进行全局检索。

- 请求方式: `同时支持 POST 和 GET 方式。`
- API 地址: `/rest/data/v2.0/query/xosl`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| q | 是 | application/x-www-form-urlencoded | XOSL 查询表达式 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 数据 ID |
| 字段 apikey | Apikey 的数据类型 | 返回字段数据 |
| attributes | Json | 返回数据对象的 apikey |

### 获取系统设置日志

获取系统设置日志。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/logs/actions/getSystemLog`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| queryParams | 是 | Json | 查询参数，详细内容请参考queryParams 参数说明表 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 状态码，成功返回值为200，失败时返回错误代码 |
| msg | String | 提示消息 |
| result | Json | 实际返回结果，详细内容请参考result 格式定义表 |

### 实体数据变更明细操作日志查询

主要用于部分租户基于该接口搭建自有的日志查询功能。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/logs/xobjectFieldHistory/actions/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| pageNum | 是 | Integer | 查询页码，为大于 0 的正整数（默认每页最多返回 100 条数据） |
| objectApiKey | 是 | String | 指定查询目标实体 |
| createdByIds | 否 | JSONArray | 日志创建人用户 ID 数组。指定该参数时，将仅查询数组中所列用户 ID 的日志数据 |
| dataIds | 否 | JSONArray | 目标数据 ID 数组。指定该参数时，仅查询数组中所列数据的日志；未指定时，将查询全部数据的日志 |
| itemApiKey | 否 | String | 字段的 apiKey。指定该参数时，将查询对应字段的变更日志 |
| startTime | 是 | Long | 起始时间毫秒数 |
| endTime | 是 | Long | 结束时间毫秒数。
                                最大支持查询跨度为 30 天。
                                日志在线存储 18 个月（540 天），接口可查询 18 个月内的日志。
                                时间边界包含 startTime，不包含 endTime。
                                    startTime 必须小于 endTime
                                    endTime - startTime 的时间差不得超过 30 天（即 30 × 24 × 60 × 60 × 1000
                                        毫秒） |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 响应结果码
                                0：成功
                                其他值为错误码 |
| msg | String | 响应结果描述 |
| result | JSON | 具体返回的数据内容，结构请参考返回 result 格式定义 |

---

## 其他业务API接口

### 获取目标接口描述

获取目标对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/description`

### 创建目标

创建目标。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goalPro`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的目标ID（唯一标识） |

### 更新目标

更新目标信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标ID |

### 查询目标

根据条件查询目标数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/query`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| year | 是 | Integer | 财年 |
| goalModelId | 是 | Long | 目标模型ID |
| defaultGoalPeriod | 是 | Integer | 默认考核周期 |
| goalPeriod | 是 | Integer | 查询考核周期 |
| isSum | 是 | Boolean | 是否是汇总目标 |
| done | 是 | Boolean | 是否查看完成情况 |
| refresh | 是 | Boolean | 是否刷新 |
| goalType | 否 | Integer | 目标类型 |
| depart | 否 | JSONObject | 部门 |

### 锁定目标

锁定目标。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标ID |

### 解锁目标

解锁目标。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标ID |

### 删除目标

删除目标。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标ID |

### 获取目标信息

获取指定目标的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goalPro/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标ID |

### 获取目标模型接口描述

获取目标模型对象的表结构、数据类型等信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goalModel/description`

### 创建目标模型

创建目标模型。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goalModel`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| name | 是 | Text | 目标模型名称 |
| entityType | 是 | Long | 业务类型 |
| dimDepart | 是 | Long | 部门 |
| goalObject | 是 | Long | 考核对象-业务对象 |
| goalObjectField | 是 | Long | 考核对象-显示字段 |
| goalContObject | 是 | Long | 考核内容-业务对象 |
| goalContField | 是 | Long | 考核内容-字段 |
| goalContStati | 是 | Long | 考核内容-统计方式 |
| goalPeriod | 是 | Long | 考核周期 |
| goalPeriodSum | 是 | Long | 考核周期向上汇总 |
| goalDateField | 是 | Long | 统计时间 |
| goalStatus | 是 | Long | 目标模型状态 |
| goalRelation1 | 是 | Long | 关联对象1 |
| goalRelation2 | 是 | Long | 关联对象2 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Long | 新创建的目标模型ID（唯一标识) |

### 更新目标模型

更新目标模型信息。

- 请求方式: `PATCH`
- API 地址: `/rest/data/v2.0/xobjects/goalModel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 目标模型ID |

### 查询目标模型

根据条件查询目标模型数据。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/xobjects/goalModel/query`

### 删除目标模型

删除目标模型。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/goalModel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要删除的目标模型ID |

### 获取目标模型信息

获取指定目标模型的信息。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/goalModel/{id}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要查看的目标模型ID |

### 文档锁定

锁定指定文档。

- 请求方式: `PUT`
- API 地址: `/rest/data/v2.0/xobjects/twitterFile/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要锁定的文档ID |
| objectId | 是 | Long | 对象ID |
| belongId | 是 | Long | 关联到对象ID |

### 文档解锁

解锁指定文档。

- 请求方式: `DELETE`
- API 地址: `/rest/data/v2.0/xobjects/twitterFile/actions/locks/{id}/lock`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| id | 是 | Long | 需要解锁的文档ID |
| objectId | 是 | Long | 对象ID |
| belongId | 是 | Long | 关联到对象ID |

### 获取对象下文档列表

根据对象 ID 获取该对象下的文档列表。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects/twitterFile/actions/search-records`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| belongId | 否 | Long | 对象的 belongId |
| belongType | 否 | Long | 类型 |
| objectId | 否 | Long | 对象 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 返回编码 |
| msg | String | 编码信息 |
| data | JSON | 响应数据 |

### 获取翻译资源列表

获取特定 key 在特定语种下的翻译值。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/i18n/resources/actions/queryByKeyListLangCode`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| resourceKeyList | 是 | JSONArray | 资源 key 列表 |
| langCode | 否 | String | 语种
                                此参数不填时，将返回该 key 在中文下的翻译值 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | JSONObject | totalSize：记录数
                                count：记录数
                                records：翻译资源查询结果（JSONObject 类型） |

### 批量保存翻译资源

批量保存翻译资源。

- 请求方式: `POST`
- API 地址: `/rest/data/v2.0/i18n/resources/actions/saveOrUpdateBatch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| resources | 是 | JSONArray | 资源数据列表 |
| needSync | 否 | boolean | 保存完是否需要同步资源，默认为 false |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| code | String | 错误码 |
| msg | String | 错误信息 |
| data | JSONObject | totalSize：记录数
                                count：记录数
                                records：保存是否成功（boolean 类型） |

---

## Bulk API接口

### 查询支持对象接口

查询 Bulk API 支持的对象，返回的所有对象都支持。

- 请求方式: `GET`
- API 地址: `/rest/data/v2.0/xobjects`

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| apiKey | String | 对象的 apiKey |
| label | String | 对象名称 |
| objectId | Long | 对象 ID |

### 创建异步作业

创建异步作业。

- 请求方式: `POST`
- API 地址: `/rest/bulk/v2/job`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| operation | 是 | String | 执行的数据操作类型，可选项为：insert创建数据
                                        update更新数据
                                        delete删除数据
                                        query查询数据 |
| object | 是 | String | 操作对象的 apiKey，可通过/rest/data/v2.0/xobjects获取 |
| batchContentType | 否 | String | 使用的数据传入格式，可选项为：JSON
                                        CSV
                                默认为 JSON 格式。
                                CSV 格式需要以 UTF-8 无 BOM 格式编码。 |
| execOption | 否 | String[] | 当数据操作为新建或更新时，设置需要检查的数据规则，可选项为：CHECK_RULE执行校验规则。
                                        CHECK_DUPLICATE执行查重规则。 |
| returnFields | 否 | String[] | 当数据操作为新建或更新时，设置需要返回的字段。
                                最多可设置 3 个字段。
                                        支持返回的字段类型包括：文本、自动编号、关联关系、主子明细。 |
| callBackClasses | 否 | String[] | 批量操作执行完成后，需要执行的业务逻辑代码（Bulk API 回调）。
                                如果需要执行多个业务逻辑代码，则业务逻辑代码之间以逗号分隔。例如：
                                "callBackClasses":["other.com.icesoft.BulkApiCallBackImpl1","other.com.icesoft.BulkApiCallBackImpl2"]
                                示例中的 other.com.icesoft.BulkApiCallBackImpl1 和
                                            other.com.icesoft.BulkApiCallBackImpl2
                                            需要根据实际开发情况替换为要执行的类，格式为：package 名.类名。
                                        业务逻辑代码的执行顺序与参数中填写业务逻辑代码的顺序相同。
                                关于 Bulk API 回调业务逻辑代码的编写方法请参考Bulk API回调（文档中心
                                        产品手册
                                        PaaS 平台
                                        PaaS平台开发手册
                                        业务逻辑开发
                                        业务逻辑扩展点及开发方法
                                        Bulk API回调）。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| createdAt | String | 创建时间 |
| createdBy | Long | 创建人 ID |
| id | String | 新创建的作业 ID |
| state | String | 作业状态
                                open进行中
                                    aborted已终止
                                    closed已完成 |
| operation | String | 操作类型 |
| object | String | 对象的 apiKey |

### 更新异步作业

更新异步作业，仅允许更新异步作业的状态。

- 请求方式: `PATCH`
- API 地址: `/rest/bulk/v2/job/{jobId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jobId | 是 | String | 作业 ID |
| status | 是 | String | 作业状态，可选项为：open进行中
                  aborted已终止
                  closed已完成作业状态更新为 close 后，该作业将不再允许提交新的异步任务，已经提交的异步任务会继续正常执行直至结束。
                    作业状态更新为 abort
                      后，该作业将不再允许提交新的异步任务。此外，在调度队列中等待的异步任务也将被取消执行；已经执行的异步任务不会受到影响。 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| closedBy | String | 更新人 |
| jobId | String | 作业 ID |
| state | String | 作业状态open进行中
                  aborted已终止
                  closed已完成 |
| closedAt | String | 更新时间 |
| operation | String | 操作类型
                insert创建数据
                  update更新数据
                  delete删除数据
                  query查询数据 |
| object | String | 对象的 apiKey |

### 获取异步作业详细信息

获取指定异步作业的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/job/{jobId}`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jobId | 是 | String | 作业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| createdAt | String | 创建时间 |
| createdBy | Long | 创建人 |
| execOptions | JSON | execOption当数据操作为新建或更新时，需要校验的逻辑值
                  execOptionDetails校验详情 |
| id | String | 作业 ID |
| state | String | 作业状态
                open进行中
                  aborted已终止
                  closed已完成 |
| operation | String | 操作类型
                insert创建数据
                  update更新数据
                  delete删除数据
                  query查询数据 |
| object | String | 对象的 apiKey |

### 获取所有异步作业详细信息

获取指定租户下所有异步作业的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/job`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| createdAtBegin | 否 | Long | 时间戳，创建时间开始值
                                单位：毫秒 |
| createdAtEnd | 否 | Long | 时间戳，创建时间结束值
                                单位：毫秒 |
| state | 否 | String | 作业状态
                                open进行中
                                    aborted已终止
                                    closed已完成 |
| operation | 否 | String | 操作类型
                                insert创建数据
                                    update更新数据
                                    delete删除数据
                                    query查询数据 |
| object | 否 | String | 对象的 apiKey |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| jobId | String | 作业 ID |
| createdAt | String | 创建时间 |
| createdBy | Long | 创建人 |
| execOptions | JSON | execOption当数据操作为新建或更新时，需要校验的逻辑值
                                    execOptionDetails校验详情 |
| state | String | 作业状态
                                open进行中
                                    aborted已终止
                                    closed已完成 |
| operation | String | 操作类型
                                insert创建数据
                                    update更新数据
                                    delete删除数据
                                    query查询数据 |
| object | String | 对象的 apiKey |
| count | Integer | 作业总数 |

### 创建异步任务

创建异步任务。

- 请求方式: `POST`
- API 地址: `/rest/bulk/v2/batch`

**请求参数**

| 字段 | 必须 | 类型 | 说明 |
|------|------|------|------|
| jobId | 是 | String | 返回的作业 ID |
| datas | 是 | JSONArray | 任务执行数据 |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| jobId | String | 作业 ID |
| createdAt | String | 创建时间 |
| state | String | 任务状态
                                queued队列中
                                    inprocess进行中
                                    completed已完成
                                    failed失败
                                    timeout超时 |
| batchId | String | 任务 ID |

### 获取异步任务原始请求数据

获取指定异步任务的原始请求数据。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/batch/{batchId}/request`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| batchId | 是 | 任务 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| jobId | String | 作业 ID |
| datas | JSONArray | 请求数据详情 |

### 获取异步任务详细信息

获取指定异步任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/batch/{batchId}`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| batchId | 是 | 任务 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| jobId | String | 作业 ID |
| batchId | String | 任务 ID |
| startTime | String | 任务开始执行时间 |
| endTime | String | 任务执行结束时间 |
| productTime | String | 任务加入队列时间 |
| createdAt | String | 任务创建时间 |
| numberRecordsProcessed | Long | 执行成功的记录数 |
| numRecordsFailed | Long | 执行失败的记录数 |
| state | String | 任务执行状态queued队列中
                  inprocess进行中
                  completed已完成
                  failed失败
                  timeout超时 |

### 获取所有异步任务详细信息

获取指定租户下所有异步任务的详细信息。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/batch`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| jobId | 是 | 作业 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| datas | JSONArray | 任务详情 |
| jobId | String | 作业 ID |
| createBy | Long | 创建人 |
| numberRecordsProcessed | Integer | 处理的记录数 |
| state | String | 任务状态 |
| batchId | String | 任务 ID |
| createAt | String | 任务创建时间 |
| count | Integer | 任务总数 |
| startTime | String | 作业开始时间 |
| endTime | String | 作业结束时间 |

### 获取异步任务执行结果

获取指定异步任务的执行结果。

- 请求方式: `GET`
- API 地址: `/rest/bulk/v2/batch/{batchId}/result`

**请求参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| batchId | 是 | 任务 ID |

**返回参数**

| 字段 | 类型 | 说明 |
|------|------|------|
| total | Integer | 处理数据记录的总数，即 records 中返回的数据总数 |
| records | JSONArray | 结果记录详情 |
| create | String | 作业的操作类型为 insert 时返回此项。
                true：数据创建成功
                false：数据创建失败 |
| update | String | 作业的操作类型为 update 时返回此项。
                true：数据更新成功
                false：数据更新失败 |
| delete | String | 作业的操作类型为 delete 时返回此项。
                true：数据删除成功
                false：数据删除失败 |
| id | String | 数据 ID |
| message | String | 执行失败信息 |
| count | Integer | 处理数据记录的总数，即 records 中返回的数据总数 |

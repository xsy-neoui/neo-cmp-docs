# NeoCRM后端开发最佳实践

## 概述

本文档总结了在NeoCRM平台进行Java后端开发（包括触发器、REST API、计划作业等）的最佳实践、常见问题和解决方案。基于客户查重触发器项目的实践经验编写。

## 目录结构规范

### 正确的目录结构
```
src/codePackages/
└── <包名>/                    # 项目包名，如customer-check
    └── other/
        └── <公司缩写>/         # 公司缩写，如xsy
            └── <模块名>/       # 模块名，如customer
                ├── *.java     # Java类文件
                ├── *.xml      # 配置文件
                └── *.jar      # 依赖文件
```

### 注意事项
1. **必须严格遵循**此目录结构，否则部署会失败
2. 包名通常与项目功能相关，如`customer-check`
3. 公司缩写建议使用标准缩写，如公司域名的首字母
4. 模块名应描述具体功能，如`customer`、`order`等

## 包命名规范

### Java包名要求
```java
// 正确示例
package other.xsy.customer;

// 错误示例
package com.example.customer;  // 不以other开头
package other.customer;        // 不是三级包名
```

### 规范要求
1. **必须为三级包名**：`other.公司.模块`
2. **必须以"other"开头**：表示这是自定义代码包
3. **使用小写字母**：包名全部使用小写
4. **避免特殊字符**：使用字母和点号

## 触发器开发

### 触发器XML配置
```xml
<?xml version="1.0" encoding="UTF-8"?>
<root>
    <trigger>
        <name>CustomerDuplicateCheckTrigger</name>
        <object>Account</object>  <!-- 注意：使用API key，不是显示名称 -->
        <status>enabled</status>
        <type>before add</type>
        <executionOrder>10</executionOrder>
        <className>other.xsy.customer.CustomerDuplicateCheckTrigger</className>
    </trigger>
</root>
```

### 配置要点
1. **对象名**：使用实体的API key（如`Account`），标准实体不带“__c”，自定义实体统一都带“__c”
2. **触发时机**：`before add`、`after update`等
3. **执行顺序**：数字越小越先执行
4. **类名**：完整的Java类名，包括包名

### Java触发器类
```java
package other.xsy.customer;

import com.rkhd.platform.sdk.model.DataModel;
import com.rkhd.platform.sdk.model.DataResult;
import com.rkhd.platform.sdk.service.XObjectService;
import com.rkhd.platform.sdk.model.QueryResult;
import com.rkhd.platform.sdk.trigger.TriggerResponse;

public class CustomerDuplicateCheckTrigger {
    
    public DataResult beforeAdd(DataModel newAccount, TriggerResponse triggerResponse) {
        try {
            // 1. 获取数据
            String name = (String) newAccount.getAttribute("name");
            if (name == null || name.trim().isEmpty()) {
                return DataResult.success(newAccount);
            }
            
            // 2. 查询现有记录（使用转义防止SQL注入）
            String escapedName = escapeSqlString(name);
            String sql = "select id, name, createTime, ownerId from Account " +
                        "where name = '" + escapedName + "' and deleteFlag = false";
            
            QueryResult queryResult = XObjectService.instance().query(sql);
            
            // 3. 处理查询结果
            if (queryResult != null && queryResult.getRecords() != null 
                    && queryResult.getRecords().size() > 0) {
                // 构建错误信息
                String createTime = (String) queryResult.getRecords().get(0).getAttribute("createTime");
                String ownerId = (String) queryResult.getRecords().get(0).getAttribute("ownerId");
                
                String errorMessage = String.format(
                    "客户【%s】已存在，创建日期为：%s，当前所有人为：%s",
                    name, createTime, ownerId
                );
                
                // 返回错误阻止保存
                return DataResult.failure(errorMessage, newAccount);
            }
            
            return DataResult.success(newAccount);
            
        } catch (Exception e) {
            // 记录日志并返回错误
            return DataResult.failure("系统错误：" + e.getMessage(), newAccount);
        }
    }
    
    /**
     * 转义SQL字符串，防止SQL注入
     */
    private String escapeSqlString(String input) {
        if (input == null) return "";
        return input.replace("'", "''");
    }
}
```

## SDK使用规范

### 正确的导入语句
```java
// 正确
import com.rkhd.platform.sdk.model.DataModel;
import com.rkhd.platform.sdk.model.DataResult;
import com.rkhd.platform.sdk.model.QueryResult;
import com.rkhd.platform.sdk.service.XObjectService;
import com.rkhd.platform.sdk.trigger.TriggerResponse;

// 错误（不存在的包）
import com.rkhd.platform.sdk.query.*;  // 这个包不存在
```

### 查询数据
```java
// 正确：使用XObjectService
String sql = "select id, name from Account where name = 'test'";
QueryResult result = XObjectService.instance().query(sql);

// 错误：使用不存在的SimpleQueryBuilder
// QueryResult result = SimpleQueryBuilder.withQuery(sql).query(); // 不存在的方法
```

### 处理查询结果
```java
if (queryResult != null && queryResult.getRecords() != null 
        && queryResult.getRecords().size() > 0) {
    // 有结果时的处理逻辑
    DataModel record = queryResult.getRecords().get(0);
    String name = (String) record.getAttribute("name");
    // ... 其他处理
} else {
    // 无结果时的处理逻辑
}
```

## 部署配置

### token.json配置
```json
{
    "refresh_token": "your_refresh_token",
    "access_token": "your_access_token",
    "expires_in": 7200,
    "scope": "all",
    "token_type": "Bearer",
    "instance_uri": "https://crm.xiaoshouyi.com"  // 必须添加此项
}
```

### 部署流程
1. **登录环境**
   ```bash
   neo login -e production
   ```

2. **验证token配置**
   ```bash
   cat .neo-cli/token.json
   ```
   确保包含`instance_uri`字段

3. **打包上传**
   ```bash
   cd hello-buddy-demo
   neo upload -p customer-check
   ```

## 安全最佳实践

### SQL注入防护
```java
// 必须转义用户输入
private String escapeSqlString(String input) {
    if (input == null) return "";
    // 转义单引号
    return input.replace("'", "''");
}

// 使用示例
String userName = (String) data.getAttribute("name");
String safeName = escapeSqlString(userName);
String sql = "select * from Account where name = '" + safeName + "'";
```

### 日期条件拼接规范

动态拼接 SQL 时，日期条件必须使用时间戳（毫秒）。如果日期参数为 null 或空字符串，不要拼接该条件，否则会导致查询异常或返回空结果。

```java
// 正确：日期条件使用时间戳（毫秒），先判空再拼接
StringBuilder sql = new StringBuilder("SELECT id, name FROM opportunity WHERE id > 0");

if (closeDateStart != null) {
    sql.append(" AND closeDate >= ").append(closeDateStart);  // closeDateStart 为 long 类型时间戳
}
if (closeDateEnd != null) {
    sql.append(" AND closeDate <= ").append(closeDateEnd);
}

// 如果入参是日期字符串，需先转为时间戳：
// long timestamp = new SimpleDateFormat("yyyy-MM-dd").parse("2026-04-01").getTime();

// 错误：不判空直接拼接
// sql.append(" AND closeDate >= ").append(closeDateStart);
```

### 输入验证
```java
// 验证必填字段
if (name == null || name.trim().isEmpty()) {
    return DataResult.failure("客户名称不能为空", data);
}

// 验证数据类型
Object value = data.getAttribute("amount");
if (value != null && !(value instanceof Number)) {
    return DataResult.failure("金额必须为数字", data);
}
```

### 错误处理
```java
try {
    // 业务逻辑
    return DataResult.success(data);
} catch (Exception e) {
    // 记录详细日志
    logger.error("触发器执行失败: " + e.getMessage(), e);
    
    // 返回用户友好的错误信息
    return DataResult.failure("系统处理异常，请联系管理员", data);
}
```

## 常见问题与解决方案

### 问题1：SDK 包路径错误
**症状**：编译报错找不到类，如 `com.rkhd.platform.sdk.batchJob.* does not exist`
**原因**：凭记忆猜测包路径，实际 SDK 包结构与直觉不同
**正确路径示例**：
- `BatchJobPro` → `com.rkhd.platform.sdk.task.BatchJobPro`
- `BatchJobParam` / `BatchJobData` / `PrepareParam` → `com.rkhd.platform.sdk.task.param.*`
- `BatchJobException` → `com.rkhd.platform.sdk.exception.BatchJobException`
- `BatchJobProService` → `com.rkhd.platform.sdk.service.BatchJobProService`

**解决**：遇到编译找不到类时，从 `references/sdk-api-reference.md` 或 `src/xObjects/model_classes.md` 中确认正确的包路径，不要凭记忆猜测。

### 问题2：实体名和字段名大小写错误
**症状**：SQL 查询返回空结果或报错，但数据确实存在
**原因**：XOQL/SQL 中实体名和字段名严格区分大小写，猜测的名称与实际不符
**错误示例**：
- `growth_record__c` → 正确为 `GrowthRecord__c`
- `staff_code__c` → 正确为 `StaffCode__c`
- `total_points__c` → 正确为 `TotalPoints__c`

**解决**：开发前必须从 `src/xObjects/AllxObjects.md` 查找实体 API Key，从 `src/xObjects/fields/<apiKey>.md` 查找字段 API Key，严格按文档编码。

### 问题3：XoqlService 与 XObjectService 返回类型混淆
**症状**：类型转换异常，`JSONObject cannot be cast to XObject`
**原因**：两个查询服务返回类型不同
**区别**：
- `XObjectService.instance().query()` → 返回 `QueryResult<XObject>`，用 `getAttribute()` 取值
- `XoqlService.instance().query()` → 返回 `QueryResult<JSONObject>`，用 `getString()` / `getLong()` / `getJSONArray()` 取值

**解决**：两者不能混用。使用 XOQL 查询时统一用 JSONObject 的方法读取字段；需要 XObject 时使用 XObjectService。

### 问题4：BatchJobPro 的 prepare SQL 不支持 ORDER BY
**症状**：BatchJobPro 执行报错或行为异常
**原因**：`prepare()` 方法返回的 SQL 不支持 ORDER BY 子句
**解决**：prepare SQL 保持简单，只做数据筛选（如 `WHERE id > 0`），排序逻辑放到 `execute()` 方法中处理。

### 问题5：N+1 查询性能问题
**症状**：API 响应极慢，脚本超时（超过 15 秒同步限制）
**原因**：在 for 循环中对每条记录单独执行 SQL 查询
**解决**：使用 XOQL 子查询一次性获取关联数据：
```sql
SELECT id, name, StaffCode__c, TotalPoints__c,
  (SELECT id, Type__c, Points__c, Date__c, Status__c FROM GrowthRecord__c 
   WHERE Staff__c = Staff__c.id ORDER BY Date__c DESC LIMIT 5) growthRecords
FROM Staff__c WHERE name IN (...)
```
如果平台不支持子查询，退而求其次用两次查询 + 内存分组：
1. 第一次查询获取所有主记录
2. 第二次用 `WHERE 关联字段 IN (...)` 一次性获取所有关联记录
3. 内存中按关联字段分组

### 问题6：SQL 查询条件使用了选项标签而非选项值
**症状**：SQL 查询返回空结果，但数据确实存在
**原因**：选项类字段（如客户级别）在 SQL 中应使用选项值（数字），不是选项标签（文字）
**错误**：`WHERE level = 'A(重点客户)'`
**正确**：`WHERE level = 1`
**解决**：查阅 `src/xObjects/fields/<apiKey>.md` 中的"选项列表"章节，获取选项值与标签的对应关系。

### 问题7：部署时缺少instance_uri
**症状**：部署脚本报错，提示token.json缺少instance_uri字段
**解决**：在`.neo-cli/token.json`中添加`"instance_uri": "https://crm.xiaoshouyi.com"`

### 问题8：触发器对象名错误
**症状**：部署错误，"trigger [object] not support value (Account__c)"
**解决**：XML配置中使用实体的API key（如`account`），严格参考 `AllxObjects.md`

### 问题9：查询结果处理空指针
**症状**：空指针异常
**解决**：全面检查查询结果
```java
if (queryResult != null && queryResult.getRecords() != null 
        && queryResult.getRecords().size() > 0) {
    // 安全处理
}
```

## 调试与测试

### 本地测试建议
1. **单元测试**：编写JUnit测试用例
2. **日志记录**：添加详细的日志输出
3. **边界测试**：测试空值、特殊字符、超长字符串等边界情况
4. **并发测试**：测试多线程情况下的数据一致性

### 部署后验证
1. **检查部署状态**：在NeoCRM管理后台查看触发器状态
2. **功能测试**：创建测试数据验证触发器逻辑
3. **性能测试**：测试大数据量下的性能表现
4. **安全测试**：测试SQL注入等安全漏洞

## 代码质量规范

### 命名规范
- **类名**：大驼峰，如`CustomerDuplicateCheckTrigger`
- **方法名**：小驼峰，如`beforeAdd`、`escapeSqlString`
- **变量名**：小驼峰，有意义的名称
- **常量名**：全大写，下划线分隔，如`MAX_RETRY_COUNT`

### 注释规范
```java
/**
 * 客户查重触发器
 * 在保存客户前检查是否存在同名客户
 * 
 * @author 开发者
 * @version 1.0
 * @since 2026-04-02
 */
public class CustomerDuplicateCheckTrigger {
    
    /**
     * 保存前的处理逻辑
     * 
     * @param newAccount 新客户数据
     * @param triggerResponse 触发器响应对象
     * @return 处理结果，成功或失败
     */
    public DataResult beforeAdd(DataModel newAccount, TriggerResponse triggerResponse) {
        // 方法实现
    }
    
    /**
     * 转义SQL字符串防止注入
     * 
     * @param input 原始字符串
     * @return 转义后的字符串
     */
    private String escapeSqlString(String input) {
        // 实现
    }
}
```

### 异常处理
```java
public DataResult beforeAdd(DataModel newAccount, TriggerResponse triggerResponse) {
    try {
        // 主逻辑
        return processBusinessLogic(newAccount);
        
    } catch (BusinessException e) {
        // 业务异常，返回用户友好的错误信息
        return DataResult.failure(e.getMessage(), newAccount);
        
    } catch (Exception e) {
        // 系统异常，记录日志并返回通用错误
        logger.error("系统异常: ", e);
        return DataResult.failure("系统处理异常，请联系管理员", newAccount);
    }
}
```

## 版本控制

### 版本命名
- **主版本**：重大功能变更
- **次版本**：新功能添加
- **修订号**：Bug修复

### 变更记录
每次部署应记录：
1. 部署时间
2. 部署人员
3. 变更内容
4. 影响范围
5. 回滚方案

## 总结

遵循上述最佳实践可以：
1. 减少部署错误和开发问题
2. 提高代码质量和可维护性
3. 增强系统安全性
4. 提升开发效率
5. 便于团队协作

---

## 员工绩效成长值系统踩坑总结

基于员工绩效成长值自动结算系统的代码审查，总结以下高频问题和修复方案。

### 问题8：XOQL 子查询语法使用关系名 `__r` 而非实体名 `__c`

**症状**：XOQL 子查询执行报错或返回空结果
**原因**：XOQL 子查询中应使用子实体的 API Key（`__c`）并显式指定关联条件，而不是用关系名（`__r`）
**错误**：
```sql
SELECT id, name,
  (SELECT id, type__c FROM GrowthRecord__r ORDER BY date__c DESC LIMIT 5)
FROM Staff__c WHERE name IN ('张三')
```
**正确**：
```sql
SELECT id, name,
  (SELECT id, type__c FROM GrowthRecord__c 
   WHERE staff__c = Staff__c.id ORDER BY date__c DESC LIMIT 5) growthRecords
FROM Staff__c WHERE name IN ('张三')
```
**要点**：
- 子查询 `FROM` 后面跟实体名 `GrowthRecord__c`，不是关系名 `GrowthRecord__r`
- 必须显式写关联条件 `WHERE staff__c = Staff__c.id`
- 子查询需要一个别名（如 `growthRecords`），否则返回结果中无法通过 key 获取子查询数据

### 问题9：XoqlService 返回 JSONObject 却按 XObject 处理

**症状**：运行时类型转换异常，`JSONObject cannot be cast to XObject`
**原因**：`XoqlService.instance().query()` 返回 `QueryResult<JSONObject>`，不是 `QueryResult<XObject>`
**错误**：
```java
QueryResult queryResult = XoqlService.instance().query(sql);
for (XObject staff : queryResult.getRecords()) {  // 实际是 JSONObject
    staff.getId();           // JSONObject 没有 getId()
    staff.getAttribute(...); // JSONObject 没有 getAttribute()
}
```
**正确**：
```java
QueryResult<JSONObject> queryResult = XoqlService.instance().query(sql, true);
for (JSONObject staff : queryResult.getRecords()) {
    staff.getLong("id");
    staff.getString("name");
    staff.getJSONArray("growthRecords");  // 子查询结果用别名获取
}
```
**要点**：
- `XoqlService.query()` → `JSONObject`，用 `getString()`/`getLong()`/`getJSONArray()` 取值
- `XObjectService.query()` → `XObject`，用 `getAttribute()` 取值
- 第二个参数 `true` 表示管理员权限，确保能查到所有数据

### 问题10：BatchJobDataBuilder 使用了不存在的 API

**症状**：编译报错，找不到 `builder()` 方法或 `buildQueryData(String)` 方法
**原因**：`BatchJobDataBuilder` 没有静态 `builder()` 方法，`buildQueryData()` 也不接受参数
**错误**：
```java
return BatchJobDataBuilder.builder()
    .buildQueryData(sql)
    .setApiKey("GrowthRecord__c");
```
**正确**：
```java
return new BatchJobDataBuilder()
    .setSql(sql)
    .setAdmin(true)
    .buildQueryData();
```
**要点**：
- 使用 `new BatchJobDataBuilder()` 构造，不是 `builder()`
- 先 `setSql()` 设置查询语句，再 `setAdmin(true)` 设置管理员权限
- 最后调用无参的 `buildQueryData()` 构建返回值
- prepare SQL 不支持 ORDER BY，保持简单筛选条件

### 问题11：BatchJobPro.execute 的 List 参数类型取决于 prepare 返回的数据

**症状**：运行时类型转换异常或字段读取返回 null
**原因**：`execute(List dataList, BatchJobParam param)` 中 `dataList` 的元素类型取决于 `prepare` 中使用的查询方式
**规则**：
- 如果 `prepare` 使用 `buildQueryData()`，`dataList` 中的元素是 `XObject`
- 如果 `prepare` 使用 `buildListData()`，`dataList` 中的元素是自定义传入的对象

**错误**：
```java
// prepare 查询的是 Staff__c，但 execute 中按 BatchJobParam 处理
public void execute(List<BatchJobParam> dataList, BatchJobParam param) {
    for (BatchJobParam record : dataList) {
        record.get("staff__c");  // BatchJobParam.get() 只能获取启动参数
    }
}
```
**正确**：
```java
public void execute(List dataList, BatchJobParam param) {
    for (Object obj : dataList) {
        XObject staff = (XObject) obj;
        Long staffId = staff.getId();
        Object points = staff.getAttribute("totalPoints__c");
    }
}
```

### 问题12：BatchJobPro 以错误的实体作为拆分单位导致并发积分覆盖

**症状**：批处理完成后员工积分不正确，部分积分丢失
**原因**：以 `GrowthRecord__c` 作为拆分单位时，同一员工的成长记录可能分散在不同批次。两个批次各自查询员工当前积分 → 各自累加 → 各自写回，后写入的会覆盖先写入的结果。
**错误设计**：
```java
// prepare 查询成长记录，按记录拆分批次
String sql = "SELECT id, staff__c, points__c FROM GrowthRecord__c WHERE status__c = '待处理'";
```
**正确设计**：
```java
// prepare 查询所有员工，不加筛选条件，保持最简单
// 由 execute 中判断该批员工是否有待处理记录
String sql = "SELECT id, totalPoints__c FROM Staff__c WHERE id > 0";
```
然后在 `execute` 中用 XOQL 一次性查询本批次所有员工的待处理记录：
```java
String growthSql = "SELECT id, staff__c, points__c FROM GrowthRecord__c " +
                   "WHERE staff__c IN (" + staffIdsStr + ") AND status__c = '待处理'";
QueryResult<JSONObject> result = XoqlService.instance().query(growthSql, true);
```

### 问题13：SQL 注入转义使用反斜杠而非双单引号

**症状**：包含单引号的输入导致 SQL 执行异常
**原因**：NeoCRM XOQL 使用双单引号 `''` 转义，不支持反斜杠 `\'`
**错误**：
```java
nameList.add("'" + name.replace("'", "\\'") + "'");
```
**正确**：
```java
nameList.add("'" + name.replace("'", "''") + "'");
```

### 问题14：SimpleDateFormat 作为 static final 字段导致线程安全问题

**症状**：并发请求下日期格式化结果错乱或抛出 NumberFormatException
**原因**：`SimpleDateFormat` 不是线程安全的，多线程共享同一实例会互相干扰
**错误**：
```java
private static final SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

private String formatDateTime(Object value) {
    return DATETIME_FORMAT.format(new Date(timestamp));  // 并发不安全
}
```
**正确**：
```java
private String formatDateTime(Object value) {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  // 每次创建新实例
    return fmt.format(new Date(timestamp));
}
```

### 问题15：XObjectService.update 的 partialSuccess 和 admin 参数设置不当

**症状**：单条数据更新失败导致整批回滚；或因权限不足导致更新失败
**原因**：`update(list, partialSuccess, admin)` 两个 boolean 参数含义不同
**建议**：
```java
// partialSuccess=true：部分失败不影响其他记录
// admin=true：以管理员权限执行，避免权限问题
XObjectService.instance().update(batch, true, true);
```
批量更新建议分页大小 100 条/批，避免超出单次 DML 10,000 条限制。

---

### 问题16：自定义 API 类不应实现 ApiSupport 接口

**症状**：编译报错 `does not override abstract method execute(Request, Long, Long) in ApiSupport`
**原因**：`ApiSupport` 接口的 `execute` 方法签名是 `execute(Request, Long, Long)`，与 `@RestMapping` 注解的自定义方法签名不匹配。实现该接口后编译器要求覆写抽象方法，导致冲突。
**错误**：
```java
@RestApi(baseUrl = "/performance")
public class MyApi implements ApiSupport {  // ❌ 不要实现 ApiSupport
    @Override  // ❌ 方法签名不匹配，编译报错
    @RestMapping(value = "/getData", method = RequestMethod.POST)
    public String execute(@RestBeanParam(name = "requestBody") String body) throws Exception {
```
**正确**：
```java
@RestApi(baseUrl = "/performance")
public class MyApi {  // ✅ 普通类，只用 @RestApi 注解
    @RestMapping(value = "/getData", method = RequestMethod.POST)
    public String execute(@RestBeanParam(name = "requestBody") String body)
            throws ApiEntityServiceException {  // ✅ 抛 ApiEntityServiceException
```
**要点**：
- 自定义 API 类只需 `@RestApi` 注解，不需要实现任何接口
- 方法异常声明用 `ApiEntityServiceException`，不要用 `Exception`
- 不需要 `@Override` 注解

### 问题17：XObject 构造器是 protected，不能直接 new

**症状**：编译报错 `XObject(java.lang.String) has protected access` 或 `constructor XObject cannot be applied to given types`
**原因**：`XObject` 的构造器是 `protected`，不能在业务代码中直接 `new XObject()` 或 `new XObject("apiKey")`
**错误**：
```java
XObject obj = new XObject();              // ❌ 无参构造不存在
XObject obj = new XObject("Staff__c");    // ❌ protected，无法访问
```
**正确**：
```java
import com.rkhd.platform.sdk.data.model.Staff__c;
import com.rkhd.platform.sdk.data.model.GrowthRecord__c;

XObject obj = new Staff__c();             // ✅ 使用 model.jar 中的子类
obj.setId(staffId);
obj.setAttribute("TotalPoints__c", 100.0);
```
**要点**：
- 必须使用 `model.jar` 中的实体子类（如 `Staff__c`、`GrowthRecord__c`）来构造 XObject
- 子类位于 `com.rkhd.platform.sdk.data.model` 包下
- 如果没有 model.jar，先执行 `python3 scripts/update_model_jar.py <项目目录>` 下载

### 问题18：BatchJobPro 必须指定泛型参数

**症状**：编译报错 `Class<MyJob> cannot be converted to Class<? extends BatchJobPro<?>>`
**原因**：`BatchJobProService.addBatchJob` 要求传入的类必须实现 `BatchJobPro<T>`，缺少泛型参数会导致类型不匹配
**错误**：
```java
public class MyJob implements BatchJobPro {  // ❌ 缺少泛型参数
```
**正确**：
```java
public class MyJob implements BatchJobPro<XObject> {  // ✅ 指定泛型为 XObject
    @Override
    public BatchJobData prepare(PrepareParam param) { ... }

    @Override
    public void execute(List<XObject> dataList, BatchJobParam param) {  // ✅ 类型化的 List
        // 注意：不能 throws Exception，接口方法未声明异常
        try {
            // 业务逻辑
        } catch (Exception e) {
            log.error("批次处理异常: " + e.getMessage(), e);
        }
    }

    @Override
    public void finish(BatchJobParam param) { ... }
}
```
**要点**：
- `implements BatchJobPro<XObject>`，使用 `buildQueryData()` 时泛型为 `XObject`
- `execute` 方法不能声明 `throws Exception`，需在方法内 try-catch
- `addBatchJob` 的 `PrepareParam` 参数可以传 `null`

### 问题19：选项类字段在 SQL 中必须使用选项值（数字），不是选项标签（文字）

**症状**：SQL 查询返回空结果，但数据确实存在
**原因**：选项类字段（Picklist）在数据库中存储的是选项值（整数），不是选项标签（文字）。查询和更新时必须使用数字。
**错误**：
```java
// ❌ 用选项标签查询
String sql = "SELECT id FROM GrowthRecord__c WHERE Status__c = '待处理'";
// ❌ 用字符串更新
obj.setAttribute("Status__c", "已处理");
```
**正确**：
```java
// ✅ 用选项值（数字）查询 —— 从实体字段描述文件中查找选项值
String sql = "SELECT id FROM GrowthRecord__c WHERE Status__c = 1";  // 1=待处理
// ✅ 用整数更新
obj.setAttribute("Status__c", 2);  // 2=已处理
```
**查找选项值的方法**：
1. 执行 `python3 scripts/gen_entity_desc.py <项目目录> <实体apiKey>` 拉取字段描述
2. 在生成的 `src/xObjects/fields/<apiKey>.md` 中查看"选项列表"章节

### 问题20：开发前必须拉取实体模型验证字段 API Key

**症状**：字段名大小写错误、字段名多了或少了 `__c` 后缀、使用了不存在的字段
**原因**：凭需求文档或记忆编码，未与平台实际字段定义核对
**正确流程**：
```bash
# 1. 登录平台
cd <项目目录> && neo login

# 2. 拉取实体字段描述
python3 scripts/gen_entity_desc.py <项目目录> Staff__c
python3 scripts/gen_entity_desc.py <项目目录> GrowthRecord__c

# 3. 下载 model.jar（获取 Java 子类）
python3 scripts/update_model_jar.py <项目目录>

# 4. 解析 model.jar（生成模型类速查表）
python3 scripts/parse_model_jar.py <项目目录>
```
**实际案例**：需求文档定义字段为 `LastCalcTime__c`，但平台实际创建的 API Key 是 `LastCalcTime__c__c`（多了一个 `__c`）。不拉取实体模型就无法发现这个差异。

---

### 问题10：XObject 不能直接 new，必须用 model.jar 子类
**症状**：编译报错 `XObject()` 构造器不存在或 protected 无法访问
**解决**：使用 `com.rkhd.platform.sdk.data.model.{EntityApiKey}` 子类构造，如 `new Staff__c()`、`new Account()`

### 问题11：@RestApi baseUrl 必须以 / 开头
**症状**：API 路由 404
**错误**：`@RestApi(baseUrl = "staffPoints")`
**正确**：`@RestApi(baseUrl = "/staffPoints")`

### 问题12：@RestApi 不支持 devDescription 参数
**症状**：编译错误
**解决**：`@RestApi` 只接受 `baseUrl` 参数，描述信息放 `scriptTrigger.xml` 的 `<description>` 标签

### 问题13：insert 自定义实体必须设置 entityType
**症状**：`insert()` 不抛异常但 `getDataId()` 返回 null
**解决**：创建前必须设置业务类型：
```java
MetadataModel busiType = MetadataService.instance().getBusiType("Staff__c", "defaultBusiType");
xObject.setAttribute("entityType", busiType.getId());
```

### 问题14：MetadataService.getBusiType 是两参数方法
**症状**：编译报错找不到方法
**正确**：`MetadataService.instance().getBusiType("entityApiKey", "defaultBusiType")`，返回 `MetadataModel`

### 问题15：新实体创建后 model.jar 需要同步时间
**症状**：部署报错 `cannot find symbol: class XXX__c`
**解决**：新实体通过 Metadata API 创建后，服务器端 model.jar 需要时间同步。等待片刻后重试部署

### 问题16：部署时偶发 Dubbo RPC 错误
**症状**：`Failed to invoke the method compilerUpdateByZip`
**解决**：重试几次即可，这是基础设施层面的问题，与代码无关

### 问题17：最小可验证原则
**教训**：每次只做最小粒度改动并立即验证。先部署一个 Hello World API 验证路由可用，再逐步增加逻辑。避免一次性写完整逻辑后再部署导致多个问题叠加难以排查

---

*文档版本：1.4*  
*最后更新：2026-05-13*  
*基于客户查重触发器、员工成长系统、员工绩效积分等项目实践经验编写*
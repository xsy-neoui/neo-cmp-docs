# NeoCRM PaaS SDK 参考

从 SDK class 文件解析生成，包含所有公开类、接口和方法签名。

## 包概览

| 包名 | 用途 | 类数量 |
|------|------|--------|
| com.rkhd.platform.sdk | 核心接口（ScheduleJob、ScriptTrigger） | 2 |
| com.rkhd.platform.sdk.api | 自定义 REST API 开发 | 1 |
| com.rkhd.platform.sdk.api.annotations | 自定义 API 注解 | 6 |
| com.rkhd.platform.sdk.bulkapi.bulkapicallback | 批量 API 回调 | 2 |
| com.rkhd.platform.sdk.common | 通用配置（OAuth） | 1 |
| com.rkhd.platform.sdk.context | 脚本运行时上下文 | 2 |
| com.rkhd.platform.sdk.creekflow.approvalchooser | 审批人选择器扩展 | 3 |
| com.rkhd.platform.sdk.creekflow.approvalevent | 审批事件扩展 | 4 |
| com.rkhd.platform.sdk.creekflow.autoflowevent | 自动化流程事件扩展 | 3 |
| com.rkhd.platform.sdk.creekflow.ruleevent | 规则事件扩展 | 3 |
| com.rkhd.platform.sdk.creekflow.stageprocessevent | 阶段流程事件扩展 | 3 |
| com.rkhd.platform.sdk.developer.aiaction | AI Action 脚本扩展 | 3 |
| com.rkhd.platform.sdk.developer.aiaction.annotations | AI Action 注解 | 3 |
| com.rkhd.platform.sdk.exception | 异常类 | 12 |
| com.rkhd.platform.sdk.http | HTTP 客户端工具 | 17 |
| com.rkhd.platform.sdk.http.handler | HTTP 响应处理器 | 2 |
| com.rkhd.platform.sdk.license.assignlicenseevent | 许可证分配事件 | 4 |
| com.rkhd.platform.sdk.listener | 事件监听器 | 3 |
| com.rkhd.platform.sdk.log | 日志工具 | 2 |
| com.rkhd.platform.sdk.log.logevent | 日志事件 | 2 |
| com.rkhd.platform.sdk.model | 数据模型（XObject、QueryResult 等） | 8 |
| com.rkhd.platform.sdk.noticeflow.noticeevent | 通知流程事件 | 7 |
| com.rkhd.platform.sdk.param | 参数模型 | 3 |
| com.rkhd.platform.sdk.prompt | AI 提示词模板 | 5 |
| com.rkhd.platform.sdk.serialize | 序列化/反序列化 | 3 |
| com.rkhd.platform.sdk.service | 核心服务类（XObjectService、CacheService 等） | 11 |
| com.rkhd.platform.sdk.task | 异步任务（BatchJob、FutureTask） | 4 |
| com.rkhd.platform.sdk.task.param | BatchJob 参数模型 | 8 |
| com.rkhd.platform.sdk.test.tool | 本地测试工具 | 5 |
| com.rkhd.platform.sdk.trigger | 触发器开发 | 5 |
| com.rkhd.platform.sdk.userdepart.assignrespevent | 用户职责分配事件 | 3 |
| com.rkhd.platform.sdk.userdepart.assignroleevent | 用户角色分配事件 | 3 |
| com.rkhd.platform.sdk.util | 工具类（IO） | 1 |
| com.rkhd.platform.sdk.util.aes | AES 加密工具 | 2 |
| com.rkhd.platform.sdk.util.encrypt | 对称加密工具 | 4 |
| com.rkhd.platform.sdk.util.encrypt.asymmetric | 非对称加密工具（RSA） | 5 |

---

## com.rkhd.platform.sdk

核心接口（ScheduleJob、ScriptTrigger）

### ScheduleJob

`interface com.rkhd.platform.sdk.ScheduleJob`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | void | ScheduleJobParam |

### ScriptTrigger

`interface com.rkhd.platform.sdk.ScriptTrigger`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | ScriptTriggerResult | ScriptTriggerParam |

---

## com.rkhd.platform.sdk.api

自定义 REST API 开发

### ApiSupport

`interface com.rkhd.platform.sdk.api.ApiSupport`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | String | Request, Long, Long |

---

## com.rkhd.platform.sdk.api.annotations

自定义 API 注解

### MediaType

`enum com.rkhd.platform.sdk.api.annotations.MediaType`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static values | MediaType[] | - |
| static valueOf | MediaType | String |
| getValue | String | - |

### RequestMethod

`enum com.rkhd.platform.sdk.api.annotations.RequestMethod`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static values | RequestMethod[] | - |
| static valueOf | RequestMethod | String |

### RestApi

`interface com.rkhd.platform.sdk.api.annotations.RestApi`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| baseUrl | String | - |

### RestBeanParam

`interface com.rkhd.platform.sdk.api.annotations.RestBeanParam`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| name | String | - |

### RestMapping

`interface com.rkhd.platform.sdk.api.annotations.RestMapping`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| value | String | - |
| method | RequestMethod | - |
| responseMediaType | MediaType | - |

### RestQueryParam

`interface com.rkhd.platform.sdk.api.annotations.RestQueryParam`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| name | String | - |

---

## com.rkhd.platform.sdk.bulkapi.bulkapicallback

批量 API 回调

### BulkApiCallBack

`interface com.rkhd.platform.sdk.bulkapi.bulkapicallback.BulkApiCallBack`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | void | BulkApiCallBackRequest |

### BulkApiCallBackRequest

`class com.rkhd.platform.sdk.bulkapi.bulkapicallback.BulkApiCallBackRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BulkApiCallBackRequest (构造器) | void | - |
| getBatchId | String | - |
| setBatchId | void | String |

---

## com.rkhd.platform.sdk.common

通用配置（OAuth）

### OauthConfig

`class com.rkhd.platform.sdk.common.OauthConfig`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| OauthConfig (构造器) | void | - |
| getUserName | String | - |
| getPassword | String | - |
| getSecurityCode | String | - |
| getClientId | String | - |
| getClientSecret | String | - |
| getOauthUrl | String | - |
| getDomain | String | - |

---

## com.rkhd.platform.sdk.context

脚本运行时上下文

### EnvInfo

`class com.rkhd.platform.sdk.context.EnvInfo`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getLanguageCode | String | - |
| getName | String | - |

### ScriptRuntimeContext

`class com.rkhd.platform.sdk.context.ScriptRuntimeContext`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | ScriptRuntimeContext | - |
| getUserId | Long | - |
| getTenantId | Long | - |
| getEnvInfo | EnvInfo | - |

---

## com.rkhd.platform.sdk.creekflow.approvalchooser

审批人选择器扩展

### ApprovalChooser

`interface com.rkhd.platform.sdk.creekflow.approvalchooser.ApprovalChooser`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | ApprovalChooserResponse | ApprovalChooserRequest |

### ApprovalChooserRequest

`class com.rkhd.platform.sdk.creekflow.approvalchooser.ApprovalChooserRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ApprovalChooserRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getDataId | Long | - |
| setDataId | void | Long |
| getUsertaskLogId | Long | - |
| setUsertaskLogId | void | Long |
| getProcdefId | Long | - |
| setProcdefId | void | Long |
| getTaskDefKey | String | - |
| setTaskDefKey | void | String |
| getTaskDefName | String | - |
| setTaskDefName | void | String |

### ApprovalChooserResponse

`class com.rkhd.platform.sdk.creekflow.approvalchooser.ApprovalChooserResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ApprovalChooserResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |
| getData | List | - |
| setData | void | List |

---

## com.rkhd.platform.sdk.creekflow.approvalevent

审批事件扩展

### ApprovalEvent

`interface com.rkhd.platform.sdk.creekflow.approvalevent.ApprovalEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | ApprovalEventResponse | ApprovalEventRequest |

### ApprovalEventRequest

`class com.rkhd.platform.sdk.creekflow.approvalevent.ApprovalEventRequest`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ApprovalEventRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getDataId | Long | - |
| setDataId | void | Long |
| getUsertaskLogId | Long | - |
| setUsertaskLogId | void | Long |
| getProcessApiKey | String | - |
| setProcessApiKey | void | String |
| getInstanceId | Long | - |
| setInstanceId | void | Long |
| getTaskInfo | TaskInfo | - |
| setTaskInfo | void | TaskInfo |

### ApprovalEventResponse

`class com.rkhd.platform.sdk.creekflow.approvalevent.ApprovalEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ApprovalEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

### TaskInfo

`class com.rkhd.platform.sdk.creekflow.approvalevent.TaskInfo`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TaskInfo (构造器) | void | - |
| getNodeName | String | - |
| setNodeName | void | String |
| getNodeApiKey | String | - |
| setNodeApiKey | void | String |
| getButtonName | String | - |
| setButtonName | void | String |
| getButtonApiKey | String | - |
| setButtonApiKey | void | String |
| getPreNodeName | String | - |
| setPreNodeName | void | String |
| getPreNodeApiKey | String | - |
| setPreNodeApiKey | void | String |
| getPreButtonName | String | - |
| setPreButtonName | void | String |
| getPreButtonApiKey | String | - |
| setPreButtonApiKey | void | String |

---

## com.rkhd.platform.sdk.creekflow.autoflowevent

自动化流程事件扩展

### AutoFlowEvent

`interface com.rkhd.platform.sdk.creekflow.autoflowevent.AutoFlowEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | AutoFlowEventResponse | AutoFlowEventRequest |

### AutoFlowEventRequest

`class com.rkhd.platform.sdk.creekflow.autoflowevent.AutoFlowEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AutoFlowEventRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getDataId | Long | - |
| setDataId | void | Long |
| getProcessInstanceId | Long | - |
| setProcessInstanceId | void | Long |

### AutoFlowEventResponse

`class com.rkhd.platform.sdk.creekflow.autoflowevent.AutoFlowEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AutoFlowEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

---

## com.rkhd.platform.sdk.creekflow.ruleevent

规则事件扩展

### RuleEvent

`interface com.rkhd.platform.sdk.creekflow.ruleevent.RuleEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | RuleEventResponse | RuleEventRequest |

### RuleEventRequest

`class com.rkhd.platform.sdk.creekflow.ruleevent.RuleEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RuleEventRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getDataId | Long | - |
| setDataId | void | Long |

### RuleEventResponse

`class com.rkhd.platform.sdk.creekflow.ruleevent.RuleEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RuleEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

---

## com.rkhd.platform.sdk.creekflow.stageprocessevent

阶段流程事件扩展

### StageProcessEvent

`interface com.rkhd.platform.sdk.creekflow.stageprocessevent.StageProcessEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | StageProcessEventResponse | StageProcessEventRequest |

### StageProcessEventRequest

`class com.rkhd.platform.sdk.creekflow.stageprocessevent.StageProcessEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| StageProcessEventRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getDataId | Long | - |
| setDataId | void | Long |
| getUsertaskLogId | Long | - |
| setUsertaskLogId | void | Long |

### StageProcessEventResponse

`class com.rkhd.platform.sdk.creekflow.stageprocessevent.StageProcessEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| StageProcessEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

---

## com.rkhd.platform.sdk.developer.aiaction

AI Action 脚本扩展

### ScriptAIAction

`interface com.rkhd.platform.sdk.developer.aiaction.ScriptAIAction`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | ScriptAIActionResponse | ScriptAIActionRequest |

### ScriptAIActionRequest

`class com.rkhd.platform.sdk.developer.aiaction.ScriptAIActionRequest`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ScriptAIActionRequest (构造器) | void | - |
| getInputParams | JSONObject | - |
| setInputParams | void | JSONObject |

### ScriptAIActionResponse

`class com.rkhd.platform.sdk.developer.aiaction.ScriptAIActionResponse`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ScriptAIActionResponse (构造器) | void | - |
| getResponse | String | - |
| setResponse | void | String |

---

## com.rkhd.platform.sdk.developer.aiaction.annotations

AI Action 注解

### ScriptAIActionAnnotation

`interface com.rkhd.platform.sdk.developer.aiaction.annotations.ScriptAIActionAnnotation`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| apiKey | String | - |
| label | String | - |
| description | String | - |

### ScriptAIActionField

`interface com.rkhd.platform.sdk.developer.aiaction.annotations.ScriptAIActionField`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| name | String | - |
| label | String | - |
| description | String | - |

### ScriptAIActionParams

`interface com.rkhd.platform.sdk.developer.aiaction.annotations.ScriptAIActionParams`

实现: Annotation

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| params | ScriptAIActionField[] | - |

---

## com.rkhd.platform.sdk.exception

异常类

### AesException

`class com.rkhd.platform.sdk.exception.AesException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| AesException (构造器) | void | String |
| AesException (构造器) | void | Throwable |
| AesException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### ApiEntityServiceException

`class com.rkhd.platform.sdk.exception.ApiEntityServiceException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| ApiEntityServiceException (构造器) | void | String |
| ApiEntityServiceException (构造器) | void | String, Long |
| ApiEntityServiceException (构造器) | void | Throwable |
| ApiEntityServiceException (构造器) | void | String, Long, Throwable |
| ApiEntityServiceException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### AsyncTaskException

`class com.rkhd.platform.sdk.exception.AsyncTaskException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| AsyncTaskException (构造器) | void | String |
| AsyncTaskException (构造器) | void | String, Long |
| AsyncTaskException (构造器) | void | Throwable |
| AsyncTaskException (构造器) | void | String, Long, Throwable |
| AsyncTaskException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### BatchJobException

`class com.rkhd.platform.sdk.exception.BatchJobException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| BatchJobException (构造器) | void | String |
| BatchJobException (构造器) | void | Throwable |
| BatchJobException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### CacheException

`class com.rkhd.platform.sdk.exception.CacheException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| CacheException (构造器) | void | String |
| CacheException (构造器) | void | Throwable |
| CacheException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### CustomConfigException

`class com.rkhd.platform.sdk.exception.CustomConfigException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| CustomConfigException (构造器) | void | String |
| CustomConfigException (构造器) | void | Throwable |
| CustomConfigException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### EmailException

`class com.rkhd.platform.sdk.exception.EmailException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| EmailException (构造器) | void | String |
| EmailException (构造器) | void | Throwable |
| EmailException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### LockServiceException

`class com.rkhd.platform.sdk.exception.LockServiceException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| LockServiceException (构造器) | void | String |
| LockServiceException (构造器) | void | Throwable |
| LockServiceException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### RkhdSoapException

`class com.rkhd.platform.sdk.exception.RkhdSoapException`

继承: RuntimeException

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| RkhdSoapException (构造器) | void | String |
| RkhdSoapException (构造器) | void | String, Long |
| RkhdSoapException (构造器) | void | Throwable |
| RkhdSoapException (构造器) | void | String, Long, Throwable |
| RkhdSoapException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### ScriptBusinessException

`class com.rkhd.platform.sdk.exception.ScriptBusinessException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| ScriptBusinessException (构造器) | void | String |
| ScriptBusinessException (构造器) | void | Throwable |
| ScriptBusinessException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### TriggerContextException

`class com.rkhd.platform.sdk.exception.TriggerContextException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| TriggerContextException (构造器) | void | String |
| TriggerContextException (构造器) | void | Throwable |
| TriggerContextException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

### XsyHttpException

`class com.rkhd.platform.sdk.exception.XsyHttpException`

继承: Exception

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getMessage | String | - |
| XsyHttpException (构造器) | void | String |
| XsyHttpException (构造器) | void | String, Long |
| XsyHttpException (构造器) | void | Throwable |
| XsyHttpException (构造器) | void | String, Long, Throwable |
| XsyHttpException (构造器) | void | String, Throwable |
| getCause | Throwable | - |

---

## com.rkhd.platform.sdk.http

HTTP 客户端工具

### CommonData

`class com.rkhd.platform.sdk.http.CommonData`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| CommonData (构造器) | void | - |
| CommonData (构造器) | void | String, String, String |
| static newBuilder | CommonData$Builder | - |
| getCall_type | String | - |
| setCall_type | void | String |
| getBody | String | - |
| setBody | void | String |
| getCallString | String | - |
| setCallString | void | String |
| getHeaders | Map | - |
| putHeader | void | String, String |
| getBinary | Object | - |
| putBinary | void | Object |
| getFormData | Map | - |
| putFormData | void | String, Object |
| putFormDataAll | void | Map |
| getFormType | String | - |
| setFormType | void | String |
| addHeader | void | String, String |
| addHeader | void | HttpHeader |
| getMimeType | String | - |
| getHeaderList | List | - |
| toString | String | - |

### CommonHttpClient

`class com.rkhd.platform.sdk.http.CommonHttpClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| CommonHttpClient (构造器) | void | - |
| static instance | CommonHttpClient | int, int |
| static instance | CommonHttpClient | - |
| performRequest | String | CommonData |
| execute | HttpResult | CommonData |
| execute | CommonResponse | CommonData, ResponseBodyHandler |
| downFile | RkhdFile | CommonData |
| downBlob | RkhdBlob | CommonData |
| close | void | - |
| createClientWithoutSSL | void | - |
| createClientWithoutSSL | void | int, int |
| createSSLClient | void | - |
| getContentEncoding | String | - |
| setContentEncoding | void | String |
| getContentType | String | - |
| setContentType | void | String |

### CommonHttpSoapClient

`class com.rkhd.platform.sdk.http.CommonHttpSoapClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | CommonHttpSoapClient | - |
| execute | RkhdSoapResponse | RkhdSoapRequest |

### CommonResponse

`class com.rkhd.platform.sdk.http.CommonResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| CommonResponse (构造器) | void | - |
| getCode | int | - |
| setCode | void | int |
| getHeaders | List | - |
| setHeaders | void | List |
| getData | Object | - |
| setData | void | Object |

### HttpDeleteWithEntity

`class com.rkhd.platform.sdk.http.HttpDeleteWithEntity`

继承: HttpEntityEnclosingRequestBase

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| HttpDeleteWithEntity (构造器) | void | - |
| HttpDeleteWithEntity (构造器) | void | URI |
| HttpDeleteWithEntity (构造器) | void | String |
| getMethod | String | - |

### HttpHeader

`class com.rkhd.platform.sdk.http.HttpHeader`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| HttpHeader (构造器) | void | - |
| getName | String | - |
| setName | void | String |
| getValue | String | - |
| setValue | void | String |

### HttpResult

`class com.rkhd.platform.sdk.http.HttpResult`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| HttpResult (构造器) | void | - |
| getAllHeaders | List | - |
| setHeader | void | String, String |
| getHeaders | List | String |
| getResult | String | - |
| setResult | void | String |

### Request

`class com.rkhd.platform.sdk.http.Request`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| Request (构造器) | void | - |
| putParameter | void | String, String[] |
| setReader | void | StringBuffer |
| getParameter | String | String |
| getParameterValues | String[] | String |
| getParameterMap | Map | - |
| getReader | StringBuffer | - |
| static main | void | String[] |

### RkhdBlob

`class com.rkhd.platform.sdk.http.RkhdBlob`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RkhdBlob (构造器) | void | - |
| RkhdBlob (构造器) | void | String, byte[] |
| getFileName | String | - |
| setFileName | void | String |
| getBytes | byte[] | - |
| setBytes | void | byte[] |
| size | int | - |

### RkhdFile

`class com.rkhd.platform.sdk.http.RkhdFile`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RkhdFile (构造器) | void | - |
| RkhdFile (构造器) | void | String, String |
| getFileName | String | - |
| setFileName | void | String |
| getFileContent | String | - |
| setFileContent | void | String |

### RkhdHttpClient

`class com.rkhd.platform.sdk.http.RkhdHttpClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RkhdHttpClient (构造器) | void | - |
| static instance | RkhdHttpClient | - |
| performRequest | String | RkhdHttpData |
| downFile | RkhdFile | RkhdHttpData |
| downBlob | RkhdBlob | RkhdHttpData |
| execute | Object | RkhdHttpData, ResponseBodyHandler |
| close | void | - |
| setContentEncoding | void | String |
| setContentType | void | String |

### RkhdHttpData

`class com.rkhd.platform.sdk.http.RkhdHttpData`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RkhdHttpData (构造器) | void | - |
| RkhdHttpData (构造器) | void | String, String, String |
| getCall_type | String | - |
| setCall_type | void | String |
| getBody | String | - |
| setBody | void | String |
| getCallString | String | - |
| setCallString | void | String |
| getFormData | Map | - |
| putFormData | void | String, Object |
| setFormData | void | HashMap |
| getHeaderMap | Map | - |
| setHeaderMap | void | Map |
| putHeader | void | String, String |
| toString | String | - |
| static newBuilder | RkhdHttpData$Builder | - |

### RkhdSoapRequest

`class com.rkhd.platform.sdk.http.RkhdSoapRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getInvokeUrl | String | - |
| getTargetNameSpaceUrl | String | - |
| getOperationNameSpaceUrl | String | - |
| getOperationName | String | - |
| getParamUseOperationPrefix | Boolean | - |
| getSoapVersion | RkhdSoapRequest$SoapVersionEnum | - |
| getHttpHeaders | Map | - |
| getSoapHeaders | Map | - |
| getBodyParams | Map | - |
| getReadTimeout | Integer | - |
| getConnectTimeout | Integer | - |
| getXmlRequest | String | - |
| setOperationNameSpaceUrl | void | String |
| static builder | RkhdSoapRequest$RkhdSoapRequestBuilder | - |
| static xmlBuilder | RkhdSoapRequest$RkhdSoapRequestXmlBuilder | - |

### RkhdSoapResponse

`class com.rkhd.platform.sdk.http.RkhdSoapResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RkhdSoapResponse (构造器) | void | - |
| getResultStr | String | - |
| setResultStr | void | String |
| getResultByteArray | byte[] | - |
| setResultByteArray | void | byte[] |
| getCode | int | - |
| setCode | void | int |
| getHeaders | List | - |
| setHeaders | void | List |
| toString | String | - |

### WXWorkInnerClient

`class com.rkhd.platform.sdk.http.WXWorkInnerClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | WXWorkInnerClient | - |
| execute | CommonResponse | CommonData, String, String, ResponseBodyHandler |

### WXWorkIsvClient

`class com.rkhd.platform.sdk.http.WXWorkIsvClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | WXWorkIsvClient | - |
| execute | CommonResponse | CommonData, String, ResponseBodyHandler |
| getWXWorkUserDetail | CommonResponse | String |
| close | void | - |

### WXWorkIsvProviderClient

`class com.rkhd.platform.sdk.http.WXWorkIsvProviderClient`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | WXWorkIsvProviderClient | - |
| execute | CommonResponse | CommonData, ResponseBodyHandler |
| close | void | - |

---

## com.rkhd.platform.sdk.http.handler

HTTP 响应处理器

### ResponseBodyHandler

`interface com.rkhd.platform.sdk.http.handler.ResponseBodyHandler`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| handle | Object | String |

### ResponseBodyHandlers

`class com.rkhd.platform.sdk.http.handler.ResponseBodyHandlers`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ResponseBodyHandlers (构造器) | void | - |
| static ofString | ResponseBodyHandler | - |
| static ofJSON | ResponseBodyHandler | - |

---

## com.rkhd.platform.sdk.license.assignlicenseevent

许可证分配事件

### AssignLicenseEvent

`interface com.rkhd.platform.sdk.license.assignlicenseevent.AssignLicenseEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | AssignLicenseEventResponse | AssignLicenseEventRequest |

### AssignLicenseEventRequest

`class com.rkhd.platform.sdk.license.assignlicenseevent.AssignLicenseEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignLicenseEventRequest (构造器) | void | - |
| getAddUserlicenses | List | - |
| setAddUserlicenses | void | List |
| getDeleteUserlicenses | List | - |
| setDeleteUserlicenses | void | List |

### AssignLicenseEventResponse

`class com.rkhd.platform.sdk.license.assignlicenseevent.AssignLicenseEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignLicenseEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

### UserLicense

`class com.rkhd.platform.sdk.license.assignlicenseevent.UserLicense`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| UserLicense (构造器) | void | - |
| getUserId | Long | - |
| setUserId | void | Long |
| getLicenseId | Long | - |
| setLicenseId | void | Long |

---

## com.rkhd.platform.sdk.listener

事件监听器

### Listener

`interface com.rkhd.platform.sdk.listener.Listener`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | void | ListenerRequest |

### ListenerRequest

`class com.rkhd.platform.sdk.listener.ListenerRequest`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ListenerRequest (构造器) | void | - |
| getDataList | List | - |
| setDataList | void | List |

### ScriptLogListenerData

`class com.rkhd.platform.sdk.listener.ScriptLogListenerData`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ScriptLogListenerData (构造器) | void | - |
| getErrorCode | Integer | - |
| setErrorCode | void | Integer |
| getClassName | String | - |
| setClassName | void | String |
| getMethodName | String | - |
| setMethodName | void | String |
| getCreateAt | Long | - |
| setCreateAt | void | Long |
| getLogSource | String | - |
| setLogSource | void | String |
| getMessage | String | - |
| setMessage | void | String |
| getRtTraceId | String | - |
| setRtTraceId | void | String |
| getUserId | Long | - |
| setUserId | void | Long |

---

## com.rkhd.platform.sdk.log

日志工具

### Logger

`interface com.rkhd.platform.sdk.log.Logger`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| debug | void | String |
| debug | void | String, Throwable |
| info | void | String |
| info | void | String, Throwable |
| warn | void | String |
| warn | void | String, Throwable |
| error | void | String |
| error | void | String, Throwable |

### LoggerFactory

`class com.rkhd.platform.sdk.log.LoggerFactory`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static getLogger | Logger | - |

---

## com.rkhd.platform.sdk.log.logevent

日志事件

### LogEvent

`interface com.rkhd.platform.sdk.log.logevent.LogEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | void | LogEventRequest |

### LogEventRequest

`class com.rkhd.platform.sdk.log.logevent.LogEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| LogEventRequest (构造器) | void | - |
| getLogApiKey | String | - |
| setLogApiKey | void | String |
| getUserId | Long | - |
| setUserId | void | Long |
| getCreatedAt | Long | - |
| setCreatedAt | void | Long |
| getLogId | Long | - |
| setLogId | void | Long |
| getLogModel | JSONObject | - |
| setLogModel | void | JSONObject |

---

## com.rkhd.platform.sdk.model

数据模型（XObject、QueryResult 等）

### BatchOperateResult

`class com.rkhd.platform.sdk.model.BatchOperateResult`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BatchOperateResult (构造器) | void | - |
| getCode | Long | - |
| setCode | void | Long |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getErrorMessage | String | - |
| setErrorMessage | void | String |
| getOperateResults | List | - |
| setOperateResults | void | List |

### DataModel

`class com.rkhd.platform.sdk.model.DataModel`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| DataModel (构造器) | void | Map |
| setAttribute | void | String, Object |
| getAttribute | Object | String |
| getAttributeNames | Set | - |
| getBoolean | Boolean | String |
| getByte | Byte | String |
| getShort | Short | String |
| getInteger | Integer | String |
| getFloat | Float | String |
| getLong | Long | String |
| getDouble | Double | String |
| getString | String | String |
| toString | String | - |

### EmailAttachment

`class com.rkhd.platform.sdk.model.EmailAttachment`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| EmailAttachment (构造器) | void | String, String |
| getFileName | String | - |
| setFileName | void | String |
| getFileUrl | String | - |
| setFileUrl | void | String |
| toString | String | - |

### EmailBody

`class com.rkhd.platform.sdk.model.EmailBody`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| EmailBody (构造器) | void | - |
| EmailBody (构造器) | void | String, String, List, List, String, String, String, String, boolean, String, List |
| EmailBody (构造器) | void | String, String, List, List, String, String, String, String, String, String, String, boolean, String, List |
| addReceiver | void | String |
| addCc | void | String |
| addAttachment | void | EmailAttachment |
| addAttachment | void | String, String |
| getSenderUserName | String | - |
| setSenderUserName | void | String |
| getSenderUserPass | String | - |
| setSenderUserPass | void | String |
| getReceiverList | List | - |
| setReceiverList | void | List |
| getCcList | List | - |
| setCcList | void | List |
| getAttachmentList | List | - |
| setAttachmentList | void | List |
| getSubject | String | - |
| setSubject | void | String |
| getBody | String | - |
| setBody | void | String |
| getSmtpHost | String | - |
| setSmtpHost | void | String |
| getSmtpPort | String | - |
| setSmtpPort | void | String |
| isSSL | boolean | - |
| setSSL | void | boolean |
| getSslProtocols | String | - |
| setSslProtocols | void | String |
| getTrust | String | - |
| setTrust | void | String |
| getTls | String | - |
| setTls | void | String |
| getMechanisms | String | - |
| setMechanisms | void | String |
| isSkipCert | boolean | - |
| setSkipCert | void | boolean |
| isNoSocketFactory | boolean | - |
| setNoSocketFactory | void | boolean |
| toString | String | - |
| static newBuilder | EmailBody$Builder | - |

### MetadataModel

`class com.rkhd.platform.sdk.model.MetadataModel`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| MetadataModel (构造器) | void | Map |
| setId | void | Long |
| getId | Long | - |
| getBoolean | Boolean | String |
| getByte | Byte | String |
| getShort | Short | String |
| getInteger | Integer | String |
| getFloat | Float | String |
| getLong | Long | String |
| getDouble | Double | String |
| getString | String | String |
| getAttributeNames | Set | - |
| getProperties | Map | - |
| setProperties | void | Map |
| getAttribute | Object | String |
| setAttribute | void | String, Object |
| toString | String | - |

### OperateResult

`class com.rkhd.platform.sdk.model.OperateResult`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| OperateResult (构造器) | void | - |
| getDataId | Long | - |
| setDataId | void | Long |
| getErrorMessage | String | - |
| setErrorMessage | void | String |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getCode | Long | - |
| setCode | void | Long |

### QueryResult

`class com.rkhd.platform.sdk.model.QueryResult`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| QueryResult (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getErrorMessage | String | - |
| setErrorMessage | void | String |
| getTotalCount | Long | - |
| setTotalCount | void | Long |
| getCurrentCount | Long | - |
| setCurrentCount | void | Long |
| getRecords | List | - |
| setRecords | void | List |
| getCode | Long | - |
| setCode | void | Long |

### XObject

`class com.rkhd.platform.sdk.model.XObject`

继承: JobData | 实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getAttribute | Object | String |
| setAttribute | void | String, Object |
| getId | Long | - |
| setId | void | Long |
| getApiKey | String | - |
| getAttributeNames | Set | - |
| toString | String | - |

---

## com.rkhd.platform.sdk.noticeflow.noticeevent

通知流程事件

### Link

`class com.rkhd.platform.sdk.noticeflow.noticeevent.Link`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| Link (构造器) | void | - |
| getMsgUrl | String | - |
| setMsgUrl | void | String |
| getMsgContent | String | - |
| setMsgContent | void | String |

### Message

`class com.rkhd.platform.sdk.noticeflow.noticeevent.Message`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| Message (构造器) | void | - |
| getMsgType | String | - |
| setMsgType | void | String |
| getUserId | String | - |
| setUserId | void | String |
| getSource | String | - |
| setSource | void | String |
| getBelongId | String | - |
| setBelongId | void | String |
| getObjectId | String | - |
| setObjectId | void | String |
| getLink | Link | - |
| setLink | void | Link |
| getText | Text | - |
| setText | void | Text |

### NoticeEvent

`interface com.rkhd.platform.sdk.noticeflow.noticeevent.NoticeEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | NoticeEventResponse | NoticeEventRequest |

### NoticeEventRequest

`class com.rkhd.platform.sdk.noticeflow.noticeevent.NoticeEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| NoticeEventRequest (构造器) | void | - |
| getEntityApiKey | String | - |
| setEntityApiKey | void | String |
| getMessage | Message | - |
| setMessage | void | Message |
| getReceiverInfo | ReceiverInfo | - |
| setReceiverInfo | void | ReceiverInfo |

### NoticeEventResponse

`class com.rkhd.platform.sdk.noticeflow.noticeevent.NoticeEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| NoticeEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |

### ReceiverInfo

`class com.rkhd.platform.sdk.noticeflow.noticeevent.ReceiverInfo`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ReceiverInfo (构造器) | void | - |
| getReceiveUseridList | Set | - |
| setReceiveUseridList | void | Set |
| getReceiveDeptIdList | Set | - |
| setReceiveDeptIdList | void | Set |
| getToAllUser | Boolean | - |
| setToAllUser | void | Boolean |

### Text

`class com.rkhd.platform.sdk.noticeflow.noticeevent.Text`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| Text (构造器) | void | - |
| getMsgContent | String | - |
| setMsgContent | void | String |

---

## com.rkhd.platform.sdk.param

参数模型

### ScheduleJobParam

`class com.rkhd.platform.sdk.param.ScheduleJobParam`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ScheduleJobParam (构造器) | void | - |
| getUserId | Long | - |

### ScriptTriggerParam

`class com.rkhd.platform.sdk.param.ScriptTriggerParam`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getPosition | String | - |
| getOperate | String | - |
| ScriptTriggerParam (构造器) | void | - |
| ScriptTriggerParam (构造器) | void | List |
| getDataModelList | List | - |
| setDataModelList | void | List |
| getUserId | Long | - |
| setPosition | void | String |
| setOperate | void | String |
| toString | String | - |

### ScriptTriggerResult

`class com.rkhd.platform.sdk.param.ScriptTriggerResult`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ScriptTriggerResult (构造器) | void | - |
| ScriptTriggerResult (构造器) | void | List |
| getDataModelList | List | - |
| setDataModelList | void | List |

---

## com.rkhd.platform.sdk.prompt

AI 提示词模板

### XAIPromptTemplate

`class com.rkhd.platform.sdk.prompt.XAIPromptTemplate`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| getInput | XAIPromptTemplateInput | - |
| setInput | void | XAIPromptTemplateInput |
| getApiKey | String | - |
| getOutputClassType | Class | - |

### XAIPromptTemplateInput

`class com.rkhd.platform.sdk.prompt.XAIPromptTemplateInput`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| XAIPromptTemplateInput (构造器) | void | - |
| getAttribute | Object | String |
| setAttribute | void | String, Object |
| toString | String | - |

### XAIPromptTemplateOutput

`class com.rkhd.platform.sdk.prompt.XAIPromptTemplateOutput`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| XAIPromptTemplateOutput (构造器) | void | - |
| getType | Integer | - |

### XAIPromptTemplateResult

`class com.rkhd.platform.sdk.prompt.XAIPromptTemplateResult`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| XAIPromptTemplateResult (构造器) | void | - |
| getCode | Integer | - |
| setCode | void | Integer |
| getMsg | String | - |
| setMsg | void | String |
| getData | XAIPromptTemplateOutput | - |
| setData | void | XAIPromptTemplateOutput |

### XAIPromptTemplateService

`class com.rkhd.platform.sdk.prompt.XAIPromptTemplateService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| XAIPromptTemplateService (构造器) | void | - |
| static instance | XAIPromptTemplateService | - |
| generate | XAIPromptTemplateResult | XAIPromptTemplate |

---

## com.rkhd.platform.sdk.serialize

序列化/反序列化

### DefaultDeserializeProcess

`class com.rkhd.platform.sdk.serialize.DefaultDeserializeProcess`

实现: DeserializeProcess

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| DefaultDeserializeProcess (构造器) | void | - |
| convert | XObject | String, Class |

### DeserializeProcess

`interface com.rkhd.platform.sdk.serialize.DeserializeProcess`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| convert | XObject | String, Class |

### ExactMatchDeserializeProcess

`class com.rkhd.platform.sdk.serialize.ExactMatchDeserializeProcess`

实现: DeserializeProcess

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| ExactMatchDeserializeProcess (构造器) | void | - |
| convert | XObject | String, Class |

---

## com.rkhd.platform.sdk.service

核心服务类（XObjectService、CacheService 等）

### BatchJobProService

`class com.rkhd.platform.sdk.service.BatchJobProService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BatchJobProService (构造器) | void | - |
| static instance | BatchJobProService | - |
| addBatchJob | String | Class, int, PrepareParam |

### BatchJobService

`class com.rkhd.platform.sdk.service.BatchJobService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | BatchJobService | - |
| addBatchJob | String | Class |
| addBatchJob | String | Class, int |

### CacheService

`class com.rkhd.platform.sdk.service.CacheService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | CacheService | - |
| get | String | String |
| set | Boolean | String, String |
| setIfNotChange | Boolean | String, String |
| delete | Boolean | String |

### CustomConfigService

`class com.rkhd.platform.sdk.service.CustomConfigService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | CustomConfigService | - |
| getConfigSet | Map | String |

### EmailService

`class com.rkhd.platform.sdk.service.EmailService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | EmailService | - |
| sendEmail | void | EmailBody |

### FastjsonService

`class com.rkhd.platform.sdk.service.FastjsonService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static parse | Object | String |
| static parse | Object | String, int |
| static parse | Object | byte[], Feature[] |
| static parse | Object | byte[], int, int, CharsetDecoder, Feature[] |
| static parse | Object | byte[], int, int, CharsetDecoder, int |
| static parse | Object | String, Feature[] |
| static parseObject | JSONObject | String, Feature[] |
| static parseObject | JSONObject | String |
| static parseObject | Object | String, TypeReference, Feature[] |
| static parseObject | Object | String, Class, Feature[] |
| static parseObject | Object | String, Class, ParseProcess, Feature[] |
| static parseObject | Object | String, Type, Feature[] |
| static parseObject | Object | String, Type, ParseProcess, Feature[] |
| static parseObject | Object | String, Type, int, Feature[] |
| static parseObject | Object | String, Type, ParserConfig, int, Feature[] |
| static parseObject | Object | String, Type, ParserConfig, ParseProcess, int, Feature[] |
| static parseObject | Object | byte[], Type, Feature[] |
| static parseObject | Object | byte[], int, int, CharsetDecoder, Type, Feature[] |
| static parseObject | Object | char[], int, Type, Feature[] |
| static parseObject | Object | String, Class |
| static parseArray | JSONArray | String |
| static parseArray | List | String, Class |
| static parseArray | List | String, Type[] |
| static toJSONString | String | Object |
| static toJSONString | String | Object, SerializerFeature[] |
| static toJSONStringWithDateFormat | String | Object, String, SerializerFeature[] |
| static toJSONString | String | Object, SerializeFilter, SerializerFeature[] |
| static toJSONString | String | Object, SerializeFilter[], SerializerFeature[] |
| static toJSONBytes | byte[] | Object, SerializerFeature[] |
| static toJSONString | String | Object, SerializeConfig, SerializerFeature[] |
| static toJSONString | String | Object, SerializeConfig, SerializeFilter, SerializerFeature[] |
| static toJSONString | String | Object, SerializeConfig, SerializeFilter[], SerializerFeature[] |
| static toJSONStringZ | String | Object, SerializeConfig, SerializerFeature[] |
| static toJSONBytes | byte[] | Object, SerializeConfig, SerializerFeature[] |
| static toJSONString | String | Object, boolean |
| static writeJSONStringTo | void | Object, Writer, SerializerFeature[] |
| static toJSON | Object | Object |
| static toJSON | Object | Object, ParserConfig |
| static toJavaObject | Object | JSON, Class |

### FutureTaskService

`class com.rkhd.platform.sdk.service.FutureTaskService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | FutureTaskService | - |
| addFutureTask | String | Class, String |

### LockService

`class com.rkhd.platform.sdk.service.LockService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static newLock | LockService | String |
| lock | boolean | - |
| lock | boolean | int |
| unLock | boolean | - |

### MetadataService

`class com.rkhd.platform.sdk.service.MetadataService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | MetadataService | - |
| getBusiType | MetadataModel | String, String |

### XObjectService

`class com.rkhd.platform.sdk.service.XObjectService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | XObjectService | - |
| setOption | void | Integer |
| query | QueryResult | String |
| query | QueryResult | String, boolean |
| query | QueryResult | String, boolean, boolean |
| get | XObject | XObject |
| get | XObject | XObject, boolean |
| getByIds | List | String, List |
| getByIds | List | String, List, boolean |
| insert | OperateResult | XObject |
| insert | OperateResult | XObject, boolean |
| insert | BatchOperateResult | List |
| insert | BatchOperateResult | List, boolean |
| insert | BatchOperateResult | List, boolean, boolean |
| update | OperateResult | XObject |
| update | OperateResult | XObject, boolean |
| update | BatchOperateResult | List |
| update | BatchOperateResult | List, boolean |
| update | BatchOperateResult | List, boolean, boolean |
| delete | OperateResult | XObject |
| delete | OperateResult | XObject, boolean |
| delete | BatchOperateResult | List |
| delete | BatchOperateResult | List, boolean |
| lock | OperateResult | XObject |
| lock | OperateResult | XObject, boolean |
| unlock | OperateResult | XObject |
| unlock | OperateResult | XObject, boolean |
| transfer | OperateResult | XObject, Long |
| transfer | OperateResult | XObject, Long, boolean |

### XoqlService

`class com.rkhd.platform.sdk.service.XoqlService`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | XoqlService | - |
| query | QueryResult | String |
| query | QueryResult | String, boolean |
| query | QueryResult | String, boolean, boolean |

---

## com.rkhd.platform.sdk.task

异步任务（BatchJob、FutureTask）

### BatchJob

`interface com.rkhd.platform.sdk.task.BatchJob`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| prepare | BatchJobPrepare | - |
| execute | void | List, String |
| finish | void | String |

### BatchJobPrepare

`class com.rkhd.platform.sdk.task.BatchJobPrepare`

### BatchJobPro

`interface com.rkhd.platform.sdk.task.BatchJobPro`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| prepare | BatchJobData | PrepareParam |
| execute | void | List, BatchJobParam |
| finish | void | BatchJobParam |

### FutureTask

`interface com.rkhd.platform.sdk.task.FutureTask`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | void | String |

---

## com.rkhd.platform.sdk.task.param

BatchJob 参数模型

### BatchJobData

`interface com.rkhd.platform.sdk.task.param.BatchJobData`

### BatchJobDataBuilder

`class com.rkhd.platform.sdk.task.param.BatchJobDataBuilder`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BatchJobDataBuilder (构造器) | void | - |
| buildQueryData | BatchJobQueryData | - |
| buildListData | BatchJobListData | - |
| getSql | String | - |
| setSql | BatchJobDataBuilder | String |
| isAdmin | Boolean | - |
| setAdmin | BatchJobDataBuilder | Boolean |
| getDataList | List | - |
| setDataList | BatchJobDataBuilder | List |
| getApiKey | String | - |
| setApiKey | BatchJobDataBuilder | String |
| setBatchJobParam | BatchJobDataBuilder | String, String |

### BatchJobListData

`class com.rkhd.platform.sdk.task.param.BatchJobListData`

实现: BatchJobData

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BatchJobListData (构造器) | void | - |
| BatchJobListData (构造器) | void | List |
| BatchJobListData (构造器) | void | List, String, Boolean |
| getDataList | List | - |
| setDataList | void | List |
| getApiKey | String | - |
| setApiKey | void | String |
| isAdmin | Boolean | - |
| setAdmin | void | Boolean |

### BatchJobParam

`class com.rkhd.platform.sdk.task.param.BatchJobParam`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| get | String | String |
| getBatchJobId | String | - |

### BatchJobQueryData

`class com.rkhd.platform.sdk.task.param.BatchJobQueryData`

实现: BatchJobData

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BatchJobQueryData (构造器) | void | - |
| BatchJobQueryData (构造器) | void | String |
| getSql | String | - |
| setSql | void | String |

### JobData

`class com.rkhd.platform.sdk.task.param.JobData`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| JobData (构造器) | void | - |

### PrepareParam

`class com.rkhd.platform.sdk.task.param.PrepareParam`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| PrepareParam (构造器) | void | - |
| PrepareParam (构造器) | void | Map |
| getParamMap | Map | - |
| setParamMap | void | Map |
| get | String | String |
| set | void | String, String |

### SimpleMap

`class com.rkhd.platform.sdk.task.param.SimpleMap`

继承: JobData | 实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| SimpleMap (构造器) | void | - |
| get | String | String |
| set | void | String, String |
| getData | Map | - |
| toString | String | - |

---

## com.rkhd.platform.sdk.test.tool

本地测试工具

### CustomizeApiHandler

`class com.rkhd.platform.sdk.test.tool.CustomizeApiHandler`

继承: HttpServlet

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| CustomizeApiHandler (构造器) | void | ApiSupport |
| doPost | void | HttpServletRequest, HttpServletResponse |
| doGet | void | HttpServletRequest, HttpServletResponse |
| print | void | HttpServletResponse, String |

### TestCustomizeApiTool

`class com.rkhd.platform.sdk.test.tool.TestCustomizeApiTool`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TestCustomizeApiTool (构造器) | void | - |
| test | void | String, ApiSupport |

### TestFutureTaskTool

`class com.rkhd.platform.sdk.test.tool.TestFutureTaskTool`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TestFutureTaskTool (构造器) | void | - |
| test | void | String, FutureTask |

### TestScheduleJobTool

`class com.rkhd.platform.sdk.test.tool.TestScheduleJobTool`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TestScheduleJobTool (构造器) | void | - |
| test | void | ScheduleJob |

### TestTriggerTool

`class com.rkhd.platform.sdk.test.tool.TestTriggerTool`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TestTriggerTool (构造器) | void | - |
| test | void | String, ScriptTrigger |
| test | void | String, Trigger, Boolean |
| setObjectName | void | String |
| getObjectName | String | - |
| getPosition | String | - |
| setPosition | void | String |
| getOperate | String | - |
| setOperate | void | String |

---

## com.rkhd.platform.sdk.trigger

触发器开发

### DataResult

`class com.rkhd.platform.sdk.trigger.DataResult`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| DataResult (构造器) | void | - |
| DataResult (构造器) | void | Boolean, String, XObject |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |
| getxObject | XObject | - |
| setxObject | void | XObject |
| toString | String | - |

### Trigger

`interface com.rkhd.platform.sdk.trigger.Trigger`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | TriggerResponse | TriggerRequest |

### TriggerContext

`class com.rkhd.platform.sdk.trigger.TriggerContext`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TriggerContext (构造器) | void | - |
| TriggerContext (构造器) | void | Map |
| set | void | String, String |
| get | String | String |
| delete | void | String |
| toString | String | - |

### TriggerRequest

`class com.rkhd.platform.sdk.trigger.TriggerRequest`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TriggerRequest (构造器) | void | - |
| getPartialSuccess | Boolean | - |
| getPosition | String | - |
| getOperate | String | - |
| getDataList | List | - |
| getUserId | Long | - |
| setDataList | void | List |
| setPosition | void | String |
| setOperate | void | String |
| setUserId | void | Long |
| setPartialSuccess | void | Boolean |
| getTriggerContext | TriggerContext | - |
| setTriggerContext | void | TriggerContext |
| toString | String | - |

### TriggerResponse

`class com.rkhd.platform.sdk.trigger.TriggerResponse`

实现: Serializable

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| TriggerResponse (构造器) | void | - |
| TriggerResponse (构造器) | void | Boolean, String, List |
| TriggerResponse (构造器) | void | Boolean, String, List, TriggerContext |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getMsg | String | - |
| setMsg | void | String |
| getData | List | - |
| setData | void | List |
| addDataResult | TriggerResponse | DataResult |
| getTriggerContext | TriggerContext | - |
| setTriggerContext | void | TriggerContext |
| addDataResult | TriggerResponse | DataResult, String |
| toString | String | - |

---

## com.rkhd.platform.sdk.userdepart.assignrespevent

用户职责分配事件

### AssignRespEvent

`interface com.rkhd.platform.sdk.userdepart.assignrespevent.AssignRespEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | AssignRespEventResponse | AssignRespEventRequest |

### AssignRespEventRequest

`class com.rkhd.platform.sdk.userdepart.assignrespevent.AssignRespEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignRespEventRequest (构造器) | void | - |
| getTargetUserId | Long | - |
| setTargetUserId | void | Long |
| getResponsibilityIds | Set | - |
| setResponsibilityIds | void | Set |

### AssignRespEventResponse

`class com.rkhd.platform.sdk.userdepart.assignrespevent.AssignRespEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignRespEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getSuccessResponsibilityIds | Set | - |
| setSuccessResponsibilityIds | void | Set |
| getMsg | String | - |
| setMsg | void | String |

---

## com.rkhd.platform.sdk.userdepart.assignroleevent

用户角色分配事件

### AssignRoleEvent

`interface com.rkhd.platform.sdk.userdepart.assignroleevent.AssignRoleEvent`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| execute | AssignRoleEventResponse | AssignRoleEventRequest |

### AssignRoleEventRequest

`class com.rkhd.platform.sdk.userdepart.assignroleevent.AssignRoleEventRequest`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignRoleEventRequest (构造器) | void | - |
| getTargetUserId | Long | - |
| setTargetUserId | void | Long |
| getRoleIds | Set | - |
| setRoleIds | void | Set |

### AssignRoleEventResponse

`class com.rkhd.platform.sdk.userdepart.assignroleevent.AssignRoleEventResponse`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AssignRoleEventResponse (构造器) | void | - |
| getSuccess | Boolean | - |
| setSuccess | void | Boolean |
| getSuccessRoleIds | Set | - |
| setSuccessRoleIds | void | Set |
| getMsg | String | - |
| setMsg | void | String |

---

## com.rkhd.platform.sdk.util

工具类（IO）

### IOUtil

`class com.rkhd.platform.sdk.util.IOUtil`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| IOUtil (构造器) | void | - |
| static toStringWithLimit | String | InputStream |
| static toByteArrayWithLimit | byte[] | InputStream |

---

## com.rkhd.platform.sdk.util.aes

AES 加密工具

### AesUtil

`class com.rkhd.platform.sdk.util.aes.AesUtil`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static instance | AesUtil | String |
| static instance | AesUtil | String, SecretkeyCreator |
| encrypt | String | String, String |
| decrypt | String | String, String |

### SecretkeyCreator

`interface com.rkhd.platform.sdk.util.aes.SecretkeyCreator`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| createSecretKey | SecretKeySpec | String |

---

## com.rkhd.platform.sdk.util.encrypt

对称加密工具

### KeyType

`enum com.rkhd.platform.sdk.util.encrypt.KeyType`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static values | KeyType[] | - |
| static valueOf | KeyType | String |
| getValue | int | - |

### KeyUtil

`class com.rkhd.platform.sdk.util.encrypt.KeyUtil`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| KeyUtil (构造器) | void | - |
| static generateKeyPair | KeyPair | String |
| static generateKeyPair | KeyPair | String, int, SecureRandom |
| static getKeyPairGenerator | KeyPairGenerator | String |
| static getMainAlgorithm | String | String |
| static generateRSAPublicKey | PublicKey | byte[] |
| static generateRSABase64PublicKey | PublicKey | String |
| static generateRSAPrivateKey | PrivateKey | byte[] |
| static generateRSABase64PrivateKey | PrivateKey | String |

### SymmetricCryptoModel

`class com.rkhd.platform.sdk.util.encrypt.SymmetricCryptoModel`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| SymmetricCryptoModel (构造器) | void | SymmetricCryptoModel$AlgorithmEnum, SymmetricCryptoModel$ModelEnum, SymmetricCryptoModel$PaddingEnum, String, String |
| SymmetricCryptoModel (构造器) | void | SymmetricCryptoModel$AlgorithmEnum, SymmetricCryptoModel$ModelEnum, SymmetricCryptoModel$PaddingEnum, String, String, Charset |
| static builder | SymmetricCryptoModel$Builder | - |
| getAlgorithm | SymmetricCryptoModel$AlgorithmEnum | - |
| setAlgorithm | void | SymmetricCryptoModel$AlgorithmEnum |
| getModel | SymmetricCryptoModel$ModelEnum | - |
| setModel | void | SymmetricCryptoModel$ModelEnum |
| getPadding | SymmetricCryptoModel$PaddingEnum | - |
| setPadding | void | SymmetricCryptoModel$PaddingEnum |
| getKey | String | - |
| setKey | void | String |
| getOffset | String | - |
| setOffset | void | String |
| getEncoding | Charset | - |
| setEncoding | void | Charset |
| getAlgorithmString | String | - |
| getSecretKeySpec | SecretKey | - |

### SymmetricCryptoUtil

`class com.rkhd.platform.sdk.util.encrypt.SymmetricCryptoUtil`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| SymmetricCryptoUtil (构造器) | void | - |
| static encrypt | String | String, SymmetricCryptoModel |
| static decrypt | String | String, SymmetricCryptoModel |

---

## com.rkhd.platform.sdk.util.encrypt.asymmetric

非对称加密工具（RSA）

### AbstractAsymmetricCrypto

`abstract class com.rkhd.platform.sdk.util.encrypt.asymmetric.AbstractAsymmetricCrypto`

继承: BaseAsymmetric

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AbstractAsymmetricCrypto (构造器) | void | String, PrivateKey, PublicKey |
| encrypt | byte[] | byte[], KeyType |
| encryptBase64 | String | byte[], KeyType |
| encryptBase64 | String | String, KeyType |
| decrypt | byte[] | byte[], KeyType |
| decryptStr | String | String, KeyType |

### AsymmetricAlgorithm

`enum com.rkhd.platform.sdk.util.encrypt.asymmetric.AsymmetricAlgorithm`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| static values | AsymmetricAlgorithm[] | - |
| static valueOf | AsymmetricAlgorithm | String |
| getValue | String | - |

### AsymmetricCrypto

`class com.rkhd.platform.sdk.util.encrypt.asymmetric.AsymmetricCrypto`

继承: AbstractAsymmetricCrypto

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| AsymmetricCrypto (构造器) | void | AsymmetricAlgorithm |
| AsymmetricCrypto (构造器) | void | String |
| AsymmetricCrypto (构造器) | void | String, PrivateKey, PublicKey |
| init | AsymmetricCrypto | String, PrivateKey, PublicKey |
| encrypt | byte[] | byte[], KeyType |
| decrypt | byte[] | byte[], KeyType |

### BaseAsymmetric

`class com.rkhd.platform.sdk.util.encrypt.asymmetric.BaseAsymmetric`

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| BaseAsymmetric (构造器) | void | String, PrivateKey, PublicKey |
| initKeys | BaseAsymmetric | - |

### RSA

`class com.rkhd.platform.sdk.util.encrypt.asymmetric.RSA`

继承: AsymmetricCrypto

| 方法 | 返回类型 | 参数 |
|------|----------|------|
| RSA (构造器) | void | - |
| RSA (构造器) | void | String |
| RSA (构造器) | void | String, PrivateKey, PublicKey |
| static builder | RSA$Builder | - |

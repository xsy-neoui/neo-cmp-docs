---
name: neo-backend-dev
description: Neo 后端 PaaS 开发技能，辅助在 NeoCRM 平台上进行 Java 后端开发。当用户需要：(1) 查询数据（SQL/XOQL）或执行 DML 操作（创建/更新/删除/锁定/转移记录），(2) 开发 Trigger 触发器、自定义 REST API、计划作业、流程扩展脚本，(3) 使用 SDK 工具类（异步任务 FutureTask、批量处理 BatchJobPro、HTTP 调用、缓存、日志、加密、邮件、分布式锁），(4) 打包上传/下载/卸载后端代码包，(5) 获取和查询实体模型时，使用此技能。
---

# Neo 后端 PaaS 开发

辅助完成 NeoCRM PaaS 平台 Java 后端开发全流程。

## 前置条件

- 已全局安装 neo-cmp-cli：`npm i -g neo-cmp-cli`。通过 `neo -v` 检测是否已安装
- Node.js 环境
- JDK 1.8（后端代码编译）

## 重要约定

- **前置检查**：收到开发需求后，先检查项目目录下 `solutions/` 是否存在已确认的任务列表（tasks.md）。如果不存在，**主动询问用户**："当前没有找到方案设计文档，是否需要先使用 neo-solution-design 技能包进行需求梳理和技术方案设计？这有助于明确实体模型、接口设计和任务拆分。" 用户选择跳过后才继续直接开发。
- **项目优先**：在创建任何代码文件之前，必须先完成工程项目的确认或创建（核心工作流第 1 步）。禁止在没有 `neo.config.js` 的目录下编写代码。
- **每次需要登录时都必须让用户重新选择环境**，不要默认登录上次选择的环境。环境参数：`production`、`gray`、`sandbox`、`cd`、`tencentuat`、`custom`
- Java 包路径以 `other` 开头，前三级为模块包名（如 `other.xsy.account`），全部小写。第四级可选，仅允许 triggers/apis/schedules/flows/utils。**部署时包名必须是三级**
- 仅支持第三方包：fastJson + commons-lang
- **实体名和字段名严格区分大小写**，必须从 `AllxObjects.md` 和 `fields/<apiKey>.md` 查找，不要凭记忆猜测
- **SQL 中选项字段必须用选项值（数字），不能用选项标签（文字）**

## 开发参考文档

按需求类型选择对应参考：

| 需求类型 | 参考文档 |
|----------|----------|
| 查询数据（SQL/XOQL）、DML 操作（增删改锁转）、文件处理 | [01-业务数据操作.md](references/01-业务数据操作.md) |
| Trigger、自定义 API、计划作业、流程扩展、scriptTrigger.xml 配置 | [02-业务扩展点.md](references/02-业务扩展点.md) |
| FutureTask、BatchJobPro、HTTP 调用、缓存、日志、加密、邮件、锁等 | [03-SDK工具类.md](references/03-SDK工具类.md) |
| SDK 完整类和方法签名速查 | [sdk-api-reference.md](references/sdk-api-reference.md) |
| 平台 REST API 完整接口列表 | [rest-api-reference.md](references/rest-api-reference.md) |
| 常见问题、踩坑记录、编码规范 | [NeoCRM后端开发最佳实践.md](references/NeoCRM后端开发最佳实践.md) |

## 核心工作流

### 1. 确认工程项目

1. 在工作空间子目录中搜索 `neo.config.js`
2. 找到则列出所有项目，询问用户使用哪个
3. 未找到则询问项目名称，执行 `neo create project -n <名称>`

所有后端代码必须放在项目目录的 `src/codePackages/` 下。

### 2. 登录租户

先让用户选择环境：

| 选项 | 环境值 |
|------|--------|
| 线上生产环境（crm.xiaoshouyi.com） | `production` |
| 沙盒环境（crm-sandbox.xiaoshouyi.com） | `sandbox` |
| 自定义环境 | `custom` |

后台启动 `neo login -e <env>`，轮询输出检测 `登录成功` 或 `成功获取 access token`。

### 3. 自动拉取实体列表

登录成功后自动执行：
```bash
node neo-entity-management/scripts/gen_entitylist.js <项目目录>
```

### 4. 后端代码开发

开发涉及实体操作的代码前，必须先确认实体模型：
1. 检查 `src/xObjects/fields/<apiKey>.md` 是否存在
2. 不存在则运行 `node neo-entity-management/scripts/gen_entity_desc.js <项目目录> <apiKey>`
3. 根据模型描述中的字段 API Key 和 Java 类型编写代码

代码包目录结构：
```
<项目>/src/codePackages/<代码包简称>/
  other/<company>/<module>/
    triggers/    apis/    schedules/    flows/    utils/
  scriptTrigger.xml
  doc.md
```

### 关键限制

| 限制项 | 值 |
|--------|-----|
| 同步脚本最大运行时长 | 15 秒 |
| 异步脚本最大运行时长 | 90 秒 |
| 单次 DML 最大数据量 | 10,000 条 |
| commonHttpClient 最大调用次数 | 50 次/脚本 |
| 缓存最大大小 | 200 KB |

## 部署后端代码包

```bash
node neo-backend-dev/scripts/deploy_server_script.js <项目目录> <代码包简称> <Java包名>
```

## 下载服务端代码包

```bash
node neo-backend-dev/scripts/download_server_script.js <项目目录> <Java包名> [代码包简称]
```

## 卸载代码包

```bash
node neo-backend-dev/scripts/uninstall_server_script.js <项目目录> <Java包名> [--force]
```

## 实体模型类规则

### 模型类路径

所有实体模型类位于 `com.rkhd.platform.sdk.data.model` 包下：
- 标准实体：首字母大写，如 `account` → `com.rkhd.platform.sdk.data.model.Account`
- 自定义实体：保持原样，如 `CheckPlan__c` → `com.rkhd.platform.sdk.data.model.CheckPlan__c`

### 字段类型 → Java 类型映射

| 平台字段类型 | Java 类型 | 说明 |
|---|---|---|
| 文本/多行文本/电话/邮箱/网址/富文本 | String | — |
| 整数/选项列表(单选)/布尔 | Integer | — |
| 引用/日期/日期时间/所有人 | Long | 引用字段存储的是目标记录 ID |
| 金额/百分比/小数/统计字段 | Double | — |
| 多选列表 | Integer[] | — |
| 文件/图片 | List\<Map\> | — |

## 获取实体模型

```bash
# 生成实体字典
node neo-entity-management/scripts/gen_entitylist.js <项目目录>

# 查询实体字段
node neo-entity-management/scripts/gen_entity_desc.js <项目目录> <apiKey>
```

## 注意事项

- Java 类名不能以 "test" 结尾，文件必须 UTF-8 无 BOM
- Trigger 的 DataResult 数量必须与 TriggerRequest 数据量一致
- 部署 Trigger 时 order 冲突则 +1 重试
- SSL 证书错误时加 `NEO_SKIP_SSL_VERIFY=true`
- 自定义 API 路径是 `/rest/data/v2.0/scripts/api/{baseUrl}/{path}`
- BatchJobPro 不需要配置文件，ScheduleJob 需要
- XObject 查询结果的 getAttribute() 返回 Object，需判空后 toString()
- insert 不回填 ID，必须从 OperateResult.getDataId() 获取
- npm install 仅前端需要，后端部署不依赖 node_modules

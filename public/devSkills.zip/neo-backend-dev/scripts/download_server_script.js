#!/usr/bin/env node
/**
 * 下载服务端代码包到本地 src/codePackages/ 目录。
 * 用法: node download_server_script.js <项目目录> <Java包名> [代码包简称]
 * 示例: node download_server_script.js 验证项目 other.xsy.account 客户管理
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const { execSync } = require('child_process');

if (process.argv.length < 4) {
  console.log('用法: node download_server_script.js <项目目录> <Java包名> [代码包简称]');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const javaPackage = process.argv[3];
const displayName = process.argv[4] || javaPackage.split('.').pop();
const outputDir = path.join(projectDir, 'src/codePackages', displayName);

const { accessToken, baseUrl } = getConfig(projectDir);

function getConfig(dir) {
  const tokenPath = path.join(dir, '.neo-cli/token.json');
  if (!fs.existsSync(tokenPath)) {
    console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
    process.exit(1);
  }
  const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
  const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';
  return { accessToken: token.access_token, baseUrl };
}

function apiGet(apiPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname, port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: { 'Authorization': accessToken },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { resolve({ code: String(res.statusCode), msg: data.substring(0, 200) }); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

function downloadFile(fileUrl, destPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(fileUrl);
    const options = {
      hostname: url.hostname, port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      const file = fs.createWriteStream(destPath);
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(); });
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  // 1. 检查本地
  if (fs.existsSync(outputDir)) {
    console.log('本地已存在: %s，将更新覆盖', outputDir);
    fs.rmSync(outputDir, { recursive: true });
  }

  // 2. 获取代码包信息
  console.log('获取代码包信息: %s ...', javaPackage);
  const data = await apiGet('/rest/metadata/v2.0/scripts/packages?packageName=' + encodeURIComponent(javaPackage));

  if (data.code !== '200' || !data.data || !data.data.records) {
    console.error('错误: 代码包不存在或无权限 (%s)', data.msg || data.code || '');
    process.exit(1);
  }

  const records = data.data.records;
  const downloadUrl = records.uploadFile || '';
  if (!downloadUrl) {
    console.error('错误: 未找到下载地址');
    process.exit(1);
  }
  console.log('版本: %s', records.version || '');

  // 3. 下载 ZIP
  const zipPath = path.join(projectDir, displayName + '_download.zip');
  console.log('下载代码包 ...');
  await downloadFile(downloadUrl, zipPath);
  console.log('已下载: %d bytes', fs.statSync(zipPath).size);

  // 4. 解压
  console.log('解压到 %s ...', outputDir);
  fs.mkdirSync(outputDir, { recursive: true });
  try {
    execSync(`unzip -o "${zipPath}" -d "${outputDir}"`, { stdio: 'pipe' });
  } catch (e) {
    execSync(`tar -xzf "${zipPath}" -C "${outputDir}"`, { stdio: 'pipe' });
  }

  // 5. 清理
  fs.unlinkSync(zipPath);
  console.log('\n✅ 完成: 代码包已下载到 %s', outputDir);
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

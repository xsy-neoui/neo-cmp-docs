#!/usr/bin/env node
/**
 * 卸载服务端代码包。
 * 用法: node uninstall_server_script.js <项目目录> <Java包名> [--force]
 * 示例: node uninstall_server_script.js 验证项目 other.xsy.account
 *       node uninstall_server_script.js 验证项目 other.xsy.account --force
 */
const fs = require('fs');
const path = require('path');
const https = require('https');

if (process.argv.length < 4) {
  console.log('用法: node uninstall_server_script.js <项目目录> <Java包名> [--force]');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const javaPackage = process.argv[3];
const force = process.argv.includes('--force');

const { accessToken, baseUrl } = getConfig(projectDir);

function getConfig(dir) {
  const tokenPath = path.join(dir, '.neo-cli/token.json');
  if (!fs.existsSync(tokenPath)) {
    console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
    process.exit(1);
  }
  const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
  const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';
  return { accessToken: token.access_token, baseUrl };
}

async function main() {
  const forceStr = force ? 'true' : 'false';
  console.log('卸载代码包: %s (force=%s) ...', javaPackage, forceStr);

  const apiPath = '/rest/metadata/v2.0/scripts/packages/installations/' + encodeURIComponent(javaPackage) + '?force=' + forceStr;

  const result = await new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname, port: 443,
      path: url.pathname + url.search,
      method: 'DELETE',
      headers: { 'Authorization': accessToken },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { resolve({ code: String(res.statusCode), msg: data.substring(0, 200) }); }
      });
    });
    req.on('error', reject);
    req.end();
  });

  if (result.code === '200' || result.code === '000000') {
    console.log('✅ 卸载成功');
  } else if (result.code === '290030') {
    console.error('❌ 有任务正在运行，请使用 --force 强制卸载');
    process.exit(1);
  } else {
    console.error('❌ 卸载失败: %s', result.msg || result.code);
    process.exit(1);
  }
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

#!/usr/bin/env node
/**
 * 打包并上传后端代码包到 NeoCRM 平台。
 * 用法: node deploy_server_script.js <项目目录> <代码包简称> <Java包名>
 * 示例: node deploy_server_script.js 验证项目 客户管理 other.xsy.account
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const { execSync } = require('child_process');

if (process.argv.length < 5) {
  console.log('用法: node deploy_server_script.js <项目目录> <代码包简称> <Java包名>');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const displayName = process.argv[3];
const javaPackage = process.argv[4];
const packageDir = path.join(projectDir, 'src/codePackages', displayName);
const zipPath = path.join(projectDir, displayName + '.zip');

if (!fs.existsSync(packageDir)) {
  console.error('错误: 代码包目录不存在: %s', packageDir);
  process.exit(1);
}

const { accessToken, baseUrl } = getConfig(projectDir);

function getConfig(dir) {
  const tokenPath = path.join(dir, '.neo-cli/token.json');
  if (!fs.existsSync(tokenPath)) {
    console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
    process.exit(1);
  }
  const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
  const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';
  return { accessToken: token.access_token, baseUrl };
}

function apiCall(method, apiPath, body, headers) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname, port: 443,
      path: url.pathname + url.search,
      method,
      headers: { 'Authorization': 'Bearer ' + accessToken, ...headers },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { resolve({ code: String(res.statusCode), msg: data.substring(0, 200) }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

// 简单的 ZIP 创建（使用系统 zip 命令）
function createZip(sourceDir, outputPath) {
  if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
  const cwd = sourceDir;
  try {
    execSync(`zip -r "${outputPath}" .`, { cwd, stdio: 'pipe' });
  } catch (e) {
    // fallback: 用 Node.js 手动创建简单 zip（无压缩库时）
    console.error('zip 命令失败，尝试 tar 方式...');
    execSync(`tar -czf "${outputPath}" -C "${sourceDir}" .`, { stdio: 'pipe' });
  }
}

async function main() {
  // 1. 打包 ZIP
  console.log('打包 %s ...', packageDir);
  createZip(packageDir, zipPath);
  const zipSize = fs.statSync(zipPath).size;
  console.log('ZIP: %s (%d bytes)', zipPath, zipSize);

  // 2. 检查代码包是否存在
  console.log('\n检查代码包 ...');
  const checkResult = await apiCall('GET', '/rest/metadata/v2.0/scripts/packages?packageName=' + encodeURIComponent(javaPackage));
  const exists = checkResult.code === '200' && checkResult.data && checkResult.data.records;

  if (!exists) {
    console.log('创建代码包 %s ...', javaPackage);
    const createBody = JSON.stringify({ packageName: javaPackage, name: displayName, content: displayName });
    const r = await apiCall('POST', '/rest/metadata/v2.0/scripts/packages', createBody, { 'Content-Type': 'application/json' });
    if (r.code !== '200') {
      console.error('创建失败: %s', r.msg || '');
      fs.unlinkSync(zipPath);
      process.exit(1);
    }
    console.log('创建成功');
  } else {
    console.log('代码包已存在');
  }

  // 3. 上传文件（multipart/form-data）
  console.log('\n上传文件 ...');
  const boundary = '----NodeBoundary' + Date.now();
  const zipData = fs.readFileSync(zipPath);
  const bodyParts = [
    `--${boundary}\r\n`,
    `Content-Disposition: form-data; name="file"; filename="${displayName}.zip"\r\n`,
    'Content-Type: application/zip\r\n\r\n'
  ];
  const bodyEnd = `\r\n--${boundary}--\r\n`;

  const bodyBuffer = Buffer.concat([
    Buffer.from(bodyParts.join('')),
    zipData,
    Buffer.from(bodyEnd)
  ]);

  const uploadResult = await new Promise((resolve, reject) => {
    const url = new URL('/rest/metadata/v2.0/scripts/packages/files?packageName=' + encodeURIComponent(javaPackage), baseUrl);
    const options = {
      hostname: url.hostname, port: 443,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'multipart/form-data; boundary=' + boundary,
        'Content-Length': bodyBuffer.length
      },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { resolve({ code: String(res.statusCode), msg: data.substring(0, 200) }); }
      });
    });
    req.on('error', reject);
    req.write(bodyBuffer);
    req.end();
  });

  if (uploadResult.code !== '200') {
    console.error('上传失败: %s', uploadResult.msg || '');
    fs.unlinkSync(zipPath);
    process.exit(1);
  }
  console.log('上传成功');

  // 4. 安装代码包
  console.log('\n安装代码包 ...');
  const installBody = JSON.stringify({ packageName: javaPackage });
  const installResult = await apiCall('POST', '/rest/metadata/v2.0/scripts/packages/installations', installBody, { 'Content-Type': 'application/json' });
  if (installResult.code === '200') {
    console.log('安装成功');
  } else {
    console.error('安装失败: %s', installResult.msg || '');
  }

  // 5. 清理
  fs.unlinkSync(zipPath);
  console.log('\n已清理临时文件');
  console.log('\n✅ 完成!');
}

main().catch(err => {
  console.error('异常:', err.message);
  if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
  process.exit(1);
});

#!/usr/bin/env node
/**
 * 查询 CRM 系统数据工具。借助当前项目的登录状态执行 SQL 查询。
 * 用法: node query_crm.js <项目目录> "<SQL查询语句>"
 * 示例: node query_crm.js 验证项目 "SELECT id, accountName, level FROM account LIMIT 10"
 */
const fs = require('fs');
const path = require('path');
const https = require('https');

if (process.argv.length < 4) {
  console.log('用法: node query_crm.js <项目目录> "<SQL查询语句>"');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const sql = process.argv[3];
const tokenPath = path.join(projectDir, '.neo-cli/token.json');

if (!fs.existsSync(tokenPath)) {
  console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
  process.exit(1);
}

const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
const accessToken = token.access_token;

// 从 token.json 获取 API 基础地址（仅取根路径）
const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';

function apiGet(apiPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json'
      },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error: ' + data.substring(0, 100))); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  console.log('执行查询: %s\n', sql);

  const encodedSql = encodeURIComponent(sql);
  const apiPath = '/rest/data/v2/query?q=' + encodedSql;

  try {
    const data = await apiGet(apiPath);
    const result = data.result || data.data || {};
    const records = result.records || [];
    const total = result.totalSize || records.length;

    if (records.length > 0) {
      // 提取字段名
      const fields = Object.keys(records[0]);

      // 打印表头
      const header = fields.join(' | ');
      console.log(header);
      console.log('-'.repeat(header.length));

      // 打印数据
      for (const r of records) {
        const row = fields.map(f => String(r[f] != null ? r[f] : '')).join(' | ');
        console.log(row);
      }

      console.log('\n共 %s 条记录', total);
    } else {
      console.log('无数据');
      console.log('原始响应: %s', JSON.stringify(data).substring(0, 1000));
    }
  } catch (e) {
    console.error('异常: %s', e.message);
    process.exit(1);
  }
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

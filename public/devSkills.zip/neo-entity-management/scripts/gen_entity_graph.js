/**
 * gen_entity_graph.js
 * 
 * 从项目的 src/xObjects/fields/*.md 文件中提取实体和关联关系，
 * 生成 graph-data.json 供 schema-viewer.html 使用。
 * 
 * 用法：
 *   node neo-entity-management/scripts/gen_entity_graph.js <项目目录>
 * 
 * 输出：
 *   <项目目录>/src/xObjects/graph-data.json
 *   同时复制 schema-viewer.html 到同目录
 */

const fs = require('fs');
const path = require('path');

// ============ Main ============
function main() {
  const projectDir = process.argv[2];
  if (!projectDir) {
    console.error('用法: node gen_entity_graph.js <项目目录>');
    process.exit(1);
  }

  const xObjectsDir = path.join(projectDir, 'src', 'xObjects');
  const fieldsDir = path.join(xObjectsDir, 'fields');
  const allObjectsFile = path.join(xObjectsDir, 'AllxObjects.md');

  if (!fs.existsSync(fieldsDir)) {
    console.error(`错误: 字段目录不存在 ${fieldsDir}`);
    console.error('请先执行 gen_entity_desc.js 拉取实体字段');
    process.exit(1);
  }

  // 1. 读取实体列表
  const entityMap = parseAllObjects(allObjectsFile);

  // 2. 解析每个字段文件
  const entities = [];
  const relationships = [];
  const fieldFiles = fs.readdirSync(fieldsDir).filter(f => f.endsWith('.md'));

  console.log(`正在解析 ${fieldFiles.length} 个实体字段文件...`);

  fieldFiles.forEach(file => {
    const apiKey = file.replace('.md', '');
    const filePath = path.join(fieldsDir, file);
    const content = fs.readFileSync(filePath, 'utf-8');
    
    const result = parseEntityFile(content, apiKey, entityMap);
    entities.push(result.entity);
    relationships.push(...result.relationships);
  });

  // 3. 生成 graph-data.js (var GRAPH_DATA = <JSON>; 格式，兼容 file:// 协议 script src 引用)
  const graphData = { entities, relationships };
  const jsPath = path.join(xObjectsDir, 'graph-data.js');
  const jsContent = 'var GRAPH_DATA = ' + JSON.stringify(graphData, null, 2) + ';\n';
  fs.writeFileSync(jsPath, jsContent, 'utf-8');
  console.log(`✅ 已生成 ${jsPath}`);
  console.log(`   实体: ${entities.length} 个, 关系: ${relationships.length} 条`);

  // 4. 复制 schema-viewer.html 到同目录
  const viewerSrc = path.join(__dirname, '..', 'schema-viewer', 'schema-viewer.html');
  const viewerDest = path.join(xObjectsDir, 'schema-viewer.html');
  if (fs.existsSync(viewerSrc)) {
    fs.copyFileSync(viewerSrc, viewerDest);
    console.log(`✅ 已复制查看器到 ${viewerDest}`);
    console.log(`\n打开查看器: open "${viewerDest}"`);
  } else {
    console.log(`⚠️  查看器源文件不存在: ${viewerSrc}`);
  }
}

// ============ Parse AllxObjects.md ============
function parseAllObjects(filePath) {
  const map = {}; // apiKey → { label, custom }
  if (!fs.existsSync(filePath)) return map;

  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');

  lines.forEach(line => {
    // 匹配表格行: | 名称 | apiKey | 类型 |
    const match = line.match(/\|\s*(.+?)\s*\|\s*(\w+(?:__c)?)\s*\|\s*(标准|自定义)\s*\|/);
    if (match) {
      const [, label, apiKey, type] = match;
      map[apiKey] = { label: label.trim(), custom: type === '自定义' };
    }
  });

  return map;
}

// ============ Parse Entity Field File ============
function parseEntityFile(content, apiKey, entityMap) {
  const lines = content.split('\n');
  const fields = [];
  const relationships = [];

  // Extract entity label from first heading: # 客户 (account)
  let entityLabel = apiKey;
  const headingMatch = content.match(/^#\s+(.+?)\s*\(/m);
  if (headingMatch) {
    entityLabel = headingMatch[1].trim();
  }

  // Determine if custom
  const isCustom = apiKey.endsWith('__c');

  // Parse table rows for fields
  let inTable = false;
  let tableHeaders = [];

  lines.forEach(line => {
    // Detect table header
    if (line.includes('|') && (line.includes('API Key') || line.includes('apiKey') || line.includes('字段名称'))) {
      inTable = true;
      tableHeaders = line.split('|').map(h => h.trim().toLowerCase());
      return;
    }

    // Skip separator line
    if (line.match(/^\|[\s\-:]+\|/)) return;

    // Parse table data row
    if (inTable && line.startsWith('|') && line.includes('|')) {
      const cells = line.split('|').map(c => c.trim()).filter(c => c);
      if (cells.length < 2) return;

      const field = parseFieldRow(cells, tableHeaders, lines);
      if (field && field.apiKey && field.apiKey !== '---') {
        fields.push(field);

        // Extract relationship
        if (field.referTo) {
          relationships.push({
            from: apiKey,
            to: field.referTo,
            field: field.apiKey,
            label: field.label,
            type: field.relType || 'reference'
          });
        }
      }
    }

    // End of table
    if (inTable && line.trim() === '') {
      inTable = false;
    }
  });

  // Also try to extract relationships from "关联字段" section
  const refSection = extractRelationships(content, apiKey);
  refSection.forEach(rel => {
    // Avoid duplicates
    if (!relationships.find(r => r.from === rel.from && r.field === rel.field)) {
      relationships.push(rel);
      // Also add to fields if not present
      if (!fields.find(f => f.apiKey === rel.field)) {
        fields.push({ apiKey: rel.field, label: rel.label, type: 'reference', referTo: rel.to });
      }
    }
  });

  return {
    entity: {
      apiKey,
      label: entityLabel,
      custom: isCustom,
      fieldCount: fields.length,
      fields: fields.slice(0, 50) // Limit fields for performance
    },
    relationships
  };
}

// ============ Parse a table row into a field object ============
function parseFieldRow(cells, headers, allLines) {
  const field = {};

  if (cells.length < 2) return null;

  // Clean cells
  const cleanCells = cells.map(c => c.replace(/[*`]/g, '').trim());

  // Map Chinese type names to standard types
  const typeMap = {
    '文本': 'text', '多行文本': 'textarea', '富文本': 'text',
    '整数': 'int', '金额': 'currency', '百分比': 'percent', '小数': 'float',
    '日期': 'date', '日期时间': 'datetime', '时间': 'time',
    '引用': 'reference', '关联关系': 'reference', '主子明细': 'detail',
    '查找': 'join', '关联查询': 'join',
    '单选': 'picklist', '多选': 'multipicklist',
    '布尔': 'boolean', '复选框': 'boolean',
    '电话': 'phone', '邮箱': 'email', '网址': 'url',
    '自动编号': 'autonumber', '图片': 'image', '文件': 'doc',
    '地理位置': 'location', '维度': 'text', '复合字段': 'text',
    '所有人': 'reference', '公式': 'text', '汇总': 'text'
  };

  // Standard format: 字段名称 | API Key | 字段类型 | 引用对象 | 标准/自定义
  field.label = cleanCells[0];
  field.apiKey = cleanCells[1];

  // Type (3rd column)
  if (cleanCells.length >= 3) {
    const rawType = cleanCells[2];
    field.type = typeMap[rawType] || 'text';
  } else {
    field.type = 'text';
  }

  // Reference target (4th column)
  if (cleanCells.length >= 4) {
    const refTarget = cleanCells[3];
    if (refTarget && refTarget !== '-' && refTarget !== '—' && refTarget !== '') {
      field.referTo = refTarget;
      if (field.type === 'text') field.type = 'reference';
    }
  }

  // Also check for → pattern in any cell
  cells.forEach(cell => {
    if (cell.includes('→') || cell.includes('->')) {
      const refMatch = cell.match(/[→\->]\s*(\w+(?:__c)?)/);
      if (refMatch && !field.referTo) {
        field.referTo = refMatch[1];
        if (field.type === 'text') field.type = 'reference';
      }
    }
  });

  // Determine relation type
  if (field.type === 'detail') {
    field.relType = 'detail';
  } else if (field.type === 'reference') {
    field.relType = 'reference';
  } else if (field.type === 'join') {
    field.relType = 'join';
  }

  return field;
}

// ============ Extract relationships from 关联字段 section ============
function extractRelationships(content, entityApiKey) {
  const relationships = [];
  
  // Pattern: look for lines with "关联目标" column or "→ entity" patterns
  const lines = content.split('\n');
  let inRelSection = false;

  lines.forEach(line => {
    if (line.includes('关联字段') || line.includes('关联关系')) {
      inRelSection = true;
      return;
    }
    if (inRelSection && line.startsWith('#')) {
      inRelSection = false;
      return;
    }

    if (inRelSection && line.startsWith('|') && !line.includes('---')) {
      // Try to extract: | fieldLabel | apiKey | type | target | ...
      const cells = line.split('|').map(c => c.trim()).filter(c => c);
      if (cells.length >= 4) {
        const label = cells[0].replace(/[*`]/g, '');
        const fieldApiKey = cells[1].replace(/[*`]/g, '');
        const type = cells[2].toLowerCase();
        const target = cells[3].replace(/[*`]/g, '').trim();

        if (target && target !== '关联目标' && target !== '说明') {
          relationships.push({
            from: entityApiKey,
            to: target,
            field: fieldApiKey,
            label: label,
            type: type === 'detail' ? 'detail' : (type === 'join' ? 'join' : 'reference')
          });
        }
      }
    }
  });

  return relationships;
}

// ============ Run ============
main();

#!/usr/bin/env node
/**
 * 创建自定义实体
 * 用法: node create_entity.js <项目目录> <apiKey> <label> [options]
 * 
 * 示例:
 *   node create_entity.js 验证项目 customerCard 客户档案卡
 *   node create_entity.js 验证项目 coupon 优惠券 --autoNumber "YJ{YYYY}{MM}{DD}{000}"
 *   node create_entity.js 验证项目 myEntity 我的实体 --enableScript
 * 
 * 参数:
 *   <项目目录>   NEO 项目目录（包含 .neo-cli/token.json）
 *   <apiKey>     实体 API Key（系统自动追加 __c 后缀）
 *   <label>      实体显示名称
 * 
 * 选项:
 *   --autoNumber <format>   主字段使用自动编号，指定格式（如 "AC{YYYY}{MM}{DD}{000}"）
 *   --desc <description>    实体描述
 *   --enableScript           启用脚本触发器
 *   --enableBusitype         启用业务类型
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// ============================================================
// 参数解析
// ============================================================
const args = process.argv.slice(2);
if (args.length < 3) {
  console.log('用法: node create_entity.js <项目目录> <apiKey> <label> [options]');
  console.log('');
  console.log('选项:');
  console.log('  --autoNumber <format>   主字段使用自动编号');
  console.log('  --desc <description>    实体描述');
  console.log('  --enableScript          启用脚本触发器');
  console.log('  --enableBusitype        启用业务类型');
  process.exit(1);
}

const projectDir = args[0];
const apiKey = args[1];
const label = args[2];

// 解析选项
let autoNumber = null;
let description = '';
let enableScript = false;
let enableBusitype = false;

for (let i = 3; i < args.length; i++) {
  if (args[i] === '--autoNumber' && args[i + 1]) {
    autoNumber = args[++i];
  } else if (args[i] === '--desc' && args[i + 1]) {
    description = args[++i];
  } else if (args[i] === '--enableScript') {
    enableScript = true;
  } else if (args[i] === '--enableBusitype') {
    enableBusitype = true;
  }
}

// ============================================================
// 读取 token 和 API 地址
// ============================================================
function getConfig(projectDir) {
  const tokenPath = path.resolve(projectDir, '.neo-cli/token.json');
  if (!fs.existsSync(tokenPath)) {
    console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
    process.exit(1);
  }
  const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));

  // 从 token.json 获取 API 基础地址（仅取根路径）
  const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';

  return { accessToken: token.access_token, baseUrl };
}

// ============================================================
// HTTP 请求
// ============================================================
function apiPost(baseUrl, apiPath, body, accessToken) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const data = JSON.stringify(body);

    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data)
      },
      rejectUnauthorized: false
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', chunk => responseData += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(responseData));
        } catch (e) {
          resolve({ code: res.statusCode, msg: responseData.substring(0, 200) });
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// ============================================================
// 主流程
// ============================================================
async function main() {
  const { accessToken, baseUrl } = getConfig(projectDir);

  // 构建请求体
  const body = {
    apiKey,
    label,
    description: description || label,
    nameItem: autoNumber
      ? { itemType: 9, dataFormat: autoNumber }
      : { itemType: 1, maxLength: 200 },
    enableScriptExecutor: enableScript,
    enableBusitype: enableBusitype
  };

  console.log('创建实体: %s (%s)', label, apiKey);
  console.log('API 地址: %s', baseUrl);
  console.log('主字段: %s', autoNumber ? '自动编号 ' + autoNumber : '文本');
  console.log('');

  const result = await apiPost(baseUrl, '/rest/metadata/v3.1/xobjects/', body, accessToken);

  if (result.code === 200 || result.code === '200') {
    console.log('✅ 创建成功!');
    console.log('   API Key: %s', result.data?.apiKey || apiKey + '__c');
    console.log('   Object ID: %s', result.data?.objectId || '');
  } else if (result.code === 'ERROR_OBJECT_APIKEY_REPEAT') {
    console.log('⚠️  实体已存在: %s', result.data?.apiKey || apiKey + '__c');
  } else {
    console.error('❌ 创建失败: %s', result.msg || JSON.stringify(result));
    process.exit(1);
  }
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

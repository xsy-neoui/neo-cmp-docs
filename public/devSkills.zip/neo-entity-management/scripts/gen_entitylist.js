#!/usr/bin/env node
/**
 * 生成实体字典：通过 API 获取实体列表，输出 AllxObjects.md
 * 用法: node gen_entitylist.js <项目目录>
 * 示例: node gen_entitylist.js 验证项目
 */
const fs = require('fs');
const path = require('path');
const https = require('https');

if (process.argv.length < 3) {
  console.log('用法: node gen_entitylist.js <项目目录>');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const tokenPath = path.join(projectDir, '.neo-cli/token.json');
const outputDir = path.join(projectDir, 'src/xObjects');

if (!fs.existsSync(tokenPath)) {
  console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
  process.exit(1);
}

const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
const accessToken = token.access_token;

// 从 token.json 获取 API 基础地址（仅取根路径）
const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';

function apiGet(apiPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json'
      },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error: ' + data.substring(0, 100))); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  const allEntities = [];

  for (const customFlag of ['false', 'true']) {
    const typeLabel = customFlag === 'true' ? '自定义' : '标准';
    console.log('获取%s实体列表 ...', typeLabel);
    try {
      const data = await apiGet('/rest/metadata/v2.0/xobjects/filter?custom=' + customFlag + '&active=true');
      const records = (data.data && data.data.records) || [];
      for (const r of records) {
        allEntities.push({
          apiKey: r.apiKey || '',
          label: r.label || r.apiKey || '',
          description: r.description || '',
          isStandard: customFlag === 'false',
          enableBusitype: r.enableBusitype || false,
          enableGroupMember: r.enableGroupMember || false,
          enableScriptExecutor: r.enableScriptExecutor || false,
          enableCheckrule: r.enableCheckrule || false,
          enableDuplicaterule: r.enableDuplicaterule || false,
          detail: r.detail || false,
          objectType: r.objectType || 0
        });
      }
      console.log('  获取到 %d 个实体', records.length);
    } catch (e) {
      console.log('警告: 获取实体列表失败 (custom=%s): %s', customFlag, e.message);
    }
  }

  // 排序
  const entities = allEntities.sort((a, b) => a.apiKey.localeCompare(b.apiKey));
  const standard = entities.filter(e => e.isStandard);
  const custom = entities.filter(e => !e.isStandard);

  // 统计
  const detailCount = entities.filter(e => e.detail).length;
  const busitypeCount = entities.filter(e => e.enableBusitype).length;
  const teamCount = entities.filter(e => e.enableGroupMember).length;
  const scriptCount = entities.filter(e => e.enableScriptExecutor).length;

  // 生成 Markdown
  const lines = [
    '# 实体字典', '',
    `租户 ID: ${token.tenant_id || ''} | 环境: ${baseUrl}`, '',
    `共 ${entities.length} 个实体（${standard.length} 个标准实体 + ${custom.length} 个自定义实体）`, '',
    '## 功能统计', '',
    '| 功能 | 启用数量 | 说明 |',
    '|------|----------|------|',
    `| 明细对象 | ${detailCount} | 可作为主从关系的明细对象 |`,
    `| 业务类型 | ${busitypeCount} | 支持多业务类型配置 |`,
    `| 团队成员 | ${teamCount} | 支持团队协作和数据共享 |`,
    `| 触发器 | ${scriptCount} | 支持服务端脚本触发器 |`,
    '',
    '## 实体列表', '',
    '| 实体名称 | API Key | 类型 | 描述 | 明细对象 | 业务类型 | 团队成员 | 触发器 | 校验规则 | 查重规则 |',
    '|----------|---------|------|------|----------|----------|----------|--------|----------|----------|'
  ];

  for (const e of entities) {
    const etype = e.isStandard ? '标准' : '自定义';
    const desc = e.description || '-';
    const detail = e.detail ? '✓' : '-';
    const busitype = e.enableBusitype ? '✓' : '-';
    const team = e.enableGroupMember ? '✓' : '-';
    const script = e.enableScriptExecutor ? '✓' : '-';
    const check = e.enableCheckrule ? '✓' : '-';
    const duplicate = e.enableDuplicaterule ? '✓' : '-';
    lines.push(`| ${e.label} | ${e.apiKey} | ${etype} | ${desc} | ${detail} | ${busitype} | ${team} | ${script} | ${check} | ${duplicate} |`);
  }

  // 写入文件
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'AllxObjects.md');
  fs.writeFileSync(outputPath, lines.join('\n'), 'utf-8');

  console.log('完成: %s (%d 个实体)', outputPath, entities.length);
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

#!/usr/bin/env node
/**
 * 为实体创建字段
 * 用法: node create_field.js <项目目录> <实体apiKey> <字段定义JSON>
 * 
 * 示例:
 *   # 创建文本字段
 *   node create_field.js 验证项目 customerCard__c '{"apiKey":"name","label":"名称","itemType":1,"maxLength":200}'
 * 
 *   # 创建单选字段
 *   node create_field.js 验证项目 coupon__c '{"apiKey":"status","label":"状态","itemType":3,"pickOption":[{"optionLabel":"启用","optionCode":1},{"optionLabel":"停用","optionCode":2}]}'
 * 
 *   # 从 JSON 文件批量创建
 *   node create_field.js 验证项目 customerCard__c --file fields.json
 * 
 * 支持的 itemType:
 *   1  - 文本 (必填: maxLength)
 *   2  - 多行文本 (必填: maxLength)
 *   3  - 单选 (必填: pickOption)
 *   4  - 多选 (必填: pickOption)
 *   5  - 整数
 *   6  - 金额 (必填: maxLength, decimal)
 *   7  - 日期
 *   21 - 日期时间
 *   22 - 电话
 *   23 - 邮箱
 *   24 - 网址
 *   29 - 图片 (必填: maxLength, 1-9)
 *   31 - 布尔
 *   32 - 地理位置
 *   33 - 百分比 (必填: maxLength, decimal)
 *   39 - 文件 (必填: maxLength, 1-9, 默认9)
 *   40 - 富文本 (必填: maxLength)
 * 
 * 不支持 API 创建（需后台手动）:
 *   10 - 关联关系
 *   26 - 查找字段
 *   34 - 多态关联
 *   41 - 多值关联
 * 
 * 注意:
 *   - apiKey 无需手动添加 __c 后缀，系统自动追加
 *   - 不支持设置 isRequired（必填），需在后台手动配置
 *   - pickOption 中 optionCode 为 Integer 类型
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// ============================================================
// 参数解析
// ============================================================
const args = process.argv.slice(2);
if (args.length < 3) {
  console.log('用法: node create_field.js <项目目录> <实体apiKey> <字段定义JSON>');
  console.log('      node create_field.js <项目目录> <实体apiKey> --file <fields.json>');
  console.log('');
  console.log('字段定义 JSON 示例:');
  console.log('  {"apiKey":"name","label":"名称","itemType":1,"maxLength":200}');
  console.log('');
  console.log('批量文件格式 (fields.json):');
  console.log('  [{"apiKey":"f1","label":"字段1","itemType":1,"maxLength":100}, ...]');
  process.exit(1);
}

const projectDir = args[0];
const entityApiKey = args[1];

// 解析字段定义
let fieldDefs = [];
if (args[2] === '--file') {
  const filePath = args[3];
  if (!filePath || !fs.existsSync(filePath)) {
    console.error('错误: 文件不存在: %s', filePath);
    process.exit(1);
  }
  const content = fs.readFileSync(filePath, 'utf-8');
  const parsed = JSON.parse(content);
  fieldDefs = Array.isArray(parsed) ? parsed : [parsed];
} else {
  try {
    fieldDefs = [JSON.parse(args[2])];
  } catch (e) {
    console.error('错误: 无法解析 JSON: %s', args[2]);
    process.exit(1);
  }
}

// ============================================================
// 读取配置
// ============================================================
function getConfig(projectDir) {
  const tokenPath = path.resolve(projectDir, '.neo-cli/token.json');
  if (!fs.existsSync(tokenPath)) {
    console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
    process.exit(1);
  }
  const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));

  // 从 token.json 获取 API 基础地址（仅取根路径）
  const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';

  return { accessToken: token.access_token, baseUrl };
}

// ============================================================
// HTTP 请求
// ============================================================
function apiPost(baseUrl, apiPath, body, accessToken) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const data = JSON.stringify(body);

    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data)
      },
      rejectUnauthorized: false
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', chunk => responseData += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(responseData));
        } catch (e) {
          resolve({ code: res.statusCode, msg: responseData.substring(0, 200) });
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// ============================================================
// 字段校验
// ============================================================
const UNSUPPORTED_TYPES = [10, 26, 34, 41];
const TYPE_NAMES = {
  1: '文本', 2: '多行文本', 3: '单选', 4: '多选', 5: '整数',
  6: '金额', 7: '日期', 9: '自动编号', 21: '日期时间',
  22: '电话', 23: '邮箱', 24: '网址', 29: '图片',
  31: '布尔', 32: '地理位置', 33: '百分比',
  39: '文件', 40: '富文本'
};

function validateField(field) {
  if (!field.apiKey || !field.label || !field.itemType) {
    return '缺少必填参数: apiKey, label, itemType';
  }
  if (UNSUPPORTED_TYPES.includes(field.itemType)) {
    return `itemType=${field.itemType} 不支持 API 创建，需后台手动操作`;
  }
  if ([1, 2, 40].includes(field.itemType) && !field.maxLength) {
    return `itemType=${field.itemType} 需要 maxLength 参数`;
  }
  if ([6, 33].includes(field.itemType) && (!field.maxLength || field.decimal === undefined)) {
    return `itemType=${field.itemType} 需要 maxLength 和 decimal 参数`;
  }
  if ([3, 4].includes(field.itemType) && (!field.pickOption || !field.pickOption.length)) {
    return `itemType=${field.itemType} 需要 pickOption 参数`;
  }
  if (field.itemType === 29 && !field.maxLength) {
    return 'itemType=29(图片) 需要 maxLength 参数(1-9)';
  }
  return null;
}

// ============================================================
// 主流程
// ============================================================
async function main() {
  const { accessToken, baseUrl } = getConfig(projectDir);
  const apiPath = `/rest/metadata/v3.1/xobjects/${entityApiKey}/items`;

  console.log('目标实体: %s', entityApiKey);
  console.log('API 地址: %s', baseUrl);
  console.log('待创建字段: %d 个', fieldDefs.length);
  console.log('');

  let okCount = 0;
  let failCount = 0;

  for (const field of fieldDefs) {
    // 校验
    const error = validateField(field);
    if (error) {
      console.log('  ❌ %s (%s) — %s', field.label || field.apiKey, field.apiKey, error);
      failCount++;
      continue;
    }

    // 移除不支持的参数
    delete field.isRequired;
    delete field.required;

    // 创建
    const result = await apiPost(baseUrl, apiPath, field, accessToken);

    if (result.code === 200 || result.code === '200') {
      const typeName = TYPE_NAMES[field.itemType] || field.itemType;
      console.log('  ✅ %s (%s) → %s [%s]', field.label, field.apiKey, result.data?.apiKey || '', typeName);
      okCount++;
    } else if (result.code === 'ERROR_ITEM_APIKEY_REPEAT') {
      console.log('  ⚠️  %s (%s) — 字段已存在', field.label, field.apiKey);
      okCount++;
    } else {
      console.log('  ❌ %s (%s) — %s', field.label, field.apiKey, result.msg || JSON.stringify(result).substring(0, 100));
      failCount++;
    }

    // 避免请求过快
    await new Promise(r => setTimeout(r, 300));
  }

  console.log('');
  console.log('结果: 成功 %d / 失败 %d / 总计 %d', okCount, failCount, fieldDefs.length);

  if (failCount > 0) process.exit(1);
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

#!/usr/bin/env node
/**
 * 生成实体字段描述：通过 API 获取指定实体的字段信息，输出 <apiKey>.md
 * 用法: node gen_entity_desc.js <项目目录> <实体apiKey>
 * 示例: node gen_entity_desc.js 验证项目 account
 */
const fs = require('fs');
const path = require('path');
const https = require('https');

if (process.argv.length < 4) {
  console.log('用法: node gen_entity_desc.js <项目目录> <实体apiKey>');
  process.exit(1);
}

const projectDir = path.resolve(process.argv[2]);
const apiKey = process.argv[3];
const tokenPath = path.join(projectDir, '.neo-cli/token.json');
const outputDir = path.join(projectDir, 'src/xObjects/fields');

if (!fs.existsSync(tokenPath)) {
  console.error('错误: 未找到 %s，请先执行 neo login', tokenPath);
  process.exit(1);
}

const token = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
const accessToken = token.access_token;

// 从 token.json 获取 API 基础地址（仅取根路径）
const baseUrl = token.instance_uri ? new URL(token.instance_uri).origin : 'https://crm.xiaoshouyi.com';

const ITEM_TYPE_MAP = {
  1: '文本', 2: '多行文本', 3: '整数', 4: '小数', 5: '金额',
  6: '百分比', 7: '日期', 8: '日期时间', 9: '复选框',
  10: '引用', 11: '选项列表', 12: '多选列表', 13: '自动编号',
  14: '图片', 15: '地理位置', 16: '电话', 17: '邮箱',
  18: '网址', 19: '长整数', 20: '计算字段', 21: '汇总字段',
  22: '富文本', 23: '文件', 24: '签名', 25: '级联选项',
  26: '复合字段', 27: '统计字段', 28: '自动计算', 29: '关联字段',
  30: '标签', 31: '布尔', 38: '日期范围', 99: '维度'
};

function apiGet(apiPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(apiPath, baseUrl);
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json'
      },
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error')); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  // 1. 获取实体信息
  console.log('获取实体信息: %s ...', apiKey);
  let entityLabel = apiKey;
  try {
    const entityData = await apiGet('/rest/metadata/v2.0/xobjects/' + apiKey);
    const entity = (entityData.data && entityData.data.records) || {};
    entityLabel = entity.label || apiKey;
  } catch (e) {
    console.log('警告: 获取实体信息失败: %s', e.message);
  }

  // 2. 获取字段列表
  console.log('获取字段列表 ...');
  let fields;
  try {
    const fieldsData = await apiGet('/rest/metadata/v2.0/xobjects/' + apiKey + '/items');
    fields = (fieldsData.data && fieldsData.data.records) || [];
  } catch (e) {
    console.error('错误: 获取字段列表失败: %s', e.message);
    process.exit(1);
  }

  // 3. 生成 Markdown
  const lines = [
    `# ${entityLabel} (${apiKey})`, '',
    `共 ${fields.length} 个字段`, '',
    '| 字段名称 | API Key | 字段类型 | 引用对象 | 标准/自定义 |',
    '|----------|---------|----------|----------|------------|'
  ];

  for (const f of fields) {
    const fk = f.apiKey || '';
    const label = f.label || '';
    const itemType = f.itemType || 0;
    const ftype = ITEM_TYPE_MAP[itemType] || String(itemType);
    const refer = f.referObjectApiKey || '-';
    const isStd = f.custom ? '自定义' : '标准';
    lines.push(`| ${label} | ${fk} | ${ftype} | ${refer} | ${isStd} |`);
  }

  // 选项列表（过滤掉选项过多的字段）
  const pickFields = fields.filter(f => f.pickOption && f.pickOption.length > 0 && f.pickOption.length <= 50);
  if (pickFields.length > 0) {
    lines.push('', '## 选项列表', '');
    for (const f of pickFields) {
      const activeOpts = f.pickOption.filter(opt => opt.active !== false);
      if (activeOpts.length === 0) continue;
      lines.push(`### ${f.label || ''} (${f.apiKey || ''})`, '');
      lines.push('| 选项值 | 选项标签 |');
      lines.push('|--------|----------|');
      for (const opt of activeOpts) {
        lines.push(`| ${opt.optionApiKey || ''} | ${opt.optionLabel || ''} |`);
      }
      lines.push('');
    }
  }

  // 写入文件
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, apiKey + '.md');
  fs.writeFileSync(outputPath, lines.join('\n'), 'utf-8');

  console.log('完成: %s (%s, %d 个字段)', outputPath, entityLabel, fields.length);
}

main().catch(err => {
  console.error('异常:', err.message);
  process.exit(1);
});

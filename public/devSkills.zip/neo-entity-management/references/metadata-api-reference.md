# Metadata Cloud API v3.1 参考

基础路径：`/rest/metadata/v3.1/xobjects/`

## 接口总览

| 方法 | 路径 | 说明 |
|:---|:---|:---|
| GET | /rest/metadata/v3.1/xobjects/filter | 查询实体列表 |
| POST | /rest/metadata/v3.1/xobjects/ | 创建自定义实体 |
| PATCH | /rest/metadata/v3.1/xobjects/{xobjectApiKey} | 更新实体 |
| GET | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/items | 查询实体所有字段 |
| POST | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/items | 创建字段 |
| PATCH | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/items/{itemApiKey} | 更新字段 |
| GET | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/busiTypes | 查询业务类型列表 |
| POST | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/busiTypes | 创建业务类型 |
| PATCH | /rest/metadata/v3.1/xobjects/{xobjectApiKey}/busitypes/{busiTypeApiKey} | 更新业务类型 |
| GET | /rest/metadata/v3.1/xobjects/relationships | 查询所有关联关系 |

## 认证

通过 OAuth Token 认证，Header 携带 `Authorization: Bearer {token}`。

前置条件：
- 租户需开通 Metadata API 访问权限
- 用户职能需勾选「开发者平台 > Metadata API」权限

## 字段类型枚举（itemType）

| itemType | 类型名称 | API 创建 | 必填参数 | 来源 |
|:---|:---|:---:|:---|:---|
| 1 | 单行文本 | ✅ | maxLength | 已验证 |
| 2 | 多行文本 | ✅ | maxLength | 已验证 |
| 3 | 单选下拉 | ✅ | pickOption | 已验证，optionLabel + optionCode(Integer) |
| 4 | 多选复选框 | ✅ | pickOption | 已验证，optionLabel + optionCode(Integer) |
| 5 | 整数 | ✅ | — | 已验证 |
| 6 | 金额/实数 | ✅ | maxLength, decimal | 已验证，推荐 maxLength=14, decimal=2 |
| 7 | 日期 | ✅ | — | 已验证 |
| 9 | 自动编号 | ✅ | dataFormat | 已验证，仅用于实体主字段 |
| 10 | 关联关系 | ✅ | referObjectApiKey, cascadeDelete | 已验证，使用 referObjectApiKey |
| 21 | 日期时间 | ✅ | — | Wiki |
| 22 | 电话 | ✅ | — | 已验证 |
| 23 | 邮箱 | ✅ | — | 已验证 |
| 24 | 网址 | ✅ | — | 已验证 |
| 26 | 引用（只读） | ✅ | joinLinkItemApiKey + joinItemApiKey | 已验证，推荐用 apiKey 方式 |
| 27 | 计算字段 | ❌ | — | Wiki，不支持 API 创建 |
| 28 | 汇总累计 | ❌ | — | Wiki，不支持 API 创建 |
| 29 | 图片 | ✅ | maxLength, imageUploadMode | 已验证，maxLength 为图片最大数量 |
| 30 | 布尔 | ✅ | — | Wiki |
| 31 | 地理定位 | ✅ | — | 已验证 |
| 32 | 百分比 | ✅ | decimal | 已验证 |
| 33 | 多态关联 | ✅ | multiReferObjectIds | Wiki |
| 34 | 多值关联 | ✅ | referObjectId, cascadeDelete | Wiki |
| 38 | 时间 | — | — | 未验证 |
| 39 | 文件 | ✅ | — | 已验证，quantity 可选 |
| 40 | 富文本 | ✅ | — | Wiki |

**支持 API 创建**：共 22 种（1,2,3,4,5,6,7,9,10,21,22,23,24,26,29,30,31,32,33,34,39,40）

**不支持 API 创建**：共 2 种（27 计算字段, 28 汇总累计）

**已废弃编号**（均返回"itemType 不在合法范围内"）：8, 11, 13, 15, 16, 17, 20

**编号映射**（旧 → 新）：8→21, 11→32, 13→30, 15→23, 16→22, 17→24, 20→29

## apiKey 命名规则

- 仅允许字母、数字和下划线
- 不能以数字开头
- 系统自动追加 `__c` 后缀，调用时无需手动添加
- 创建后不可修改

## 幂等性

所有创建接口均支持幂等：同名 apiKey 已存在时返回已有资源信息，不会创建重复数据。

## 限制

- 不提供删除接口
- 不提供批量接口（单条操作）
- 仅支持自定义实体创建
- 字段类型创建后不可变更
- 并发写入使用分布式锁（租户ID + apiKey 粒度）

# 常见问题

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

本文汇总自定义组件开发、发布与设计器使用过程中较常遇到的问题及处理思路。

::: v-pre

## CLI 安装相关

### Q1. Windows 控制台执行 `neo` 命令「禁止运行脚本」

Windows 默认安全策略导致。PowerShell 里执行：

```powershell
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser
```

### Q2. 「无法将 neo 项识别为 cmdlet、函数、脚本文件或可运行程序的名称」

PATH 问题，PowerShell 找不到全局安装的 CLI。三步解决：

```powershell
# 1) 查看 npm 全局路径
$npmPath = npm config get prefix

# 2) 当前终端临时生效
$env:PATH += ";$npmPath"

# 3) 永久写入用户环境变量（重启仍生效）
[Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";$npmPath", "User")
```

常见原因：安装 Node 时未勾选「Automatically install the necessary tools…」。

## 授权登录

### Q3. 浏览器没有自动打开？

命令行会打印登录授权 URL，复制到浏览器打开即可完成登录和授权。

### Q4. Token 刷新失败？

若 `refresh_token` 已过期，需重新 `neo login`；同时检查网络。

### Q5. 登录后没有跳回 redirect_uri？

可能被浏览器扩展干扰。已知 **Neo UI Extension** 可能影响授权流程，可暂时关闭后重试。

## 发布相关

### Q6. 发布时报错：找不到 `neo-ui-common` 模块

**原因**：`neo-ui-common` 是平台虚拟模块（非真实 NPM 包），仅在 Neo 平台运行时注入。

**解决方式一**：用 neo-cmp-cli 构建发布（`neo init` / `neo create project` 默认就是）。
**解决方式二**：自建 Webpack 时，在 `externals` 的函数形式中把这些模块映射为 `neoRequire(...)`：

```js
// webpack.config.js（Webpack 5）
module.exports = {
  entry: './src/index.js',
  output: { filename: 'bundle.js', path: __dirname + '/dist' },
  externals: [
    { /* 其他对象形 externals */ },
    function (context, request, callback) {
      const neoModules = ['neo-ui-common', 'neo-ui-component-web', 'neo-ui-component-h5', 'neo-open-api'];
      if (neoModules.includes(request)) {
        return callback(null, `neoRequire("${request}")`, 'commonjs');
      }
      callback();
    },
  ],
};
```

Webpack 4 及以下不支持对象 + 函数数组混写，需全部并入函数内。

### Q7. 「未找到自定义组件模型文件」？

- 确认组件目录下存在 `model.ts` / `model.js`。
- 确认构建产物中含对应的 `xxCmpModel.js`。
- 确认 `model` 是默认导出或同名导出。

## 设计器与组件渲染

### Q8. 发布后，设计器左侧组件面板看不到自定义组件

排查顺序：

1. **模型文件是否缺失**：组件目录下必须有 `model.[tj]s`。
2. **模型中的页面 / 设备是否匹配**：`targetPage` / `targetDevice` 与当前设计器一致。
3. **是否 `exposedToDesigner: false`**：为子组件用途时才设 `false`。
4. **是否发布成功**：在 NeoCRM 后台「自定义组件」列表中能看到。

### Q9. 拖拽到画布后未正常渲染（空白）

**可能原因**：组件运行时报错。打开浏览器开发者工具查看控制台，按报错修复。

常见原因：

- 引用了 `neo-ui-component-web` / `neo-open-api` 但运行环境不支持（本地预览）
- JS 报错导致 React 整棵树卸载

### Q10. 属性里「是否显示」设为「否」未生效

**原因**：组件根节点未合并 `props.className`。

设计器隐藏组件时会向 `props.className` 注入 `design-hide`，组件必须把 `className` 合到根节点 DOM 上：

```tsx
<div className={classnames('infoCard__c', this.props.className)}>
```

### Q11. 事件动作「组件控制 / 组件可见性」未生效

**原因**：组件未继承 `BaseCmp`。

这些能力依赖 `BaseCmp`：

```tsx
// @ts-ignore
import { BaseCmp } from 'neo-ui-common';

class MyCmp extends BaseCmp<Props, State> { /* ... */ }
```

### Q12. 已配置的事件动作不执行

排查顺序：

1. **是否继承 `BaseCmp`**：`model.functions` 依赖 `BaseCmp`。
2. **`this` 是否丢失**：组件动作内使用 `this` 时，**构造函数里要 `bind(this)`**：

   ```tsx
   constructor(props: Props) {
     super(props);
     this.refreshData = this.refreshData.bind(this);
   }
   ```

3. **方法名与 `apiKey` 是否一致**：`model.functions[i].apiKey` 与组件方法名必须严格一致。
4. **装饰器是否启用**：`tsconfig.json` 里 `experimentalDecorators: true`。

### Q13. 自定义组件根节点样式未生效

**原因**：根节点没用**与组件目录名一致**的类名（className），被样式隔离策略影响。

发布或 `linkDebug` 时，CLI 会为组件样式增加作用域前缀（如 `[data-scope=组件目录名]`）。根节点 className 与目录名不一致，作用域无法正确匹配。

**解决**：

```tsx
// 目录名：infoCard__c
<div className="infoCard__c"> ... </div>
```

如确实需要关闭样式隔离，在 `neo.config.js` 设 `disableAutoAddStyleScope: true`（不推荐）。

## 开发体验

### Q14. 本地预览报「找不到 neo-ui-common / neo-open-api / neo-ui-component-*」

**原因**：这些是平台虚拟模块，本地没有。

**解决**：`neo preview` 只能预览**不依赖平台运行时**的组件；依赖这些模块的组件必须用 `neo linkDebug` + 真实页面设计器联调。

### Q15. `neo preview` 启动失败 / 端口占用

- 检查 Node 版本（v16+，推荐 v20+）
- 换端口：`neo.config.js` 的 `preview.port`
- 检查 `neo.config.js` 语法（语法错误会让 CLI 直接退出）

### Q16. 装饰器 `@NeoEvent.dispatch` / `@FormItem` 报 TS 错

`tsconfig.json`：

```json
{
  "compilerOptions": {
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true
  }
}
```

### Q17. 事件动作 / 属性面板调用组件函数但拿不到最新 `this.state` / `this.props`

React 状态更新是异步的。在事件动作回调里需要读取最新值时：

```tsx
// ❌ 可能拿到旧值
@NeoEvent.function
logState() { console.log(this.state.count); }

// ✅ 函数式更新 + 读取 ref
this.setState((prev) => {
  console.log(prev.count);
  return { count: prev.count + 1 };
});
```

## 数据源 / OpenAPI

数据源相关问题（`xObject.query` 返回 `false`、`like` 语法限制、自定义 API 403 等）全部移至 `references/open-api.md` 的「常见陷阱」一节，此处不再重复。使用时请直接查阅 `open-api.md`。

## 版本冲突 / 运行时错误

### Q21. `Invalid hook call, Hooks can only be called inside ...`

典型的 `react` 多实例。检查：

- 工程里 `react` 版本是否对齐 `^16.13.1`
- 是否把 `react` 打进了 bundle（看 `dist/*.js` 有没有 `React`）
- 是否在依赖链上有另一个版本的 react

### Q22. antd Modal / Popover / Tooltip 样式跑偏

- 弹层样式写到 `common.scss` / `reset.scss`（不被样式隔离）
- 用 `overlayClassName` 挂一个组件级唯一 className：

```tsx
<Popover overlayClassName="myCmp__c-popover" content={...}>
```

```scss
/* common.scss */
.myCmp__c-popover .ant-popover-inner { /* ... */ }
```

## 参考

- 原始问答：[常见问题](https://neo-cmp-docs.netlify.app/常见问题)
- CLI 问题：`references/neo-cli-workflow.md`
- 事件动作：`references/event-action.md`
- 样式：`references/styling.md`
- OpenAPI：`references/open-api.md`

:::

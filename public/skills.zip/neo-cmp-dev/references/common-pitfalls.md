# 常见陷阱大全（会直接让组件不工作）

> 本文是 `SKILL.md`「常见陷阱」的展开版。按类别分组，方便排查时快速定位。
>
> **核心建议**：开发时先按 `SKILL.md` 中 11 步走，每一步都做对应自检，本表用于出问题时「对号入座」。

::: v-pre

## 目录与命名

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 根类名与目录名不一致 | 样式隔离 `[data-scope]` 匹配不上，样式全失效 | 根节点 className 必须等于组件目录名（如 `infoCard__c`） |
| 未把 `props.className` 合到 DOM | 设计器「是否显示」设成「否」时 `design-hide` 注入失败 | 根节点 `${classnames('目录名', this.props.className)}` |
| 入口文件名不是 `index.*` | CLI 扫描不到组件 | 入口必须叫 `index.tsx` / `index.jsx` 等 |
| 模型文件不是 `model.*` | 组件在设计器中不可见 | 模型文件必须叫 `model.ts` / `model.js` |

## 事件动作

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 组件未 `extends BaseCmp` | 事件动作、组件控制、可见性全失效 | `class MyCmp extends BaseCmp<Props, State>` |
| `@NeoEvent.function` 方法没 `bind(this)` | 运行时 `this` 为 undefined | 构造函数里 `this.xxx = this.xxx.bind(this)` |
| `model.functions` / `model.events` 未声明 | 设计器看不到事件动作配置项 | 代码声明 + 模型声明必须同时做 |
| `apiKey` 与组件方法名不一致 | 事件动作绑定后不生效 | `apiKey` 严格匹配方法名 |
| 构造函数没调 `super(props)` | `BaseCmp` 初始化失败 | 构造函数首行必须是 `super(props)` |

## propsSchema（属性面板）

> **硬约束 4**：`propsSchema[].type` **必须**从 `references/props-schema.md` 的平台真实类型里挑选；选不到就按 `references/custom-props-item.md` 注册自定义配置项，**禁止**写未注册的 `type`。

| 陷阱 | 后果 | 解决 |
|---|---|---|
| `type` 写成泛名称（`input` / `select` / `radio` / `color`） | 设计器找不到控件 | 必须用平台类型：`panelInput` / `panelSelect` / `neoRadio` / `panelColor` 等，清单见 `references/props-schema.md` |
| 写了平台清单之外的 `type` 却没按 `custom-props-item.md` 注册 | 属性面板为空 / 控件不渲染 | 先用 `@FormItem({ type: 'xxx__c' })` 注册 → `model.ts` side-effect 引入 → `propsSchema` 用同名 `type` |
| 自定义 `type` 与平台 / 他人已占用名冲突 | 全局冲突、渲染错乱 | 加业务前缀（如 `orderBoardLayout__c`）保证唯一 |
| 自定义配置项忘了调 `this.props.onChange(newValue)` | 配了但保存不了 | 用户确认 / 保存时必须调用 `onChange` 写回表单 |
| 外部 `data` 变化后自定义配置项没刷新 | 动态联动失效 | `@FormItem({ type, detectProps: ['data'] })` 声明依赖 |
| 用 `panelInput` + JSON 文本凑合复杂对象 | 业务方填 JSON 极易出错；不是合规路径 | 按 `custom-props-item.md` 开发一个专用渲染器 |
| `propsSchema[].name` 与 props 字段名不对齐 | 配置项不生效 | `name` 必须与组件 props 字段名严格一致 |
| `type` 与 props 数据类型不匹配（布尔用 `panelInput`、枚举用 `panelInput` 等） | 配了不生效或类型转换失败 | 布尔 → `panelSwitch`；枚举 → `panelSelect` / `neoRadio`；数字 → `panelNumber`；颜色 → `panelColor` |
| `defaultComProps` 和 `propsSchema` 默认值冲突 | 初始值不一致 | 以 `defaultComProps` 为准，保持一致 |
| `defaultComProps` 漏了某个 schema 字段 | 首次拖入为 `undefined`，组件异常 | 每个 `propsSchema` 条目都要有默认值 |
| 回调写进 `propsSchema` | 设计器出现无意义的输入框 | 回调走 `model.events` + 事件动作绑定 |
| 选项 `options[].value` 类型与 props 类型不一致 | 选了不生效 | 对齐 TS literal union 类型 |

## 依赖与构建

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 直接 `import 'neo-ui-common'` 到 `package.json` | 发布报错「找不到模块」 | 虚拟模块，只需 `// @ts-ignore` 导入，不要 npm install |
| `neo-ui-component-web` / `neo-open-api` 用在 `neo preview` 下 | 报「找不到模块」 | 虚拟模块本地没有，改用 `neo linkDebug` |
| React / antd 被打进 bundle | 体积炸 + `Invalid hook call` | 确保走平台 externals；检查 `dist/*.js` 有没有 React |
| 工具方法塞在组件文件里 | 无法复用、难以测试 | 下沉到 `src/utils/`，按领域拆文件并命名导出 |
| 自研功能子组件散落在组件目录内 | 无法跨组件复用 | 非 antd / antd-mobile 的 UI 子组件放在 `src/common/` |

## 平台数据访问

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 读/写平台实体却自己写 `axios` | 丢失登录态、权限校验、审计 | 改用 `neo-open-api.xObject` + 数据源类 `propsSchema` |
| 展示平台实体列表却用 `antd Table` + `xObject.query` 手写 | 失去 SmartView、批量操作等平台能力 | H5 用 `NeoEntityList`、PC 用 `NeoEntityGrid` |
| 调外部 API 不部署通用代理就直接请求 | CORS 与路径白名单双重拦截 | 先部署 `forward.zip`，再用 `customApi.run` 走代理 |
| 通用代理的 `methodType` 写成非 POST | 走错路由 | 外层固定 `POST`，真正方法放内层 `data.method` |
| 只靠 `code === 0` 判断成功 | 网关语义不一致导致误判 | 以 `status: boolean` 为准，`msg` 做错误展示 |

## 样式

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 弹层样式放到 `index.scss` | 样式被隔离，弹层不生效 | 放 `common.scss` / `reset.scss`（不被隔离） |
| 单位 `0px` | stylelint 报错 | 改 `0` |
| 颜色值大写 | stylelint 报错 | 改小写 |
| 多用 `!important` | 难以维护 | 优先提高选择器特异性 |

## 安装与发布

| 陷阱 | 后果 | 解决 |
|---|---|---|
| 安装命令不走淘宝源 | 国内网络访问 registry.npmjs.org 超时 | 命令加 `--registry=https://registry.npmmirror.com`（yarn 用空格分隔） |
| 使用旧域名 `registry.npm.taobao.org` | 该域名 2024 年已下线，解析失败 | 一律用 `registry.npmmirror.com` |
| 发布时 `name` / `version` 冲突 | 发布失败 | `name` 在租户内唯一，`version` 每次递增 |
| Windows 控制台 `neo` 命令识别不了 | 无法使用 CLI | 见 `references/faq.md`（PATH 与 PowerShell 策略） |
| UI 库选型不对齐端 | PC 用非 antd、H5 用非 antd-mobile，主题割裂 | 遵循硬约束 1 |

## 调试排查

| 现象 | 排查路径 |
|---|---|
| 组件拖入画布空白 | 打开浏览器控制台看报错 → 检查是否引用了虚拟模块在本地预览 → 改用 `neo linkDebug` |
| 事件动作不生效 | 检查：`extends BaseCmp`？`bind(this)`？`model.functions` 声明了？`apiKey` 一致？装饰器启用了？ |
| 样式不生效 | 检查根节点 className = 目录名？样式隔离 `[data-scope]` 匹配？弹层样式放对了文件？ |
| 属性面板不显示 | 检查 `propsSchema.type` 是否为平台真实类型（`references/props-schema.md`）？若用了自定义 `type`，是否按 `references/custom-props-item.md` 完成 `@FormItem` 注册 + `model.ts` side-effect 引入？`name` 与 props 字段对齐？`defaultComProps` 有一致默认值？ |

:::
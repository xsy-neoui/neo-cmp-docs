# 从 Vue 组件迁移到 Neo React 自定义组件

本文是 **本技能** 与 **`vue-to-react`** 技能的**桥接文档**：

- 语法层面迁移（模板、响应式、生命周期、通信、状态管理、路由等）走 **`vue-to-react`** 技能。
- 迁移后落地到 Neo 平台的**组件规范**（目录、`model.ts`、`propsSchema`、事件动作、样式隔离、externals）走本技能。

**关键提醒**：Vue 2 技术栈在 Neo 平台 **不支持事件动作**。如果组件需要与其它组件联动，**迁移到 React 是必需的**。

::: v-pre

## 迁移流程（高层）

1. **读取 `vue-to-react` 技能**：确定 React 形态、MobX Store、样式方案、UI 库映射等。
2. **切换到本技能**：按下面清单把产物落到 `src/components/<cmpName>__c/` 结构。
3. **补齐设计器侧**：`model.ts` + `propsSchema`（平台真实类型）+ `defaultComProps` + `events` / `functions`。
4. **接入平台能力**：`extends BaseCmp`（需要事件动作时）、`props.env.ctx`、`neo-open-api`。
5. **对齐平台依赖**：React 16 + antd 4.9.4（PC）/ antd-mobile 2.3.4（H5），不要用 Tailwind（平台环境不引入 Tailwind）。
6. **本地验证**：`neo preview`（纯展示）/ `neo linkDebug`（含平台能力）。

## 关键差异（vue-to-react 建议 vs Neo 平台）

| vue-to-react 推荐 | Neo 平台自定义组件 | 原因 |
|---|---|---|
| Tailwind + CSS Modules | **SCSS + stylelint**（BEM） | 平台未预置 Tailwind；CSS Modules 与样式隔离机制可能冲突 |
| React Router v5 | **通常不需要**（组件粒度） | 自定义组件运行在平台页面里，路由由平台控制 |
| `neo-cmp-cli` 工程化 | 同左 | ✅ 一致 |
| MobX 6 + `observer` | 同左 | ✅ 一致 |
| React 16 + TS | 同左 | ✅ 一致 |
| antd 任意版本 | **必须 `antd@4.9.4`** | 与平台预置版本对齐 |
| 函数组件为主 | **需要组件联动时必须类组件 + `extends BaseCmp`** | 事件动作、组件动作依赖 BaseCmp |

## 产物映射（SFC → Neo 组件目录）

```
Button.vue                       src/components/button__c/
├── <template>         →         ├── index.tsx         (JSX)
├── <script setup>     →         │   └── hooks/        (可选抽出)
├── <style scoped>     →         ├── index.scss        (会被样式隔离)
                                 ├── common.scss       (弹层样式，不隔离)
                                 ├── model.ts          (新增：设计器模型 + events + functions)
                                 └── types.ts          (可选：Props 类型)
```

> 组件目录名带 `__c` 后缀（平台约定）。

## 迁移 checklist

对每个 `.vue` 组件，完成以下项：

### 1. 结构

- [ ] 在 `src/components/` 下建 `<cmpName>__c/`
- [ ] 生成 `index.tsx` / `model.ts` / `index.scss`
- [ ] **根节点 className == 目录名**（如 `button__c`）
- [ ] **根节点合并 `props.className`**（设计器隐藏注入 `design-hide`）

### 2. 模板 → JSX

- [ ] `v-if` → 条件渲染（`&&` / 三元）
- [ ] `v-for` → `.map()`，带稳定 `key`（不用数组下标）
- [ ] `@click` → `onClick`，`.stop/.prevent` 改为手动 `e.stopPropagation()`
- [ ] `v-model` → `value` + `onChange`
- [ ] `:class` / `:style` → `className={classnames(...)}` / `style={{ ... }}`
- [ ] 默认插槽 → `props.children`；具名插槽 → 命名 prop（`header={<H1 />}`）

### 3. 响应式 → Hooks / setState

- [ ] 类组件：`data()` → `state`；`computed` → 在 `render` 里算 / 缓存在 `state`
- [ ] 函数组件：`data()` → `useState`；`computed` → `useMemo`
- [ ] `watch` → `useEffect(fn, [deps])` / 类组件 `componentDidUpdate`
- [ ] `methods` → 类属性箭头函数（类组件） / `useCallback`（函数组件）

### 4. 生命周期

- [ ] `mounted` → `componentDidMount` / `useEffect(fn, [])`
- [ ] `beforeDestroy` → `componentWillUnmount` / `useEffect` 的 cleanup
- [ ] `updated` → `componentDidUpdate` / `useEffect(fn)`
- [ ] `errorCaptured` → 类组件 `componentDidCatch` + `getDerivedStateFromError`（ErrorBoundary）

### 5. 通信

- [ ] `props` → `props`（TS interface）
- [ ] `$emit('xxx', v)` → **`@NeoEvent.dispatch`** + `model.events[]`（替代 callback 方案）
- [ ] `provide/inject` → `createContext` + `useContext`
- [ ] `$refs` → `useRef` + `forwardRef` + `useImperativeHandle`

### 6. 样式

- [ ] `<style scoped>` → `index.scss`，根节点 className 作命名空间
- [ ] 弹层样式（antd Modal/Popover）放 `common.scss`
- [ ] 通过 stylelint：`npx stylelint "src/**/*.scss"`

### 7. 平台能力接入（**新增**）

- [ ] **事件动作**：
  - [ ] `extends BaseCmp`（若需要组件联动）
  - [ ] `@NeoEvent.dispatch` + `model.events[]`
  - [ ] `@NeoEvent.function` + `model.functions[]` + 构造函数 `bind(this)`
- [ ] **运行时上下文**：把用 `this.$store` / 全局变量的地方换成 `this.props.env.ctx` / `this.props.data.__Neo*`
- [ ] **数据访问**：把 `axios.get(...)` 换成 `xObject.query(...)` / `customApi.run(...)`

### 8. 设计器模型（**新增**）

- [ ] `model.ts` 含 `label` / `description`
- [ ] `propsSchema` 用**平台真实类型**（`panelInput` / `panelSelect` / `panelSwitch` / `xObjectDataApi` 等，不要写 `input` / `select`）
- [ ] 每项 `name` 与 props 字段名一致
- [ ] `defaultComProps` 与 propsSchema 默认值一致
- [ ] `targetDevice` 与 UI 库选择一致（antd → `'web'`，antd-mobile → `'mobile'`）
- [ ] `events` / `functions` 声明了可触发事件与可被调用的组件动作

### 9. 依赖

- [ ] 换成平台预置版本（见 `platform-deps.md`）
- [ ] 特别注意 `react@16.13.1`、`antd@4.9.4`
- [ ] 虚拟模块（`neo-ui-common` / `neo-open-api` / `neo-ui-component-*`）**不写进 `package.json`**
- [ ] 原 Vue 专用库（`vue-i18n`、`vuex` 等）替换成对应实现或移除

### 10. 验证

- [ ] `npm run lint` 通过
- [ ] `tsc --noEmit` 通过
- [ ] `neo preview`（纯展示）或 `neo linkDebug`（含平台能力）渲染正常
- [ ] 在页面设计器里属性面板联动正常
- [ ] 事件动作（如有）绑定后行为正确

## 一个具体的迁移示例

### 原 Vue 2 组件

```vue
<!-- src/components/button/index.vue -->
<template>
  <button
    :class="['btn', `btn-${variant}`, { 'is-loading': loading }]"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <span v-if="loading" class="spinner" />
    <slot />
  </button>
</template>

<script>
export default {
  name: 'Button',
  props: {
    variant: { type: String, default: 'primary' },
    loading: Boolean,
    disabled: Boolean,
  },
  methods: {
    handleClick(e) {
      if (!this.loading && !this.disabled) this.$emit('click', e);
    },
  },
};
</script>

<style scoped>
.btn { padding: 8px 16px; border-radius: 4px; }
.btn-primary { background: #2563eb; color: white; }
.btn-ghost { background: transparent; color: #2563eb; }
.is-loading { opacity: 0.7; cursor: wait; }
</style>
```

### 迁移后（Neo React 自定义组件）

```tsx
// src/components/button__c/types.ts
import { ReactNode } from 'react';

export interface ButtonCProps {
  variant?: 'primary' | 'ghost';
  loading?: boolean;
  disabled?: boolean;
  children?: ReactNode;
  className?: string; // 平台注入（design-hide 等）
}
```

```tsx
// src/components/button__c/index.tsx
import * as React from 'react';
import classnames from 'classnames';
// @ts-ignore 平台运行时注入
import { BaseCmp, NeoEvent } from 'neo-ui-common';
import { ButtonCProps } from './types';
import './index.scss';

export default class ButtonC extends BaseCmp<ButtonCProps, {}> {
  constructor(props: ButtonCProps) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  /** 对外触发的事件（在 model.events 里声明） */
  @NeoEvent.dispatch
  onButtonClick(payload: { variant: string }) {
    return payload;
  }

  handleClick() {
    const { variant = 'primary', loading, disabled } = this.props;
    if (!loading && !disabled) this.onButtonClick({ variant });
  }

  render() {
    const { variant = 'primary', loading = false, disabled = false, children, className } = this.props;
    return (
      <button
        type="button"
        className={classnames(
          'button__c',
          `button__c--${variant}`,
          { 'button__c--loading': loading },
          className,
        )}
        disabled={disabled || loading}
        onClick={this.handleClick}
      >
        {loading && <span className="button__c__spinner" />}
        {children}
      </button>
    );
  }
}
```

```scss
/* src/components/button__c/index.scss */
.button__c {
  padding: 8px 16px;
  border-radius: 4px;
  border: 0;
  cursor: pointer;

  &--primary { background: #2563eb; color: #fff; }
  &--ghost { background: transparent; color: #2563eb; }
  &--loading { opacity: 0.7; cursor: wait; }

  &__spinner {
    display: inline-block;
    width: 12px;
    height: 12px;
    margin-right: 8px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: button-spin 0.8s linear infinite;
  }
}

@keyframes button-spin {
  to { transform: rotate(360deg); }
}
```

```ts
// src/components/button__c/model.ts
export class ButtonCModel {
  label = '按钮';
  description = '基础按钮组件，支持主色与幽灵风格';
  tags = ['基础', '自定义组件'];
  targetDevice = 'web';

  defaultComProps = {
    variant: 'primary',
    loading: false,
    disabled: false,
  };

  events = [
    { apiKey: 'onButtonClick', label: '点击按钮后', helpText: '按钮被点击时触发' },
  ];

  propsSchema = [
    {
      type: 'neoRadio', name: 'variant', label: '风格',
      options: [
        { label: '主要', value: 'primary' },
        { label: '幽灵', value: 'ghost' },
      ],
    },
    { type: 'panelSwitch', name: 'loading', label: '加载中' },
    { type: 'panelSwitch', name: 'disabled', label: '禁用' },
  ];
}

export default ButtonCModel;
```

## 常见迁移陷阱（结合 Neo 平台）

- **用了 Tailwind 的 class** → 平台不引入 Tailwind，样式失效；全部改成 SCSS。
- **根节点类名沿用 Vue 里的命名** → 必须等于目录名（否则样式隔离失效）。
- **没有合并 `props.className` 到根节点 DOM** → 设计器「是否显示」设为「否」不生效。
- **`$emit` 改成 callback 但没用事件动作** → 应改成 `@NeoEvent.dispatch` + `model.events`，通过设计器的事件动作面板绑定。
- **`propsSchema` 写成 `input` / `select` / `radio`** → 应写平台类型 `panelInput` / `panelSelect` / `neoRadio`。
- **antd 版本不对齐** → 用了 4.x 新特性或 5.x API 都会出事，严格对齐 `4.9.4`。
- **遗漏 `model.ts`** → 组件无法被设计器识别。
- **React 16 不支持自动批处理** → Vue 里 `this.a = 1; this.b = 2;` 自动合并；React 16 要手动 `unstable_batchedUpdates`。
- **忘了 `extends BaseCmp`** → 事件动作、组件控制、组件可见性全失效。
- **使用 `this` 的组件动作没 `bind`** → 事件触发时 `this` 丢失。

:::

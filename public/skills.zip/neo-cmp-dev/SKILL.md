---
name: neo-cmp-dev
description: 在 neo-cmp-cli 创建的工程里做**组件开发 / Neo 平台自定义组件开发**（React 16 + TypeScript）。凡是用户意图是"写 / 开发 / 改造 / 增强 / 实现一个组件的内部实现"——**不论用户是否显式说'自定义组件'**——统一走本技能：覆盖组件目录与 `index.tsx` 入口、`model.ts` 模型、`propsSchema` 真实类型与自定义配置项、事件动作（@NeoEvent + BaseCmp）、运行时上下文（props.env.ctx / props.data.__Neo*）、平台预置组件、平台实体数据源与自定义 API（xObject / customApi / 通用代理 forward）、SCSS + BEM 样式隔离、模板选型、工程规范（Airbnb + stylelint）、依赖安装与发布前格式化。**字段兜底规则**：当用户未明确说明要使用实体的哪些字段时，**必须先**通过运行时 `xObject.getDesc('<apiKey>')` 或 `neo-cmp-cli` 的 `scripts/fetchEntityDesc.js` 查询实体已有的字段列表，再从已有字段中挑选要使用的字段；文档信息不完整时改走运行时 `xObject.getDesc('<apiKey>')` 或在 `propsSchema` 中用 `selectFieldsApi` / `selectFieldDescApi` 让业务方选字段，**不得**凭直觉杜撰字段名。**首次创建自定义组件项目**：优先走 `neo create project`（空项目骨架），**仅当用户明确要求"基于某个内置模板起步"**（如 echarts / antd / neo-h5-cmps / neo-bi-cmps 等）时才改用 `neo init -t <type>`；具体命令由 `neo-cmp-cli` 执行。**淘宝源（https://registry.npmmirror.com）仅在两类场景自动注入**：① 全局安装 / 升级 `neo-cmp-cli`；② 安装工程全量依赖（`npm install` / `yarn` / `pnpm install`）。其它 npm / yarn / pnpm 操作（单包增删升级、`npx`、发布构建等）使用默认源，不再追加 `--registry`。**开发完成后**（组件代码、模型、样式、依赖安装与格式化齐备后），本技能**必须**向用户提示"预览 / linkDebug / 发布"三选项（可多选），并**按用户选择转交 `neo-cmp-cli` 技能**执行对应命令（`neo preview` / `neo linkDebug` / `neo push cmp`），不在本技能内直接拼命令。**不用于**：只是执行 `neo` 命令（创建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 登录）且**不写任何组件内部代码**的场景（→ neo-cmp-cli）；把 Vue 组件或整个 Vue 项目改造 / 转换 / 迁移成自定义组件的前半段语法迁移（→ vue-to-react，迁移完成后再回到本技能落地平台规范）。触发关键词：组件开发、开发组件、写组件、实现组件、React 组件开发、实现 / 开发 / 编写 / 改造 Neo 自定义组件功能、加属性面板配置项、自定义配置项开发、被其他组件调用的组件动作、读写平台实体数据、调用自定义 API / 外部接口。**实体识别关键词**：客户、联系人、销售机会、订单、合同、销售线索、产品、任务、用户、部门、审批、商品、回款、发票、库存、采购、报表、日程、公告、服务工单、巡访记录、活动记录、预算、费用、报销、资产、项目以及所有 Neo 标准实体名称（见 `references/standard-entities.md`）。
---

# Neo 平台 React 自定义组件开发技能

本技能在 neo-cmp-cli 工程中，按平台规范开发 **React 16 + TypeScript** 自定义组件。覆盖五件事：
- **落地规范**：目录约定、model.ts、propsSchema 真实类型、根节点 className 与样式隔离、平台预置依赖
- **对接平台能力**：事件动作（`@NeoEvent` + `BaseCmp`）、运行时上下文（`props.env.ctx` / `props.data.__Neo*`）、平台预置组件（`NeoEntityList` / `NeoEntityGrid`）、`neo-open-api` 数据源（`xObject` / `customApi`）
- **收敛开发步骤**：一张 11 步清单覆盖「需求→选型→模型→属性面板→实现→依赖/格式化→询问用户下一步」
- **对齐工程规范**：Airbnb ESLint + stylelint-config-standard
- **完成后交接**：必须向用户确认「预览/linkDebug/发布」并转交 [`neo-cmp-cli`](../neo-cmp-cli/SKILL.md) 执行

> **命令执行层**：所有 `neo` 命令的交互式参数与非交互式映射由 [`neo-cmp-cli`](../neo-cmp-cli/SKILL.md) 承载；本技能第 3/10/11 步涉及的命令以 `neo-cmp-cli` 为准。

## 技能边界（三技能路由）

| 用户意图 | 应使用的技能 |
|---|---|
| 只是**执行命令**（创建项目/骨架/预览/调试/发布/拉取/删除/登录） | **`neo-cmp-cli`** |
| **实现/开发/改造组件内部功能**（属性面板、事件动作、数据对接、样式） | **`neo-cmp-dev`（本技能）** |
| "开发组件/写组件/做组件"（在 neo 工程中默认即是自定义组件） | **`neo-cmp-dev`（本技能）** |
| 把**现有 Vue 组件/项目**迁移成自定义组件 | **`vue-to-react`**（先）→ **本技能**（后） |

**同时表达"创建+实现"**：先走 `neo-cmp-cli` 的 `neo create cmp` 生成骨架，再由本技能接管其余步骤。

## 技术栈

| 维度 | 选择 |
|---|---|
| 框架 | **React 16.13.1**（与平台预置对齐） |
| 组件形态 | 需要事件动作/组件函数 → **类组件 + `extends BaseCmp`**；纯展示 → 函数组件 + Hooks |
| PC 端 UI | **antd ^4.9.4**（externals 剔除，直接 import） |
| H5 端 UI | **antd-mobile 2.3.4**（externals 剔除，直接 import） |
| 平台运行时 | `neo-ui-common`（BaseCmp, NeoEvent）+ `neo-open-api`（xObject, customApi, request） |
| 平台预置组件 | PC: `NeoEntityGrid`（`neo-ui-component-web`）；H5: `NeoEntityList` / `GlobalSearchInput`（`neo-ui-component-h5`） |
| 状态管理 | 组件内 `useState` / `useReducer` / `this.state`；跨组件优先**事件动作** |
| 样式 | **SCSS** + BEM（根类名=组件目录名） |
| 代码规范 | Airbnb（工程 `.eslintrc.js` 已继承） |
| 构建 | `neo preview` / `neo linkDebug` / `neo push cmp` |

> `neo-ui-common` / `neo-ui-component-*` / `neo-open-api` 都是**平台运行时注入的虚拟模块**，不要在 `package.json` 安装；`import` 时加 `// @ts-ignore`。

## 硬性约束

### 约束 1：UI 组件库与端对齐

| 端 | 必须优先使用 | 自研兜底 |
|---|---|---|
| PC（`web`） | **antd ^4.9.4** | `antd`/`antd-mobile` 无对应能力时，自研子组件放 `src/common/`，在 README 说明原因；**禁止**引入 Element/MUI/Semi/Arco/Vant/NutUI 等其他 UI 库替代 |
| H5（`mobile`） | **antd-mobile 2.3.4** | 同上 |
| 通用（`all`） | 按实际渲染端择一，避免混用两套风格 | 拆两个组件或分支渲染 |

### 约束 2：平台列表类数据源优先使用平台列表组件

- H5：**`NeoEntityList`**（`neo-ui-component-h5`）→ 需传 `render={this.props.render}`
- PC：**`NeoEntityGrid`**（`neo-ui-component-web`）→ 需传 `render={this.props.render}`
- **禁止**为绕过学习成本/样式定制而用 `antd Table` + `xObject.query` 自研列表
- **例外**：显著偏离列表语义（卡片墙、看板、日历、地图等）且平台组件扩展点覆盖不到时可用 `antd Table`/`antd-mobile List`，需在 README 说明原因
- 配置项使用 `xObjectEntityList` / `xObjectDataApi` 等数据源类类型，避免写死 apiKey

### 约束 3：工具类方法统一放 `src/utils/`

通用逻辑、纯函数、格式化、校验、解析、常量、SDK 包装等**必须**下沉到 `src/utils/`，禁止塞在 `index.tsx` / `components/*.tsx` / `model.ts` 里。按领域分文件（`date.ts` / `number.ts` / `entity.ts` / `proxy.ts`），命名导出。组件级私有辅助可放组件目录的 `helpers.ts`。

### 约束 4：`propsSchema` 的 `type` 必须来自平台真实类型

- **允许的 type** 仅两类：**表单类**（`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `neoCheckbox` / `neoCascader` / `neoTreeSelect` / `neoDatePicker` / `neoTimePicker` / `neoRate` / `neoSlider` / `neoUpload` / `neoTransfer`）和**数据源类**（`xObjectEntityList` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `selectFieldDescApi` / `dataViewIdSelect` / `customApi`）
- `name` 必须与 `defaultComProps` 和组件 props 字段严格对齐
- 选不到合适类型 → 按 `references/custom-props-item.md` 走 `@FormItem` 注册自定义配置项，**禁止**写未注册的 `type` 或用 `panelInput` + JSON 凑合
- 事件回调不进 `propsSchema`，由 `model.events` 声明

### 约束 5：淘宝源仅注入两类场景

| 允许注入场景 | 命令 | 注入方式 |
|---|---|---|
| ① 全局安装/升级 neo-cmp-cli | `npm i -g neo-cmp-cli` / `yarn global add neo-cmp-cli` / `pnpm add -g neo-cmp-cli` | 追加 `--registry=https://registry.npmmirror.com` |
| ② 工程根目录安装全量依赖 | `npm install` / `yarn` / `pnpm install` | 同上 |

**禁止注入**：单包增删升级、`npx`、发布/构建命令。工程已有 `.npmrc` 指向私服时沿用工程配置。旧域名 `registry.npm.taobao.org` 已停用。

## 组件目录约定

```
src/components/<cmpName>__c/     # 目录名=组件名=cmpType（__c 后缀）
├── index.tsx                     # 必须：入口
├── model.ts                      # 必须：设计器配置（propsSchema/events/functions）
├── index.scss                    # 可选：样式（CLI 做样式隔离）
├── common.scss                   # 可选：弹层类样式（不隔离）
└── types.ts / hooks/ / components/ / helpers.ts / README.md  # 可选
src/common/<SubCmpName>/          # 自研功能子组件（跨组件复用）
src/utils/                        # 工具类方法（按领域分文件）
```

**硬约束**：目录名必须与 `cmpType` 一致（`__c` 后缀）；根节点 `className` 必须与目录名一致且合并 `props.className`（否则「是否显示」失效）。

## 开发关键步骤（11 步）

按顺序走完以下步骤，产出符合规范的组件。

### 步骤 1：需求分析 & 模板选型

明确组件解决的问题、可配置项、`targetPage` 与 `targetDevice`。**需求→模板快速映射**：PC 列表/筛选/Picker → `neo-web-entity-grid`；H5 业务组件 → `neo-h5-cmps`；通用业务组件 → `neo`；BI 指标 → `neo-bi-cmps`；图表 → `echarts`；地图 → `amap`；表单 → `neo-web-form`。按硬约束逐条自检 UI 库、列表组件、工具方法沉淀、propsSchema 类型、包管理器源。

### 步骤 2：实体识别 + 数据接入决策（关键）

**先完成实体识别，再进行数据接入决策。**

**实体识别**：扫描需求中的业务对象关键词 → 匹配 `references/standard-entities.md` 确定 apiKey。有歧义时向用户确认。

**字段兜底规则（用户未指定字段时）**：

> 用户没说用哪些字段？ → **第一步：先通过运行时查询获取实体已有字段列表**（使用 `xObject.getDesc('<apiKey>')` 或 `neo-cmp-cli` 的 `scripts/fetchEntityDesc.js`），从查询结果的字段清单中按场景挑选（列表→常用展示字段、搜索→过滤键、录入→必填字段），**不得凭直觉杜撰**。若运行时查询不可用，回退到 `references/standard-entities.md` 的字段清单。挑选后列出供用户复核。

**数据接入决策**：

| 需求特征 | 首选 API | propsSchema 配置项 |
|---|---|---|
| 读/写平台实体数据（CRUD） | `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` | `xObjectEntityList` + `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` |
| 调平台自定义 API | `customApi.run` | `customApi` |
| 调外部 HTTP 接口（CORS） | **通用代理**：`customApi.run({ apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', ... })`（先部署 `forward.zip`） | `panelInput` 或 `customApi` |

**硬性约束**：能用 `xObject` 不用手写 `axios`；propsSchema 优先暴露数据源类配置项让业务方设计器选字段；错误处理以 `status` 判断成功（不依赖 `code === 0`）。

### 步骤 3：初始化组件目录

若尚无 neo 工程（无 `neo.config.js`）→ 交 `neo-cmp-cli` 执行 `neo create project --name=<name>`（默认空项目）或 `neo init -t <type> -n <name>`（用户指定模板时）。已有工程 → 交 `neo-cmp-cli` 执行 `neo create cmp -n <name> -d <all|web|mobile>`。

### 步骤 4：定义组件模型

填 `model.ts`：`label` / `description` / `iconUrl` / `tags` / `targetDevice` / `defaultComProps` / `propsSchema` / `events` / `functions`（→ `references/model-file.md`）。

### 步骤 5：选择组件形态

需要组件动作/事件动作 → **类组件 + `extends BaseCmp`**；纯展示 → 函数组件 + Hooks（→ `references/component-form.md`）。

### 步骤 6：实现组件主体

props 类型与 propsSchema 对齐；按步骤 2 决策调用 `xObject` / `customApi` / `request`；PC 用 antd、H5 用 antd-mobile（缺失时自研放 `src/common/`）；平台实体列表优先用 `NeoEntityList`/`NeoEntityGrid`；纯函数下沉到 `src/utils/`。

### 步骤 7：绑定属性面板

`propsSchema` 的 `type` 从平台真实类型中挑选（约束 4）；`name` 与组件 props 字段一一对应；挑不到时按 `references/custom-props-item.md` 开发自定义配置项。

### 步骤 8：接入事件动作

对外触发 → `@NeoEvent.dispatch` + `model.events`；被调用 → `@NeoEvent.function` + `model.functions` + `extends BaseCmp` + 构造函数 `bind(this)`（→ `references/event-action.md`）。

### 步骤 9：写样式

根节点 `className` = 组件目录名，合并 `props.className`；SCSS BEM 平铺；弹层样式放 `common.scss`（→ `references/styling.md`）。

### 步骤 10：安装依赖 + 全局格式化

**自动执行**（不再等待确认）：① 识别包管理器 → 安装工程全量依赖（淘宝源，工程有 `.npmrc` 私服时沿用）；② `npm run format`（不存在时提示补 `"format": "prettier --write ..."`）；③ 汇总结果。步骤失败时记录原因并跳过，不阻塞后续流程。

### 步骤 11：开发完成 → 询问用户下一步

代码、模型、样式、依赖与格式化齐备后，按下方话术询问用户并转交 `neo-cmp-cli`（本技能禁止直接跑 `neo` 命令）。

## 实体识别

### 匹配规则（常见实体）

| 用户输入 | apiKey | label |
|---|---|---|
| 客户/客户列表 | `account` | 客户 |
| 联系人 | `contact` | 联系人 |
| 销售机会/商机 | `opportunity` | 销售机会 |
| 订单 | `order` | 订单 |
| 合同 | `contract` | 合同 |
| 销售线索/线索 | `lead` | 销售线索 |
| 产品 | `product` | 产品 |
| 任务 | `task` | 任务 |
| 服务工单/工单 | `serviceCase` | 服务工单 |
| 审批 | `apply` | 审批 |
| 费用/报销 | `expenseaccount` | 报销单 |
| 巡访/拜访记录 | `visitRecord` | 拜访记录 |
| 用户/员工 | `user` | 用户 |
| 部门 | `department` | 部门 |
| 活动记录/活动 | `activityrecord` | 活动记录 |
| 日程/日历 | `schedule` | 日程 |
| 回款 | `payment` | 回款记录 |
| 发票 | `receipt` | 发票 |
| 商品/库存 | `goods` | 商品 |
| 采购订单 | `purchaseOrder` | 采购订单 |
| 市场活动 | `campaign` | 市场活动 |

> `activityrecord` 和 `campaign` 都匹配"活动"，必须向用户确认。
> 完整清单见 `references/standard-entities.md`。

### 硬性规则

1. **用户未指定字段时，必须先查实体已有字段**（通过 `xObject.getDesc('<apiKey>')` 或 `neo-cmp-cli/scripts/fetchEntityDesc.js`），从查询结果中挑选字段，**不得凭直觉杜撰字段名**。
2. 运行时查询不可用时回退到 `references/standard-entities.md`。
3. 有歧义时向用户确认（如"客户"可能指 `account` / `potentialCustomer` / `partner`）。
4. apiKey 区分大小写。
5. 标准实体表找不到 → 可能是自定义实体（`custom: true`），建议 `xObject.getEntityList({ custom: true })` 运行时获取，或在 propsSchema 用 `xObjectEntityList` 让业务方选。

## 平台能力对接速览

| 能力 | 入口 | 参考文件 |
|---|---|---|
| 运行时用户/租户/页面信息 | `props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` | `references/runtime-context.md` |
| 全局工具、Toast、弹窗、导航 | `props.env.ctx`（`system`/`user`/`ui`/`util`/`api`） | `references/runtime-context.md` |
| 事件动作（触发/被调用/广播） | `NeoEvent.dispatch` / `NeoEvent.function` / `NeoEvent.broadcast` / `NeoEvent.listen` | `references/event-action.md` |
| 平台实体 CRUD | `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` | `references/open-api.md` |
| 自定义 API / 通用代理 | `customApi.run` / `customApi.getList` / `request` | `references/open-api.md` |
| 平台列表组件 | H5: `NeoEntityList` / `GlobalSearchInput`；PC: `NeoEntityGrid`（必传 render） | `references/platform-components.md` |
| 自定义配置项 | amis `@FormItem` 注册 + propsSchema 自定义 type | `references/custom-props-item.md` |
| 模块共享 | `neo.config.js` 的 `neoCommonModule.exports` + remoteDeps | `references/module-sharing.md` |

## 开发完成后：选择预览 / linkDebug / 发布（第 11 步展开）

先给用户简结：组件目录、targetDevice、接入的平台能力、依赖/格式化结果。然后抛出三选项（**可多选，可跳过**）：

> ✅ **组件 `<cmpName>__c` 已开发完成。接下来要做什么？**
> 1. **预览（`neo preview`）** — 本地/在线预览；纯展示选 `local`，依赖平台运行时选 `online`
> 2. **外链调试（`neo linkDebug`）** — 挂到页面设计器联调（依赖运行时必选），targetDevice → `-p pc|h5`
> 3. **发布（`neo push cmp`）** — 构建推送到 NeoCRM（确保 `version` 已递增、已登录目标环境）

**转交规则**：参数收集后统一转交 `neo-cmp-cli` 执行，本技能禁止直接跑命令。同时勾选 linkDebug+发布 → 先联调后发布。发布前自检：ESLint/stylelint/tsc 通过、version 已递增、根节点 className 与目录名一致、事件动作声明齐备。

## 常见陷阱

- **根类名与目录名不一致** → 样式隔离失效；**未合并 `props.className`** → 设计器「是否显示」失效
- **事件动作不生效**：未 `extends BaseCmp` / 未 `bind(this)` / `model.events`/`functions` 未声明
- **propsSchema type 写成泛名**（`input`/`select`）→ 必须用平台真实类型（`panelInput`/`panelSelect` 等）
- **需求是读/写平台实体却自己写 `axios`** → 丢失登录态/权限/审计；**展示列表却手写 antd Table** → 失去 SmartView/批量操作
- **用户未指定字段时凭直觉写字段** → 必须先查实体已有字段，从查询结果中挑选
- **调外部 API 不部署通用代理** → CORS 与白名单双重拦截
- **安装命令错配淘宝源**：仅两类场景注入——① 全局装 `neo-cmp-cli`；② 工程根 `npm install`；其余走默认源
- **使用已停用的 `registry.npm.taobao.org`** → 一律用 `registry.npmmirror.com`

## 参考文件

- `references/standard-entities.md` — 标准实体 apiKey ↔ label 映射 + 常见核心字段表
- `references/props-schema.md` — propsSchema 可用 type 清单（表单类+数据源类）
- `references/event-action.md` — 事件动作机制（dispatch/function/broadcast/listen）
- `references/open-api.md` — xObject CRUD + customApi + 通用代理
- `references/runtime-context.md` — `props.data.__Neo*` / `props.env.ctx` / keyIdentifier
- `references/platform-components.md` — NeoEntityList / NeoEntityGrid / GlobalSearchInput
- `references/custom-props-item.md` — 自定义配置项开发（amis @FormItem 注册）
- `references/model-file.md` — model.ts 各字段含义与取值约束
- `references/templates.md` — 内置模板选型指南
- `references/cmp-dev-case.md` — 常见开发案例（PC/H5 列表、商机 CRUD）
- `references/common-pitfalls.md` — 27 条陷阱大全
- `references/minimal-example.md` — 最小可运行示例（infoCard__c 完整源码）
- `references/styling.md` / `references/react-essentials.md` / `references/component-form.md`
- `references/platform-deps.md` — 平台预置依赖清单 + externals 机制
- `references/module-sharing.md` / `references/neo-cli-workflow.md` / `references/faq.md`
- `references/migration-from-vue.md` / `references/spec-checklist.md`
- `examples/` — 示例组件源码（xObject CRUD、customApi、事件动作）

## 资料来源

- Neo 平台文档：[neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/)（组件开发规范/CLI/配置项/数据源/事件动作/模板）
- React 官方：[react.dev](https://react.dev/learn) / React 16 Legacy：[legacy.reactjs.org](https://legacy.reactjs.org/)
- Airbnb React/JSX Style Guide：[github.com/airbnb/javascript/tree/master/react](https://github.com/airbnb/javascript/tree/master/react)

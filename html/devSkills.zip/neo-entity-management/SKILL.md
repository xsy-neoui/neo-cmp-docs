---
name: neo-entity-management
description: Neo 实体模型管理技能，辅助在 NeoCRM 平台上查询、理解和管理实体元数据。当用户需要：(1) 查询租户有哪些实体（业务对象），(2) 查询实体的字段定义、类型、选项值，(3) 理解实体间的关联关系，(4) 创建自定义实体，(5) 为实体创建或更新字段，(6) 创建或更新业务类型，(7) 设计数据模型（实体关系规划），(8) 排查字段名错误导致的代码问题时，使用此技能。
---

# Neo 实体模型管理

辅助开发者和管理员查询、理解和管理 NeoCRM 平台的实体元数据（业务对象、字段、关联关系、业务类型）。

## 定位

本技能包是实体元数据的统一入口，覆盖「模型认知」和「模型创建」两个层面：

- **模型认知**（查询）：帮助开发者和 Agent 理解租户的数据模型，生成准确的 SQL/DML
- **模型创建**（写入）：帮助管理员通过对话式交互创建实体、字段和业务类型

其他技能包在需要实体元数据时，应委托给本技能包处理，而非自行调用底层脚本或 API。

### 与其他技能包的关系

| 场景 | 委托方向 |
|:---|:---|
| neo-solution-design 方案设计阶段需要评估实体模型 | → 委托 neo-entity-management 查询 |
| neo-backend-dev 开发前需要确认字段 API Key | → 委托 neo-entity-management 查询 |
| neo-frontend-dev 开发前需要确认字段类型和选项值 | → 委托 neo-entity-management 查询 |
| 用户要求创建新实体或字段 | → 由 neo-entity-management 直接处理 |

---

## 前置条件

- 已全局安装 neo-cmp-cli：`npm i -g neo-cmp-cli`。通过 `neo -v` 检测是否已安装
- 项目已创建（存在 `neo.config.js`）
- 已登录租户（存在 `.neo-cli/token.json`）

如果前置条件不满足，提示用户先通过 neo-backend-dev 或 neo-frontend-dev 完成项目创建和登录。

---

## 核心工作流

### 一、模型认知（查询）

#### 1.1 查询实体列表

用户想了解租户有哪些业务对象时执行。

**优先使用本地缓存**：
1. 检查 `src/xObjects/AllxObjects.md` 是否存在
2. 如果存在且用户未要求刷新，直接读取本地文件
3. 如果不存在或用户要求刷新，执行拉取：

```bash
node neo-entity-management/scripts/gen_entitylist.js <项目目录>
```

输出文件：`src/xObjects/AllxObjects.md`，包含所有实体的名称、API Key 和类型（标准/自定义）。

**呈现方式**：根据用户意图决定展示粒度：
- 用户问"有哪些实体" → 展示完整列表，按标准/自定义分组
- 用户问"有没有 xxx 相关的实体" → 在列表中搜索匹配项，只展示相关结果
- 用户问"自定义实体有哪些" → 只展示自定义实体

#### 1.2 查询实体字段

用户想了解某个实体有哪些字段时执行。

**优先使用本地缓存**：
1. 检查 `src/xObjects/fields/<apiKey>.md` 是否存在
2. 如果存在且用户未要求刷新，直接读取本地文件
3. 如果不存在或用户要求刷新，通过脚本拉取并生成本地文件

**前置校验**：
- 执行前必须先确认实体 API Key 正确——在 `AllxObjects.md` 中查找匹配
- 如果用户给的是中文名称，先在 AllxObjects.md 中找到对应的 API Key
- 如果找不到匹配实体，告知用户并建议刷新实体列表

**输出结构要求**：

脚本拉取的字段描述文件（`src/xObjects/fields/<apiKey>.md`）必须包含以下信息，以便 Agent 和开发者准确理解数据模型：

1. 实体级信息：apiKey、label、是否自定义(custom)、是否可创建/删除/更新/查询
2. 每个字段的完整元数据：

| 属性 | 说明 | 用途 |
|:---|:---|:---|
| apiKey | 字段 API Key | 编写 SQL/DML 时使用 |
| label | 字段显示名称 | 理解业务含义 |
| type | 字段类型（text/picklist/reference/detail/int/float/date/datetime/time/boolean/textarea/phone/email/url/currency/percent/autonumber/formula_*/join/multipicklist/owner/entitytype/dimension/dummy/doc/image/location） | 决定代码中如何读写该字段。其中 reference 为普通关联，detail 为主子明细关系（父子强关联，子记录必须属于某个父记录），doc 为文件附件，image 为图片，location 为地理位置，time 为纯时间（不含日期） |
| itemType | Java 类型（String/Integer/Long/Double/Boolean/Integer[]） | 决定 getAttribute() 后的类型转换方式 |
| required | 是否必填 | 创建记录时的参数校验 |
| createable | 是否可在创建时设置 | 判断 insert 时能否传入该字段 |
| updateable | 是否可更新 | 判断 update 时能否修改该字段 |
| maxLength | 最大长度 | 文本字段的长度限制 |
| defaultValue | 默认值 | 创建记录时的默认行为 |
| selectitem | 单选选项列表（label + value） | picklist 类型字段的可选值 |
| checkitem | 多选选项列表（label + value） | multipicklist 类型字段的可选值 |
| referTo | 关联目标实体 apiKey | reference 类型字段指向哪个实体 |
| joinTo | 关联查询字段（objectApiKey + itemApiKey） | join 类型字段从哪个实体的哪个字段取值 |
| dependentPropertyName | 级联依赖字段 | 选项值依赖于哪个父字段（如城市依赖省份） |
| encrypt | 是否加密 | 敏感字段标识 |
| quantity | 文件/图片最大数量 | doc/image 类型字段的上传数量限制 |
| localupload | 是否支持本地上传 | doc/image 类型字段 |
| cameraUpload | 是否支持拍照上传 | image 类型字段 |

**输出文件格式示例**（`src/xObjects/fields/account.md`）：

```markdown
# 客户 (account)

> 类型: 标准实体 | 可创建: 是 | 可删除: 是 | 可更新: 是 | 可查询: 是

## 字段列表

### 基础字段

| 字段名称 | API Key | 类型 | Java类型 | 必填 | 可创建 | 可更新 | 说明 |
|:---|:---|:---|:---|:---:|:---:|:---:|:---|
| 客户名称 | accountName | text | String | ✅ | ✅ | ✅ | maxLength: 100 |
| 客户负责人 | ownerId | owner | Long | ❌ | ✅ | ❌ | → user |
| 客户类型 | entityType | entitytype | Long | ✅ | ✅ | ❌ | → entityBelongType |
| 备注 | comment | textarea | String | ❌ | ✅ | ✅ | maxLength: 65535 |

### 单选字段

| 字段名称 | API Key | 必填 | 默认值 | 选项 |
|:---|:---|:---:|:---|:---|
| 客户级别 | level | ❌ | 2 | 1:战略客户, 2:企业客户, 3:中小企业, 4:其他 |
| 行业 | industryId | ❌ | — | 1:金融, 2:电信, 3:教育, 4:高科技, ... |

### 多选字段

| 字段名称 | API Key | 选项 |
|:---|:---|:---|
| 客户来源 | highSeaAccountSource | 1:广告, 2:研讨会, 3:搜索引擎, 4:客户介绍, 5:其他 |

### 关联字段

| 字段名称 | API Key | 类型 | 关联目标 | 说明 |
|:---|:---|:---|:---|:---|
| 上级客户 | parentAccountId | reference | account | 普通关联，自关联 |
| 创建人 | createdBy | reference | user | 系统字段，不可修改 |
| 区域 | territoryId | reference | territory | — |
| 关联经销商 | relAcctName__c | reference | account | 自定义字段 |
| 子实体明细 | customItem3__c | detail | customEntity132__c | 主子明细关系，子记录必须关联父记录 |

### 关联查询字段（join）

| 字段名称 | API Key | 来源实体 | 来源字段 | 说明 |
|:---|:---|:---|:---|:---|
| 企微昵称 | wxUserName | qwContact | wxUserName | 只读，从企微联系人取值 |
| 企微头像 | wxAvatarUrl | qwContact | wxAvatarUrl | 只读 |

### 级联选项字段

| 字段名称 | API Key | 依赖字段 | 说明 |
|:---|:---|:---|:---|
| 城市 | fCity | fState（省份） | 选项值根据省份动态过滤 |
| 区县 | fDistrict | fCity（城市） | 选项值根据城市动态过滤 |

### 计算/聚合字段

| 字段名称 | API Key | 类型 | 说明 |
|:---|:---|:---|:---|
| 成交商机数 | totalWonOpportunities | formula_aggregate | 系统自动计算 |
| 是否成交客户 | isCustomer | formula_text | 系统自动计算 |
| 客户评分 | accountScore | formula_real | 系统自动计算 |

### 文件/图片字段

| 字段名称 | API Key | 类型 | 最大数量 | 本地上传 | 拍照上传 | 说明 |
|:---|:---|:---|:---:|:---:|:---:|:---|
| 附件 | customItem2__c | doc | 9 | ✅ | — | itemType: List<Map> |
| 产品图片 | customItem3__c | image | 1 | ✅ | ✅ | itemType: List<Map> |
```

**关键设计原则**：
- 按字段类型分组展示，而非简单的平铺表格——不同类型的字段关注点不同
- 单选/多选字段必须展示选项值（label + value），这是开发者写代码时最常查阅的信息
- 关联字段必须展示目标实体，这是理解数据模型关系的关键
- 级联字段必须标注依赖关系，避免开发者忽略级联逻辑
- join 字段标注来源，让开发者知道这些字段是只读的、从其他实体取值
- 省略选项值过多的字段（如省/市/区的完整列表），只标注"选项较多，请通过 API 查询"

**呈现方式**：根据用户意图决定展示粒度：
- 用户问"客户实体有哪些字段" → 展示完整字段列表（按类型分组）
- 用户问"客户实体的手机号字段叫什么" → 搜索匹配字段，只展示相关结果
- 用户问"这个实体有哪些自定义字段" → 只展示 API Key 以 `__c` 结尾的字段
- 用户问"客户级别有哪些选项" → 直接展示该字段的 selectitem 列表
- 用户问"客户关联了哪些实体" → 只展示 reference/join 类型字段

#### 1.3 查询实体关联关系

用户想了解实体之间的关联关系时执行。

**执行方式**：
1. 读取目标实体的字段列表（同 1.2）
2. 从字段列表中筛选关联类型字段（字段类型为关联关系或主子明细）
3. 整理为关联关系视图

**呈现方式**：

```
客户（account）的关联关系：
├── 所属公司 (belongId) → 客户(account) [关联关系]
├── 负责人 (ownerId) → 用户(user) [关联关系]
└── 创建人 (createdBy) → 用户(user) [关联关系]

被关联（其他实体指向客户）：
├── 联系人(contact).客户(accountId) → 客户 [主子明细]
├── 商机(opportunity).客户(accountId) → 客户 [关联关系]
└── 活动(activity).关联对象(activityRecordFrom) → 客户 [多态关联]
```

> 注：被关联方向需要遍历多个实体的字段才能获取完整信息，如果用户只需要正向关联，只查当前实体字段即可。

#### 1.4 数据查询验证

用户想验证某个 SQL 查询是否正确时执行。

```bash
node neo-entity-management/scripts/query_crm.js <项目目录> "<SQL>"
```

**使用场景**：
- 开发者写了一段 SQL，想确认字段名是否正确
- 方案设计阶段验证数据是否存在
- 排查代码中字段名错误的问题

**SQL 规范提醒**（每次执行查询时检查）：
- 基础条件用 `WHERE id > 0`，不支持 `WHERE 1=1`
- 日期条件必须用时间戳（毫秒），不支持日期字符串
- 只选择必要字段，不支持 `SELECT *`
- 单次查询最大返回 300 条

---

### 二、模型创建（写入）

通过 Metadata Cloud API v3.1 直接创建和管理实体、字段、业务类型。

#### 2.1 创建自定义实体

用户想创建新的业务对象时执行。

**信息收集**（必须在创建前确认）：

| 信息 | 必填 | 说明 | 示例 |
|:---|:---:|:---|:---|
| 实体名称（label） | ✅ | 中文显示名 | 项目 |
| API Key | ✅ | 驼峰命名，自定义实体以 `__c` 结尾 | project__c |
| 描述 | 建议 | 实体用途说明 | 用于管理项目信息 |
| 主字段类型 | ✅ | 文本(1) 或 自动编号(9) | 自动编号 |
| 自动编号格式 | 条件必填 | 主字段为自动编号时必填 | {YY}{MM}{DD}{00000} |
| 启用业务类型 | 可选 | 是否需要多业务类型 | 否 |
| 启用脚本 | 可选 | 是否需要 Trigger 扩展 | 是 |

**命名规范校验**：
- API Key 只能包含下划线、字母和数字，不能以数字开头
- 自定义实体 API Key 必须以 `__c` 结尾
- **创建时 apiKey 参数不要加 `__c` 后缀**，平台会自动追加。如传入 `"Staff"` 实际创建为 `Staff__c`；传入 `"Staff__c"` 会变成 `Staff__c__c`

**选项字段注意**：
- `pickOption` 中的 `optionCode` 必须是 Integer 类型，不能是 String（如 `1` 而非 `"1"`）

**关联关系字段注意**：
- `referObjectApiKey` 使用目标实体的完整 API Key（含 `__c`），如 `"Staff__c"`
- `cascadeDelete` 取值：0=级联删除，1=置空，2=不允许删除
- `linkLabel` 为在目标实体相关列表中显示的名称
- 不能使用保留字（参见「命名约束」章节）

**执行方式**：

**执行方式**：

```
POST /rest/metadata/v3.1/xobjects/
Authorization: Bearer {access_token}

{
  "apiKey": "project",
  "label": "项目",
  "description": "用于管理项目信息",
  "nameItem": {
    "itemType": 9,
    "dataFormat": "{YY}{MM}{DD}{00000}"
  },
  "enableScriptExecutor": true
}
```

> 注意：apiKey 无需手动添加 `__c` 后缀，系统自动追加。

**创建后必须执行**：
1. 刷新本地实体列表：`node neo-entity-management/scripts/gen_entitylist.js <项目目录>`
2. 拉取新实体的字段定义：`node neo-entity-management/scripts/gen_entity_desc.js <项目目录> <apiKey>`

#### 2.2 创建业务类型

用户想为实体添加业务类型时执行。

**前置条件**：目标实体必须已启用业务类型功能（enableBusitype）。

**信息收集**：

| 信息 | 必填 | 说明 |
|:---|:---:|:---|
| 目标实体 API Key | ✅ | 业务类型要添加到哪个实体 |
| 业务类型名称（label） | ✅ | 中文显示名 |
| 业务类型 API Key | ✅ | 创建后自动追加 `__c` |
| 描述 | 可选 | 业务类型说明 |

**执行方式**：

**执行方式**：

```
POST /rest/metadata/v3.1/xobjects/{apiKey}/busiTypes
Authorization: Bearer {access_token}

{
  "apiKey": "projectType",
  "label": "项目类型"
}
```

#### 2.3 更新业务类型

可更新属性：label、description、helpText、active（启用/停用）。

#### 2.4 创建字段

用户想为实体添加自定义字段时执行。

**信息收集**（必须在创建前确认）：

| 信息 | 必填 | 说明 |
|:---|:---:|:---|
| 目标实体 API Key | ✅ | 字段要添加到哪个实体 |
| 字段名称（label） | ✅ | 中文显示名 |
| 字段 API Key | ✅ | 自定义字段以 `__c` 结尾 |
| 字段类型 | ✅ | 见「字段类型速查」 |
| 是否必填 | — | API 不支持设置必填，需在后台手动配置 |
| 描述 | 建议 | 字段用途说明 |

**字段类型速查（经验证）**：

| itemType | 类型名称 | API 创建 | 必填参数 | 备注 |
|:---:|:---|:---:|:---|:---|
| 1 | 文本 (Text) | ✅ | maxLength | — |
| 2 | 多行文本 (TextArea) | ✅ | maxLength | — |
| 3 | 单选 (SingleSelect) | ✅ | pickOption | optionLabel + optionCode |
| 4 | 多选 (MultiSelect) | ✅ | pickOption | optionLabel + optionCode |
| 5 | 整数 (Integer) | ✅ | — | — |
| 6 | 小数 (Decimal) | ✅ | maxLength, decimal | 推荐 maxLength=14, decimal=2 |
| 6 | 货币 (Currency) | ✅ | maxLength, decimal, currency=true | 货币类型，额外设置 currency:true；可选 isMultiCurrency:true 支持多货币 |
| 7 | 日期 (Date) | ✅ | — | — |
| 9 | 自动编号 (AutoNumber) | ✅ | dataFormat | 仅用于实体主字段（nameItem） |
| 10 | 关联关系 (Reference) | ✅ | referObjectApiKey, cascadeDelete, linkLabel | cascadeDelete: 0=级联删除, 1=置空, 2=不允许删除; linkLabel 为关联显示名 |
| 10 | 主子明细 (Detail) | ✅ | referObjectApiKey, cascadeDelete, linkLabel, detailLink=true | 同关联关系，额外设置 detailLink:true 表示主子明细 |
| 21 | 日期时间 (DateTime) | ✅ | — | — |
| 22 | 电话 (Phone) | ✅ | — | — |
| 23 | 邮箱 (Email) | ✅ | — | — |
| 24 | 网址 (URL) | ✅ | — | — |
| 26 | 引用 (Lookup) | ✅ | joinLinkItemApiKey + joinItemApiKey | 引用关联实体的字段值（只读） |
| 29 | 图片 (Image) | ✅ | maxLength | 图片最大数量 1-9，通过 maxLength 传入 |
| 31 | 布尔 (Boolean) | ✅ | — | — |
| 32 | 地理位置 (GeoLocation) | ✅ | — | — |
| 33 | 百分比 (Percentage) | ✅ | maxLength, decimal | — |
| 34 | 多态关联 (PolyReference) | ✅ | multiReferObjectIds | 多态关联，支持关联多种实体 |
| 39 | 文件 (File) | ✅ | maxLength | 文件最大数量 1-9，通过 maxLength 传入，默认 9 |
| 40 | 富文本 (RichText) | ✅ | maxLength | — |
| 41 | 多值关联 (MultiValueReference) | ✅ | referObjectId | 多对多关联 |

**不支持 API 创建的字段类型**（需在 CRM 后台手动创建）：
- 计算字段（itemType=27）
- 汇总累计（itemType=28）

**已废弃的旧编号**（均返回"itemType 不在合法范围内"，请使用新编号）：
- itemType=8（日期时间旧）→ 使用 itemType=21
- itemType=11（百分比旧）→ 使用 itemType=33
- itemType=13（复选框旧）→ 使用 itemType=31
- itemType=15（邮箱旧）→ 使用 itemType=23
- itemType=16（电话旧）→ 使用 itemType=22
- itemType=17（网址旧）→ 使用 itemType=24
- itemType=20（图片旧）→ 使用 itemType=29

**命名规范校验**：
- 字段 API Key 只能包含下划线、字母和数字，不能以数字开头
- 自定义字段 API Key 必须以 `__c` 结尾
- 同一实体内字段 API Key 不能重复

**执行方式**：

**执行方式**：

```
POST /rest/metadata/v3.1/xobjects/{apiKey}/items
Authorization: Bearer {access_token}

{
  "apiKey": "projectStatus",
  "label": "项目状态",
  "itemType": 3,
  "description": "项目当前状态",
  "pickOption": [
    {"optionLabel": "进行中", "optionCode": 1},
    {"optionLabel": "已完成", "optionCode": 2},
    {"optionLabel": "已取消", "optionCode": 3}
  ]
}
```

> 注意：apiKey 无需手动添加 `__c` 后缀，系统自动追加。optionCode 为 Integer 类型。

**关联关系字段（itemType=10）创建示例**：

```
POST /rest/metadata/v3.1/xobjects/{entityApiKey}/items
Authorization: Bearer {access_token}

{
  "apiKey": "relatedAccount",
  "label": "关联客户",
  "itemType": 10,
  "referObjectApiKey": "account",
  "cascadeDelete": 1,
  "linkLabel": "关联客户"
}
```

参数说明：
- `referObjectApiKey`：目标实体的 apiKey（必填，系统自动解析 objectId）
- `cascadeDelete`：级联删除规则 — 0=级联删除，1=清理（置空），2=不允许删除
- `linkLabel`：在目标实体的相关列表中显示的名称

**主子明细字段（itemType=10 + detailLink=true）创建示例**：

主子明细是关联关系的强化版本，子记录必须属于某个父记录，父记录删除时子记录级联删除。创建方式与关联关系相同，额外设置 `detailLink: true`。

```
POST /rest/metadata/v3.1/xobjects/{entityApiKey}/items
Authorization: Bearer {access_token}

{
  "apiKey": "courseId",
  "label": "所属课程",
  "itemType": 10,
  "referObjectApiKey": "TrainingCourse__c",
  "cascadeDelete": 0,
  "linkLabel": "培训签到",
  "detailLink": true
}
```

参数说明：
- `detailLink`：是否为主子明细关联。`true`=主子明细（子记录强依赖父记录），`false`或不传=普通关联
- 主子明细关系下，`cascadeDelete` 通常设为 `0`（级联删除），即父记录删除时子记录一并删除
- 其余参数与普通关联关系一致

**查找字段（itemType=26）创建示例**：

查找字段用于引用关联实体的某个字段值（只读），前提是本实体上已存在一个关联关系字段。

```
POST /rest/metadata/v3.1/xobjects/{entityApiKey}/items
Authorization: Bearer {access_token}

{
  "apiKey": "accountName",
  "label": "客户名称",
  "itemType": 26,
  "joinLinkItemApiKey": "relatedAccount__c",
  "joinItemApiKey": "accountName"
}
```

参数说明：
- `joinLinkItemApiKey`：本实体上关联关系字段的 apiKey（必须是已存在的 itemType=10 字段）
- `joinItemApiKey`：目标实体上要引用的字段 apiKey
- 系统会自动根据 joinLinkItemApiKey 解析出 joinLink、joinObject，再根据 joinItemApiKey 获取 joinItem

也可以直接使用数字 ID（适合已知 ID 的场景）：

```json
{
  "apiKey": "accountName",
  "label": "客户名称",
  "itemType": 26,
  "joinLink": 2001,
  "joinObject": 1,
  "joinItem": 10001
}
```

> 推荐使用 apiKey 方式（joinLinkItemApiKey + joinItemApiKey），无需提前查询数字 ID。

**批量创建场景**：
- 如果用户一次描述了多个字段，整理为字段清单表格，让用户确认后逐个创建
- 每个字段创建后记录结果（成功/失败+原因）
- 全部完成后刷新本地字段定义

#### 2.5 更新字段

用户想修改已有字段的属性时执行。

**可更新属性**：label、description、helpText、defaultValue、maxLength、decimal、dataFormat、cascadeDelete

**不可更新**：字段类型（itemType）一旦创建不可修改。如需变更类型，需删除后重建（V1 不支持删除，需在后台手动操作）。

**执行方式**：

**执行方式**：

```
PATCH /rest/metadata/v3.1/xobjects/{apiKey}/items/{itemApiKey}
Authorization: Bearer {access_token}

{
  "label": "新的字段名称",
  "description": "更新后的描述"
}
```

---

### 三、数据模型设计辅助

当用户在方案设计阶段需要规划数据模型时，本技能包提供以下辅助能力：

#### 3.1 实体模型评估

基于用户的业务需求，评估现有实体能否满足：

1. 读取 `AllxObjects.md` 了解已有实体
2. 读取相关实体的字段定义
3. 输出评估结论：

| 实体 | API Key | 操作 | 说明 |
|:---|:---|:---|:---|
| 客户 | account | 复用 | 已有，无需修改 |
| 商机 | opportunity | 扩展 | 需新增 customField__c 字段 |
| 项目 | project__c | 新建 | 不存在，需创建 |

#### 3.2 字段类型选型建议

根据用户描述的业务含义，推荐合适的字段类型：

| 业务含义 | 推荐类型 | 理由 |
|:---|:---|:---|
| 状态、阶段 | 单选(3) | 固定选项，互斥 |
| 标签、特征 | 多选(4) | 可多选 |
| 金额、价格 | 货币(6+currency) | 支持货币格式，可选多货币 |
| 小数、比率 | 小数(6) | 纯数值，无货币符号 |
| 关联其他实体 | 关联关系(10) | 建立实体间引用，支持 API 创建 |
| 父子强关联（子记录必须属于父记录） | 主子明细(10+detailLink) | 同关联关系，设置 detailLink:true |
| 是/否 | 布尔(31) | 布尔值 |
| 由其他字段计算得出 | 计算字段(27) | 自动计算，不可手动编辑 |
| 唯一编号 | 自动编号(9) | 系统自动生成 |

---

## 命名约束

### 实体命名规范

| 规则 | 说明 | 示例 |
|:---|:---|:---|
| 自定义实体以 `__c` 结尾 | 平台强制要求 | `project__c` |
| 驼峰命名（camelCase） | 首字母小写 | `orderItem__c` |
| 只能包含字母、数字、下划线 | 不能以数字开头 | ✅ `task__c` ❌ `1task__c` |
| 不能使用保留字 | 见下方列表 | ❌ `select__c` |

### 字段命名规范

| 规则 | 说明 | 示例 |
|:---|:---|:---|
| 自定义字段以 `__c` 结尾 | 平台强制要求 | `projectStatus__c` |
| 驼峰命名（camelCase） | 首字母小写 | `closeDate__c` |
| 同一实体内不能重复 | API Key 唯一 | — |

### 保留字（不可用作 API Key）

以下词汇不能用作实体或字段的 API Key：
- SQL 关键字：`select`, `from`, `where`, `limit`, `order`, `group`, `having`, `join`, `insert`, `update`, `delete`
- 系统字段：`id`, `name`, `createdAt`, `updatedAt`, `createdBy`, `updatedBy`, `ownerId`, `deleteFlag`
- 平台保留：`type`, `status`, `data`, `result`, `code`, `msg`

---

## 平台 API 参考

所有 API 携带 `Authorization: Bearer <access_token>`。Token 和 API 基础地址从项目目录下 `.neo-cli/token.json` 读取。

> 注意：Metadata API v3.1 的基础路径为 `/rest/metadata/v3.1/xobjects/`。
> 完整的请求示例见 [references/metadata-api-postman.json](references/metadata-api-postman.json)（Postman 集合，可直接导入测试）。

### 查询 API（已可用）

| API | 方法 | 路径 | 说明 |
|:---|:---|:---|:---|
| 实体列表 | GET | `/rest/metadata/v2.0/xobjects/filter?custom=<true\|false>&active=true` | 按标准/自定义过滤 |
| 实体字段 | GET | `/rest/metadata/v2.0/xobjects/<apiKey>/items` | 获取实体所有字段 |
| 业务类型列表 | GET | `/rest/data/v2.0/xobjects/<apiKey>/busiType` | 获取实体的业务类型 |

### 写入 API（v3.1）

| API | 方法 | 路径 | 说明 |
|:---|:---|:---|:---|
| 创建实体 | POST | `/rest/metadata/v3.1/xobjects/` | 创建自定义实体 |
| 更新实体 | PATCH | `/rest/metadata/v3.1/xobjects/{apiKey}` | 更新实体属性 |
| 创建字段 | POST | `/rest/metadata/v3.1/xobjects/{apiKey}/items` | 创建单个字段 |
| 更新字段 | PATCH | `/rest/metadata/v3.1/xobjects/{apiKey}/items/{itemApiKey}` | 更新字段属性 |
| 创建业务类型 | POST | `/rest/metadata/v3.1/xobjects/{apiKey}/busiTypes` | 创建业务类型 |
| 更新业务类型 | PATCH | `/rest/metadata/v3.1/xobjects/{apiKey}/busitypes/{busiTypeApiKey}` | 更新业务类型 |
| 查询关联关系 | GET | `/rest/metadata/v3.1/xobjects/relationships` | 查询所有实体间关联关系 |

> 写入 API 需要用户职能开启「Metadata API」功能点。沙盒环境默认可用，生产环境需向 NeoCRM 申请开通。
> 所有创建接口支持幂等：同名 apiKey 已存在时返回已有资源信息，不会创建重复数据。
> apiKey 无需手动添加 `__c` 后缀，系统自动追加。

---

## 验证清单

每次执行实体/字段操作后，检查以下项目：

### 查询操作
- [ ] 实体 API Key 在 AllxObjects.md 中存在
- [ ] 字段 API Key 与 `<apiKey>.md` 中的定义一致
- [ ] 关联字段的目标实体确实存在

### 创建实体
- [ ] API Key 符合命名规范（驼峰 + `__c` 后缀）
- [ ] API Key 不是保留字
- [ ] 主字段类型正确（文本或自动编号）
- [ ] 自动编号时 dataFormat 已填写
- [ ] 创建后已刷新本地实体列表
- [ ] 创建后已拉取新实体字段定义

### 创建字段
- [ ] 目标实体存在
- [ ] 字段 API Key 符合命名规范（驼峰 + `__c` 后缀）
- [ ] 字段 API Key 在该实体中不重复
- [ ] 字段类型编号正确
- [ ] 类型特定参数已填写（单选的选项、关联的目标实体等）
- [ ] 创建后已刷新本地字段定义

### 创建业务类型
- [ ] 目标实体已启用业务类型功能
- [ ] 业务类型 API Key 不重复
- [ ] 创建后 API Key 自动追加了 `__c`

---

## 常见问题排查

| 问题 | 原因 | 解决方式 |
|:---|:---|:---|
| 代码中字段名报错 | 字段 API Key 拼写错误 | 用 gen_entity_desc.py 拉取真实字段定义 |
| SQL 查询返回空结果 | 实体 API Key 错误 | 在 AllxObjects.md 中确认正确的 API Key |
| 日期查询无结果 | 使用了日期字符串而非时间戳 | 改用毫秒时间戳，如 `closeDate >= 1711900800000` |
| 创建字段返回 409 | 字段 API Key 已存在 | 换一个 API Key 或先查询确认 |
| 创建实体返回 403 | 无元数据 API 权限或环境未开通 | 检查职能权限配置；生产环境需申请开通 |

---

## 跨技能包委托

| 需求 | 委托给 |
|:---|:---|
| 需要编写后端代码（Trigger/API/Job） | neo-backend-dev |
| 需要开发前端组件 | neo-frontend-dev |
| 需要做完整的方案设计 | neo-solution-design |
| 需要总结本次操作 | neo-task-summary |


---

## 待支持功能

以下功能在规划中，待平台 API 就绪后实现：

| 功能 | 状态 | 说明 |
|:---|:---:|:---|
| 校验规则管理 | 📋 待 API 就绪 | 创建/管理实体的条件表达式校验规则（如"战略客户行业必填"） |
| 查重规则管理 | 📋 待 API 就绪 | 创建/管理实体的自动查重配置（如"按客户名称+手机号查重"） |
| 实体关联关系查询（被关联方向） | ⚠️ 部分支持 | 当前仅支持正向关联查询，被关联方向需遍历多个实体，待优化 |

在 API 就绪前，如果用户需要配置校验规则或查重规则，引导用户在 CRM 后台手动操作：
- 校验规则：系统后台 → 对象管理 → 选择实体 → 校验规则
- 查重规则：系统后台 → 对象管理 → 选择实体 → 查重规则

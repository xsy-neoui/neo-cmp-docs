---
name: neo-theme-skill
description: 当用户要求项目支持 Neo 主题换肤功能时触发。将 Neo 平台历史项目中的硬编码色值、旧版 CSS 变量、按钮样式改造为支持运行时主题换肤的标准写法。覆盖三大核心任务：① 硬编码色值替换为 CSS 变量；② 旧版 CSS 变量迁移为新版变量名；③ primary 模式按钮色改造为按钮色 CSS 变量。每次执行需按顺序完成全部三项任务，最终生成 Neo主题换肤功能升级报告.md。触发关键词：项目支持Neo主题换肤功能、项目支持主题换肤、Neo主题换肤功能升级、Neo主题换肤升级、主题换肤功能升级、主题换肤升级、项目换肤升级。
---

# Neo 平台主题换肤功能升级技能

将 Neo 平台历史项目的硬编码色值、旧版 CSS 变量、按钮样式，改造为支持运行时主题换肤的标准写法。

## 触发条件

当用户提出以下需求时启动本技能：

- **"让项目支持 Neo 主题换肤功能"**
- "项目支持 Neo 主题换肤功能升级"
- "项目主题换肤升级"
- "Neo 主题换肤功能升级"

> 本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

---

## 一、Neo 平台主题换肤机制概述

Neo 平台基于 **CSS 变量 + TokenHelper 运行时引擎** 实现主题换肤，核心设计要点：

1. **Hex 主变量 + -rgb 伴侣变量双输出**：`--brand-color: #0564f5` + `--brand-color-rgb: 5, 100, 245`
2. **品牌色、按钮色、导航色三套独立体系**，通过 `TokenHelper.setBaseColor()` / `setButtonPrimaryColor()` / `setNavBannerColor()` 分别控制
3. **组件通过 `var(--xxx)` 消费 CSS 变量**，运行时主题切换自动生效

### 核心原则

- ✅ 所有品牌相关颜色必须使用 CSS 变量
- ❌ 禁止硬编码品牌色 hex/rgb 值
- ❌ 禁止从 `ColorsConfig` 读取颜色后以内联 `style={{}}` 写入

---

## 二、升级任务总览

每次执行本技能，**必须按顺序**完成以下四项任务：

### 任务清单

| 步骤 | 任务 | 说明 |
|:--|:--|:--|
| **1** | 硬编码色值 → CSS 变量替换 | 遍历源码，将品牌相关硬编码色值替换为 `var(--xxx)`；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有硬编码色值均已替换** |
| **2** | 旧 CSS 变量 → 新 CSS 变量迁移 | 包含两类：① 将带 `-bg` 后缀的旧按钮变量名替换为新变量名；② 将旧版导航色变量（`--dayone-theme-header-*`）替换为新版导航色变量（`--brand-nav-header-*`） |
| **3** | Primary 按钮色改造 | 按背景色白/非白区分规则，替换为按钮色变量；**完成后须执行遗漏检测，存在遗漏则自动重试，直到所有 primary 按钮背景色均已改造** |
| **4** | 生成主题换肤功能升级报告 | **前三项任务全部完成后**，**依据当前项目代码的实际改动**（`git diff` / `git status`）汇总所有改动，生成 `Neo主题换肤功能升级报告.md`（详见「任务 4」章节） |

> ⚠️ **报告生成时机与依据**：任务 1 ~ 任务 3 执行过程中可临时记录改动明细，但**最终报告必须在全部任务执行完成后**、依据**当前项目代码的实际改动**统一生成，确保报告内容与仓库真实 diff 一致，而非仅凭执行过程中的记忆或中间记录。

---

## 三、任务 1：硬编码色值替换

> 🚨 **匹配规则总则（Task 1 强制前置条件，最高优先级，先于所有要求）**：
>
> 1. **优先完全匹配**：源代码中的硬编码色值与 3.1 替换规则对照表列出的色值**逐字符完全匹配**（大小写不敏感）时 → 直接命中并按对应规则替换，无需报告标记。
> 2. **允许近似色匹配（唯一基准 `#0564f5`，1-2 色阶差）**：源代码中的色值虽未在 3.1 完全匹配表中列出，但与**主品牌基准色 `#0564f5`（rgb(5, 100, 245)）差异极小（≤ 2 色阶）**时 → 推断为主品牌色的近似变体，统一替换为 `var(--brand-color)`（含透明度时用 `var(--brand-color-rgb)`）。**近似匹配只与 `#0564f5` 这一个基准比较，不与表中其他任何色值比较**（表中其余色值仅参与「完全匹配」）。此时**必须**在报告中标记 `[近似匹配]`，供人工复核。近似色的精确定义与阈值详见 **3.1.2 近似色匹配规则**。
> 3. **超阈值一律不替换**：源色值与基准色 `#0564f5` 的差异超出近似阈值（单通道 > 32 或欧氏距离 > 50）→ **不视为近似色**，必须保留原样。
> 4. **禁止基于色名自动扩展**：**不得**基于色名、变量名（含 `primary`、`blue`）或代码上下文自行推断替换目标；替换必须由色值本身的匹配结果（完全匹配 或 与 `#0564f5` 的 1-2 色阶近似匹配）驱动。
> 5. **8 位十六进制的特殊匹配规则**：8 位色值 `#RRGGBBAA` 的**前 6 位** `#RRGGBB` 若按上述规则 1 或 2 命中即视为命中，具体规则见下方 **3.1.1 8 位十六进制色值（含透明度）匹配规则**。
> 6. **rgb / rgba 数值格式**：`rgb(r, g, b)` / `rgba(r, g, b, a)` 的三个数字若与表中某色值完全相等（允许逗号后空格差异）→ 完全匹配；否则**仅与基准色 `#0564f5 = rgb(5, 100, 245)`** 按 3.1.2 的 `Δ_ch` / `d` 双阈值判定是否为近似色（不再使用「±16」这类粗略说法，一律以双阈值为准）。
> 7. **近似匹配必须在报告中单独标记**：所有非完全匹配（即近似匹配）替换都要在 `Neo主题换肤功能升级报告.md` 中单列，附源色值、匹配基准、色阶差、替换目标，供人工复核。
>
> ⚠️ 违反上述总则（例如将差异超过 2 色阶的色值当作品牌色替换）属于**错误改动**，必须在报告中回滚并标记。

### 3.0 强制防护方案（Task 1 最高优先级，先于替换执行）

> 🛡️ **本节为 Task 1 的强制防护流程，优先级高于 3.1 之后的所有替换动作。**
> 任何色值匹配行在被替换前，**必须**先完整跑完本节的两道防护，任一防护判定为「跳过」即终止该行的替换。

#### 防护 1：强制「先判定后替换」流程（6 项跳过检查全部通过才允许替换）

对**每一个**色值匹配行，必须**先跑完全部 6 项跳过检查**，确认该行不属于任一跳过场景后，**才允许**进入替换决策。**6 项检查的执行顺序固定、不可打乱、不可跳步**：

```
匹配行
  ↓
检查 1：类名 / 变量名含色值？（要求 1）
         如 text-[#0564f5]、bg-[#4e80f5] → 跳过
  ↓ 未命中
检查 2：测试文件？（要求 3）
         *.test.*、*.spec.*、__tests__/ → 跳过
  ↓ 未命中
检查 3：已注释行？（要求 3）
         以 // 或 /* 开头、或被 /* */ 包裹的行 → 跳过
  ↓ 未命中
检查 4：blue 类选择器回溯？（要求 4 补充）
         向上回溯所在 CSS 规则块（含多行、SCSS/Less 嵌套、& 拼接），
         任一层祖先选择器 class 名含 blue（大小写不敏感）→ 跳过
  ↓ 未命中
检查 5：ECharts / 颜色数组 / var() 回退值 / 取色器对象？（要求 4 场景 ②③④⑦）
         ECharts option 属性值（须读取完整文件上下文、向上回溯到最外层 option 对象，
           满足任一即成立：①任意层级命中 series:[{type:'bar'/'line'/'pie'...}]、
           xAxis、yAxis、legend、grid、tooltip、visualMap、dataZoom 等专有属性；
           ②祖先 key 链含 ECharts 专有 key（如 legend.pageIconColor）；
           ③经 define()/export default/module.exports/return 导出、
           顶层含 ≥2 个 ECharts 顶层 option 键的独立配置模块——
           即使不 import echarts、不用 <ReactECharts>、变量不叫 option 也算；
           判定细则见 要求 4 补充「ECharts 判定细则」）、
         ['#0564f5', ...] 数组字面量、
         var(--x, #0564f5) 回退值、
         纯色值对象（对象内所有属性值均为 hex/rgb/rgba）→ 跳过
  ↓ 未命中
检查 6：SASS / Less 变量名含 blue（要求 4 场景 ⑤⑥）？
         $blue-base、@blue-6 等变量定义 → 跳过
  ↓ 全部 6 项均未命中
✅ 全部通过 → 才允许进入替换决策（按 3.1 / 3.1.1 / 3.1.2 规则替换）
```

**执行铁律**：

- **顺序不可乱**：必须严格按 检查 1 → 检查 2 → 检查 3 → 检查 4 → 检查 5 → 检查 6 的顺序执行；任一步命中即判为「合法跳过」，立即终止该行处理，**不再执行后续检查，也不得替换**。
- **不可跳步**：不允许因为「看起来像品牌色」就省略任何一项检查直接替换；替换决策必须建立在「6 项检查全部通过」这一前提之上。
- **命中即记录**：任一检查命中跳过时，须在 `Neo主题换肤功能升级报告.md` 的「跳过详情」表中记录文件、行号、色值、命中的检查项与跳过原因。
- **遗漏检测同样适用**：3.3.5 遗漏检测阶段对每个命中行也必须重新跑完这 6 项检查，全部通过者才判为「遗漏」并补替换。

#### 防护 2：已有 `// var(...)` 注释 ≠ 替换许可

> 🚫 **核心原则**：源码中已存在的 `// var(...)`（或 `/* var(...) */`）注释行，**只在检查 3（已注释行）中被当作「已注释行」跳过它自身**，它的存在**不构成**对同一规则块内其他活跃行的替换许可，也**不影响**其他活跃行独立走完 6 项检查的判定。

- **注释行只跳过它自己**：一行 `// background-color: #0564f5;` 之类的注释，只在检查 3 命中并被跳过；它**不代表**该样式块「已改造完成」或「已被授权替换」。
- **不得据此放行同块其他行**：同一 CSS 规则块 / 同一组件内的其他**活跃（未注释）色值行**，仍须各自独立、完整地跑完防护 1 的 6 项检查，**不能**因为块内已存在某个 `// var(...)` 注释就跳过判定或直接替换。
- **不得据此反向替换注释行**：已注释行本身保持原样，不因块内有活跃行被替换而被「反向激活」或重复处理（另见 10.2 注释行被重复替换）。
- **判定相互独立**：注释行的跳过（检查 3）与活跃行的替换决策是两条互不影响的判定路径；每一行的命运由它自己的 6 项检查结果决定。

**示例（注释行的存在不影响同块活跃行独立判定）**：

```scss
// 场景：块内已有一行 // var(...) 注释，但块内仍有活跃硬编码行
.panel {
  // color: #0564f5;              // ← 已注释行：检查 3 命中 → 只跳过它自己
  color: var(--brand-color);      // ← 已是 var()，无需处理

  border-color: #0564f5;          // ← 活跃行：不因上方存在 // var(...) 就被放行，
                                  //    仍须独立跑完 6 项检查，全部通过后才替换
}
```

上例中，上方的 `// color: #0564f5;` 注释**不授予**下方 `border-color: #0564f5;` 任何替换许可；`border-color` 行必须自己走完检查 1~6，确认非跳过场景后才替换为 `var(--brand-color)`。

### 3.1 替换规则对照表

#### 主品牌色 → `var(--brand-color)`

```
#0564f5  → var(--brand-color)
#0564F5  → var(--brand-color)
rgb(5, 100, 245)  → var(--brand-color)
rgb(5,100,245)    → var(--brand-color)

#096dd9  → var(--brand-color)
#096DD9  → var(--brand-color)
rgb(9, 109, 217)  → var(--brand-color)
rgb(9,109,217)    → var(--brand-color)

#2065cf  → var(--brand-color)
#2065CF  → var(--brand-color)
rgb(32, 101, 207) → var(--brand-color)
rgb(32,101,207)   → var(--brand-color)

#1d77ff  → var(--brand-color)
#1D77FF  → var(--brand-color)
rgb(29, 119, 255) → var(--brand-color)
rgb(29,119,255)   → var(--brand-color)

// Ant Design v5 主色
#1677ff  → var(--brand-color) 
#1677FF  → var(--brand-color)
rgb(22, 119, 255) → var(--brand-color)
rgb(22,119,255)   → var(--brand-color)

#0052d9  → var(--brand-color)
#0052D9  → var(--brand-color)
rgb(0, 82, 217) → var(--brand-color)
rgb(0,82,217)   → var(--brand-color)

#2b7fff  → var(--brand-color)
#2B7FFF  → var(--brand-color)
rgb(43, 127, 255) → var(--brand-color)
rgb(43,127,255)   → var(--brand-color)

#0060df  → var(--brand-color)
#0060DF  → var(--brand-color)
rgb(0, 96, 223) → var(--brand-color)
rgb(0,96,223)   → var(--brand-color)

#1a7aff  → var(--brand-color) 
#1A7AFF  → var(--brand-color)
rgb(26, 122, 255) → var(--brand-color)
rgb(26,122,255)   → var(--brand-color)

// 实战补充：与基准 #0564f5 相差 1-2 色阶、历史项目高频出现的硬编码变体，
// 原应由近似匹配命中，因近似色无法被固定 grep 捞出而漏网，升级为完全匹配
#257cff  → var(--brand-color)
#257CFF  → var(--brand-color)
rgb(37, 124, 255) → var(--brand-color)
rgb(37,124,255)   → var(--brand-color)

#0656d5  → var(--brand-color)
#0656D5  → var(--brand-color)
rgb(6, 86, 213) → var(--brand-color)
rgb(6,86,213)   → var(--brand-color)

// Bootstrap 主蓝
#007bff  → var(--brand-color)
#007BFF  → var(--brand-color)
rgb(0, 123, 255) → var(--brand-color)
rgb(0,123,255)   → var(--brand-color)

#2468f2  → var(--brand-color)
#2468F2  → var(--brand-color)
rgb(36, 104, 242) → var(--brand-color)
rgb(36,104,242)   → var(--brand-color)

#1c61da  → var(--brand-color)
#1C61DA  → var(--brand-color)
rgb(28, 97, 218) → var(--brand-color)
rgb(28,97,218)   → var(--brand-color)

#1865d9  → var(--brand-color)
#1865D9  → var(--brand-color)
rgb(24, 101, 217) → var(--brand-color)
rgb(24,101,217)   → var(--brand-color)

// Tailwind blue-600
#2563eb  → var(--brand-color)
#2563EB  → var(--brand-color)
rgb(37, 99, 235) → var(--brand-color)
rgb(37,99,235)   → var(--brand-color)

// Tailwind blue-700
#1d4ed8  → var(--brand-color)
#1D4ED8  → var(--brand-color)
rgb(29, 78, 216) → var(--brand-color)
rgb(29,78,216)   → var(--brand-color)

// amis cxd 主色
#047bdb  → var(--brand-color)
#047BDB  → var(--brand-color)
rgb(4, 123, 219) → var(--brand-color)
rgb(4,123,219)   → var(--brand-color)

#1758e7  → var(--brand-color)
#1758E7  → var(--brand-color)
rgb(23, 88, 231) → var(--brand-color)
rgb(23,88,231)   → var(--brand-color)

#007eff  → var(--brand-color)
#007EFF  → var(--brand-color)
rgb(0, 126, 255) → var(--brand-color)
rgb(0,126,255)   → var(--brand-color)

```

#### 次品牌色 → `var(--brand-color-hover)`

```
#4e80f5  → var(--brand-color-hover)
#4E80F5  → var(--brand-color-hover)
rgb(78, 128, 245) → var(--brand-color-hover)
rgb(78,128,245)   → var(--brand-color-hover)

#1890ff  → var(--brand-color-hover)
#1890FF  → var(--brand-color-hover)
rgb(24, 144, 255) → var(--brand-color-hover)
rgb(24,144,255)   → var(--brand-color-hover)

#40a9ff  → var(--brand-color-hover)
#40A9FF  → var(--brand-color-hover)
rgb(64, 169, 255) → var(--brand-color-hover)
rgb(64,169,255)   → var(--brand-color-hover)

#3886fb  → var(--brand-color-hover)
#3886FB  → var(--brand-color-hover)
rgb(56, 134, 251) → var(--brand-color-hover)
rgb(56,134,251)   → var(--brand-color-hover)

#238dff  → var(--brand-color-hover)
#238DFF  → var(--brand-color-hover)
rgb(35, 141, 255) → var(--brand-color-hover)
rgb(35,141,255)   → var(--brand-color-hover)

#3783ff  → var(--brand-color-hover)
#3783FF  → var(--brand-color-hover)
rgb(55, 131, 255) → var(--brand-color-hover)
rgb(55,131,255)   → var(--brand-color-hover)

// Ant Design v5 hover、Ant Design 浅蓝
#4096ff  → var(--brand-color-hover) 
#4096FF  → var(--brand-color-hover)
rgb(64, 150, 255) → var(--brand-color-hover)
rgb(64,150,255)   → var(--brand-color-hover)

#5b8ff9  → var(--brand-color-hover)
#5B8FF9  → var(--brand-color-hover)
rgb(91, 143, 249) → var(--brand-color-hover)
rgb(91,143,249)   → var(--brand-color-hover)

#69c0ff  → var(--brand-color-hover) 
#69C0FF  → var(--brand-color-hover)
rgb(105, 192, 255) → var(--brand-color-hover)
rgb(105,192,255)   → var(--brand-color-hover)

#4ca1dc  → var(--brand-color-hover)
#4CA1DC  → var(--brand-color-hover)
rgb(76, 161, 220) → var(--brand-color-hover)
rgb(76,161,220)   → var(--brand-color-hover)
```

### 3.1.1 8 位十六进制色值（含透明度）匹配要点

源码中的 **8 位十六进制色值** `#RRGGBBAA` 按以下要点处理，**完整规则、alpha 对照表与示例见 [references/color-matching-details.md](references/color-matching-details.md) 第一节**：

- 取**前 6 位** `#RRGGBB`（大小写不敏感）与 3.1 表比对；命中则替换，未命中保留原样。
- 命中时替换为 `rgba(var(--xxx-rgb), <alpha>)`，其中 `<alpha> = round(后2位hex / 255, 2)`。
- `AA = FF` → 直接用主变量 `var(--xxx)`；`AA = 00` → `rgba(var(--xxx-rgb), 0)`。
- 例：`#0564f533 → rgba(var(--brand-color-rgb), 0.2)`；`#123456ff → 保留原样`。
- 注释保留写法与要求 2 一致。

### 3.1.2 近似色匹配要点（仅以 `#0564f5` 为基准，1-2 色阶差自动推断替换）

源码色值虽未在 3.1 完全匹配表中列出，但与**唯一基准色 `#0564f5`（rgb(5, 100, 245)）差异极小（≤ 2 色阶）**时，推断为主品牌色近似变体，替换为 `var(--brand-color)`。**近似匹配只以 `#0564f5` 为基准，不与表中其他任何色值比较**——这样做是为了避免 3.1 表中十余个蓝色候选的近似邻域相互重叠，导致把并非品牌色的普通蓝色也误判替换。判定阈值如下，**8 位近似、注释写法、报告格式等完整规则见 [references/color-matching-details.md](references/color-matching-details.md) 第二节**：

设源色值与 `#0564f5` 的 `Δ_ch = max(|ΔR|,|ΔG|,|ΔB|)`、欧氏距离 `d = √(ΔR²+ΔG²+ΔB²)`，两者需**同时满足**区间：

| 相似度 | Δ_ch | d | 处理 |
|:--|:--|:--|:--|
| 完全匹配 | = 0 | = 0 | 直接替换，无需标记 |
| 1 色阶差 | ≤ 16 | ≤ 25 | 替换为 `var(--brand-color)` + 标记 `[近似匹配·1色阶]` |
| 2 色阶差 | ≤ 32 且 > 16 | ≤ 50 且 > 25 | 替换为 `var(--brand-color)` + 标记 `[近似匹配·2色阶]` |
| 超阈值 | > 32 | 或 > 50 | 保留原样，不替换 |

- **单一基准、无多候选歧义**：近似匹配的基准恒为 `#0564f5`，因此不存在多候选，也无需 Tiebreaker；近似命中一律替换为 `var(--brand-color)`（含透明度时用 `rgba(var(--brand-color-rgb), a)`）。
- 表中除 `#0564f5` 外的其余色值（含次品牌色）**只做完全匹配**，不参与近似判定。
- **近似匹配必须**在报告「近似匹配详情」表中单独记录并附注释标注，供人工复核。

> 🔧 **可选工具**：`scripts/neoThemeColorMatcher.js` 提供了与本节规则一致的可编程匹配引擎（完全匹配 30 色 + 仅对 `#0564f5` 的近似匹配），可用于批量脚本 / pre-commit / CI，用法见 [scripts/README.md](scripts/README.md)。

### 3.1.3 近似色执行缺口修补 —— 全量色值普查（必须执行）

> 🚨 **为什么必须有这一步**：近似匹配规则（3.1.2）本身是正确的，但它是**被动**的——只能对「已经被捞出来的可疑蓝色」做判定。而 SKILL 的实际扫描 / 遗漏检测 / 校验都依赖**固定 grep 命令**，命令里只枚举了完全匹配表中的确定色值；**近似色没有固定 grep 模式，永远不会被 grep 捞出，也就永远不会被送进近似判定**。

除按 3.1 完全匹配表逐色 grep 外，**必须**额外执行一次「全量蓝色普查」：抽取源码中**所有** hex / rgb(a) 色值，逐一交给匹配器（`matchBrandColor()` 或按 3.1.2 手工计算 Δ_ch / d）判定，surfacing 出所有与 `#0564f5` 差 1-2 色阶但不在完全匹配表中的近似色。

```bash
# 全量抽取所有 hex(6/8 位) 与 rgb/rgba 色值（去重），交由匹配器判定
grep -rhoE "#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?|rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}[^)]*\)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" --exclude-dir="dist" --exclude-dir="build" \
  | sort -u > /tmp/all-colors.txt
```

```bash
# 逐一喂给匹配器，打印所有近似命中（approximate*），供人工复核后替换
node -e '
const { matchBrandColor } = require("./skills/neo-theme-skill/scripts/neoThemeColorMatcher");
const fs = require("fs");
const colors = fs.readFileSync("/tmp/all-colors.txt", "utf8").split("\n").filter(Boolean);
for (const c of colors) {
  const r = matchBrandColor(c.trim());
  if (r.matchType && r.matchType.startsWith("approximate")) {
    console.log(`[近似·${r.shade}色阶] ${c.trim()} → ${r.output} (基准 ${r.baseHex}, Δ=${r.delta}, d≈${r.distance})`);
  }
}
'
```

对普查输出的每个近似命中：先按 3.0 防护 1 的 6 项跳过检查逐项判定，全部通过后按 3.1.2 规则替换为 `var(--brand-color)`（含透明度用 `var(--brand-color-rgb)`），并在报告「近似匹配详情」表中单独记录。若普查过程中反复出现某个高频近似色，应考虑将其反馈补充进 3.1 完全匹配表（如本次的 11 色）。

### 3.2 操作要求（共 8 条，按优先级从高到低排列，越靠前越优先执行）

> ⚠️ **优先级说明**：以下 8 条要求按优先级从高到低排列，序号越靠前优先级越高。
> **前 5 条（要求 1 ~ 要求 5）为最高优先级，必须严格优先执行到位**；后续要求（要求 6 ~ 要求 8）在前 5 条完全满足的前提下再执行。

#### 要求 1：变量名保护（跳过非硬编码色值）【最高优先级】

不要在以下情境替换：
- 类名/变量名中包含硬编码色值，如 `text-[#0564f5]`、`bg-[#4e80f5]` → **跳过**
- SASS/Less 变量名含 `blue` 关键字，如 `$blue-base: #096dd9`、`@blue-6: #1890ff` → **跳过**

#### 要求 2：注释保留原有写法【高优先级】

| 文件类型 | 注释方式 | 操作 |
|:--|:--|:--|
| `.scss` / `.less` | `//` | 注释掉原有行，在其下方新增替换行 |
| `.css` | `/* */` | 注释掉原有行，在其下方新增替换行 |
| `.tsx` / `.jsx` / `.ts` / `.js` | 不注释 | 直接替换，不保留原有写法 |

**示例（.scss）**：

```scss
// 替换前
.button {
  background-color: #0564f5;
}

// 替换后
.button {
  // background-color: #0564f5;
  background-color: var(--brand-color);
}
```

**示例（.css）**：

```css
/* 替换前 */
.button {
  background-color: #0564f5;
}

/* 替换后 */
.button {
  /* background-color: #0564f5; */
  background-color: var(--brand-color);
}
```

#### 要求 3：跳过测试文件和已注释行【高优先级】

- 跳过 `*.test.*`、`*.spec.*`、`__tests__/` 目录下的所有文件
- 跳过已注释行（以 `//` 或 `/*` 开头、或被 `/* */` 包裹的行）

#### 要求 4：多类场景跳过不替换【高优先级】

| 场景 | 判定方式 |
|:--|:--|
| ① 在注释中 | 色值位于注释内容中，非有效代码 → 跳过 |
| ② ECharts 属性 | 色值作为 echarts option 的属性值 → **跳过**（ECharts 需使用 `getCssVarHex()` 方案）。⚠️ **不能只看单行属性名**（如 `color:` / `borderColor:`）就判定，**必须读取完整文件上下文、向上回溯到最外层 option 对象**：满足以下任一即成立 —— ①任意层级命中 `series`、`xAxis`、`yAxis`、`legend`、`grid`、`visualMap`、`dataZoom` 等专有属性；②祖先 key 链含 ECharts 专有 key（如 `legend.pageIconColor`）；③经 `define()` / `export default` / `module.exports` / `return` 导出、顶层含 ≥2 个 ECharts 顶层 option 键的独立配置模块（**即使不 import echarts、不用 `<ReactECharts>`、变量不叫 option 也算**）。判定细则见 要求 4 补充「ECharts 判定细则」 |
| ③ 颜色数组中 | 色值位于数组字面量内，如 `['#0564f5', '#4e80f5']` → 跳过 |
| ④ var() 默认值 | 作为 `var()` 的回退值，如 `var(--custom-color, #0564f5)` → 跳过 |
| ⑤ class / 变量名含 blue | class 名中包含 `blue` 关键字 → 跳过 |
| ⑥ SASS/Less 变量名含 blue | 变量名中包含 `blue` 关键字（如 `$blue-base`、`@blue-6`），其对应的硬编码色值也 → 跳过 |
| ⑦ 取色器对象 | 色值作为对象的属性值存在，且该对象**所有其他属性值也都是色值**（hex / rgb / rgba）→ 认定为取色器（调色板）对象，其中所有硬编码色值 → **跳过**（判定方式见 要求 4 补充「取色器对象保护规则」） |

##### 要求 4 补充：ECharts 判定细则（场景 ② 判定细则）

> 🚫 **失效根因**：ECharts option 里常见的属性名（`color`、`borderColor`、`backgroundColor`、`lineStyle`、`itemStyle`、`textStyle` 等）与普通 CSS-in-JS / 内联样式的属性名高度重合。若**只看色值所在的单行或就近几行**，很容易把真正的 ECharts 色值漏判（未跳过而误替换），也可能把普通内联样式误判成 ECharts。因此**不允许仅凭单行属性名**做 ECharts 判定。

**判定铁律：必须读取完整文件上下文，向上回溯到「最外层 option 对象」再判定。**

> 🔑 **回溯不能只看色值所在的最近一层 `{}`**。ECharts 色值往往深埋在嵌套结构里（如 `legend.pageIconColor`、`xAxis.axisLabel.color`、`series[].itemStyle.color`）。若只检查色值最近的那层对象的同级属性，很可能因为该层同级属性（如 `legend` 内的 `show` / `data`）都不是强特征而漏判。因此**回溯必须一路向上，直到当前对象字面量最外层的顶层对象**（即被 `return {...}` / `export default {...}` / `module.exports = {...}` / `const option = {...}` / 传入图表 API 的那个根对象），并沿途记录**祖先 key 链**。

对每个命中色值行，执行两段回溯并做三类匹配：

**① 结构回溯**：从命中行一路向上，直到最外层对象字面量的起始 `{`，同时记录它被赋值的变量声明、函数返回、`define()` / `export default` / `module.exports` / 传参位置。

**② 三类匹配（命中任一即判定为 ECharts option，其内所有硬编码色值一律跳过 / 不替换 / 不计入残留）**：

**匹配 A — 强特征属性（顶层或任意层级出现任一即成立）**：

- `series: [{ type: 'bar' | 'line' | 'pie' | 'scatter' | 'radar' | 'map' | 'gauge' | 'funnel' | 'candlestick' | 'heatmap' | 'graph' | 'tree' | 'treemap' | 'sunburst' | 'boxplot' | 'themeRiver' | 'lines' | 'effectScatter' | 'pictorialBar' | ... }]`（`series` 数组内元素含 `type` 图表类型）
- `xAxis` / `yAxis` / `radiusAxis` / `angleAxis` / `singleAxis`（含 `axisLine`、`axisLabel`、`axisTick`、`axisPointer`、`splitLine`、`splitArea`、`nameTextStyle`、`boundaryGap`、`scale` 等子属性）
- `legend`（图例，含 ECharts 专有子属性 `pageIconColor`、`pageIconInactiveColor`、`pageTextStyle`、`inactiveColor`、`selectedMode` 等）
- `grid`（直角坐标系网格）
- `tooltip`（且与 `series` / 坐标轴同级，含 `axisPointer`、`confine`、`extraCssText`、`formatter` 等，属图表提示框而非普通 UI）
- `dataZoom`、`visualMap`（含 `inRange`、`outOfRange`、`calculable`、`pieces`）、`polar`、`radar`、`geo`、`parallel`、`toolbox`、`brush`、`graphic`、`timeline`、`calendar`、`dataset`、`title`（与上述任一并存的图表标题）（ECharts 专有顶层配置）

**匹配 B — 祖先 key 链（色值对象挂在某个 ECharts 专有 key 之下即成立）**：沿 ① 记录的祖先 key 链，只要某一层的 key 名属于上述强特征 key（`series` / `xAxis` / `yAxis` / `legend` / `grid` / `tooltip` / `visualMap` / `dataZoom` / `polar` / `radar` / `geo` / `toolbox` / `graphic` / `title` / `axisLine` / `axisLabel` / `splitLine` / `itemStyle` / `lineStyle` / `areaStyle` / `nameTextStyle` / `emphasis` 等），即判定色值处于 ECharts option 内。例如 `#4E80F5` 位于 `legend.pageIconColor`，其祖先 key 链含 `legend` → 命中。

**匹配 C — 独立 ECharts 配置模块（整文件/整对象识别）**：当某个对象字面量作为**模块级配置**被导出或返回，且其**顶层键中同时出现 ≥ 2 个 ECharts 顶层 option 键**（`title` / `grid` / `legend` / `xAxis` / `yAxis` / `series` / `tooltip` / `visualMap` / `dataZoom` / `polar` / `radar` / `geo` / `toolbox` / `angleAxis` / `radiusAxis` / `dataset` 等）时，**整个对象判定为 ECharts option**，其内所有硬编码色值全部跳过。此判定**不依赖**是否 `import echarts`、是否用 `<ReactECharts>`、变量是否叫 `option`。常见导出/返回形态：

- `define(function(require, exports, module) { return { title, grid, legend, xAxis, yAxis, series, ... }; })`（AMD 模块）
- `export default { ... }` / `export const chartOption = { ... }`
- `module.exports = { ... }`
- `return { ... }`（工厂函数 / `getOption()` 返回图表配置）

**辅助特征（可提升置信度，但不单独作为判定依据）**：

- 变量 / 参数名为 `option`、`chartOption`、`echartsOption`、`getOption()` 返回值等；
- 该色值最终传入 `<ReactECharts option={...} />`、`echarts.init(...).setOption(...)`、`myChart.setOption(...)`；
- 文件顶部 `import` 了 `echarts` / `echarts-for-react` / `@ant-design/charts` 等图表库；
- 文件名 / 路径含 `chart`、`echart`、`option`、`bi` 等图表语义。

**判定流程**：

```
命中色值行（属性名疑似图表色，如 color/itemStyle/lineStyle/pageIconColor...）
  ↓
向上回溯到「最外层」对象字面量起始 {，并记录祖先 key 链 + 变量声明 / 函数返回 / define/export/传参位置
  ↓
匹配 A：任意层级出现强特征属性（series[].type / xAxis / yAxis / legend / grid / dataZoom / visualMap ...）？
匹配 B：祖先 key 链含 ECharts 专有 key（legend / series / xAxis / itemStyle ...）？
匹配 C：最外层对象顶层键含 ≥ 2 个 ECharts 顶层 option 键，且经 define/export/module.exports/return 导出或返回？
  ├─ 任一命中 → 判定为 ECharts option → 跳过（辅助特征仅增强置信度）
  └─ 全否 → 不足以判定为 ECharts → 回到防护 1 其余检查（取色器对象 ⑦ / 数组 ③ / var 回退 ④ 等）逐一判定
```

```js
// ✅ 匹配 C：AMD 模块 return 一个含 title/grid/legend/xAxis/yAxis/series 等多顶层键的对象
//    → 整体判定为 ECharts option → 内部所有色值（含 #4E80F5、#182437、#6A7280）全部跳过
define(function (require, exports, module) {
  'use strict';
  return {
    title: { text: '气泡图', left: 16 },
    grid: { top: '10%' },
    legend: { show: true, pageIconColor: '#4E80F5' },   // 跳过（匹配 B：祖先 key legend / 匹配 C）
    visualMap: [{ type: 'continuous', inRange: { symbolSize: [10, 70] } }],
    tooltip: { textStyle: { color: '#182437' } },        // 跳过
    xAxis: { nameTextStyle: { color: '#6A7280' } },      // 跳过
    yAxis: { nameTextStyle: { color: '#6A7280' } },      // 跳过
    dataZoom: [{}, { disabled: true }],
    series: [{ type: 'scatter', data: [] }],
  };
});
```

```tsx
// ✅ 匹配 A / B：向上回溯命中 series[].type + xAxis + legend → 判定 ECharts option → 全部色值跳过
const option = {
  legend: { textStyle: { color: '#0564f5' } },   // 跳过（祖先 key legend）
  xAxis: { axisLine: { lineStyle: { color: '#4e80f5' } } },  // 跳过
  yAxis: {},
  series: [
    { type: 'bar', itemStyle: { color: '#0564f5' } },  // 跳过
  ],
};
return <ReactECharts option={option} />;

// ❌ 无任何 ECharts 强特征 / 祖先 key / 多顶层键，只是普通内联样式对象 → 不按 ECharts 跳过，回到其余检查
const style = { color: '#0564f5', padding: 8 };   // #0564f5 走取色器对象/常规替换判定
```

> **要点**：ECharts 判定的核心是「回溯到**最外层** option 对象 + 检查祖先 key 链 + 识别独立配置模块」，**读取完整文件上下文**是硬性前提。跨行、深层嵌套（`legend.pageIconColor`、`series[].itemStyle.color`、`xAxis.axisLabel.color` 等）绝不能只看最近一层 `{}` 的同级属性；配置模块（AMD `define` / `export default` / `module.exports` / 工厂函数 `return`）即使不 `import echarts`、不用 `<ReactECharts>`、变量不叫 `option`，也必须按匹配 C 整体跳过。该细则同样适用于 3.3.5 遗漏检测阶段，避免把 ECharts 色值误判为遗漏。

##### 要求 4 补充：取色器对象保护规则（场景 ⑦ 判定细则）

「调色板 / 色板 / 取色器」对象里的色值是**数据**而非**主题样式**，替换会破坏取值逻辑，须整体跳过。

**判定条件（同时满足才算取色器对象，其内色值一律跳过）**：

1. 色值是某**对象字面量** `{ ... }` 的**属性值**（如 `key: '#0564f5'`）；
2. 该对象**每一个属性值都是色值**（hex / `rgb(...)` / `rgba(...)`，允许引号包裹）；
3. 对象内无任何非色值属性值（数字、布尔、文案、嵌套对象、函数、`var(...)` 等）。

**要点**：只看属性值类型（与 key 名无关）；hex/rgb/rgba 混用仍算全色值；纯色值数组（场景③）与纯色值对象等价处理；嵌套时以最内层纯色值对象为判定单元；判定忽略注释。**不满足条件时不按本规则跳过**，色值回到防护 1 其余检查逐一判定。

```ts
// ✅ 取色器（全部属性值为色值）→ 整体跳过
const palette = { primary: '#0564f5', hover: '#4e80f5', mask: 'rgba(5, 100, 245, 0.2)' };

// ❌ 含非色值属性（title/fontSize）→ 不是取色器，其中 #0564f5 回到防护 1 判定
const theme = { title: '主色', fontSize: 14, primary: '#0564f5' };
```

##### 要求 4 补充：向上回溯所在 CSS 选择器，检测 blue class 保护规则

场景 ⑤ 仅查「色值同一行」是否含 `blue`，但 `blue` 保护规则常是**选择器在上、色值在下**的多行/嵌套结构。因此对每个色值匹配行**必须**先向上回溯其所属 CSS 规则块的选择器：

- **回溯范围**：从匹配行向上找到最近的 `{` 定位所属规则块；SCSS/Less 嵌套需**逐层向上拼接所有祖先选择器**，`&.blue`、`&-blue`、`.icon-blue &` 等 `&` 拼接形式一并拼接判定。
- **命中即跳过**：拼接后的选择器任一 class 名 / 标签名含 `blue`（大小写不敏感，如 `Blue`、`blueGray`）→ 判为「合法跳过」，记录原因「blue 选择器保护规则」，不再走后续检查与替换。

```scss
.blue-badge { color: #0564f5; }          // 回溯到 .blue-badge → 跳过
.card { .blue-tag { background: #4e80f5; } }  // 逐层回溯命中 .blue-tag → 跳过
.btn { &.blue { border-color: #096dd9; } }    // & 拼接为 .btn.blue → 跳过
```

> 该回溯检查同样适用于 3.3.5 遗漏检测阶段的「合法跳过场景」判定，避免将 blue 保护规则误判为遗漏。

#### 要求 5：rgba 色值使用 -rgb 伴侣变量替换【高优先级】

当需要替换的色值为 `rgba()` 格式时，必须使用对应的 **-rgb 伴侣变量**并保留原有的透明度值：

```
rgba(5, 100, 245, 0.2)  → rgba(var(--brand-color-rgb), 0.2)
rgba(78, 128, 245, 0.15) → rgba(var(--brand-color-hover-rgb), 0.15)
```

> 核心原则：**保留原始透明度**，仅替换颜色分量部分，alpha 值原样保留。
>
> **注意**：仅处理 `rgba()` 格式，`rgb()` 格式的色值按常规 hex 色值方式替换为 `var(--brand-color)` 等 hex 主变量。

---

> ⚠️ **分隔线说明**：以上 5 条要求为**最高优先级**，必须优先严格执行到位。
> 以下 3 条要求（要求 6 ~ 要求 8）为常规优先级，在前 5 条完全满足后再处理。

---

#### 要求 6：替换后检查代码逻辑

每次替换后确认：
- CSS 变量名拼写正确
- `var()` 语法正确（括号配对、逗号位置）
- 替换后颜色语义一致：主品牌色 → `--brand-color`，次品牌色 → `--brand-color-hover`
- 不会破坏原有选择器、属性键、其他属性值

#### 要求 7：记录本任务的替换明细（供最终报告汇总）

每完成一个文件的替换，先临时记录本次改动明细（文件、原写法、替换后、匹配类型）。这些明细将在**全部任务执行完成后**，由「任务 4」依据当前项目代码的实际改动（`git diff`）统一核对并汇总进最终报告 `Neo主题换肤功能升级报告.md`。

> 📌 临时记录仅用于辅助，**最终报告以实际代码改动为准**（见 [任务 4](#六任务-4生成-neo-主题换肤功能升级报告)）。

本任务（硬编码色值替换）相关的报告片段格式如下：

```markdown
# 硬编码色值 CSS 变量替换报告

## 汇总信息

| 指标 | 数值 |
|:--|:--|
| 扫描文件总数 | XXX |
| 修改文件总数 | XXX |
| 替换次数（主品牌色·完全匹配） | XXX |
| 替换次数（次品牌色·完全匹配） | XXX |
| 替换次数（近似匹配·1 色阶） | XXX |
| 替换次数（近似匹配·2 色阶） | XXX |
| 跳过次数 | XXX |
| 操作日期 | YYYY-MM-DD |

## 跳过详情

| 文件 | 行号 | 色值 | 跳过原因 |
|:--|:--|:--|:--|
| src/components/Foo.scss | 12 | #0564f5 | 变量名保护：类名 text-[#0564f5] |
| src/charts/Chart.tsx | 45 | #0564f5 | ECharts option 属性 |
| src/components/Foo.scss | 78 | #3080d0 | 超阈值：与最近基准差 Δ_ch=43，不视为品牌色 |
| ... | ... | ... | ... |

## 完全匹配替换详情

| 文件 | 原写法 | 替换后 | 状态 |
|:--|:--|:--|:--|
| src/components/Header.scss | `color: #0564f5` | `color: var(--brand-color)` | ✅ |
| src/components/Button.scss | `background: #4e80f5` | `background: var(--brand-color-hover)` | ✅ |
| ... | ... | ... | ... |

## 近似匹配详情（需人工复核）

> 以下为按 3.1.2 近似色匹配规则自动推断的替换，色阶差 ≤ 2，建议人工检查是否符合设计意图。

> 匹配基准恒为 `#0564f5`，替换目标恒为 `var(--brand-color)`（含透明度时用 `var(--brand-color-rgb)`）。

| 文件 | 行号 | 源色值 | 匹配基准 | 色阶差 | Δ_ch | d | 替换为 |
|:--|:--|:--|:--|:--|:--|:--|:--|
| src/Foo.scss | 12 | `#0968f5` | `#0564f5` | 1 色阶 | 4 | 5.7 | `var(--brand-color)` |
| src/Bar.tsx | 34 | `#256bd8` | `#0564f5` | 2 色阶 | 32 | 43.7 | `var(--brand-color)` |
| src/Baz.less | 56 | `#0968f533` | `#0564f5` | 1 色阶 | 4 | 5.7 | `rgba(var(--brand-color-rgb), 0.2)` |
| ... | ... | ... | ... | ... | ... | ... | ... |
```

#### 要求 8：不修改非相关内容

- 仅替换匹配上述色值列表中的值（大小写均匹配）或与列表色值差 ≤ 2 色阶的近似色（按 3.1.2 规则处理）
- 不修改未列出且超阈值的其他颜色值
- 不修改代码结构、逻辑或其他属性

### 3.3 安全替换执行规范

#### 3.3.1 替换策略选择

根据匹配量选择合适策略，避免在大规模场景下使用高风险方式：

| 匹配量 | 策略 | 说明 |
|:--|:--|:--|
| 少量（< 20 个匹配） | **逐行 replace_in_file** | 每次精确替换一条 CSS 属性声明，最安全 |
| 中量（20-200 个匹配） | **逐文件逐行解析** | Python 按行解析文件，属性级精准替换 |
| 大量（> 200 个匹配） | **分区域并行** | 按目录拆分，多个 agent 并行，各自独立校验 |

#### 3.3.2 逐行 replace_in_file 方式（首选）

适用于匹配量可控的场景。每次替换一条属性声明，`old_str` 包含完整的一行内容：

```
① 使用 search_content 搜索所有匹配的硬编码色值
② 对每个命中行，**必须先按 3.0 防护 1 的固定顺序跑完全部 6 项跳过检查**（检查 1 类名/变量名含色值 → 检查 2 测试文件 → 检查 3 已注释行 → 检查 4 blue 类选择器回溯 → 检查 5 ECharts/数组/var 回退 → 检查 6 SASS 变量），全部通过才进入替换；块内已有的 `// var(...)` 注释不构成替换许可（3.0 防护 2）
③ 对需要替换的行：
   - SCSS/CSS：old_str 为"属性名: 色值"所在行原文，new_str 为注释行 + 替换行
   - TSX/TS/JS：old_str 为包含色值的原文片段，new_str 为替换后片段
④ 执行 replace_in_file 替换
⑤ 每替换一个文件后检查逻辑（要求 6）
⑥ 更新 Neo主题换肤功能升级报告.md
```

#### 3.3.3 批量脚本替换安全规则（匹配量巨大时）

当匹配量超过 200 个必须用脚本批量处理时，**必须**遵守三条铁律（Python 代码、误伤属性对照表、校验命令等**完整规则见 [references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第一节**）：

1. **属性名边界锚定**：禁止裸匹配 `color: #xxx`（会误伤 `border-color`、`background-color`），必须用 `(^|\{|;)\s*color:` 之类锚定。
2. **逐行拆解属性名与值**：只替换属性值中的色值，属性名保持不变。
3. **替换后必跑完整性校验**：检测属性名撕裂（`grep -rn "[a-z]\-// [a-z]"`）、孤立 var() 行、残留品牌色。发现撕裂立即修复（见 reference 第二节）。

#### 3.3.4 完整执行流程

```
① 评估匹配量级，选择合适策略（3.3.1）
② 使用 search_content 搜索所有匹配的硬编码色值
③ 对每个命中行，**必须先执行 3.0 防护 1 的 6 项跳过检查（顺序固定、不可跳步），全部通过才允许替换**；同时遵守 3.0 防护 2（块内已有 `// var(...)` 注释不放行同块其他活跃行）
④ 按照选择的策略执行替换
⑤ 如果使用了批量脚本，必须执行完整性校验（3.3.3 规则 3）
⑥ 更新 Neo主题换肤功能升级报告.md
⑦ 执行 3.3.5 遗漏检测 → 如有遗漏则自动重复 ①~⑥，直到无遗漏
```

#### 3.3.5 遗漏检测与自动重试（必须执行）

任务 1 第一轮替换完成后，**必须**执行遗漏检测：重新使用 `search_content` 全面搜索当前项目源码，检查是否存在遗漏的硬编码色值。

**检测范围**（以下色值的所有大小写/格式变形，含 6 位 hex、8 位 hex、`rgb()` 与 `rgba()`）：

主品牌色（→ `var(--brand-color)` 或 `-rgb` 伴侣）：

| 应替换的色值（前 6 位） | 8 位变体示例 | 目标 CSS 变量 |
|:--|:--|:--|
| `#0564f5` / `#0564F5` / `rgb(5, 100, 245)` / `rgba(5, 100, 245, ...)` | `#0564f5<AA>`（任意 AA） | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#096dd9` / `#096DD9` / `rgb(9, 109, 217)` / `rgba(9, 109, 217, ...)` | `#096dd9<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2065cf` / `#2065CF` / `rgb(32, 101, 207)` / `rgba(32, 101, 207, ...)` | `#2065cf<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1d77ff` / `#1D77FF` / `rgb(29, 119, 255)` / `rgba(29, 119, 255, ...)` | `#1d77ff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1677ff` / `#1677FF` / `rgb(22, 119, 255)` / `rgba(22, 119, 255, ...)` | `#1677ff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#0052d9` / `#0052D9` / `rgb(0, 82, 217)` / `rgba(0, 82, 217, ...)` | `#0052d9<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2b7fff` / `#2B7FFF` / `rgb(43, 127, 255)` / `rgba(43, 127, 255, ...)` | `#2b7fff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#0060df` / `#0060DF` / `rgb(0, 96, 223)` / `rgba(0, 96, 223, ...)` | `#0060df<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1a7aff` / `#1A7AFF` / `rgb(26, 122, 255)` / `rgba(26, 122, 255, ...)` | `#1a7aff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#257cff` / `#257CFF` / `rgb(37, 124, 255)` / `rgba(37, 124, 255, ...)` | `#257cff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#0656d5` / `#0656D5` / `rgb(6, 86, 213)` / `rgba(6, 86, 213, ...)` | `#0656d5<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#007bff` / `#007BFF` / `rgb(0, 123, 255)` / `rgba(0, 123, 255, ...)` | `#007bff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2468f2` / `#2468F2` / `rgb(36, 104, 242)` / `rgba(36, 104, 242, ...)` | `#2468f2<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1c61da` / `#1C61DA` / `rgb(28, 97, 218)` / `rgba(28, 97, 218, ...)` | `#1c61da<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1865d9` / `#1865D9` / `rgb(24, 101, 217)` / `rgba(24, 101, 217, ...)` | `#1865d9<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#2563eb` / `#2563EB` / `rgb(37, 99, 235)` / `rgba(37, 99, 235, ...)` | `#2563eb<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1d4ed8` / `#1D4ED8` / `rgb(29, 78, 216)` / `rgba(29, 78, 216, ...)` | `#1d4ed8<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#047bdb` / `#047BDB` / `rgb(4, 123, 219)` / `rgba(4, 123, 219, ...)` | `#047bdb<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#1758e7` / `#1758E7` / `rgb(23, 88, 231)` / `rgba(23, 88, 231, ...)` | `#1758e7<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |
| `#007eff` / `#007EFF` / `rgb(0, 126, 255)` / `rgba(0, 126, 255, ...)` | `#007eff<AA>` | `var(--brand-color)` 或 `var(--brand-color-rgb)` |

> 💡 上表后 11 行为「实战补充」高频近似色，已升级为完全匹配（详见 § 3.1.3）。

次品牌色（→ `var(--brand-color-hover)` 或 `-rgb` 伴侣）：

| 应替换的色值（前 6 位） | 8 位变体示例 | 目标 CSS 变量 |
|:--|:--|:--|
| `#4e80f5` / `#4E80F5` / `rgb(78, 128, 245)` / `rgba(78, 128, 245, ...)` | `#4e80f5<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#1890ff` / `#1890FF` / `rgb(24, 144, 255)` / `rgba(24, 144, 255, ...)` | `#1890ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#40a9ff` / `#40A9FF` / `rgb(64, 169, 255)` / `rgba(64, 169, 255, ...)` | `#40a9ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#3886fb` / `#3886FB` / `rgb(56, 134, 251)` / `rgba(56, 134, 251, ...)` | `#3886fb<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#238dff` / `#238DFF` / `rgb(35, 141, 255)` / `rgba(35, 141, 255, ...)` | `#238dff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#3783ff` / `#3783FF` / `rgb(55, 131, 255)` / `rgba(55, 131, 255, ...)` | `#3783ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#4096ff` / `#4096FF` / `rgb(64, 150, 255)` / `rgba(64, 150, 255, ...)` | `#4096ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#5b8ff9` / `#5B8FF9` / `rgb(91, 143, 249)` / `rgba(91, 143, 249, ...)` | `#5b8ff9<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#69c0ff` / `#69C0FF` / `rgb(105, 192, 255)` / `rgba(105, 192, 255, ...)` | `#69c0ff<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |
| `#4ca1dc` / `#4CA1DC` / `rgb(76, 161, 220)` / `rgba(76, 161, 220, ...)` | `#4ca1dc<AA>` | `var(--brand-color-hover)` 或 `var(--brand-color-hover-rgb)` |

**搜索命令**：

```bash
# 搜索所有待替换的 6 位 hex 色值（排除已注释行、var() 回退值、测试文件、node_modules）
# 主品牌色 20 组 + 次品牌色 10 组，均含大小写（#1a7aff 归主品牌色 → var(--brand-color)）
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索所有 8 位 hex 色值（含透明度），前 6 位命中表中任一色值
# 匹配格式：#RRGGBBAA，AA 为任意 2 位十六进制
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索所有待替换的 rgb/rgba 色值（同时匹配 rgb() 和 rgba() 格式）
grep -rnE "rgb[a]?\(\s*(5,\s*100,\s*245|9,\s*109,\s*217|32,\s*101,\s*207|29,\s*119,\s*255|22,\s*119,\s*255|0,\s*82,\s*217|43,\s*127,\s*255|0,\s*96,\s*223|26,\s*122,\s*255|37,\s*124,\s*255|6,\s*86,\s*213|0,\s*123,\s*255|36,\s*104,\s*242|28,\s*97,\s*218|24,\s*101,\s*217|37,\s*99,\s*235|29,\s*78,\s*216|4,\s*123,\s*219|23,\s*88,\s*231|0,\s*126,\s*255|78,\s*128,\s*245|24,\s*144,\s*255|64,\s*169,\s*255|56,\s*134,\s*251|35,\s*141,\s*255|55,\s*131,\s*255|64,\s*150,\s*255|91,\s*143,\s*249|105,\s*192,\s*255|76,\s*161,\s*220)" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

**遗漏判定与重试规则**：

1. 对搜索命中行逐一判断：是否属于**合法跳过场景**（参见 3.2 要求 1 / 3 / 4）：
   - 类名/变量名中的色值 → **合法跳过**
   - 测试文件 → **合法跳过**
   - 已注释行 → **合法跳过**
   - ECharts option 属性 → **合法跳过**
   - 颜色数组 → **合法跳过**
   - 取色器对象（对象内所有属性值均为 hex/rgb/rgba 色值）→ **合法跳过**（判定方式见 要求 4 补充「取色器对象保护规则」）
   - `var()` 默认值 → **合法跳过**
   - class / 变量名含 `blue` 关键字 → **合法跳过**
   - **所属 CSS 选择器（含多行、嵌套、`&` 拼接）向上回溯后含 `blue` 关键字 → 合法跳过**（判定方式见 要求 4 补充「向上回溯所在 CSS 选择器」）
   - SASS/Less 变量定义 → **合法跳过**
2. 若命中行**不属于**以上任一合法跳过场景 → 判定为**遗漏**
3. 如存在遗漏 → **立即重新执行任务 1（从 3.1 替换规则开始，按 3.2 要求逐项替换所有遗漏项）**
4. 替换完成后 → **再次执行遗漏检测（本步骤）**
5. 重复以上过程，直到**所有命中行均为合法跳过**，方可进入任务 2
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`

> ⚠️ **关键原则**：遗漏检测不是可选项，是任务 1 的强制组成部分。无论第一次替换看起来多么完整，都必须执行遗漏检测并在报告中记录结果。

---

## 四、任务 2：旧 CSS 变量迁移

本任务包含两类旧→新 CSS 变量迁移，**均须执行**：

- **4.1 / 4.2 按钮变量迁移**：带 `-bg` 后缀的旧按钮变量名 → 新变量名。
- **4.3 导航色变量迁移**：旧版导航色变量 `--dayone-theme-header-*` → 新版导航色变量 `--brand-nav-header-*`。

### 4.1 按钮变量新旧对照表

```
--color-button-filled-primary-bg          → --color-button-filled-primary
--color-button-filled-primary-bg-hover    → --color-button-filled-primary-hover
--color-button-filled-primary-bg-tint     → --color-button-filled-primary-tint
--color-button-filled-primary-bg-disabled → --color-button-filled-primary-disabled
--color-button-filled-secondary-bg        → --color-button-filled-primary-secondary
--color-button-filled-secondary-bg-hover  → --color-button-filled-primary-secondary-hover
--color-button-filled-secondary-bg-disabled → --color-button-filled-primary-secondary-disabled
```

### 4.2 按钮变量执行方式

对项目源码执行全文搜索旧变量名，逐一替换：

```
① 搜索 --color-button-filled-primary-bg
② 搜索 --color-button-filled-secondary-bg
③ 确认命中的文件和行号
④ 将每处旧变量名替换为对应的新变量名
⑤ 同样添加到替换报告中
```

### 4.3 导航色变量新旧对照表

将旧版导航色 CSS 变量 `--dayone-theme-header-*` 迁移为新版导航色 CSS 变量 `--brand-nav-header-*`（左侧旧 → 右侧新）：

```
--dayone-theme-header-back          → --brand-nav-header-bg
--dayone-theme-header-icon          → --brand-nav-header-icon
--dayone-theme-header-lanucher-icon → --brand-nav-header-launcher-icon
--dayone-theme-header-placeholder   → --brand-nav-header-placeholder
--dayone-theme-header-select        → --brand-nav-header-select
--dayone-theme-header-select-black  → --brand-nav-header-select-bg
--dayone-theme-header-font          → --brand-nav-header-font
--dayone-theme-header-back-opacity  → --brand-nav-header-elem-opacity
--dayone-theme-header-back-hover    → --brand-nav-header-elem-hover
```

> 📝 **说明**：
> - 旧变量名 `--dayone-theme-header-lanucher-icon` 中的 `lanucher` 为历史拼写（typo），新变量名已修正为 `launcher`，替换时**以对照表右侧新变量名为准**。
> - `--dayone-theme-header-font` 旧写法常带固定值（如 `--dayone-theme-header-font: white;`）。**只迁移变量名本身**（`--dayone-theme-header-font` → `--brand-nav-header-font`），变量的取值、`var()` 引用位置等其余内容保持不变。
> - 无论变量是出现在**定义处**（`--dayone-theme-header-back: ...`）还是**引用处**（`var(--dayone-theme-header-back)`），均按对照表迁移变量名。

### 4.4 导航色变量执行方式

> 🚨 **前缀顺序铁律（必须严格遵守）**：部分旧变量名互为前缀，若按短名先替换会破坏长名。**必须先替换更长（更具体）的变量名，再替换其前缀短名**，避免误伤：
>
> - 先替换 `--dayone-theme-header-back-opacity`、`--dayone-theme-header-back-hover`，**再**替换 `--dayone-theme-header-back`。
> - 先替换 `--dayone-theme-header-select-black`，**再**替换 `--dayone-theme-header-select`。
>
> 实现方式：对含前缀关系的变量，采用「整词/边界锚定」替换（确保 `--dayone-theme-header-back` 不会误伤 `--dayone-theme-header-back-hover` 的前半段），或严格按「长名 → 短名」的先后顺序执行。

```
① 全文搜索所有 --dayone-theme-header- 开头的变量（定义处与 var() 引用处均需覆盖）
② 按「长名 → 短名」顺序（见上方前缀顺序铁律），将每处旧变量名替换为对照表对应的新变量名
③ --dayone-theme-header-font 只替换变量名，保留其原有取值（如 white）
④ 替换后全文再次搜索 --dayone-theme-header-，确认无残留旧变量名（含定义与引用）
⑤ 同样添加到替换报告中
```

---

## 五、任务 3：Primary 按钮色改造

### 5.1 识别目标按钮

搜索匹配以下 class 模式的按钮：
- `button-primary`
- `ant-btn-primary`
- `btn-primary`
- `a-Button--primary`
- 其他包含 `primary` 关键词的按钮类名

**要求**：必须遍历每个文件内的**所有** primary 按钮样式块，不可遗漏。

### 5.2 使用规则 1：白色背景 primary 按钮

**条件**：背景色为 `#FFFFFF` / `#FFF` / `#ffffff` / `#fff`

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `color` 和 `border-color` → `var(--color-button-filled-primary)` |
| hover 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-hover)` |
| active 态 | `color` 和 `border-color` → `var(--color-button-filled-primary-active)` |

### 5.3 使用规则 2：非白色背景 primary 按钮

**条件**：背景色**不是**白色

| 状态 | 操作 |
|:--|:--|
| 非 hover / active | `background` 或 `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)` |
| hover 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)` |
| active 态 | `background` 或 `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)` |

> 💡 **为什么 `color` 必须使用按钮字体色变量（`--color-button-filled-primary-color` / `--color-button-filled-primary-color-hover`）？**
>
> 填充型 primary 按钮的文字直接叠在按钮背景色之上。如果 `color` 使用固定色值（如 `#fff`）或固定色值的 CSS 变量，一旦运行时把按钮背景色换成与该文字色相近的颜色（例如浅色系按钮色配白色文字），就会出现**文字与背景色相近、看起来模糊**的问题。
>
> `--color-button-filled-primary-color` / `--color-button-filled-primary-color-hover` 是随按钮背景色**自动计算的对比色**（自动在深/浅之间选择），能保证任意按钮色下文字都清晰可读。因此**非白色背景 primary 按钮的 `color` 一律改用按钮字体色变量，禁止保留固定色值或使用固定色值的 CSS 变量**。

### 5.4 使用规则 3：通用规则（适用于所有 primary 按钮）

| 背景色 | 状态 | 操作 |
|:--|:--|:--|
| 白色 | 非 hover/active | `color` + `border-color` → `var(--color-button-filled-primary)` |
| 白色 | hover | `color` + `border-color` → `var(--color-button-filled-primary-hover)` |
| 白色 | active | `color` + `border-color` → `var(--color-button-filled-primary-active)` |
| 非白色 | 非 hover/active | `background-color` → `var(--color-button-filled-primary)`；`color` → `var(--color-button-filled-primary-color)` |
| 非白色 | hover | `background-color` → `var(--color-button-filled-primary-hover)`；`color` → `var(--color-button-filled-primary-color-hover)` |
| 非白色 | active | `background` / `background-color` → `var(--color-button-filled-primary-active)`；`color` → `var(--color-button-filled-primary-color-hover)` |

> 💡 **按钮字体色规则（非白色背景 primary 按钮）**：`color` 必须使用按钮字体色变量而非固定色值/固定色值 CSS 变量——
> - 非 hover / active 态：`color` → `var(--color-button-filled-primary-color)`
> - hover / active 态：`color` → `var(--color-button-filled-primary-color-hover)`
>
> 目的是避免文字色与运行时切换后的按钮背景色相近，导致文字看起来模糊；按钮字体色变量为自动对比色，可保证任意按钮色下文字清晰可读。
>
> 白色背景轮廓 primary 按钮的 `color` 显示的是品牌色本身（文字即品牌色），仍使用 `--color-button-filled-primary` 系列，**不改用**按钮字体色变量。

### 5.5 改造前后示例对照

三类典型场景（A 白底轮廓按钮 / B 非白底填充按钮 / C 次按钮）的改造前后完整 SCSS 对照，见 **[references/examples.md](references/examples.md) 第一节**。核心口诀：

- **白底轮廓**：`color` + `border-color` → `--color-button-filled-primary` 系列，背景保持白色。
- **非白底填充**：`background` → `--color-button-filled-primary` 系列，`color` → `--color-button-filled-primary-color(-hover)` 按钮字体色变量。

### 5.6 遗漏检测与自动重试（必须执行）

任务 3 第一轮改造完成后，**必须**执行遗漏检测：重新搜索项目中所有 `ant-btn-primary` 样式块，检查其 `background` / `background-color` 属性是否仍使用了硬编码色值而非 CSS 变量。

#### 5.6.1 搜索范围

搜索匹配以下 class 模式的所有按钮样式块：
- `ant-btn-primary`
- `button-primary`
- `btn-primary`
- `a-Button--primary`
- 其他包含 `primary` 关键词的按钮类名

#### 5.6.2 检测命令

```bash
# 搜索所有 primary 按钮样式块中的硬编码背景色
grep -rn "ant-btn-primary\|button-primary\|btn-primary\|a-Button--primary" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 20 | grep -E "background(-color)?:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\()"

# 重点检测 ant-btn-primary 中的 background-color 是否为硬编码色值
grep -rn "ant-btn-primary" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -A 30 | grep -E "(background|background-color):\s*#"
```

#### 5.6.3 遗漏判定与重试规则

1. 对搜索命中的样式块逐一判断：
   - `background` / `background-color` 使用了 CSS 变量（如 `var(--color-button-filled-primary)`）→ **已完成改造**
   - `background` 为白色（`#fff` / `#FFF` / `#ffffff` / `#FFFFFF`）→ 按 5.2 轮廓按钮规则处理，**非遗漏项**（白色背景本身就是最终值）
   - `background` / `background-color` 使用了硬编码色值且非白色 → 判定为**遗漏**
2. 若存在遗漏 → **立即重新执行任务 3（从 5.1 识别目标按钮开始，按 5.2/5.3/5.4 规则逐一改造所有遗漏的 primary 按钮样式块）**
3. 改造完成后 → **再次执行遗漏检测（本步骤）**
4. 重复以上过程，直到**所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景**，方可进入任务 4
5. 同时核对每个非白色背景 primary 按钮的字体色 `color`：非 hover/active 态应为 `var(--color-button-filled-primary-color)`、hover/active 态应为 `var(--color-button-filled-primary-color-hover)`；若仍为固定色值或固定色值 CSS 变量 → 判定为遗漏，一并补改
6. 每次循环完成后更新 `Neo主题换肤功能升级报告.md`

> ⚠️ **特别关注 `ant-btn-primary`**：这是最容易被遗漏的场景。其默认样式通常写在基础组件库（如 antd）的覆盖样式表中，需要逐一确认 `background` 和 `background-color` 属性均已完成替换。

---

## 六、任务 4：生成 Neo 主题换肤功能升级报告

> 🚨 **本任务是前三项任务的收尾步骤，必须在任务 1 / 2 / 3 全部执行完成后执行。**
> 报告内容**必须依据当前项目代码的实际改动生成**（以 `git diff` / `git status` 为准），而非仅凭执行过程中的记忆或中间临时记录。

### 6.1 执行前置条件

生成报告前，确认以下三项任务均已完成并通过各自的遗漏检测：

- [ ] 任务 1（硬编码色值替换）已完成，且 3.3.5 遗漏检测通过
- [ ] 任务 2（旧 CSS 变量迁移）已完成
- [ ] 任务 3（Primary 按钮色改造）已完成，且 5.6 遗漏检测通过
- [ ] 「替换后校验」（见第十章）已执行且无异常

### 6.2 依据实际代码改动收集数据（必须）

**禁止**凭记忆或中间记录直接编写报告。必须先通过版本控制获取当前项目的真实改动，再据此汇总：

```bash
# 1. 查看本次改动涉及的文件清单（修改 / 新增 / 删除）
git status --short

# 2. 查看全部改动明细（逐行 diff），作为报告"替换详情"的唯一数据来源
git diff

# 3. 统计改动文件数与增删行数
git diff --stat

# 4. 仅列出被修改的文件路径（用于填写"修改文件总数"及逐文件明细）
git diff --name-only
```

> 若项目未启用 git 或改动尚未落盘，则以本次会话中实际执行的文件写入操作为准逐一核对，确保报告与磁盘上的真实文件内容一致。

### 6.3 报告生成规则

1. **数据来源以实际 diff 为准**：报告中的「修改文件总数」「替换次数」「替换详情」「跳过详情」「近似匹配详情」等，均须与 `git diff` 的真实结果一一对应；执行过程中的临时记录若与实际 diff 不符，**以实际 diff 为准并修正**。
2. **覆盖全部四项任务的改动**：报告须同时汇总任务 1（硬编码色值替换）、任务 2（旧变量迁移）、任务 3（Primary 按钮改造）三项任务在代码中产生的全部实际改动。
3. **文件命名固定**：报告文件名必须为 `Neo主题换肤功能升级报告.md`，生成在项目根目录。
4. **逐文件核对**：对 `git diff --name-only` 列出的每个文件，核对其改动类型（色值替换 / 变量迁移 / 按钮改造）并归入报告对应章节。

### 6.4 报告结构

最终报告须包含以下章节（其中任务 1 的明细表格式沿用 [要求 7](#要求-7记录本任务的替换明细供最终报告汇总)）：

```markdown
# Neo 主题换肤功能升级报告

## 一、总体汇总

| 指标 | 数值 |
|:--|:--|
| 操作日期 | YYYY-MM-DD |
| 改动文件总数（git diff --name-only） | XXX |
| 新增行数 / 删除行数（git diff --stat） | +XXX / -XXX |
| 任务 1·硬编码色值替换次数 | XXX |
| 任务 2·旧 CSS 变量迁移次数 | XXX |
| 任务 3·Primary 按钮改造样式块数 | XXX |
| 跳过次数（合法跳过） | XXX |

## 二、任务 1：硬编码色值替换

（沿用要求 7 的「汇总信息 / 跳过详情 / 完全匹配替换详情 / 近似匹配详情」四张表，数据以 git diff 为准）

## 三、任务 2：旧 CSS 变量迁移

### 3.1 按钮变量迁移

| 文件 | 旧变量名 | 新变量名 | 状态 |
|:--|:--|:--|:--|
| src/styles/button.scss | `--color-button-filled-primary-bg` | `--color-button-filled-primary` | ✅ |
| ... | ... | ... | ... |

### 3.2 导航色变量迁移

| 文件 | 旧变量名 | 新变量名 | 状态 |
|:--|:--|:--|:--|
| src/styles/header.scss | `--dayone-theme-header-back` | `--brand-nav-header-bg` | ✅ |
| src/styles/header.scss | `--dayone-theme-header-back-hover` | `--brand-nav-header-elem-hover` | ✅ |
| ... | ... | ... | ... |

## 四、任务 3：Primary 按钮色改造

| 文件 | 按钮类名 | 背景类型 | 改造项 | 改造后 | 状态 |
|:--|:--|:--|:--|:--|:--|
| src/styles/btn.scss | `.ant-btn-primary` | 非白色 | `background-color` | `var(--color-button-filled-primary)` | ✅ |
| src/styles/btn.scss | `.ant-btn-primary` | 非白色 | `color` | `var(--color-button-filled-primary-color)` | ✅ |
| ... | ... | ... | ... | ... | ... |

## 五、改动文件清单（git diff --name-only）

- src/components/Header.scss
- src/styles/button.scss
- ...

## 六、校验结果

| 校验项 | 命令 | 结果 |
|:--|:--|:--|
| CSS 属性名完整性（10.1） | `grep -rn "[a-z]\-// [a-z]" ...` | ✅ 无匹配 |
| 残留硬编码色值（10.2） | `grep -rnE "#0564f5\|..." ...` | ✅ 仅剩合法跳过项 |
```

> ⚠️ **关键原则**：报告是本次升级的最终交付物之一，其准确性由「实际代码改动」保证。生成前务必执行 6.2 的 `git diff` 命令核对，确保报告内容与仓库真实改动完全一致。

---

## 七、ECharts 图表处理规范

> **重要**：ECharts option 中的硬编码色值**不进行替换**。ECharts 不支持 `var(--css-variable)`。
>
> ⚠️ **如何确认「属于 ECharts」**：不能只看单行属性名（`color` / `itemStyle` / `lineStyle` 等与普通样式高度重合）。**必须读取完整文件上下文向上回溯**，确认色值所在对象确属 ECharts option（命中 `series: [{ type: 'bar' }]`、`xAxis`、`yAxis`、`legend`、`grid`、`dataZoom` 等专有属性）才成立。完整判定细则见 **[要求 4 补充：ECharts 判定细则]**（本文件 3.0 防护部分「要求 4」章节）。

正确的做法是在组件 JSX 中通过 `getCssVarHex()` 读取 CSS 变量的 hex 值后传入：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart = () => {
  const brandColor = getCssVarHex('--brand-color');

  const option = {
    color: [brandColor],
    series: [{ itemStyle: { color: brandColor } }],
  };

  return <ReactECharts option={option} />;
};
```

---

## 八、组件开发规范速查

当需要**新建**支持换肤的组件时，品牌色 / 按钮色使用示例与「要素 → CSS 变量」映射表见 **[references/examples.md](references/examples.md) 第二节**。要点：品牌相关颜色一律用 `var(--xxx)`，填充按钮字体色用 `--color-button-filled-primary-color`，链接 / 边框 / 关键文字用对应语义化 Token。

---

## 九、可用主题 CSS 变量

> Neo 平台主题 CSS 变量的完整列表、默认色值及各类场景的响应使用示例，详见 **[references/theme-css-variables.md](references/theme-css-variables.md)**。

核心变量体系概览：

| 类别 | 变量数 | 用途 |
|:--|:--|:--|
| 品牌核心变量 | 6 对（hex + -rgb） | `--brand-color` / `--brand-color-hover` / `--brand-color-shade` / ... |
| 语义化 Token — 背景 | 6 个 | `--color-bg-brand` / `--color-bg-brand-hover` / ... |
| 语义化 Token — 边框 | 6 个 | `--color-border-brand` / `--color-border-brand-hover` / ... |
| 语义化 Token — 图标 | 7 个 | `--color-icon-brand` / `--color-icon-brand-hover` / ... |
| 语义化 Token — 文本 | 7 个 | `--color-text-brand` / `--color-text-brand-link` / ... |
| 按钮色变量 | 18 个 | `--color-button-filled-primary` / `--color-button-filled-primary-hover` / ... |
| 导航 Banner 色 | 11 个 | `--brand-nav-header-bg` / `--brand-nav-header-font` / ... |

> 每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值，如 `5, 100, 245`），用于 `rgba(var(--xxx-rgb), alpha)` 半透明场景。

---

## 十、替换后校验（必须执行）

> **重要**：全部替换完成后，**必须运行以下校验命令**确认无异常。

### 10.1 CSS 属性名完整性校验

```bash
# 检测 CSS 属性名被撕裂的异常（如 border-// color:）
grep -rn "[a-z]\-// [a-z]" --include="*.scss" --include="*.css" --include="*.less"
# 预期输出：空（无任何匹配）
```

**如果发现匹配**，说明出现了"属性名撕裂"错误，必须立即修复（修复方法见 [references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节）。

### 10.2 残留硬编码色值校验

```bash
# 搜索未替换的 6 位 hex 品牌色值（排除已注释行、var() 回退值、测试文件、node_modules）
# 主品牌色 20 组 + 次品牌色 10 组，全部含大小写（#1a7aff 归主品牌色 → var(--brand-color)）
grep -rnE "#0564f5|#0564F5|#096dd9|#096DD9|#2065cf|#2065CF|#1d77ff|#1D77FF|#1677ff|#1677FF|#0052d9|#0052D9|#2b7fff|#2B7FFF|#0060df|#0060DF|#1a7aff|#1A7AFF|#257cff|#257CFF|#0656d5|#0656D5|#007bff|#007BFF|#2468f2|#2468F2|#1c61da|#1C61DA|#1865d9|#1865D9|#2563eb|#2563EB|#1d4ed8|#1D4ED8|#047bdb|#047BDB|#1758e7|#1758E7|#007eff|#007EFF|#4e80f5|#4E80F5|#1890ff|#1890FF|#40a9ff|#40A9FF|#3886fb|#3886FB|#238dff|#238DFF|#3783ff|#3783FF|#4096ff|#4096FF|#5b8ff9|#5B8FF9|#69c0ff|#69C0FF|#4ca1dc|#4CA1DC" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("

# 搜索未替换的 8 位 hex 品牌色值（含透明度）
grep -rnE "#(0564f5|096dd9|2065cf|1d77ff|1677ff|0052d9|2b7fff|0060df|1a7aff|257cff|0656d5|007bff|2468f2|1c61da|1865d9|2563eb|1d4ed8|047bdb|1758e7|007eff|4e80f5|1890ff|40a9ff|3886fb|238dff|3783ff|4096ff|5b8ff9|69c0ff|4ca1dc)[0-9a-fA-F]{2}\b" \
  --include="*.scss" --include="*.css" --include="*.less" \
  --include="*.tsx" --include="*.ts" --include="*.jsx" --include="*.js" \
  --exclude-dir="__tests__" --exclude-dir="node_modules" \
  -i | grep -v "^\s*//" | grep -v "^\s*/\*" | grep -v "var("
```

合法残留项（无需处理）：
- `$变量名: #2065CF;` — SCSS 变量定义
- `.xxx-blue { color: #1890ff; }` — class 含 blue 关键字
- `var(--xxx, #0564f5)` — var() 回退值
- `path[fill='#1890ff']` — SVG 属性选择器
- `stroke: #1890ff` — SVG stroke 属性
- `mix(#0564f5, ...)` — SCSS 函数参数

---
## 十一、常见错误与排查

批量脚本替换可能出现三类典型错误——① CSS 属性名被撕裂（`border-// color:`）、② 注释行被重复替换（双 `//` 前缀）、③ 重复的替换行。现象、根因、修复代码与预防措施详见 **[references/batch-and-troubleshooting.md](references/batch-and-troubleshooting.md) 第二节**。核心预防：属性名边界锚定、替换前检查行首是否已注释、遍历时用副本或从后向前处理。

---
## 十二、执行检查清单

完成全部任务后逐项检查：

- [ ] **3.0 防护 1「先判定后替换」已执行**（每个匹配行按固定顺序跑完检查 1~6，全部通过才替换，顺序未打乱、未跳步）
- [ ] **3.0 防护 2 已遵守**（块内已有的 `// var(...)` 注释仅在检查 3 跳过其自身，未据此放行同块其他活跃行）
- [ ] **匹配规则总则已遵守**（完全匹配优先直接替换；1-2 色阶近似匹配按 3.1.2 规则处理并标记；超阈值一律保留）
- [ ] **任务 1 遗漏检测已通过**（执行 3.3.5 搜索命令，仅剩合法跳过项，无遗漏）
- [ ] 所有匹配的硬编码色值已替换（包括 6 位 hex、8 位 hex、rgb、rgba 格式）
- [ ] **8 位 hex 色值（`#RRGGBBAA`）已按 3.1.1 规则处理**（前 6 位命中则换算 alpha 后替换为 rgba + -rgb 伴侣变量）
- [ ] **近似色匹配仅以 `#0564f5` 为基准判定**（不与表中其他色值比较；1 色阶差 Δ_ch ≤ 16 且 d ≤ 25；2 色阶差 Δ_ch ≤ 32 且 d ≤ 50；近似命中一律替换为 `var(--brand-color)`）
- [ ] **近似匹配已在报告"近似匹配详情"表中单独记录**（含源色值、基准 `#0564f5`、Δ_ch、d、目标变量），并附注释标注供人工复核
- [ ] **补充的相近品牌色值已全部替换**（Ant Design v5 / TDesign / Neo 默认色如 `#1677ff`、`#1a7aff`、`#4096ff` 等）
- [ ] 类名/变量名中的色值已正确跳过
- [ ] SCSS 中用 `//` 保留原有写法，CSS 中用 `/* */` 保留
- [ ] 测试文件已全部跳过
- [ ] ECharts option 中的色值未替换
- [ ] **取色器对象（属性值全为 hex/rgb/rgba 的对象）中的色值未替换**
- [ ] `var()` 默认值中的色值未替换
- [ ] class 含 `blue` 关键字未替换
- [ ] 旧变量 `-bg` 后缀已全部更新
- [ ] **导航色变量已全部迁移**（`--dayone-theme-header-*` → `--brand-nav-header-*`，含定义处与 `var()` 引用处；全文搜索 `--dayone-theme-header-` 无残留）
- [ ] **任务 3 遗漏检测已通过**（执行 5.6 搜索命令，所有 primary 按钮的 background-color 均已使用 CSS 变量或为白色背景）
- [ ] 所有 primary 按钮样式块已遍历，无遗漏
- [ ] 白色背景 primary 按钮的 `color` + `border-color` 已改造
- [ ] 非白色背景 primary 按钮的 `background-color` 已改造
- [ ] **非白色背景 primary 按钮的字体色 `color` 已改用按钮字体色变量**（非 hover/active 态 → `--color-button-filled-primary-color`；hover/active 态 → `--color-button-filled-primary-color-hover`），未保留固定色值或固定色值 CSS 变量
- [ ] **ant-btn-primary 的 background-color 已确认替换**
- [ ] **CSS 属性名完整性校验已通过**（执行 10.1 命令，确认无匹配）
- [ ] **残留硬编码色值校验已通过**（执行 10.2 命令，仅剩合法跳过项）
- [ ] **任务 4 已执行**：前三项任务全部完成后，已依据当前项目代码的实际改动（`git diff` / `git status`）生成 `Neo主题换肤功能升级报告.md`
- [ ] **报告内容与实际代码改动一致**（改动文件数、替换次数、逐文件明细均与 `git diff` 结果核对无误，而非仅凭中间记录）
- [ ] 无破坏代码逻辑的变更

# neo-theme-skill 说明

## 触发条件

当用户提出 **"项目支持 Neo 主题换肤功能"** 或类似需求时触发。

本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

## 核心能力

### 1. 硬编码色值 → CSS 变量替换

自动识别项目中的品牌相关硬编码色值（30 个唯一色值，含大小写与 rgb/rgba 变体），按规则替换为 CSS 变量写法：

- 主品牌色 20 个色值（含 `#1a7aff` 及 `#257cff`、`#0656d5`、`#007bff` 等 11 个实战补充高频变体）→ `var(--brand-color)`
- 次品牌色 10 个色值 → `var(--brand-color-hover)`
- 支持 6 位 hex、8 位 hex（含透明度）、rgb/rgba 格式
- **近似色匹配只以 `#0564f5` 为唯一基准**（1-2 色阶差 → `var(--brand-color)`），避免误伤非品牌蓝色
- 智能跳过多类场景：类名/变量名含色值、测试文件、已注释行、blue 选择器（含嵌套回溯）、ECharts 属性、颜色数组、取色器对象、var() 回退值、SASS/Less blue 变量
- 按文件类型保留原有写法（scss 用 `//`、css 用 `/* */`、tsx 直接替换）

### 2. 旧 CSS 变量迁移

包含两类旧→新 CSS 变量迁移：

- **按钮变量**：带 `-bg` 后缀的旧版按钮色变量名替换为新版命名（7 对）。
- **导航色变量**：旧版导航色变量 `--dayone-theme-header-*` 替换为新版 `--brand-nav-header-*`（9 对，含定义处与 `var()` 引用处；注意 `-back` / `-select` 前缀顺序，先长名后短名）。

### 3. Primary 按钮色改造

遍历所有 primary 模式按钮，按背景色白色/非白色区分处理：

- 白色背景 → `color` + `border-color` 改用按钮色变量
- 非白色背景 → `background-color` 改用按钮色变量
- 覆盖 hover / active / disabled 全部状态

## 结构

```
neo-theme-skill/
├── SKILL.md                              # 主技能文档（含 frontmatter，保留关键规则与流程）
├── README.md                             # 本文件
├── references/
│   ├── theme-css-variables.md            # 主题 CSS 变量完整参考（含使用示例 + 反向映射）
│   ├── color-matching-details.md         # 8 位十六进制 + 近似色匹配完整细则、示例、报告格式
│   ├── batch-and-troubleshooting.md      # 批量脚本替换安全规则 + 常见错误排查
│   └── examples.md                       # Primary 按钮改造前后对照 + 新建组件换肤规范
└── scripts/
    ├── neoThemeColorMatcher.js           # 硬编码色值 → CSS 变量匹配决策引擎（可编程实现）
    └── README.md                         # 脚本说明与用法
```

## 输出

执行完成后，在项目根目录生成 `Neo主题换肤功能升级报告.md`，包含：

- 汇总信息（扫描文件数、替换次数、跳过次数）
- 跳过详情（哪些色值被跳过及原因）
- 替换详情（每处替换的前后对照）

## 遵循 skill-creator 约定

- `SKILL.md` 主文档 + `references/` 目录结构
- YAML frontmatter 含 `name` / `description`，描述带触发关键词
- 主文档控制行数，详细信息分拆到 references
- 明确的执行步骤和检查清单

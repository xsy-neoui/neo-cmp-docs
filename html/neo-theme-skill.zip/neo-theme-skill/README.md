# neo-theme-skill 说明

## 触发条件

当用户提出 **"项目支持 Neo 主题换肤功能"** 或类似需求时触发。

本技能是独立可用的升级工具，无需依赖其他技能即可完成完整的主题换肤改造。

## 核心能力

### 1. 硬编码色值 → CSS 变量替换

自动识别项目中的品牌相关硬编码色值（40 种），按规则替换为 CSS 变量写法：

- 主品牌色 16 种色值 → `var(--brand-color)`
- 次品牌色 24 种色值 → `var(--brand-color-hover)`
- 支持 hex（大小写）和 rgb/rgba 格式
- 智能跳过五类场景：类名含色值、ECharts 属性、颜色数组、var() 默认值、class 含 blue
- 按文件类型保留原有写法（scss 用 `//`、css 用 `/* */`、tsx 直接替换）

### 2. 旧 CSS 变量迁移

将带 `-bg` 后缀的旧版按钮色变量名替换为新版命名（7 对）。

### 3. Primary 按钮色改造

遍历所有 primary 模式按钮，按背景色白色/非白色区分处理：

- 白色背景 → `color` + `border-color` 改用按钮色变量
- 非白色背景 → `background-color` 改用按钮色变量
- 覆盖 hover / active / disabled 全部状态

## 结构

```
neo-theme-skill/
├── SKILL.md                              # 主技能文档（含 frontmatter）
├── README.md                             # 本文件
└── references/
    └── theme-css-variables.md            # 主题 CSS 变量完整参考（含使用示例）
```

## 输出

执行完成后，在项目根目录生成 `Neo主题换肤功能升级报告.md`，包含：

- 汇总信息（扫描文件数、替换次数、跳过次数）
- 跳过详情（哪些色值被跳过及原因）
- 替换详情（每处替换的前后对照）

## 遵循 skill-creator 约定

- `SKILL.md` 主文档 + `references/` 目录结构
- YAML frontmatter 含 `name` / `description`，描述带触发关键词
- 主文档控制行数，详细信息分拆到 references
- 明确的执行步骤和检查清单

/**
 * Neo 主题换肤 · 硬编码色值匹配工具
 *
 * 用途：给定一个硬编码色值（#RRGGBB / #RRGGBBAA / rgb() / rgba()），
 *      返回其应替换的 Neo 品牌 CSS 变量。
 *
 * 匹配策略（与 SKILL.md § 3.1 ~ § 3.1.2 完全对齐）：
 *   - 完全匹配：与 BRAND_COLOR_MAP 中 30 个色值逐一比对（大小写不敏感），命中即用其目标变量。
 *   - 近似匹配：仅与唯一基准色 #0564f5 比较（1-2 色阶差），命中一律映射为 --brand-color；
 *     不与表中其他色值（含次品牌色）做近似比较，避免蓝色候选邻域重叠导致过度替换。
 *
 * 配套参考文档：references/theme-css-variables.md § 十一
 *
 * 用法：
 *   const { matchBrandColor } = require('./neoThemeColorMatcher');
 *   matchBrandColor('#0564f5');
 *   // → { matchType: 'exact', targetVar: '--brand-color', output: 'var(--brand-color)', ... }
 *
 *   matchBrandColor('#0968f5');
 *   // → { matchType: 'approximate', targetVar: '--brand-color', shade: 1, delta: 4, distance: 5.7, output: 'var(--brand-color)' }
 *
 *   matchBrandColor('#0564f533');
 *   // → { matchType: 'exact-with-alpha', targetVar: '--brand-color', alpha: 0.2, output: 'rgba(var(--brand-color-rgb), 0.2)' }
 */

'use strict';

// ===== 1. 硬编码色值 → CSS 变量映射表 =====
const BRAND_COLOR_MAP = {
  // 主品牌色 → var(--brand-color)
  '#0564f5': '--brand-color', // Neo 标准
  '#096dd9': '--brand-color', // Ant Design v4
  '#2065cf': '--brand-color',
  '#1d77ff': '--brand-color',
  '#1677ff': '--brand-color', // Ant Design v5
  '#0052d9': '--brand-color', // TDesign
  '#2b7fff': '--brand-color',
  '#0060df': '--brand-color',
  '#1a7aff': '--brand-color',

  // 实战补充：与基准 #0564f5 相差 1-2 色阶、在历史项目中高频出现的硬编码变体，
  // 原本应由「近似匹配」命中，但近似色无法被固定 grep 捞出而屡屡漏网，
  // 故升级为「完全匹配」以保证 grep + 替换的确定性。全部映射为主品牌色。
  '#257cff': '--brand-color', // rgb(37, 124, 255)  Δ_ch=32 d≈41.2
  '#0656d5': '--brand-color', // rgb(6, 86, 213)    Δ_ch=32 d≈34.9
  '#007bff': '--brand-color', // rgb(0, 123, 255)   Δ_ch=23 d≈25.6  Bootstrap 主蓝
  '#2468f2': '--brand-color', // rgb(36, 104, 242)  Δ_ch=31 d≈31.4
  '#1c61da': '--brand-color', // rgb(28, 97, 218)   Δ_ch=27 d≈35.6
  '#1865d9': '--brand-color', // rgb(24, 101, 217)  Δ_ch=28 d≈33.9
  '#2563eb': '--brand-color', // rgb(37, 99, 235)   Δ_ch=32 d≈33.5  Tailwind blue-600
  '#1d4ed8': '--brand-color', // rgb(29, 78, 216)   Δ_ch=29 d≈43.6  Tailwind blue-700
  '#047bdb': '--brand-color', // rgb(4, 123, 219)   Δ_ch=26 d≈34.7  amis cxd 主色
  '#1758e7': '--brand-color', // rgb(23, 88, 231)   Δ_ch=18 d≈25.8
  '#007eff': '--brand-color', // rgb(0, 126, 255)   Δ_ch=26 d≈28.3

  // 次品牌色 → var(--brand-color-hover)
  '#4e80f5': '--brand-color-hover', // Neo 标准 hover
  '#1890ff': '--brand-color-hover', // Ant Design v4 hover
  '#40a9ff': '--brand-color-hover',
  '#3886fb': '--brand-color-hover',
  '#238dff': '--brand-color-hover',
  '#3783ff': '--brand-color-hover',
  '#4096ff': '--brand-color-hover', // Ant Design v5 hover
  '#5b8ff9': '--brand-color-hover', // AntV 常用蓝
  '#69c0ff': '--brand-color-hover', // Ant Design 极浅蓝
  '#4ca1dc': '--brand-color-hover',
};

// ===== 2. 近似色匹配阈值 =====
const THRESHOLDS = {
  SHADE_1_CH_MAX: 16, // 1 色阶差单通道最大值
  SHADE_1_D_MAX: 25, // 1 色阶差欧氏距离最大值
  SHADE_2_CH_MAX: 32, // 2 色阶差单通道最大值
  SHADE_2_D_MAX: 50, // 2 色阶差欧氏距离最大值
};

// ===== 3. 基础工具函数 =====
function normalizeHex(hex) {
  const trimmed = String(hex).trim().toLowerCase();
  return trimmed.startsWith('#') ? trimmed : `#${trimmed}`;
}

function hex6ToRgb(hex) {
  const m = normalizeHex(hex).match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const int = parseInt(m[1], 16);
  return { r: (int >> 16) & 0xff, g: (int >> 8) & 0xff, b: int & 0xff };
}

function parseHex8(hex) {
  const m = normalizeHex(hex).match(/^#([0-9a-f]{6})([0-9a-f]{2})$/i);
  if (!m) return null;
  const alphaInt = parseInt(m[2], 16);
  return {
    hex6: `#${m[1].toLowerCase()}`,
    alphaHex: m[2].toLowerCase(),
    alpha: Math.round((alphaInt / 255) * 100) / 100,
  };
}

function parseRgb(rgbStr) {
  const m = String(rgbStr).match(
    /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)$/i,
  );
  if (!m) return null;
  return {
    r: parseInt(m[1], 10),
    g: parseInt(m[2], 10),
    b: parseInt(m[3], 10),
    alpha: m[4] !== undefined ? parseFloat(m[4]) : null,
  };
}

function channelDelta(c1, c2) {
  return Math.max(Math.abs(c1.r - c2.r), Math.abs(c1.g - c2.g), Math.abs(c1.b - c2.b));
}

function euclideanDistance(c1, c2) {
  return Math.sqrt((c1.r - c2.r) ** 2 + (c1.g - c2.g) ** 2 + (c1.b - c2.b) ** 2);
}

// ===== 4. 判定色阶差 =====
function classifyShade(chDelta, distance) {
  if (chDelta === 0 && distance === 0) return 0;
  if (chDelta <= THRESHOLDS.SHADE_1_CH_MAX && distance <= THRESHOLDS.SHADE_1_D_MAX) return 1;
  if (chDelta <= THRESHOLDS.SHADE_2_CH_MAX && distance <= THRESHOLDS.SHADE_2_D_MAX) return 2;
  return -1; // 超阈值
}

// ===== 5. 近似匹配唯一基准 =====
// 近似（1-2 色阶）匹配只与 #0564f5 比较，命中一律映射为 --brand-color。
// 表中其余色值（含次品牌色）仅参与「完全匹配」，不作为近似基准。
const APPROX_BASE_HEX = '#0564f5';
const APPROX_BASE_VAR = '--brand-color';

function matchApprox(rgb, sourceLabel) {
  const baseRgb = hex6ToRgb(APPROX_BASE_HEX);
  const chDelta = channelDelta(rgb, baseRgb);
  const distance = euclideanDistance(rgb, baseRgb);
  const shade = classifyShade(chDelta, distance);
  if (shade !== 1 && shade !== 2) {
    return { matchType: 'none', input: sourceLabel || `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})` };
  }
  return {
    matchType: 'approximate',
    targetVar: APPROX_BASE_VAR,
    baseHex: APPROX_BASE_HEX,
    shade,
    delta: chDelta,
    distance: Math.round(distance * 10) / 10,
  };
}

// ===== 6. 核心匹配函数 =====
function matchBrandColor(input) {
  if (!input || typeof input !== 'string') {
    return { matchType: 'invalid', input };
  }

  const raw = String(input).trim();

  // 分支 A：rgb() / rgba() 数值格式
  const rgbParsed = parseRgb(raw);
  if (rgbParsed) {
    const inner = matchRgb(rgbParsed);
    if (inner.matchType === 'none') return { ...inner, output: null };
    if (rgbParsed.alpha !== null) {
      return {
        ...inner,
        matchType:
          inner.matchType === 'exact' ? 'exact-with-alpha' : 'approximate-with-alpha',
        alpha: rgbParsed.alpha,
        output: `rgba(var(${inner.targetVar}-rgb), ${rgbParsed.alpha})`,
      };
    }
    return { ...inner, output: `var(${inner.targetVar})` };
  }

  // 分支 B：8 位 hex
  const parsed8 = parseHex8(raw);
  if (parsed8) {
    const inner = matchHex6(parsed8.hex6);
    if (inner.matchType === 'none') return { ...inner, output: null };
    // AA=FF 优先直接主变量
    if (parsed8.alphaHex === 'ff') {
      return { ...inner, output: `var(${inner.targetVar})`, alpha: 1 };
    }
    return {
      ...inner,
      matchType:
        inner.matchType === 'exact' ? 'exact-with-alpha' : 'approximate-with-alpha',
      alpha: parsed8.alpha,
      output: `rgba(var(${inner.targetVar}-rgb), ${parsed8.alpha})`,
    };
  }

  // 分支 C：6 位 hex
  const result = matchHex6(raw);
  return {
    ...result,
    output: result.targetVar ? `var(${result.targetVar})` : null,
  };
}

function matchHex6(hex) {
  const normalized = normalizeHex(hex);

  // 完全匹配（全表 30 色，大小写不敏感）
  if (BRAND_COLOR_MAP[normalized]) {
    return {
      matchType: 'exact',
      targetVar: BRAND_COLOR_MAP[normalized],
      baseHex: normalized,
      shade: 0,
      delta: 0,
      distance: 0,
    };
  }

  // 近似匹配（仅与 #0564f5 比较）
  const rgb = hex6ToRgb(normalized);
  if (!rgb) return { matchType: 'invalid', input: hex };

  return matchApprox(rgb, normalized);
}

function matchRgb(rgb, sourceLabel) {
  // 完全匹配：与全表 30 色任一 rgb 值完全相等
  for (const [baseHex, targetVar] of Object.entries(BRAND_COLOR_MAP)) {
    const baseRgb = hex6ToRgb(baseHex);
    if (baseRgb.r === rgb.r && baseRgb.g === rgb.g && baseRgb.b === rgb.b) {
      return { matchType: 'exact', targetVar, baseHex, shade: 0, delta: 0, distance: 0 };
    }
  }
  // 近似匹配：仅与 #0564f5 比较
  return matchApprox(rgb, sourceLabel);
}

// ===== 7. 导出 =====
module.exports = {
  BRAND_COLOR_MAP,
  THRESHOLDS,
  matchBrandColor,
  hex6ToRgb,
  parseHex8,
  parseRgb,
  channelDelta,
  euclideanDistance,
  classifyShade,
};

# neo-theme-skill · 工具脚本

本目录提供 Neo 主题换肤功能升级过程中的可执行工具脚本，作为 [SKILL.md](../SKILL.md) 迁移规则的可编程实现。

## 文件说明

| 文件 | 说明 | 使用场景 |
|:--|:--|:--|
| `neoThemeColorMatcher.js` | 硬编码色值 → Neo CSS 变量匹配决策引擎 | 迁移工具、pre-commit hook、CI 校验 |

## `neoThemeColorMatcher.js`

**功能**：给定一个硬编码色值（`#RRGGBB` / `#RRGGBBAA` / `rgb()` / `rgba()`），返回其应替换的 Neo 品牌 CSS 变量。

**匹配规则**（与 SKILL.md § 3.1 ~ § 3.1.2 完全对齐）：

1. **完全匹配**：与 [`BRAND_COLOR_MAP`](./neoThemeColorMatcher.js) 中列出的 18 个硬编码色值逐字符匹配（大小写不敏感）
2. **1-2 色阶近似匹配**：`Δ_ch ≤ 32` 且欧氏距离 `d ≤ 50`，按 Tiebreaker 选取最优候选
3. **8 位 hex 处理**：前 6 位命中 → 后 2 位 alpha 换算为十进制 → 输出 `rgba(var(--xxx-rgb), alpha)`；`AA=FF` 时直接用主变量
4. **rgb/rgba 数值格式**：解析后同样按上述规则匹配
5. **超阈值**：`matchType === 'none'`，保留原色值不替换

### 快速使用

```javascript
const { matchBrandColor } = require('./neoThemeColorMatcher');

matchBrandColor('#0564f5');
// { matchType: 'exact', targetVar: '--brand-color', output: 'var(--brand-color)', ... }

matchBrandColor('#0968f5');
// { matchType: 'approximate', targetVar: '--brand-color', shade: 1, delta: 4, distance: 5.7, output: 'var(--brand-color)' }

matchBrandColor('#0564f533');
// { matchType: 'exact-with-alpha', targetVar: '--brand-color', alpha: 0.2, output: 'rgba(var(--brand-color-rgb), 0.2)' }

matchBrandColor('#3080d0');
// { matchType: 'approximate', targetVar: '--brand-color', shade: 2, ... }  // 命中 2 色阶差候选

matchBrandColor('#ff0000');
// { matchType: 'none', output: null }  // 超阈值，不替换
```

### API 说明

| 导出项 | 说明 |
|:--|:--|
| `matchBrandColor(input)` | 主匹配函数，返回决策结果对象 |
| `BRAND_COLOR_MAP` | 硬编码色值 → CSS 变量映射表 |
| `THRESHOLDS` | 色阶差阈值常量 |
| `hex6ToRgb`, `parseHex8`, `parseRgb` | 色值解析工具 |
| `channelDelta`, `euclideanDistance` | 色差计算工具 |
| `classifyShade` | 色阶差判定 |

### 返回值 `matchType` 字段说明

| 值 | 含义 | 处理建议 |
|:--|:--|:--|
| `exact` | 完全匹配 6 位 hex 或 rgb() | 直接替换，无需报告标记 |
| `exact-with-alpha` | 完全匹配 + 8 位 hex 或 rgba() alpha | 替换为 rgba 形式（`AA=FF` 除外）|
| `approximate` | 1-2 色阶差近似匹配（6 位 hex 或 rgb()）| 替换 + 报告"近似匹配详情"标记 |
| `approximate-with-alpha` | 1-2 色阶差近似匹配 + alpha | 替换为 rgba 形式 + 报告标记 |
| `none` | 超阈值 / 未在映射表中 | 保留原色值，不替换 |
| `invalid` | 输入格式无法解析 | 记录到跳过详情 |

### 集成示例：批量扫描替换脚本

```javascript
const fs = require('fs');
const path = require('path');
const { matchBrandColor } = require('./neoThemeColorMatcher');

// 遍历文件，识别并替换硬编码色值
function migrateFile(filePath) {
  const src = fs.readFileSync(filePath, 'utf8');
  const HEX_RE = /#[0-9a-fA-F]{6,8}\b/g;
  const results = { exact: 0, approximate: 0, skipped: 0 };

  const migrated = src.replace(HEX_RE, (hex) => {
    const r = matchBrandColor(hex);
    if (r.matchType === 'exact' || r.matchType === 'exact-with-alpha') {
      results.exact++;
      return r.output;
    }
    if (r.matchType === 'approximate' || r.matchType === 'approximate-with-alpha') {
      results.approximate++;
      console.warn(`[近似匹配·${r.shade}色阶] ${filePath}: ${hex} → ${r.output} (基准 ${r.baseHex}, Δ=${r.delta}, d≈${r.distance})`);
      return r.output;
    }
    results.skipped++;
    return hex;
  });

  fs.writeFileSync(filePath, migrated);
  return results;
}

// 示例调用
const stats = migrateFile('src/components/Header.scss');
console.log('统计：', stats);
```

> ⚠️ **实际迁移仍需遵守 [SKILL.md § 3](../SKILL.md) 的完整规则**：变量名保护、注释保留、跳过场景、遗漏检测、报告生成等。本脚本仅提供匹配决策，不覆盖完整的替换编排。

## 相关文档

- [SKILL.md](../SKILL.md) — 主题换肤功能升级技能完整规则
- [references/theme-css-variables.md § 十一](../references/theme-css-variables.md) — CSS 变量参考 + 反向映射说明

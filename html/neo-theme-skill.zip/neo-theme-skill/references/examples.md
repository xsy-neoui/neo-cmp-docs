# 示例集：Primary 按钮改造 & 新建组件换肤规范

> 本文件是 `SKILL.md` 的配套示例。任务 3（Primary 按钮改造）的改造前后完整对照见第一节；新建支持换肤的组件时参考第二节规范。SKILL.md 中保留改造规则表，具体写法对照回本文件。

---

## 一、Primary 按钮改造前后示例对照

### 场景 A：白色背景轮廓 primary 按钮

```scss
/* ===== 改造前 ===== */
.button-primary {
  background: #fff;
  color: #0564f5;
  border: 1px solid #0564f5;

  &:hover {
    color: #4e80f5;
    border-color: #4e80f5;
  }

  &:active {
    color: #096dd9;
    border-color: #096dd9;
  }
}

/* ===== 改造后 ===== */
.button-primary {
  background: #fff;
  color: var(--color-button-filled-primary);
  border: 1px solid var(--color-button-filled-primary);

  &:hover {
    color: var(--color-button-filled-primary-hover);
    border-color: var(--color-button-filled-primary-hover);
  }

  &:active {
    color: var(--color-button-filled-primary-active);
    border-color: var(--color-button-filled-primary-active);
  }
}
```

### 场景 B：非白色背景填充 primary 按钮（无边框）

```scss
/* ===== 改造前 ===== */
.ant-btn-primary {
  background: #0564f5;
  color: #fff;
  border: none;

  &:hover { background: #4e80f5; }
  &:active { background: #096dd9; }
  &:disabled { background: #80bfff; }
}

/* ===== 改造后 ===== */
.ant-btn-primary {
  background: var(--color-button-filled-primary);
  color: var(--color-button-filled-primary-color);
  border: none;

  &:hover {
    background: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-color-hover);
  }
  &:active {
    background: var(--color-button-filled-primary-active);
    color: var(--color-button-filled-primary-color-hover);
  }
  &:disabled {
    background: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

### 场景 B'：非白色背景填充 primary 按钮（含 `border-color` / `border` 简写）

> 遵循 SKILL.md 5.3.1「按钮边框替换细则」：非白色背景 primary 按钮的 `border-color` 与 `border` 简写中的色值统一改用按钮字体色变量（`--color-button-filled-primary-color` / `--color-button-filled-primary-color-hover`），与 `color` 保持一致。

```scss
/* ===== 改造前 ===== */
.ant-btn-primary {
  background: #0564f5;
  color: #fff;
  border: 1px solid #0564f5;

  &:hover {
    background: #4e80f5;
    border-color: #4e80f5;
  }
  &:active {
    background: #096dd9;
    border-color: #096dd9;
  }
}

/* ===== 改造后 ===== */
.ant-btn-primary {
  background: var(--color-button-filled-primary);
  color: var(--color-button-filled-primary-color);
  border: 1px solid var(--color-button-filled-primary-color);

  &:hover {
    background: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-color-hover);
    border-color: var(--color-button-filled-primary-color-hover);
  }
  &:active {
    background: var(--color-button-filled-primary-active);
    color: var(--color-button-filled-primary-color-hover);
    border-color: var(--color-button-filled-primary-color-hover);
  }
}
```

> 💡 **要点**：
> - `border` 简写**只替换其中的色值部分**（`1px solid` 保留原样），色值使用按钮字体色变量。
> - `border-color` 直接整体替换为按钮字体色变量。
> - 状态分派与 `background` / `color` 一致：`&:hover` / `&:active` 使用 `-color-hover` 后缀变量。

### 场景 C：次按钮

```scss
/* ===== 改造前 ===== */
.btn-secondary {
  background: #a8d7ff;
  color: #fff;

  &:hover { background: #80bfff; }
  &:disabled { background: #e6f4ff; }
}

/* ===== 改造后 ===== */
.btn-secondary {
  background: var(--color-button-filled-primary-secondary);
  color: var(--color-button-filled-primary-color);

  &:hover { background: var(--color-button-filled-primary-secondary-hover); }
  &:disabled {
    background: var(--color-button-filled-primary-secondary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

---

## 二、新建组件换肤规范速查

> 当需要**新建**支持换肤的组件时，参考以下规范。

### 2.1 品牌色使用

```scss
.my-tab.active {
  border-left: 3px solid var(--brand-color);
  color: var(--color-text-brand);
  background: var(--color-bg-brand-tint);
}
```

### 2.2 按钮色使用

```scss
.btn-primary {
  background-color: var(--color-button-filled-primary, #0564f5);
  color: var(--color-button-filled-primary-color);

  &:hover { background-color: var(--color-button-filled-primary-hover); }
  &:active { background-color: var(--color-button-filled-primary-active); }
  &:disabled {
    background-color: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
  }
}
```

### 2.3 要素映射表

| 元素 | CSS 变量 |
|:--|:--|
| 填充按钮背景 | `--color-button-filled-primary` |
| 轮廓按钮边框/文字 | `--color-button-filled-primary`（复用） |
| 文本按钮颜色 | `--color-button-filled-primary`（复用） |
| 链接文字 | `--color-text-brand-link`（正常）→ `--color-text-brand-hover`（悬停） |
| 输入框聚焦边框 | `--color-border-brand` |
| 关键数据文字 | `--color-text-brand` |
| 浅色背景卡片 | `--color-bg-brand-tint` |
| 半透明覆盖层 | `rgba(var(--brand-color-rgb), 0.15)` |


---

## 三、任务 1 操作要求示例集

> 本节收录 `SKILL.md` § 3.2「操作要求」1~5 条的示例代码。SKILL.md 中保留规则，具体写法对照回本节。

### 3.1 要求 2：注释保留原有写法

**SCSS / Less（使用 `//` 注释）**：

```scss
/* 替换前 */
.button {
  background-color: #0564f5;
}

/* 替换后 */
.button {
  // background-color: #0564f5;
  background-color: var(--brand-color);
}
```

**CSS（使用 `/* */` 注释）**：

```css
/* 替换前 */
.button {
  background-color: #0564f5;
}

/* 替换后 */
.button {
  /* background-color: #0564f5; */
  background-color: var(--brand-color);
}
```

**TSX / JSX / TS / JS（不注释，直接替换）**：

```tsx
// 替换前
<div style={{ color: '#0564f5' }} />

// 替换后
<div style={{ color: 'var(--brand-color)' }} />
```

### 3.2 要求 5：rgba 使用 -rgb 伴侣变量

```
rgba(5, 100, 245, 0.2)  → rgba(var(--brand-color-rgb), 0.2)
rgba(78, 128, 245, 0.15) → rgba(var(--brand-color-hover-rgb), 0.15)
```

**核心原则**：保留原始透明度，仅替换颜色分量部分，alpha 值原样保留。

`rgb()` 格式的色值按常规 hex 色值方式替换为 `var(--brand-color)` 等 hex 主变量。

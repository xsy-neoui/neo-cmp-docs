# Neo 平台主题 CSS 变量完整参考

> 以下为 `TokenHelper.setBaseColor('#0564f5')` 时的默认值。实际运行时由 TokenHelper 动态计算并注入，不同主题下取值不同。
>
> **核心设计**：每个 Hex 主变量均配有 `-rgb` 伴侣变量（纯数值格式如 `5, 100, 245`），专用于 `rgba()` 半透明场景。
>
> **两个视角**：
> - **正向查询**（本文档 一~十 节）：Neo 平台提供哪些 CSS 变量、默认色值是什么、如何在组件中使用
> - **反向映射**（本文档 十一 节）：历史项目中的硬编码色值应如何迁移为对应的 CSS 变量（含 1-2 色阶近似匹配规则与工具脚本），与 [SKILL.md § 3](../SKILL.md) 的迁移规则完全对齐

---

## 一、品牌核心变量（6 对，hex + -rgb）

| CSS 变量 | -rgb 伴侣变量 | 默认色值 | 说明 |
|:--|:--|:--|:--|
| `--brand-color` | `--brand-color-rgb` | `#0564f5` | 品牌主色，所有品牌色体系的根源 |
| `--brand-color-hover` | `--brand-color-hover-rgb` | `#1a7aff` | 品牌 Hover 色，各元素 hover 交互态 |
| `--brand-color-shade` | `--brand-color-shade-rgb` | `#004ccf` | 品牌深色变体，active / 按下 / 选中态 |
| `--brand-color-tint` | `--brand-color-tint-rgb` | `#e6f4ff` | 品牌最浅变体，大面积背景底色 |
| `--brand-color-tint-light` | `--brand-color-tint-light-rgb` | `#a8d7ff` | 品牌次浅变体，浅色背景 / hover 背景 |
| `--brand-color-disabled` | `--brand-color-disabled-rgb` | `#80bfff` | 品牌禁用态 |

### 使用示例

```scss
/* 直接使用品牌主色 */
.page-title {
  color: var(--brand-color);
}

/* 选中/激活态（左侧竖线标识） */
.menu-item.active {
  border-left: 3px solid var(--brand-color);
  color: var(--color-text-brand);
  background-color: var(--color-bg-brand-tint);
}

/* hover 交互态 */
.menu-item:hover {
  background-color: var(--color-bg-brand-tint-light);
  color: var(--color-text-brand-hover);
}

/* 半透明覆盖层（使用 -rgb 伴侣变量） */
.overlay {
  background: rgba(var(--brand-color-rgb), 0.72);
  backdrop-filter: blur(10px);
}

/* 半透明 hover 背景 */
.item:hover {
  background: rgba(var(--brand-color-rgb), 0.08);
}
```

---

## 二、语义化 Brand Token — 背景 Background（6 个，均级联自品牌变量）

| CSS 变量 | -rgb 伴侣变量 | 级联自 | 说明 |
|:--|:--|:--|:--|
| `--color-bg-brand` | `--color-bg-brand-rgb` | `var(--brand-color)` | 品牌主色背景，强品牌感区块底色 |
| `--color-bg-brand-hover` | `--color-bg-brand-hover-rgb` | `var(--brand-color-hover)` | 品牌 Hover 背景 |
| `--color-bg-brand-shade` | `--color-bg-brand-shade-rgb` | `var(--brand-color-shade)` | 品牌深色背景，重点强调区域 |
| `--color-bg-brand-tint` | `--color-bg-brand-tint-rgb` | `var(--brand-color-tint)` | 品牌浅色背景，卡片 / 选中行轻量底色 |
| `--color-bg-brand-tint-light` | `--color-bg-brand-tint-light-rgb` | `var(--brand-color-tint-light)` | 品牌次浅色背景 |
| `--color-bg-brand-disabled` | `--color-bg-brand-disabled-rgb` | `var(--brand-color-disabled)` | 品牌禁用态背景 |

> 每个变量均有对应的 `-rgb` 伴侣变量（如 `--color-bg-brand-rgb`）。

### 使用示例

```scss
/* 强品牌感 Banner 区域 */
.banner {
  background: var(--color-bg-brand);
  color: #ffffff;
}

/* 浅色背景卡片 */
.stat-card {
  background: var(--color-bg-brand-tint);
  border: 1px solid var(--color-border-brand-tint);
  border-radius: 12px;
  padding: 20px;

  &:hover {
    background: var(--color-bg-brand-hover);
    color: #ffffff; /* 深色背景上文字变白 */
  }
}

/* 禁用态背景 */
.card.disabled {
  background: var(--color-bg-brand-disabled);
  cursor: not-allowed;
}
```

---

## 三、语义化 Brand Token — 边框 Border（6 个）

| CSS 变量 | -rgb 伴侣变量 | 级联自 | 说明 |
|:--|:--|:--|:--|
| `--color-border-brand` | `--color-border-brand-rgb` | `var(--brand-color)` | 品牌主色边框，input focus / 选中边框 |
| `--color-border-brand-hover` | `--color-border-brand-hover-rgb` | `var(--brand-color-hover)` | 品牌 Hover 边框 |
| `--color-border-brand-shade` | `--color-border-brand-shade-rgb` | `var(--brand-color-shade)` | 品牌深色边框 |
| `--color-border-brand-tint` | `--color-border-brand-tint-rgb` | `var(--brand-color-tint)` | 品牌浅色边框 |
| `--color-border-brand-tint-light` | `--color-border-brand-tint-light-rgb` | `var(--brand-color-tint-light)` | 品牌次浅色边框 |
| `--color-border-brand-disabled` | `--color-border-brand-disabled-rgb` | `var(--brand-color-disabled)` | 品牌禁用态边框 |

### 使用示例

```scss
/* 输入框聚焦 */
.input:focus,
.select-open {
  border-color: var(--color-border-brand);
  box-shadow: 0 0 0 2px rgba(var(--color-border-brand-rgb), 0.15);
  outline: none;
}

/* 虚线分割线 */
.divider {
  border-top: 1px dashed var(--color-border-brand-tint);
}

/* hover 边框加深 */
.card:hover {
  border-color: var(--color-border-brand-hover);
  box-shadow: 0 4px 16px rgba(var(--color-border-brand-hover-rgb), 0.2);
}
```

---

## 四、语义化 Brand Token — 图标 Icon（7 个）

| CSS 变量 | -rgb 伴侣变量 | 级联自 | 说明 |
|:--|:--|:--|:--|
| `--color-icon-brand` | `--color-icon-brand-rgb` | `var(--brand-color)` | 图标主色，功能图标正常态 |
| `--color-icon-brand-hover` | `--color-icon-brand-hover-rgb` | `var(--brand-color-hover)` | 图标 Hover 色 |
| `--color-icon-brand-shade` | `--color-icon-brand-shade-rgb` | `var(--brand-color-shade)` | 图标深色，active 态 |
| `--color-icon-brand-tint` | `--color-icon-brand-tint-rgb` | `var(--brand-color-tint)` | 图标浅色 |
| `--color-icon-brand-tint-light` | `--color-icon-brand-tint-light-rgb` | `var(--brand-color-tint-light)` | 图标次浅色 |
| `--color-icon-fill-brand-link` | `--color-icon-fill-brand-link-rgb` | `var(--brand-color-shade)` | 图标链接色，可点击图标 hover 交互色 |
| `--color-icon-brand-disabled` | `--color-icon-brand-disabled-rgb` | `var(--brand-color-disabled)` | 图标禁用色 |

### 使用示例

```scss
/* 实心图标 */
.icon-solid {
  background: var(--color-icon-brand);
  color: #ffffff;

  &:hover {
    background: var(--color-icon-brand-hover);
    box-shadow: 0 4px 12px rgba(var(--color-icon-brand-hover-rgb), 0.35);
  }
}

/* 线框图标 */
.icon-outline {
  background: transparent;
  color: var(--color-icon-brand);
  border: 2px solid var(--color-border-brand);

  &:hover {
    color: var(--color-icon-brand-hover);
    border-color: var(--color-border-brand-hover);
    background: rgba(var(--color-icon-brand-hover-rgb), 0.06);
  }
}

/* 可点击链接图标 */
.icon-link:hover {
  color: var(--color-icon-fill-brand-link);
  transform: scale(1.15);
}

/* 浅底图标 */
.icon-tint {
  background: var(--color-icon-brand-tint);
  color: var(--color-icon-brand);
  border-color: var(--color-border-brand-tint);
}

/* 禁用图标 */
.icon-disabled {
  color: var(--color-icon-brand-disabled);
  cursor: not-allowed;
}
```

---

## 五、语义化 Brand Token — 文本 & 文字链接 Text（7 个）

| CSS 变量 | -rgb 伴侣变量 | 级联自 | 说明 |
|:--|:--|:--|:--|
| `--color-text-brand` | `--color-text-brand-rgb` | `var(--brand-color)` | 品牌色文字，关键数据 / 主标题 / 链接基础色 |
| `--color-text-brand-hover` | `--color-text-brand-hover-rgb` | `var(--brand-color-hover)` | 品牌 Hover 文字色 |
| `--color-text-brand-shade` | `--color-text-brand-shade-rgb` | `var(--brand-color-shade)` | 品牌深色文字，链接 active 态 |
| `--color-text-brand-tint` | `--color-text-brand-tint-rgb` | `var(--brand-color-tint)` | 品牌浅色文字底 |
| `--color-text-brand-tint-light` | `--color-text-brand-tint-light-rgb` | `var(--brand-color-tint-light)` | 品牌次浅色文字 |
| `--color-text-brand-disabled` | `--color-text-brand-disabled-rgb` | `var(--brand-color-disabled)` | 品牌禁用态文字色 |
| `--color-text-brand-link` | `--color-text-brand-link-rgb` | `var(--brand-color-shade)` | 文字链接色，hover 加深效果 |

### 使用示例

```scss
/* 关键数据指标 */
.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: var(--color-text-brand);

  &:hover {
    color: var(--color-text-brand-hover);
  }
}

/* 文字链接 */
.text-link {
  color: var(--color-text-brand-link);
  cursor: pointer;

  &:hover {
    color: var(--color-text-brand-hover);
    text-decoration: underline;
  }
}

/* 浅底高亮文本 */
.highlight {
  background: var(--color-bg-brand-tint);
  color: var(--color-text-brand);
  border-radius: 8px;
  padding: 12px 16px;
}

/* 禁用态文字 */
.text-disabled {
  color: var(--color-text-brand-disabled);
  cursor: not-allowed;
}

/* 带图标箭头的链接文本 */
.link-item {
  color: var(--color-text-brand-link);
  display: flex;
  align-items: center;
  gap: 4px;

  &:hover {
    color: var(--color-text-brand-hover);
    background: var(--color-bg-brand-tint);
  }

  &__arrow {
    transition: transform 0.2s ease;
  }

  &:hover &__arrow {
    color: var(--color-icon-brand-hover);
    transform: translateX(4px);
  }
}
```

---

## 六、按钮色变量

> ★ **核心说明**：`--color-button-filled-primary-*` 系列变量用于实心底色按钮背景色，同时可复用于白色背景按钮的 **border 边框**、**outline 描边**、**text 文字**的颜色。即 fill / border / outline / text 四种按钮形态共用这一套变量。

### 6.1 背景色（5 个，均配有 -rgb 伴侣）

| CSS 变量 | -rgb 伴侣变量 | 级联自 | 说明 |
|:--|:--|:--|:--|
| `--color-button-filled-primary` | `--color-button-filled-primary-rgb` | `var(--color-bg-brand)` | 正常态背景色（★ 同时可用于 border/outline/text 颜色） |
| `--color-button-filled-primary-hover` | `--color-button-filled-primary-hover-rgb` | `var(--color-bg-brand-hover)` | 鼠标悬停背景色 |
| `--color-button-filled-primary-active` | `--color-button-filled-primary-active-rgb` | `var(--color-bg-brand-shade)` | 点击按下背景色 |
| `--color-button-filled-primary-tint` | `--color-button-filled-primary-tint-rgb` | `var(--color-bg-brand-tint)` | 浅色背景 |
| `--color-button-filled-primary-disabled` | `--color-button-filled-primary-disabled-rgb` | `var(--color-bg-brand-disabled)` | 禁用态背景色 |

### 6.2 文字色（3 个）

| CSS 变量 | 级联自 | 说明 |
|:--|:--|:--|
| `--color-button-filled-primary-color` | `var(--color-neutral-0)` | 正常态文字色（自动对比色） |
| `--color-button-filled-primary-color-hover` | `var(--color-neutral-0)` | 悬停文字色 |
| `--color-button-filled-primary-color-disabled` | `var(--color-text-aid)` | 禁用文字色 |

### 6.3 次按钮变量（3 个，均配有 -rgb 伴侣）

| CSS 变量 | -rgb 伴侣变量 | 说明 |
|:--|:--|:--|
| `--color-button-filled-primary-secondary` | `--color-button-filled-primary-secondary-rgb` | ★ 次按钮 — 正常态背景（降一级变浅，colors[4]） |
| `--color-button-filled-primary-secondary-hover` | `--color-button-filled-primary-secondary-hover-rgb` | ★ 次按钮 — 悬停态背景（比 hover 降一级变浅） |
| `--color-button-filled-primary-secondary-disabled` | `--color-button-filled-primary-secondary-disabled-rgb` | ★ 次按钮 — 禁用态背景（比 disabled 降一级变浅） |

### 使用示例

#### 填充主按钮

```scss
.btn-primary {
  background-color: var(--color-button-filled-primary);
  color: var(--color-button-filled-primary-color);
  border: none;
  border-radius: 8px;
  padding: 10px 24px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-color-hover);
    box-shadow: 0 4px 14px rgba(var(--color-button-filled-primary-rgb), 0.25);
  }

  &:active {
    background-color: var(--color-button-filled-primary-active);
  }

  &:disabled {
    background-color: var(--color-button-filled-primary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
    cursor: not-allowed;
    box-shadow: none;
  }
}
```

#### 轮廓按钮（白色背景，border + text 复用主色）

```scss
.btn-outline-primary {
  background: transparent;
  color: var(--color-button-filled-primary);
  border: 2px solid var(--color-button-filled-primary);
  border-radius: 8px;
  padding: 10px 20px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    background: rgba(var(--color-button-filled-primary-rgb), 0.08);
    border-color: var(--color-button-filled-primary-hover);
    color: var(--color-button-filled-primary-hover);
  }

  &:active {
    border-color: var(--color-button-filled-primary-active);
    color: var(--color-button-filled-primary-active);
  }
}
```

#### 文字按钮（text 复用主色）

```scss
.btn-text-primary {
  background: transparent;
  color: var(--color-button-filled-primary);
  border: 1px solid transparent;
  padding: 10px 14px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    background: rgba(var(--color-button-filled-primary-rgb), 0.08);
    color: var(--color-button-filled-primary-hover);
  }
}
```

#### 次按钮

```scss
.btn-secondary {
  background-color: var(--color-button-filled-primary-secondary);
  color: var(--color-button-filled-primary-color);
  border: none;
  border-radius: 8px;
  padding: 8px 18px;
  cursor: pointer;

  &:hover {
    background-color: var(--color-button-filled-primary-secondary-hover);
    box-shadow: 0 2px 8px rgba(var(--color-button-filled-primary-secondary-rgb), 0.25);
  }

  &:disabled {
    background-color: var(--color-button-filled-primary-secondary-disabled);
    color: var(--color-button-filled-primary-color-disabled);
    cursor: not-allowed;
  }
}
```

---

## 七、导航 Banner 色变量（11 个）

| CSS 变量 | -rgb 伴侣变量 | 说明 |
|:--|:--|:--|
| `--brand-nav-header-bg` | `--brand-nav-header-bg-rgb` | 导航栏背景色 |
| `--brand-nav-header-font` | `--brand-nav-header-font-rgb` | 导航栏标题 / 正文文字色（自动识别深浅色） |
| `--brand-nav-header-font-hover` | `--brand-nav-header-font-hover-rgb` | 导航栏文字 Hover 态 |
| `--brand-nav-header-icon` | `--brand-nav-header-icon-rgb` | 导航栏图标色（返回 / 关闭等） |
| `--brand-nav-header-icon-hover` | `--brand-nav-header-icon-hover-rgb` | 导航栏图标 Hover 态 |
| `--brand-nav-header-launcher-icon` | `--brand-nav-header-launcher-icon-rgb` | 启动器图标色（使用品牌色） |
| `--brand-nav-header-select` | `--brand-nav-header-select-rgb` | 选中项高亮色（使用品牌深色变体） |
| `--brand-nav-header-select-bg` | `--brand-nav-header-select-bg-rgb` | 导航栏选中项背景色 |
| `--brand-nav-header-elem-opacity` | `--brand-nav-header-elem-opacity-rgb` | 导航元素半透明层 |
| `--brand-nav-header-elem-hover` | `--brand-nav-header-elem-hover-rgb` | 导航元素悬停背景色 |
| `--brand-nav-header-placeholder` | `--brand-nav-header-placeholder-rgb` | 导航栏输入框占位符色 |

### 使用示例

```scss
/* 导航栏整体 */
.nav-bar {
  background-color: var(--brand-nav-header-bg);
  color: var(--brand-nav-header-font);
  display: flex;
  align-items: center;
  padding: 12px 20px;
}

/* 返回/关闭图标 */
.nav-bar .back-icon {
  color: var(--brand-nav-header-icon);

  &:hover {
    color: var(--brand-nav-header-icon-hover);
  }
}

/* 导航栏标题 */
.nav-bar .title {
  color: var(--brand-nav-header-font);
  font-size: 17px;
  font-weight: 600;

  &:hover {
    color: var(--brand-nav-header-font-hover);
  }
}

/* 导航菜单项悬停 */
.nav-bar .menu-item:hover {
  background: var(--brand-nav-header-elem-hover);
}

/* 当前选中项 */
.nav-bar .menu-item.active {
  color: var(--brand-nav-header-select);
  background: var(--brand-nav-header-select-bg);
}

/* 启动器图标 */
.nav-bar .launcher-icon {
  color: var(--brand-nav-header-launcher-icon);
}
```

---

## 八、-rgb 伴侣变量使用规范

每个 Hex 主变量都配有对应的 `-rgb` 伴侣变量，专用于 `rgba()` 半透明场景。

### 格式

```
rgba(var(--xxx-rgb), <alpha>)
```

### 使用场景

```scss
/* 场景 1：半透明背景覆盖层 */
.overlay {
  background: rgba(var(--brand-color-rgb), 0.72);
  backdrop-filter: blur(10px);
}

/* 场景 2：hover 态半透明背景 */
.card:hover {
  background: rgba(var(--color-bg-brand-rgb), 0.08);
}

/* 场景 3：按钮 hover 半透明叠加 */
.btn:hover {
  background: rgba(var(--color-button-filled-primary-rgb), 0.08);
}

/* 场景 4：阴影色 */
.shadow {
  box-shadow: 0 4px 16px rgba(var(--brand-color-rgb), 0.25);
}

/* 场景 5：边框发光 */
.glow {
  box-shadow: 0 0 0 3px rgba(var(--color-border-brand-rgb), 0.15);
}
```

---

## 九、Fallback 默认值使用规范

建议为所有 CSS 变量添加 fallback 值，确保变量未加载时也有默认表现：

```scss
/* ✅ 推荐：提供 fallback 默认值 */
.button {
  background-color: var(--color-button-filled-primary, #0564f5);
  border-color: var(--color-border-brand, #0564f5);
  color: var(--color-text-brand, #0564f5);
}

.link {
  color: var(--color-text-brand-link, #004ccf);
}
```

---

## 十、ECharts 场景使用规范

ECharts 不支持 `var(--css-variable)` 写法，需通过 `getCssVarHex()` 转换：

```tsx
import { getCssVarHex } from 'neo-ui-common/tokenHelper';

const MyChart: React.FC = () => {
  const brandColor = getCssVarHex('--brand-color');
  const brandColorShade = getCssVarHex('--brand-color-shade');
  const brandColorTint = getCssVarHex('--color-bg-brand-tint');

  const option = {
    color: [brandColor, brandColorShade],
    series: [{
      type: 'bar',
      itemStyle: { color: brandColor },
      emphasis: { itemStyle: { color: brandColorShade } },
    }],
    backgroundColor: brandColorTint,
  };

  return <ReactECharts option={option} />;
};
```

> ⚠️ **ECharts 配置里的硬编码色值一律跳过、不替换为 `var(--xxx)`**：ECharts 不解析 CSS 变量，直接写 `var(--brand-color)` 会失效。识别 ECharts option 时**必须回溯到最外层 option 对象**，并覆盖以下三种形态（任一命中即整体跳过）：
> 1. **内联/变量式 option**：任意层级命中 `series[].type`、`xAxis`、`yAxis`、`legend`、`grid`、`visualMap`、`dataZoom` 等专有属性；
> 2. **深层嵌套色值**：色值祖先 key 链含 ECharts 专有 key，如 `legend.pageIconColor`、`xAxis.nameTextStyle.color`、`series[].itemStyle.color`；
> 3. **独立配置模块**：经 `define()`（AMD）/ `export default` / `module.exports` / 工厂函数 `return` 导出、且顶层同时含 ≥2 个 ECharts 顶层 option 键（`title`/`grid`/`legend`/`xAxis`/`yAxis`/`series`/`tooltip`/`visualMap`/`dataZoom` 等）的对象——**即使该文件不 `import echarts`、不使用 `<ReactECharts>`、变量不叫 `option`，也须整体判定为 ECharts 配置并跳过其中所有硬编码色值**。
>
> 完整判定细则见 [SKILL.md](../SKILL.md) 要求 4 补充「ECharts 判定细则」。

---

## 十一、历史硬编码色值 → CSS 变量映射参考

> 本节为 Neo 主题换肤功能升级技能（`neo-theme-skill`）的运行时对齐参考。定义了 Neo 平台历史项目中常见的硬编码品牌色值，与本文档 一~七 节所列 CSS 变量之间的**反向映射规则**。
>
> 内容与 [SKILL.md § 3.1](../SKILL.md) 及 [color-matching-details.md](color-matching-details.md) 保持完全一致，任一处调整须同步更新。

### 11.1 硬编码色值完整映射表

**主品牌色（→ `var(--brand-color)`）**：Neo 平台历史项目中常见的品牌主色变体，含 Ant Design v4/v5、TDesign 及内部约定色值。

| 类别 | 6 位 Hex（大小写） | RGB 十进制 | 8 位变体（含透明度） |
|:--|:--|:--|:--|
| Neo 标准主色 | `#0564f5` / `#0564F5` | `rgb(5, 100, 245)` | `#0564f5<AA>` |
| Ant Design v4 主色 | `#096dd9` / `#096DD9` | `rgb(9, 109, 217)` | `#096dd9<AA>` |
| 深蓝变体 | `#2065cf` / `#2065CF` | `rgb(32, 101, 207)` | `#2065cf<AA>` |
| 亮蓝变体 | `#1d77ff` / `#1D77FF` | `rgb(29, 119, 255)` | `#1d77ff<AA>` |
| Ant Design v5 主色 | `#1677ff` / `#1677FF` | `rgb(22, 119, 255)` | `#1677ff<AA>` |
| TDesign 主色 | `#0052d9` / `#0052D9` | `rgb(0, 82, 217)` | `#0052d9<AA>` |
| 内部约定 | `#2b7fff` / `#2B7FFF` | `rgb(43, 127, 255)` | `#2b7fff<AA>` |
| 内部约定 | `#0060df` / `#0060DF` | `rgb(0, 96, 223)` | `#0060df<AA>` |
| 亮蓝主色变体 | `#1a7aff` / `#1A7AFF` | `rgb(26, 122, 255)` | `#1a7aff<AA>` |
| 实战补充·高频变体 | `#257cff` / `#257CFF` | `rgb(37, 124, 255)` | `#257cff<AA>` |
| 实战补充·高频变体 | `#0656d5` / `#0656D5` | `rgb(6, 86, 213)` | `#0656d5<AA>` |
| 实战补充·Bootstrap 主蓝 | `#007bff` / `#007BFF` | `rgb(0, 123, 255)` | `#007bff<AA>` |
| 实战补充·高频变体 | `#2468f2` / `#2468F2` | `rgb(36, 104, 242)` | `#2468f2<AA>` |
| 实战补充·高频变体 | `#1c61da` / `#1C61DA` | `rgb(28, 97, 218)` | `#1c61da<AA>` |
| 实战补充·高频变体 | `#1865d9` / `#1865D9` | `rgb(24, 101, 217)` | `#1865d9<AA>` |
| 实战补充·Tailwind blue-600 | `#2563eb` / `#2563EB` | `rgb(37, 99, 235)` | `#2563eb<AA>` |
| 实战补充·Tailwind blue-700 | `#1d4ed8` / `#1D4ED8` | `rgb(29, 78, 216)` | `#1d4ed8<AA>` |
| 实战补充·amis cxd 主色 | `#047bdb` / `#047BDB` | `rgb(4, 123, 219)` | `#047bdb<AA>` |
| 实战补充·高频变体 | `#1758e7` / `#1758E7` | `rgb(23, 88, 231)` | `#1758e7<AA>` |
| 实战补充·高频变体 | `#007eff` / `#007EFF` | `rgb(0, 126, 255)` | `#007eff<AA>` |

> 💡 **关于「实战补充」11 色**：这些色值与基准 `#0564f5` 相差 1-2 色阶，本应由 11.2 近似匹配命中。但历史项目扫描中，近似色因无法被固定 grep 捞出而屡屡漏网（详见 [SKILL.md § 3.1.5 近似色执行缺口修补](../SKILL.md)）。为保证 grep + 替换的确定性，已将其升级为**完全匹配**，全部映射为 `var(--brand-color)`。

**次品牌色（→ `var(--brand-color-hover)`）**：hover 交互态色值变体。

| 类别 | 6 位 Hex（大小写） | RGB 十进制 | 8 位变体（含透明度） |
|:--|:--|:--|:--|
| Neo 标准 hover | `#4e80f5` / `#4E80F5` | `rgb(78, 128, 245)` | `#4e80f5<AA>` |
| Ant Design v4 hover | `#1890ff` / `#1890FF` | `rgb(24, 144, 255)` | `#1890ff<AA>` |
| Ant Design 浅蓝 | `#40a9ff` / `#40A9FF` | `rgb(64, 169, 255)` | `#40a9ff<AA>` |
| 变体 | `#3886fb` / `#3886FB` | `rgb(56, 134, 251)` | `#3886fb<AA>` |
| 变体 | `#238dff` / `#238DFF` | `rgb(35, 141, 255)` | `#238dff<AA>` |
| 变体 | `#3783ff` / `#3783FF` | `rgb(55, 131, 255)` | `#3783ff<AA>` |
| Ant Design v5 hover | `#4096ff` / `#4096FF` | `rgb(64, 150, 255)` | `#4096ff<AA>` |
| AntV 常用蓝 | `#5b8ff9` / `#5B8FF9` | `rgb(91, 143, 249)` | `#5b8ff9<AA>` |
| Ant Design 极浅蓝 | `#69c0ff` / `#69C0FF` | `rgb(105, 192, 255)` | `#69c0ff<AA>` |
| 灰蓝变体 | `#4ca1dc` / `#4CA1DC` | `rgb(76, 161, 220)` | `#4ca1dc<AA>` |

**替换目标**：

- 6 位 Hex `#RRGGBB` → 主变量 `var(--brand-color)` 或 `var(--brand-color-hover)`
- `rgb(r, g, b)` → 主变量 `var(--brand-color)` 或 `var(--brand-color-hover)`
- `rgba(r, g, b, a)` → 伴侣变量 `rgba(var(--brand-color-rgb), a)` 或 `rgba(var(--brand-color-hover-rgb), a)`
- 8 位 Hex `#RRGGBBAA` → 伴侣变量 `rgba(var(--xxx-rgb), <alpha_decimal>)`（`AA=FF` 时优先直接用主变量）

### 11.2 近似色匹配阈值（仅以 `#0564f5` 为基准，1-2 色阶差自动推断）

未在 11.1 表中完全列出的色值，若与**唯一基准色 `#0564f5`（rgb(5, 100, 245)）差异极小（≤ 2 色阶）**，推断为主品牌色的近似变体并替换为 `var(--brand-color)`。

> 🚨 **单一基准原则**：近似匹配**只与 `#0564f5` 比较**，**不与 11.1 表中其他色值（含次品牌色）比较**。表中其余色值仅参与「完全匹配」。次品牌色 `var(--brand-color-hover)` 仅通过完全匹配命中，不通过近似匹配命中。

**差异度量**（`Cs = 源色, Ct = #0564f5 = (5, 100, 245)`）：

- 单通道最大差异：`Δ_ch = max(|Rs - Rt|, |Gs - Gt|, |Bs - Bt|)`
- 欧氏距离：`d = √((Rs-Rt)² + (Gs-Gt)² + (Bs-Bt)²)`

**判定阈值**（`Δ_ch` 与 `d` 需**同时满足**对应区间）：

| 相似度 | Δ_ch | d | 判定 | 处理 |
|:--|:--|:--|:--|:--|
| 完全匹配 | = 0 | = 0 | ✅ 命中 | 直接替换，无需报告标记 |
| 1 色阶差 | ≤ 16 | ≤ 25 | ✅ 近似命中 | 替换为 `var(--brand-color)` + 报告标记 `[近似匹配·1色阶]` |
| 2 色阶差 | ≤ 32 且 > 16 | ≤ 50 且 > 25 | ✅ 近似命中 | 替换为 `var(--brand-color)` + 报告标记 `[近似匹配·2色阶]` |
| 超阈值 | > 32 或 > 50 | — | ❌ 不命中 | 保留原样，不替换 |

**单一基准，无多候选歧义**：基准恒为 `#0564f5`、目标恒为 `var(--brand-color)`，不存在多候选，也无需 Tiebreaker。即便源色值靠近 `#2065cf`、`#4e80f5` 等表中其他蓝色，只要它与 `#0564f5` 超阈值就一律保留原样。

### 11.3 8 位十六进制色值（含透明度）处理规则

**匹配流程**：

1. 取 `#RRGGBBAA` 的**前 6 位** `#RRGGBB`（大小写不敏感）
2. 按 11.1（完全匹配）或 11.2（1-2 色阶近似）判定基准
3. 若命中 → 后 2 位 `AA` 换算为 0-1 十进制 alpha
4. 若前 6 位未命中且非近似色 → 保留原样

**alpha 换算公式**：`alpha_decimal = round(parseInt(AA, 16) / 255, 2)`

**alpha 常用值对照**：

| Hex | Decimal | 语义 | Hex | Decimal | 语义 |
|:--|:--|:--|:--|:--|:--|
| `00` | `0` | 完全透明 | `80` | `0.5` | 50% 半透明 |
| `0D` | `0.05` | 5% | `99` | `0.6` | 60% |
| `1A` | `0.1` | 10% | `B3` | `0.7` | 70% |
| `26` | `0.15` | 15% | `CC` | `0.8` | 80% |
| `33` | `0.2` | 20% | `E6` | `0.9` | 90% |
| `40` | `0.25` | 25% | `F2` | `0.95` | 95% |
| `4D` | `0.3` | 30% | `FF` | `1` | 完全不透明 |
| `66` | `0.4` | 40% |  |  |  |

**特殊边界规则**：

- `AA = FF` → 直接替换为主变量 `var(--xxx)`（不使用 rgba 形式）
- `AA = 00` → 保持 `rgba(var(--xxx-rgb), 0)` 写法
- 其他 `AA` → 按公式实时换算，保留 2 位小数

**示例**：

```
#0564f533 → rgba(var(--brand-color-rgb), 0.2)
#0564f580 → rgba(var(--brand-color-rgb), 0.5)
#0564f5ff → var(--brand-color)              (AA=FF，直接主变量)
#4e80f533 → rgba(var(--brand-color-hover-rgb), 0.2)
#0968f533 → rgba(var(--brand-color-rgb), 0.2) [近似匹配·1色阶]
```

### 11.4 内置匹配工具脚本（JavaScript / Node.js）

硬编码色值 → CSS 变量的**可编程决策引擎**已抽取为独立脚本（避免同一逻辑在多处重复维护）：

- 源码：[`scripts/neoThemeColorMatcher.js`](../scripts/neoThemeColorMatcher.js)
- 说明与用法：[`scripts/README.md`](../scripts/README.md)

该脚本导出 `matchBrandColor(input)`，行为与本节 11.1 ~ 11.3 完全一致：

- **完全匹配**：与 31 个色值逐一比对（大小写不敏感），命中即用其目标变量（主色 / 次色）
- **近似匹配**：未完全命中时**仅与 `#0564f5` 比较**（1-2 色阶差），命中一律映射为 `--brand-color`；不与其他色值做近似比较
- **8 位 hex / rgba**：前 6 位（或 rgb 三通道）命中后按 alpha 换算输出 `rgba(var(--xxx-rgb), a)`；`AA=FF` 直接用主变量
- **超阈值 / 无法解析**：返回 `matchType: 'none' / 'invalid'`，保留原色值

> ⚠️ 本脚本仅提供匹配决策，完整迁移编排（变量名保护、注释保留、跳过场景、遗漏检测、报告生成）仍以 [SKILL.md § 3](../SKILL.md) 为准。

### 11.5 使用示例

以下示例均基于 11.1 完整映射表（31 个候选）实测，可复制到 Node.js 环境验证。

```javascript
const { matchBrandColor } = require('../scripts/neoThemeColorMatcher');

// 示例 1：完全匹配 6 位 hex
matchBrandColor('#0564f5');
// {
//   matchType: 'exact',
//   targetVar: '--brand-color',
//   baseHex: '#0564f5',
//   shade: 0, delta: 0, distance: 0,
//   output: 'var(--brand-color)'
// }

// 示例 2：1 色阶差近似匹配（Δ=4, d≈5.7）
matchBrandColor('#0968f5');
// {
//   matchType: 'approximate',
//   targetVar: '--brand-color',
//   baseHex: '#0564f5',
//   shade: 1, delta: 4, distance: 5.7,
//   output: 'var(--brand-color)'
// }

// 示例 3：8 位 hex（带透明度）— 前 6 位完全匹配 + AA=33 → 0.2
matchBrandColor('#0564f533');
// {
//   matchType: 'exact-with-alpha',
//   targetVar: '--brand-color',
//   baseHex: '#0564f5',
//   alpha: 0.2,
//   output: 'rgba(var(--brand-color-rgb), 0.2)'
// }

// 示例 4：8 位 hex 全不透明 → 直接用主变量（不用 rgba 形式）
matchBrandColor('#0564f5FF');
// {
//   matchType: 'exact',
//   targetVar: '--brand-color',
//   alpha: 1,
//   output: 'var(--brand-color)'
// }

// 示例 5：rgba() 数值格式 — 完全匹配 + 保留透明度
matchBrandColor('rgba(5, 100, 245, 0.15)');
// {
//   matchType: 'exact-with-alpha',
//   targetVar: '--brand-color',
//   alpha: 0.15,
//   output: 'rgba(var(--brand-color-rgb), 0.15)'
// }

// 示例 6：2 色阶差近似匹配（仅与 #0564f5 比较）
matchBrandColor('#256bd8');
// {
//   matchType: 'approximate',
//   targetVar: '--brand-color',
//   baseHex: '#0564f5',
//   shade: 2, delta: 32, distance: 43.7,
//   output: 'var(--brand-color)'
// }

// 示例 7：与 #0564f5 差 2 色阶 → 命中（即便同时靠近 #1677ff / #1d77ff，也只认 #0564f5）
matchBrandColor('#196ffa');
// {
//   matchType: 'approximate',
//   targetVar: '--brand-color',
//   baseHex: '#0564f5',
//   shade: 2, delta: 20, distance: 23.4,
//   output: 'var(--brand-color)'
// }

// 示例 8：与 #0564f5 超阈值 → 不替换（即便靠近 #2065cf 也保留原样）
matchBrandColor('#3080d0');
// { matchType: 'none', input: '#3080d0', output: null }

// 示例 9：真正超阈值，不替换
matchBrandColor('#00ccff');
// { matchType: 'none', input: '#00ccff', output: null }

matchBrandColor('#ff0000');
// { matchType: 'none', input: '#ff0000', output: null }
```

> **说明**：近似匹配只以 `#0564f5` 为唯一基准，因此不存在多候选，也无需 Tiebreaker——示例 6~9 的判定完全由「源色值与 `#0564f5` 的 Δ_ch / d」决定。完全匹配仍覆盖全部 31 个色值（含次品牌色与经典 Web 蓝 `#3399cc`）。实际引擎决策以脚本 `matchBrandColor` 为准，规则详见 [color-matching-details.md 第二节](color-matching-details.md)。

### 11.6 与 SKILL.md 迁移流程的衔接

- **完全匹配替换**：`matchType === 'exact'` / `'exact-with-alpha'` → 直接采用 `output` 字段值，无需在报告中标记
- **近似匹配替换**：`matchType === 'approximate'` / `'approximate-with-alpha'` → 采用 `output` 值，**必须**在 `Neo主题换肤功能升级报告.md` 的"近似匹配详情"表中记录 `baseHex` / `shade` / `delta` / `distance` 以供人工复核
- **无匹配**：`matchType === 'none'` / `'invalid'` → 保留原色值，不替换
- **注释保留**：SCSS/CSS 中应在替换行上方追加原色值的注释行（`.tsx` / `.js` 无需保留），近似匹配的注释应额外标注 `[近似匹配·N色阶] 基准 baseHex, Δ_ch=delta, d≈distance`

> ⚠️ 完整迁移规则、注释格式、报告模板、遗漏检测等详见 [SKILL.md § 3](../SKILL.md)。本节仅作为可编程决策逻辑的参考实现。

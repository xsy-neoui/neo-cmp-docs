# 状态管理：Pinia / Vuex → MobX

本技能对状态管理的默认选择是 **MobX**（配 `mobx-react`）。原因：

- 写法贴近 Vue 的响应式（可变语法、自动依赖收集），迁移认知负担最小
- 精细订阅（`observer` 只在被读取的字段变化时重渲染），性能优于 Context
- 同时支持类式（`makeObservable`）和自动式（`makeAutoObservable`）两种风格，灵活

## 目录

- 安装与约定
- Pinia Store → MobX Store（最推荐的映射）
- Vuex → MobX
- 组件接入（observer / useStore）
- 异步、副作用、派生
- Store 组合（modules → RootStore）
- 持久化
- 与 TypeScript 配合

---

## 安装

```bash
npm i mobx mobx-react
```

`tsconfig.json`（如用装饰器）：

```json
{
  "compilerOptions": {
    "experimentalDecorators": true,
    "useDefineForClassFields": true
  }
}
```

绝大多数场景用 `makeAutoObservable` 即可，**不需要装饰器**。

---

## Pinia Store → MobX Store

### Pinia 写法

```ts
// stores/counter.ts
import { defineStore } from 'pinia'

export const useCounterStore = defineStore('counter', {
  state: () => ({ count: 0, name: 'a' }),
  getters: {
    double: (s) => s.count * 2,
  },
  actions: {
    increment() { this.count++ },
    async fetchName() {
      this.name = await api.getName()
    },
  },
})
```

### MobX 对应

```ts
// stores/counter.ts
import { makeAutoObservable, runInAction } from 'mobx'

export class CounterStore {
  count = 0
  name = 'a'

  constructor() {
    makeAutoObservable(this)
  }

  // getters —— 直接用 JS 的 getter
  get double() {
    return this.count * 2
  }

  // actions —— 同步
  increment() {
    this.count++
  }

  // actions —— 异步
  async fetchName() {
    const n = await api.getName()
    runInAction(() => {   // await 后的赋值需要包一层
      this.name = n
    })
  }
}

export const counterStore = new CounterStore()
```

`makeAutoObservable` 规则：
- 非函数字段 → `observable`
- 普通方法 → `action`
- `get xxx()` → `computed`
- 异步里 `await` 之后的赋值要用 `runInAction` 或再调用一个 action 方法

### 组合式 Pinia（setup syntax）

```ts
export const useCounterStore = defineStore('counter', () => {
  const count = ref(0)
  const double = computed(() => count.value * 2)
  function increment() { count.value++ }
  return { count, double, increment }
})
```

映射到 MobX 本质不变，依然用 class + `makeAutoObservable`。

---

## Vuex → MobX

Vuex 概念与 MobX 并不一对一，需要做些"摊平"：

| Vuex | MobX |
|---|---|
| `state` | class 的字段 |
| `getters` | class 的 `get xxx()` |
| `mutations`（同步） | class 的普通方法（需保持同步语义时） |
| `actions`（可异步、调 mutation） | class 的 async 方法（直接改字段，用 `runInAction`） |
| `modules` | 多个 Store class，组合进 `RootStore` |
| `strict: true` | MobX 的 `configure({ enforceActions: 'always' })` |

### 具体示例

**Vuex：**

```js
// store/user.js
export default {
  namespaced: true,
  state: () => ({ profile: null, loading: false }),
  getters: {
    displayName: (s) => s.profile?.name ?? 'guest',
  },
  mutations: {
    SET_PROFILE(s, p) { s.profile = p },
    SET_LOADING(s, v) { s.loading = v },
  },
  actions: {
    async fetchProfile({ commit }, id) {
      commit('SET_LOADING', true)
      try {
        commit('SET_PROFILE', await api.getUser(id))
      } finally {
        commit('SET_LOADING', false)
      }
    },
  },
}
```

**MobX：**

```ts
// stores/user.ts
export class UserStore {
  profile: Profile | null = null
  loading = false

  constructor() { makeAutoObservable(this) }

  get displayName() {
    return this.profile?.name ?? 'guest'
  }

  async fetchProfile(id: string) {
    this.loading = true
    try {
      const p = await api.getUser(id)
      runInAction(() => { this.profile = p })
    } finally {
      runInAction(() => { this.loading = false })
    }
  }
}
```

> MobX 里不再需要 `commit('SET_XXX')` 这种"提交 mutation"仪式，直接赋值即可，**但赋值必须发生在 action 方法或 `runInAction` 内**。

---

## 组件接入

### 函数组件：`observer` + hook

```tsx
import { observer } from 'mobx-react'
import { useCounterStore } from '@/stores'

export const Counter = observer(() => {
  const counter = useCounterStore()
  return (
    <div>
      {counter.count} × 2 = {counter.double}
      <button onClick={() => counter.increment()}>+</button>
    </div>
  )
})
```

`observer` 的作用：订阅组件内部**实际读取**到的 observable 字段，只在这些字段变化时重渲染。

### 类组件：`@observer` 或 HOC

```tsx
import { observer } from 'mobx-react'

@observer
class Counter extends Component {
  render() {
    const { counter } = this.context   // 或通过 props、context 拿 store
    return <div>{counter.count}</div>
  }
}

// 或不用装饰器：
class Counter extends Component { /* ... */ }
export default observer(Counter)
```

---

## Store 分发：Context + hook

创建一个 RootStore，用 Context 提供，用 hook 消费。

```ts
// stores/index.ts
import { createContext, useContext } from 'react'
import { CounterStore } from './counter'
import { UserStore } from './user'

export class RootStore {
  counter = new CounterStore()
  user = new UserStore()
}

const StoreContext = createContext<RootStore | null>(null)

export const StoreProvider: FC<PropsWithChildren> = ({ children }) => {
  const [root] = useState(() => new RootStore())
  return <StoreContext.Provider value={root}>{children}</StoreContext.Provider>
}

export function useStore() {
  const s = useContext(StoreContext)
  if (!s) throw new Error('useStore must be used inside StoreProvider')
  return s
}

// 便捷 hook
export const useCounterStore = () => useStore().counter
export const useUserStore = () => useStore().user
```

在 `main.tsx` 里包一层 `<StoreProvider>` 即可。

> 也可以"单例模块导出"方式（`export const counterStore = new CounterStore()`）简单直接，但不便于多实例/测试隔离。**推荐用 Provider 模式**。

---

## 派生 / 计算

MobX 的 `get xxx()` 自带缓存，类似 Vue 的 `computed`：

```ts
class CartStore {
  items: Item[] = []
  constructor() { makeAutoObservable(this) }

  get total() {
    return this.items.reduce((s, i) => s + i.price * i.qty, 0)
  }
}
```

组件读 `cart.total` 时，MobX 只在 `items` 相关依赖变化时重算。

---

## 持久化

把 store 的部分字段存到 localStorage。推荐用 `mobx-persist-store` 或手写：

```ts
import { autorun } from 'mobx'

const cached = JSON.parse(localStorage.getItem('user') || 'null')
if (cached) Object.assign(userStore, cached)

autorun(() => {
  localStorage.setItem('user', JSON.stringify({
    profile: userStore.profile,
  }))
})
```

---

## TypeScript 小贴士

- `makeAutoObservable(this, { someMethod: false })` 可以手动排除不想代理的成员
- 基类/被继承的类需要用 `makeObservable(this, { ... })` 显式声明
- 异步方法里 `await` 后：要么包 `runInAction(() => ...)`，要么把赋值逻辑抽到另一个 action 方法里调用
- 对外暴露的类型要注意 `readonly`：MobX 的字段可变，但你可以只暴露 `get`

---

## Vuex/Pinia → MobX 的几处不对称要注意

- Vuex 的 `strict` 模式强制所有改动走 mutation；MobX 可以通过 `configure({ enforceActions: 'always' })` 强制所有改动在 action 中
- Pinia 的 `$patch` / `$reset`：MobX 没有开箱即用的 `$reset`，自己写一个 `reset()` 方法把字段置回初始值即可
- Vuex/Pinia 的"订阅"（`store.$subscribe`）：MobX 用 `reaction(() => store.xxx, (v) => {...})` 或 `autorun`

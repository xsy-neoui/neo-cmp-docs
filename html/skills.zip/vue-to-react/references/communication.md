# 组件通信：props / emits / v-model / provide-inject / refs / eventBus

## 目录

- props（父 → 子）
- emits（子 → 父）→ 回调 props
- v-model（双向）→ 受控对
- provide / inject → Context
- $refs → useRef + forwardRef + useImperativeHandle
- eventBus → 避免；用 Context 或 store
- $attrs / fallthrough → {...rest}
- $parent / $root → 避免；用 Context

---

## 父 → 子：props

与 Vue 基本一致。要点：

```tsx
interface UserCardProps {
  name: string
  age?: number              // 可选
  onRemove: () => void      // 函数 prop（对应 Vue emit）
  children?: ReactNode      // 默认插槽
}

const UserCard: FC<UserCardProps> = ({ name, age = 18, onRemove, children }) => (
  <div>
    {name} {age}
    {children}
    <button onClick={onRemove}>×</button>
  </div>
)
```

- **默认值**：解构时用 `= 18` 写默认值（类组件用 `static defaultProps`，但 TS 场景通常用默认参数）
- **类型校验**：TS 接口 / type 替代 Vue 的 `type/required/validator`
- **props 不可变**：React 里 props 是只读的，不要直接修改

### 布尔 prop

```vue
<MyCmp disabled />
```

```tsx
<MyCmp disabled />     // 简写即 disabled={true}
```

### 传对象 / 数组

和 Vue 一样：`<MyCmp :data="obj" />` → `<MyCmp data={obj} />`

---

## 子 → 父：emits → 回调 props

Vue：

```vue
<!-- Child -->
<button @click="$emit('change', value)">

<!-- Parent -->
<Child @change="onChange" />
```

React：**子组件接收一个回调函数作为 prop，触发时调用它**。

```tsx
// Child
interface ChildProps {
  onChange: (value: string) => void
}
const Child: FC<ChildProps> = ({ onChange }) => (
  <button onClick={() => onChange('hello')}>go</button>
)

// Parent
<Child onChange={(v) => console.log(v)} />
```

### 命名约定

- Vue 习惯：`@update` / `@submit` / `@change`
- React 习惯：函数 prop 统一用 **`on`+PascalCase** 前缀，例如 `onChange`、`onSubmit`、`onSelect`
- 如果组件同时支持多个"事件"，就传多个回调 prop：`onSelect`、`onOpen`、`onClose`

---

## v-model → 受控对

详见 `template-to-jsx.md` 的 v-model 部分。核心约定：

```tsx
// 子组件
interface Props {
  value: T
  onChange: (v: T) => void
}

// 父组件
const [val, setVal] = useState<T>(...)
<Child value={val} onChange={setVal} />
```

Vue 3 支持多个 v-model（`v-model:title`、`v-model:content`）：

```vue
<Editor v-model:title="t" v-model:content="c" />
```

```tsx
<Editor
  title={t} onTitleChange={setT}
  content={c} onContentChange={setC}
/>
```

---

## provide / inject → React Context

Vue：

```ts
// 祖先
provide('theme', ref('dark'))

// 后代
const theme = inject('theme')
```

React：

```tsx
// 1. 定义 Context
interface ThemeCtx {
  theme: 'light' | 'dark'
  setTheme: (t: 'light' | 'dark') => void
}
const ThemeContext = createContext<ThemeCtx | null>(null)

// 2. 祖先提供
export const ThemeProvider: FC<PropsWithChildren> = ({ children }) => {
  const [theme, setTheme] = useState<'light' | 'dark'>('dark')
  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

// 3. 封装 hook（推荐：把 null 检查封起来）
export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}

// 4. 后代消费
const { theme, setTheme } = useTheme()
```

### Context 的性能陷阱

Context 的 value 变化会让**所有消费者**重渲染。应对：

- **拆分 Context**：把"经常变的值"和"稀少变化的值"分开提供
- **useMemo 包 value**：`value={useMemo(() => ({ theme, setTheme }), [theme])}`
- **全局共享的高频状态**：别用 Context，用 **MobX**（精细到字段的订阅），这也是我们状态管理选 MobX 的重要原因

---

## $refs → useRef + forwardRef

### 访问 DOM

```vue
<input ref="inp" />
this.$refs.inp.focus()
```

```tsx
const inpRef = useRef<HTMLInputElement>(null)
<input ref={inpRef} />
inpRef.current?.focus()
```

### 访问子组件实例

Vue 里 `this.$refs.child.someMethod()` 可直接调用。React 里默认**不允许**父组件访问子组件内部 —— 需要子组件主动用 `forwardRef` + `useImperativeHandle` 暴露 API：

```tsx
// 子组件
interface ModalHandle {
  open: () => void
  close: () => void
}
const Modal = forwardRef<ModalHandle, { title: string }>(({ title }, ref) => {
  const [open, setOpen] = useState(false)
  useImperativeHandle(ref, () => ({
    open: () => setOpen(true),
    close: () => setOpen(false),
  }), [])
  return open ? <div>{title}</div> : null
})

// 父组件
const modalRef = useRef<ModalHandle>(null)
<Modal ref={modalRef} title="Hi" />
<button onClick={() => modalRef.current?.open()}>open</button>
```

### 类组件版

```tsx
class Modal extends Component<Props, State> {
  open = () => this.setState({ open: true })
  close = () => this.setState({ open: false })
  // ...
}

// 父组件
const modalRef = createRef<Modal>()
<Modal ref={modalRef} />
modalRef.current?.open()
```

---

## eventBus → 避免，用 Context 或 store

Vue 2 里常用：

```js
// bus.js
export const bus = new Vue()
bus.$emit('msg', data)
bus.$on('msg', handler)
```

迁移到 React，**强烈建议放弃事件总线**，改用以下之一：

1. **提升状态到共同父级**（最符合 React 数据流）
2. **Context**（跨层级但同子树内）
3. **MobX store**（真正全局，任意组件订阅任意字段）

如果一定要保留总线语义（比如迁移成本考虑），用一个极简的 emitter：

```ts
// bus.ts
type Handler = (payload: any) => void
class Bus {
  private map = new Map<string, Set<Handler>>()
  on(e: string, h: Handler) {
    if (!this.map.has(e)) this.map.set(e, new Set())
    this.map.get(e)!.add(h)
    return () => this.off(e, h)
  }
  off(e: string, h: Handler) { this.map.get(e)?.delete(h) }
  emit(e: string, p?: any) { this.map.get(e)?.forEach(h => h(p)) }
}
export const bus = new Bus()
```

```tsx
useEffect(() => bus.on('msg', (d) => setData(d)), [])
```

---

## $attrs / 属性透传

Vue 3 里 `<MyCmp v-bind="$attrs" />` 把所有未声明的属性传到内部根元素。React 用解构 + 剩余参数：

```tsx
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'ghost'
}
const Button: FC<ButtonProps> = ({ variant = 'primary', className, ...rest }) => (
  <button
    className={clsx('btn', variant === 'primary' && 'btn-primary', className)}
    {...rest}
  />
)
```

---

## $parent / $root → 不要用

Vue 里访问 `$parent`、`$root` 是一种反模式（破坏封装）。React 里根本没提供这类 API，迁移时应改为：

- 通过 Context 传递共享数据
- 通过回调 prop 让子组件通知父级
- 通过全局 store（MobX）共享真正跨层级的数据

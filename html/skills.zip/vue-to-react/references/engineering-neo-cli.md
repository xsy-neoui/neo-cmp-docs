# 工程配置迁移：Vue CLI / Vite(Vue) → neo-cmp-cli

本技能的工程配置**统一使用 neo-cmp-cli**，不使用 Vite(React) 或 CRA。neo-cmp-cli 基于 AKFun + Webpack，提供零配置开箱即用的 React + TypeScript 开发体验。

## 目录

- neo-cmp-cli 概述
- 项目初始化
- 配置文件对照（vue.config.js / vite.config.ts → neo.config.js）
- 环境变量
- 代理（Proxy）
- 路径别名（Alias）
- 构建入口
- 样式处理（Sass / PostCSS / 按需引入）
- ESLint / StyleLint
- 构建产物（dev / build / build2lib / build2esm）
- TypeScript 配置
- 从 Vue CLI 项目迁移步骤
- 从 Vite(Vue) 项目迁移步骤

---

## neo-cmp-cli 概述

**neo-cmp-cli** 是面向 Neo 平台的自定义组件开发工具：

- **构建工具**：Webpack（通过 AKFun 封装）
- **零配置**：内置默认配置，开箱即用
- **多技术栈**：支持 React + TypeScript、Vue 2
- **构建形态**：本地预览（热更新）、外链调试、UMD 库构建、ESM 模块构建、发布到 NeoCRM
- **配置文件**：项目根目录 `neo.config.js`

---

## 项目初始化

### 安装 CLI

```bash
npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com
# 或
yarn global add neo-cmp-cli --registry https://registry.npmmirror.com
```

### 创建 React + TS 项目

```bash
# 交互式选择模板
neo init

# 非交互式（推荐 neo 或 antd 模板）
neo init -t neo -n my-project
neo init -t antd -n my-project
```

### 生成配置文件

```bash
neo config init
```

会在项目根目录生成 `neo.config.js`，可按需修改。

---

## 配置文件对照

### Vue CLI（vue.config.js）→ neo.config.js

| vue.config.js | neo.config.js |
|---|---|
| `devServer.port` | `dev.port` |
| `devServer.proxy` | `dev.proxyTable` |
| `devServer.https` | `preview.https` |
| `publicPath` | `dev.assetsPublicPath` / `build.assetsPublicPath` |
| `outputDir` | `build.assetsRoot` |
| `configureWebpack.resolve.alias` | `webpack.resolve.alias` |
| `configureWebpack.externals` | `webpack.externals` |
| `css.sourceMap` | `dev.cssSourceMap` |
| `lintOnSave` | `settings.enableESLint` |
| `chainWebpack` | `webpack.moduleRules` / `webpack.plugins` |

### Vite（vite.config.ts）→ neo.config.js

| vite.config.ts | neo.config.js |
|---|---|
| `server.port` | `dev.port` |
| `server.proxy` | `dev.proxyTable` |
| `server.https` | `preview.https` |
| `base` | `build.assetsPublicPath` |
| `build.outDir` | `build.assetsRoot` |
| `resolve.alias` | `webpack.resolve.alias` |
| `build.rollupOptions.external` | `webpack.externals` |
| `plugins` | `webpack.plugins` / `webpack.babelPlugins` |
| `css.preprocessorOptions.scss.additionalData` | `webpack.sassResources` |

---

## 环境变量

### Vue CLI 方式

```
# .env.development
VUE_APP_API_BASE=http://localhost:3000
VUE_APP_VERSION=1.0.0
```

```js
// 使用
process.env.VUE_APP_API_BASE
```

### Vite 方式

```
# .env
VITE_API_BASE=http://localhost:3000
```

```js
import.meta.env.VITE_API_BASE
```

### neo-cmp-cli 方式（envParams）

neo-cmp-cli 使用 `params-replace-loader` 在构建时做字符串替换：

```javascript
// neo.config.js
module.exports = {
  envParams: {
    common: {
      '#version#': '20250506.1',
    },
    local: {
      '#dataApiBase#': 'http://localhost:1024',
      '#assetsPublicPath#': 'http://localhost:1024',
      '#routeBasePath#': '/',
    },
    online: {
      '#dataApiBase#': '/',
      '#assetsPublicPath#': '',
      '#routeBasePath#': '/',
    },
  },
}
```

在代码中直接使用占位符字符串：

```ts
// src/config.ts
export const API_BASE = '#dataApiBase#'
export const VERSION = '#version#'
```

构建时会被替换为对应环境的值。

**迁移映射**：

| 原环境变量 | neo.config.js envParams |
|---|---|
| `VUE_APP_API_BASE` / `VITE_API_BASE` | `envParams.local['#dataApiBase#']` |
| `VUE_APP_PUBLIC_PATH` / `base` | `envParams.local['#assetsPublicPath#']` |
| 自定义变量 | 在 `envParams.common` 或 `envParams.local/online` 中添加 |

---

## 代理（Proxy）

### Vue CLI

```js
// vue.config.js
module.exports = {
  devServer: {
    proxy: {
      '/api': {
        target: 'http://backend:8080',
        changeOrigin: true,
        pathRewrite: { '^/api': '' },
      },
    },
  },
}
```

### Vite

```ts
// vite.config.ts
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://backend:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
```

### neo-cmp-cli

```javascript
// neo.config.js
module.exports = {
  dev: {
    proxyTable: {
      '/api': {
        target: 'http://backend:8080',
        changeOrigin: true,
        pathRewrite: { '^/api': '' },
      },
    },
  },
}
```

> neo-cmp-cli 的 `proxyTable` 语法与 webpack-dev-server 的 `proxy` 完全一致（底层就是 http-proxy-middleware）。

---

## 路径别名（Alias）

### Vue CLI

```js
// vue.config.js
const path = require('path')
module.exports = {
  configureWebpack: {
    resolve: {
      alias: {
        '@': path.resolve(__dirname, 'src'),
        '@components': path.resolve(__dirname, 'src/components'),
        '@utils': path.resolve(__dirname, 'src/utils'),
      },
    },
  },
}
```

### Vite

```ts
// vite.config.ts
import { resolve } from 'path'
export default defineConfig({
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@components': resolve(__dirname, 'src/components'),
    },
  },
})
```

### neo-cmp-cli

```javascript
// neo.config.js
const { resolve } = require('akfun')

module.exports = {
  webpack: {
    resolve: {
      extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
      alias: {
        '@': resolve('src'),
        '@components': resolve('src/components'),
        '@utils': resolve('src/utils'),
        '@stores': resolve('src/stores'),
        '@hooks': resolve('src/hooks'),
      },
    },
  },
}
```

> neo-cmp-cli 默认已配置 `'@': resolve('src')`。

同时需要在 `tsconfig.json` 中配置对应的 paths：

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"],
      "@components/*": ["src/components/*"],
      "@utils/*": ["src/utils/*"],
      "@stores/*": ["src/stores/*"],
      "@hooks/*": ["src/hooks/*"]
    }
  }
}
```

---

## 构建入口

### 默认行为

neo-cmp-cli 默认扫描 `src/components` 目录，以每个子目录的 `index.ts/tsx/js/jsx` 作为入口。

### 自定义入口

```javascript
// neo.config.js
module.exports = {
  webpack: {
    entry: {
      index: './src/index.tsx',
    },
  },
  // 不同构建模式可以有独立入口
  linkDebug: { entry: {} },
  build2lib: { entry: {} },
  pushCmp: { entry: {} },
}
```

---

## 样式处理

### Sass 全局变量/Mixin 注入

Vue CLI：
```js
css: { loaderOptions: { sass: { additionalData: `@import "@/styles/variables.scss";` } } }
```

neo-cmp-cli：
```javascript
module.exports = {
  webpack: {
    sassResources: [
      './src/styles/variables.scss',
      './src/styles/mixins.scss',
    ],
  },
}
```

### 按需引入组件库样式

```javascript
module.exports = {
  webpack: {
    babelPlugins: [
      ['import', { libraryName: 'antd', style: 'css' }],
    ],
  },
}
```

### CSS Modules

neo-cmp-cli 内置支持 CSS Modules，文件名以 `.module.css` / `.module.scss` 结尾即可：

```tsx
import styles from './Button.module.scss'
<button className={styles.btn}>Click</button>
```

---

## ESLint / StyleLint

```javascript
// neo.config.js
module.exports = {
  settings: {
    enableESLint: true,
    enableESLintFix: false,
    enableStyleLint: true,
    enableStyleLintFix: false,
  },
}
```

---

## 构建产物

### 命令对照

| 用途 | Vue CLI / Vite | neo-cmp-cli |
|---|---|---|
| 本地开发 | `npm run dev` / `npm run serve` | `neo preview` |
| 生产构建 | `npm run build` | `neo build`（或 `neo push cmp` 直接构建+发布） |
| UMD 库构建 | 自行配置 | `neo build2lib` |
| ESM 模块构建 | 自行配置 | `neo build2esm` |
| 外链调试 | 无 | `neo linkDebug` |

### 构建配置

```javascript
module.exports = {
  build: {
    NODE_ENV: 'production',
    assetsRoot: resolve('dist'),
    assetsPublicPath: '/',
    assetsSubDirectory: '',
    productionSourceMap: false,
    productionGzip: false,
  },
  build2lib: {
    NODE_ENV: 'production',
    libraryName: 'MyComponent',
    assetsRoot: resolve('dist'),
    ignoreNodeModules: true,
    allowList: [],  // ignoreNodeModules 为 true 时仍打入 bundle 的包
  },
}
```

---

## TypeScript 配置

neo-cmp-cli 内置 TypeScript 支持。推荐的 `tsconfig.json`：

```json
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "es2015", "es2016", "es2017"],
    "allowJs": true,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "react",
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    },
    "experimentalDecorators": true,
    "useDefineForClassFields": true
  },
  "include": ["src"],
  "exclude": ["node_modules", "dist"]
}
```

生成类型声明文件：

```javascript
module.exports = {
  webpack: {
    createDeclaration: true,
    projectDir: ['./src'],
  },
}
```

---

## 从 Vue CLI 项目迁移步骤

1. **安装 neo-cmp-cli**（全局）
2. **创建新项目**：`neo init -t neo -n my-react-project`（或在现有目录执行 `neo config init`）
3. **迁移配置**：
   - `vue.config.js` 的 `devServer.proxy` → `neo.config.js` 的 `dev.proxyTable`
   - `resolve.alias` → `webpack.resolve.alias`
   - `.env.*` 文件 → `envParams`
   - `chainWebpack` 的自定义 loader/plugin → `webpack.moduleRules` / `webpack.plugins`
4. **迁移依赖**：
   - 移除 `@vue/cli-*`、`vue`、`vue-router`、`vuex` 等
   - 安装 `react@16`、`react-dom@16`、`@types/react@16`、`@types/react-dom@16`
   - 安装 `mobx`、`mobx-react-lite`、`react-router-dom@6`
5. **迁移源码**：按本技能的组件迁移流程执行
6. **更新 scripts**：
   ```json
   {
     "scripts": {
       "dev": "neo preview",
       "build": "neo build",
       "build:lib": "neo build2lib"
     }
   }
   ```
7. **验证**：`neo preview` 启动本地开发，确认热更新正常

---

## 从 Vite(Vue) 项目迁移步骤

1. **安装 neo-cmp-cli**
2. **生成配置**：`neo config init`
3. **迁移配置**：
   - `vite.config.ts` 的 `server.proxy` → `dev.proxyTable`
   - `resolve.alias` → `webpack.resolve.alias`
   - `.env` 文件 → `envParams`
   - Vite 插件 → 对应的 webpack loader/plugin（大部分内置）
4. **移除 Vite 相关**：
   - 删除 `vite.config.ts`、`vite-env.d.ts`
   - 移除 `vite`、`@vitejs/plugin-vue` 等依赖
5. **安装 React 依赖**：同上
6. **迁移源码**
7. **更新 scripts** 为 neo 命令
8. **验证**

---

## 自定义 Webpack 扩展

如果需要添加额外的 loader 或 plugin：

```javascript
// neo.config.js
const { resolve } = require('akfun')

module.exports = {
  webpack: {
    // 自定义 loader
    moduleRules: [
      {
        test: /\.svg$/,
        use: ['@svgr/webpack'],
      },
    ],
    // 自定义 plugin
    plugins: [
      // new SomeWebpackPlugin({ ... })
    ],
    // Babel 插件（支持函数形式动态修改）
    babelPlugins: (curPlugins) => {
      curPlugins.push(['@babel/plugin-proposal-decorators', { legacy: true }])
      return curPlugins
    },
    // 外部依赖（不打入 bundle）
    externals: {
      react: 'React',
      'react-dom': 'ReactDOM',
    },
  },
}
```

---

## 对照速查

| 操作 | Vue CLI / Vite | neo-cmp-cli |
|---|---|---|
| 启动开发服务器 | `npm run dev` | `neo preview` |
| 生产构建 | `npm run build` | `neo build` |
| 配置文件 | `vue.config.js` / `vite.config.ts` | `neo.config.js` |
| 环境变量 | `.env.*` 文件 | `envParams` 字段 |
| 代理 | `devServer.proxy` / `server.proxy` | `dev.proxyTable` |
| 别名 | `resolve.alias` | `webpack.resolve.alias` |
| 全局样式注入 | `css.loaderOptions` / `css.preprocessorOptions` | `webpack.sassResources` |
| 外部依赖 | `externals` / `rollupOptions.external` | `webpack.externals` |
| 自定义 loader | `chainWebpack` / Vite plugin | `webpack.moduleRules` |
| 自定义 plugin | `configureWebpack.plugins` | `webpack.plugins` |
| Babel 插件 | `babel.config.js` | `webpack.babelPlugins` |
| 输出目录 | `outputDir` / `build.outDir` | `build.assetsRoot` |
| Source Map | `productionSourceMap` / `build.sourcemap` | `build.productionSourceMap` |

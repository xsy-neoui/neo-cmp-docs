# 表单处理与验证：VeeValidate / Vuelidate → React Hook Form

## 目录

- Vue 表单验证生态概览
- React 表单方案选型
- VeeValidate → React Hook Form 映射
- Vuelidate → React Hook Form + Zod
- 常见表单模式迁移
- 动态表单 / 表单数组
- 表单联动与条件验证

---

## Vue 表单验证生态

Vue 项目常用：

- **VeeValidate**（v4 for Vue 3 / v3 for Vue 2）：声明式验证，支持 yup/zod schema
- **Vuelidate**：基于 Composition API 的验证库
- **Element UI / Ant Design Vue 内置表单验证**：基于 async-validator

## React 表单方案选型

| 方案 | 适用场景 | 特点 |
|---|---|---|
| **React Hook Form**（推荐） | 绝大多数场景 | 性能好（非受控）、TS 友好、生态丰富 |
| Formik | 已有项目 | 受控模式、较重 |
| 原生受控组件 | 极简表单（2-3 个字段） | 无需额外依赖 |

**本技能默认推荐 React Hook Form + Zod**（类型安全的 schema 验证）。

---

## 安装

```bash
npm i react-hook-form @hookform/resolvers zod
```

---

## VeeValidate → React Hook Form

### VeeValidate（Vue 3 Composition API）

```vue
<script setup>
import { useForm, useField } from 'vee-validate'
import * as yup from 'yup'

const schema = yup.object({
  email: yup.string().required().email(),
  password: yup.string().required().min(6),
})

const { handleSubmit, errors } = useForm({ validationSchema: schema })
const { value: email } = useField('email')
const { value: password } = useField('password')

const onSubmit = handleSubmit((values) => {
  console.log(values)
})
</script>

<template>
  <form @submit.prevent="onSubmit">
    <input v-model="email" />
    <span v-if="errors.email">{{ errors.email }}</span>
    <input v-model="password" type="password" />
    <span v-if="errors.password">{{ errors.password }}</span>
    <button type="submit">Submit</button>
  </form>
</template>
```

### React Hook Form + Zod

```tsx
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'

const schema = z.object({
  email: z.string().min(1, '必填').email('邮箱格式不正确'),
  password: z.string().min(6, '至少 6 位'),
})

type FormData = z.infer<typeof schema>

export const LoginForm: FC = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = handleSubmit((data) => {
    console.log(data)
  })

  return (
    <form onSubmit={onSubmit}>
      <input {...register('email')} />
      {errors.email && <span>{errors.email.message}</span>}

      <input {...register('password')} type="password" />
      {errors.password && <span>{errors.password.message}</span>}

      <button type="submit" disabled={isSubmitting}>Submit</button>
    </form>
  )
}
```

### 映射对照

| VeeValidate | React Hook Form |
|---|---|
| `useForm({ validationSchema })` | `useForm({ resolver: zodResolver(schema) })` |
| `useField('name')` | `register('name')` |
| `field.value` | 非受控（DOM 管理值）；需要时用 `watch('name')` |
| `errors.name` | `formState.errors.name?.message` |
| `handleSubmit(cb)` | `handleSubmit(cb)` |
| `setFieldValue('name', v)` | `setValue('name', v)` |
| `setFieldError('name', msg)` | `setError('name', { message: msg })` |
| `resetForm()` | `reset()` |
| `meta.valid` | `formState.isValid` |
| `meta.dirty` | `formState.isDirty` |
| `validateField('name')` | `trigger('name')` |

---

## Vuelidate → React Hook Form + Zod

### Vuelidate（Vue 3）

```vue
<script setup>
import { useVuelidate } from '@vuelidate/core'
import { required, email, minLength } from '@vuelidate/validators'

const state = reactive({ email: '', password: '' })
const rules = {
  email: { required, email },
  password: { required, minLength: minLength(6) },
}
const v$ = useVuelidate(rules, state)

async function submit() {
  const valid = await v$.value.$validate()
  if (valid) { /* ... */ }
}
</script>
```

### React Hook Form + Zod（等价）

```tsx
const schema = z.object({
  email: z.string().min(1, '必填').email(),
  password: z.string().min(6),
})

const { register, handleSubmit, formState: { errors } } = useForm({
  resolver: zodResolver(schema),
  mode: 'onBlur',  // 类似 Vuelidate 的 $lazy
})
```

### 验证器映射

| Vuelidate 验证器 | Zod 等价 |
|---|---|
| `required` | `z.string().min(1)` |
| `email` | `z.string().email()` |
| `minLength(n)` | `z.string().min(n)` |
| `maxLength(n)` | `z.string().max(n)` |
| `numeric` | `z.string().regex(/^\d+$/)` 或 `z.coerce.number()` |
| `between(min, max)` | `z.number().min(min).max(max)` |
| `sameAs(ref)` | `z.object({...}).refine(d => d.password === d.confirm)` |
| `url` | `z.string().url()` |
| 自定义 `helpers.withMessage` | `z.string().refine(fn, { message })` |

---

## 常见表单模式迁移

### 验证时机

| Vue 时机 | React Hook Form `mode` |
|---|---|
| 提交时验证（默认） | `mode: 'onSubmit'`（默认） |
| 失焦时验证 | `mode: 'onBlur'` |
| 输入时实时验证 | `mode: 'onChange'` |
| 首次提交后实时验证 | `mode: 'onTouched'` |

### 受控组件（第三方 UI 库）

当使用 Ant Design / MUI 等受控组件时，用 `Controller`：

```tsx
import { Controller } from 'react-hook-form'

<Controller
  name="role"
  control={control}
  render={({ field, fieldState }) => (
    <Select
      {...field}
      options={roleOptions}
      error={!!fieldState.error}
      helperText={fieldState.error?.message}
    />
  )}
/>
```

### 默认值 / 编辑表单

```tsx
// Vue: 在 data 或 watch 里设置初始值
// React Hook Form:
const { reset } = useForm<FormData>({
  defaultValues: { email: '', password: '' },
})

// 异步加载后填充
useEffect(() => {
  fetchUser(id).then((user) => reset(user))
}, [id])
```

---

## 动态表单 / 表单数组

### Vue（VeeValidate FieldArray）

```vue
<FieldArray name="items" v-slot="{ fields, push, remove }">
  <div v-for="(field, idx) in fields" :key="field.key">
    <Field :name="`items[${idx}].name`" />
    <button @click="remove(idx)">×</button>
  </div>
  <button @click="push({ name: '' })">Add</button>
</FieldArray>
```

### React Hook Form（useFieldArray）

```tsx
import { useFieldArray } from 'react-hook-form'

const { control, register, handleSubmit } = useForm({
  defaultValues: { items: [{ name: '' }] },
})

const { fields, append, remove } = useFieldArray({ control, name: 'items' })

return (
  <form onSubmit={handleSubmit(onSubmit)}>
    {fields.map((field, index) => (
      <div key={field.id}>
        <input {...register(`items.${index}.name`)} />
        <button type="button" onClick={() => remove(index)}>×</button>
      </div>
    ))}
    <button type="button" onClick={() => append({ name: '' })}>Add</button>
    <button type="submit">Submit</button>
  </form>
)
```

---

## 表单联动与条件验证

### Vue（条件规则）

```js
const rules = computed(() => ({
  address: state.needShipping ? { required } : {},
}))
```

### React Hook Form + Zod（条件 schema）

```tsx
const schema = z.object({
  needShipping: z.boolean(),
  address: z.string().optional(),
}).refine(
  (data) => !data.needShipping || (data.address && data.address.length > 0),
  { message: '需要填写地址', path: ['address'] },
)
```

或用 `superRefine` 做更复杂的联动：

```tsx
const schema = z.object({
  type: z.enum(['personal', 'company']),
  companyName: z.string().optional(),
  idNumber: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.type === 'company' && !data.companyName) {
    ctx.addIssue({ code: 'custom', message: '公司名必填', path: ['companyName'] })
  }
  if (data.type === 'personal' && !data.idNumber) {
    ctx.addIssue({ code: 'custom', message: '身份证必填', path: ['idNumber'] })
  }
})
```

### 字段联动（watch + setValue）

```tsx
const { watch, setValue } = useForm()
const country = watch('country')

useEffect(() => {
  // 国家变化时清空城市
  setValue('city', '')
}, [country])
```

---

## Element UI / Ant Design Vue 表单迁移

如果原项目用 Element UI 的 `<el-form>` + `rules`：

```vue
<el-form :model="form" :rules="rules" ref="formRef">
  <el-form-item label="Name" prop="name">
    <el-input v-model="form.name" />
  </el-form-item>
</el-form>
```

迁移到 React 时，如果用 Ant Design React：

```tsx
import { Form, Input } from 'antd'

<Form form={form} onFinish={onSubmit}>
  <Form.Item name="name" label="Name" rules={[{ required: true }]}>
    <Input />
  </Form.Item>
</Form>
```

如果不用 UI 库的内置表单，统一用 React Hook Form + Zod + 自定义 UI 组件。

---

## 对照速查

| Vue 表单概念 | React 等价 |
|---|---|
| `v-model` 绑定表单字段 | `register('field')` 或 `Controller` |
| 验证 schema（yup/zod） | `resolver: zodResolver(schema)` |
| `$v.$validate()` / `validate()` | `handleSubmit(onValid, onInvalid)` |
| `$v.field.$error` | `errors.field` |
| `$v.$reset()` | `reset()` |
| `setFieldValue` | `setValue('field', value)` |
| FieldArray | `useFieldArray` |
| 表单 ref 调用 `validate()` | `trigger()` 手动触发验证 |

# 单文件组件拆分：`.vue` → `.tsx` + Tailwind / CSS Modules

## 目录

- 目录约定
- 单文件 vs 多文件
- 模板（template）→ JSX
- 脚本（script / script setup）→ 组件体 + hooks
- 样式（style scoped）→ Tailwind 优先，CSS Modules 补充
- 类型定义放哪里
- 索引导出约定
- 示例：完整的 Button 迁移

---

## 目录约定

### 单文件组件（小到中等）

```
Button.tsx            // 所有东西（组件 + 类型 + 少量样式类名）
Button.module.css     // 可选，复杂样式
```

### 多文件组件（复杂）

```
Button/
├── Button.tsx            // 主组件
├── Button.module.css     // 样式（若 Tailwind 不够用）
├── Button.types.ts       // props / 内部类型
├── useButton.ts          // 抽出的逻辑 hook（可选）
├── Button.stories.tsx    // Storybook（可选）
├── Button.test.tsx       // 测试（可选）
└── index.ts              // re-export：export * from './Button'
```

经验阈值：

- 组件代码 < 200 行 → 单文件
- 逻辑超过 ~50 行或在多处复用 → 抽 `useButton.ts`
- 子组件仅在本组件内使用 → 同目录平级或文件内局部
- 跨多个组件复用 → 提到 `components/` 共享目录

---

## 模板 → JSX

Vue 的 `<template>` 里是类 HTML，React 写成 JSX 后放在 `return (...)` 中。几个差异要记牢：

- `class` → `className`
- `for` → `htmlFor`
- camelCase 属性（`tabindex` → `tabIndex`、`readonly` → `readOnly`）
- 事件 camelCase（`@click` → `onClick`）
- `style` 是对象（`{{ }}` 双大括号：外层 JSX 表达式 + 内层对象字面量）
- 自闭合标签必须闭合：`<img />`、`<input />`
- 注释用 `{/* */}`

详细语法对照见 `template-to-jsx.md`。

---

## 脚本 → 组件体 + hooks

### Vue 2 Options API → 函数组件

```vue
<script>
export default {
  name: 'Counter',
  props: { initial: { type: Number, default: 0 } },
  data() { return { count: this.initial } },
  computed: {
    double() { return this.count * 2 },
  },
  methods: {
    inc() { this.count++ },
  },
  mounted() {
    console.log('mounted')
  },
}
</script>
```

```tsx
interface CounterProps { initial?: number }

export const Counter: FC<CounterProps> = ({ initial = 0 }) => {
  const [count, setCount] = useState(initial)
  const double = useMemo(() => count * 2, [count])
  const inc = () => setCount(c => c + 1)

  useEffect(() => { console.log('mounted') }, [])

  return (
    <div>
      {count} × 2 = {double}
      <button onClick={inc}>+</button>
    </div>
  )
}
```

### Vue 2 Options API → 类组件（复杂场景）

```tsx
interface CounterProps { initial?: number }
interface CounterState { count: number }

export class Counter extends Component<CounterProps, CounterState> {
  static defaultProps = { initial: 0 }
  state: CounterState = { count: this.props.initial ?? 0 }

  get double() { return this.state.count * 2 }

  inc = () => this.setState(s => ({ count: s.count + 1 }))

  componentDidMount() {
    console.log('mounted')
  }

  render() {
    return (
      <div>
        {this.state.count} × 2 = {this.double}
        <button onClick={this.inc}>+</button>
      </div>
    )
  }
}
```

### Vue 3 `<script setup>` → 函数组件（1:1 最直接）

Composition API 与 hooks 很接近，迁移成本最低：

```vue
<script setup lang="ts">
interface Props { initial?: number }
const props = withDefaults(defineProps<Props>(), { initial: 0 })
const emit = defineEmits<{ (e: 'change', v: number): void }>()

const count = ref(props.initial)
const double = computed(() => count.value * 2)
function inc() {
  count.value++
  emit('change', count.value)
}
onMounted(() => console.log('mounted'))
</script>
```

```tsx
interface Props {
  initial?: number
  onChange?: (v: number) => void
}

export const Counter: FC<Props> = ({ initial = 0, onChange }) => {
  const [count, setCount] = useState(initial)
  const double = useMemo(() => count * 2, [count])

  const inc = () => {
    const next = count + 1
    setCount(next)
    onChange?.(next)
  }

  useEffect(() => { console.log('mounted') }, [])

  return <button onClick={inc}>{count} / {double}</button>
}
```

### 何时把逻辑抽到 `useXxx.ts`

- 同一段逻辑在多个组件里会复用
- 单个组件内 hooks 调用超过 ~10 个，开始凌乱
- 希望单独为逻辑写单元测试

```ts
// useCounter.ts
export function useCounter(initial = 0) {
  const [count, setCount] = useState(initial)
  const double = useMemo(() => count * 2, [count])
  const inc = useCallback(() => setCount(c => c + 1), [])
  const dec = useCallback(() => setCount(c => c - 1), [])
  return { count, double, inc, dec }
}
```

```tsx
export const Counter: FC = () => {
  const { count, double, inc } = useCounter()
  return <button onClick={inc}>{count} / {double}</button>
}
```

---

## 样式：Tailwind 优先

**默认做法**：直接把样式类写在 JSX 的 `className` 上。

```tsx
<button
  className="
    inline-flex items-center gap-2
    px-4 py-2 rounded-md
    bg-blue-600 text-white font-medium
    hover:bg-blue-700 active:bg-blue-800
    disabled:opacity-50 disabled:cursor-not-allowed
    transition-colors
  "
>
  Save
</button>
```

### 条件 class：用 `clsx`（或 `classnames`）

```tsx
import clsx from 'clsx'

<button
  className={clsx(
    'inline-flex items-center px-4 py-2 rounded-md',
    variant === 'primary' && 'bg-blue-600 text-white hover:bg-blue-700',
    variant === 'ghost' && 'bg-transparent text-blue-600 hover:bg-blue-50',
    disabled && 'opacity-50 cursor-not-allowed',
  )}
/>
```

### 变体组合：用 `tailwind-variants` 或 `cva`

当一个组件有很多变体（variant × size × state）时，`clsx` 会变长。推荐：

```ts
import { tv } from 'tailwind-variants'

const button = tv({
  base: 'inline-flex items-center rounded-md font-medium transition-colors',
  variants: {
    variant: {
      primary: 'bg-blue-600 text-white hover:bg-blue-700',
      ghost: 'bg-transparent text-blue-600 hover:bg-blue-50',
    },
    size: {
      sm: 'px-3 py-1 text-sm',
      md: 'px-4 py-2',
      lg: 'px-6 py-3 text-lg',
    },
  },
  defaultVariants: { variant: 'primary', size: 'md' },
})

// 使用
<button className={button({ variant: 'ghost', size: 'sm' })}>
```

### 当 Tailwind 不够用：CSS Modules

以下场景用 CSS Modules：

- 复杂动画 `@keyframes`
- 深层选择器（`.card :global(.tag)`）
- 伪元素 `::before` / `::after` 的复杂布局
- 要 import / 主题切换的 CSS 变量

```css
/* Button.module.css */
.ripple {
  position: relative;
  overflow: hidden;
}
.ripple::after {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle, rgba(255,255,255,0.3), transparent);
  opacity: 0;
  transition: opacity 0.3s;
}
.ripple:active::after {
  opacity: 1;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-4px); }
  75% { transform: translateX(4px); }
}
.shaking { animation: shake 0.3s; }
```

```tsx
import styles from './Button.module.css'

<button className={clsx(styles.ripple, 'px-4 py-2', shaking && styles.shaking)}>
  Click
</button>
```

### Vue `<style scoped>` 迁移策略

1. **优先转 Tailwind**：通读 SFC 里的 style，把尺寸/颜色/间距/状态改成对应 Tailwind 工具类
2. **动画、伪元素、`::deep` 深穿透** → CSS Module
3. **CSS 变量主题** → 继续保留，写在 `global.css` 或根布局

---

## 类型定义放哪里

| 类型 | 放置位置 |
|---|---|
| 组件 props | 组件文件内或 `Button.types.ts`（多文件时） |
| 组件共享类型 | `types/` 或 `components/types.ts` |
| 领域模型（User、Order） | `types/domain.ts` 或 `models/` |
| API 响应 | `api/types.ts` 或自动生成（基于 OpenAPI） |

---

## 索引导出约定

多文件组件目录下用 `index.ts` 做 barrel 导出：

```ts
// Button/index.ts
export { Button } from './Button'
export type { ButtonProps } from './Button.types'
```

使用方：`import { Button } from '@/components/Button'`

> 避免过深的 barrel（会拖慢构建）。一级够了，别再层层嵌套。

---

## 完整示例：Button 从 Vue 2 迁移到 React

### 原 Vue 2 组件

```vue
<template>
  <button
    :class="['btn', `btn-${variant}`, { 'is-loading': loading }]"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <span v-if="loading" class="spinner" />
    <slot />
  </button>
</template>

<script>
export default {
  name: 'Button',
  props: {
    variant: { type: String, default: 'primary' },
    loading: Boolean,
    disabled: Boolean,
  },
  methods: {
    handleClick(e) {
      if (!this.loading && !this.disabled) this.$emit('click', e)
    },
  },
}
</script>

<style scoped>
.btn { padding: 8px 16px; border-radius: 4px; }
.btn-primary { background: #2563eb; color: white; }
.btn-ghost { background: transparent; color: #2563eb; }
.is-loading { opacity: 0.7; cursor: wait; }
.spinner { /* ... */ }
</style>
```

### 迁移后的 React 组件

```tsx
// Button/Button.tsx
import { ButtonHTMLAttributes, FC, ReactNode } from 'react'
import clsx from 'clsx'
import styles from './Button.module.css'

export interface ButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'> {
  variant?: 'primary' | 'ghost'
  loading?: boolean
  children?: ReactNode
}

export const Button: FC<ButtonProps> = ({
  variant = 'primary',
  loading = false,
  disabled = false,
  onClick,
  children,
  ...rest
}) => {
  return (
    <button
      className={clsx(
        'inline-flex items-center gap-2 px-4 py-2 rounded-md font-medium transition-colors',
        variant === 'primary' && 'bg-blue-600 text-white hover:bg-blue-700',
        variant === 'ghost' && 'bg-transparent text-blue-600 hover:bg-blue-50',
        (disabled || loading) && 'opacity-70 cursor-not-allowed',
      )}
      disabled={disabled || loading}
      onClick={(e) => {
        if (!loading && !disabled) onClick?.(e)
      }}
      {...rest}
    >
      {loading && <span className={styles.spinner} />}
      {children}
    </button>
  )
}
```

```css
/* Button/Button.module.css */
.spinner {
  width: 14px;
  height: 14px;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
```

```ts
// Button/index.ts
export { Button } from './Button'
export type { ButtonProps } from './Button'
```

# 动画与过渡：Vue Transition → React 动画方案

## 目录

- Vue `<Transition>` / `<TransitionGroup>` 概述
- React 侧动画方案选型
- 单元素进入/离开动画
- 列表动画（TransitionGroup）
- JavaScript 钩子动画
- 路由切换动画
- 与 Tailwind 配合

---

## Vue 的动画系统

Vue 提供内置的 `<Transition>` 和 `<TransitionGroup>` 组件：

```vue
<Transition name="fade">
  <div v-if="show">Hello</div>
</Transition>

<style>
.fade-enter-active, .fade-leave-active { transition: opacity 0.3s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
```

Vue 自动在进入/离开时添加 CSS 类名：`*-enter-from`、`*-enter-active`、`*-enter-to`、`*-leave-from`、`*-leave-active`、`*-leave-to`。

---

## React 侧动画方案选型

| 场景 | 推荐方案 |
|---|---|
| 简单 CSS 过渡（fade/slide） | Tailwind `transition-*` + 条件 class |
| 进入/离开动画（需要卸载延迟） | `react-transition-group`（CSSTransition） |
| 列表增删动画 | `react-transition-group`（TransitionGroup） |
| 复杂编排 / 弹簧动画 | `framer-motion`（推荐） |
| 极简场景 | 纯 CSS + `onTransitionEnd` |

**本技能默认推荐**：
- 简单过渡 → Tailwind 类 + 状态切换
- 需要卸载延迟 → `framer-motion`（API 更现代）或 `react-transition-group`（更轻量）

---

## 单元素进入/离开动画

### Vue

```vue
<Transition name="fade">
  <div v-if="visible">Content</div>
</Transition>
```

### React 方案 1：Tailwind + 条件渲染（无卸载延迟）

适用于 `v-show` 语义（不卸载 DOM）：

```tsx
<div
  className={clsx(
    'transition-opacity duration-300',
    visible ? 'opacity-100' : 'opacity-0 pointer-events-none',
  )}
>
  Content
</div>
```

### React 方案 2：framer-motion（有卸载延迟，推荐）

```tsx
import { AnimatePresence, motion } from 'framer-motion'

<AnimatePresence>
  {visible && (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      Content
    </motion.div>
  )}
</AnimatePresence>
```

`AnimatePresence` 会在子组件卸载前等待 exit 动画完成，等价于 Vue `<Transition>` 的 leave 行为。

### React 方案 3：react-transition-group

```tsx
import { CSSTransition } from 'react-transition-group'

<CSSTransition in={visible} timeout={300} classNames="fade" unmountOnExit>
  <div>Content</div>
</CSSTransition>
```

```css
.fade-enter { opacity: 0; }
.fade-enter-active { opacity: 1; transition: opacity 300ms; }
.fade-exit { opacity: 1; }
.fade-exit-active { opacity: 0; transition: opacity 300ms; }
```

类名映射：

| Vue | react-transition-group |
|---|---|
| `fade-enter-from` | `fade-enter` |
| `fade-enter-active` | `fade-enter-active` |
| `fade-enter-to` | `fade-enter-done` |
| `fade-leave-from` | `fade-exit` |
| `fade-leave-active` | `fade-exit-active` |
| `fade-leave-to` | `fade-exit-done` |

---

## 列表动画（TransitionGroup）

### Vue

```vue
<TransitionGroup name="list" tag="ul">
  <li v-for="item in items" :key="item.id">{{ item.text }}</li>
</TransitionGroup>

<style>
.list-enter-active, .list-leave-active { transition: all 0.3s; }
.list-enter-from, .list-leave-to { opacity: 0; transform: translateX(30px); }
.list-move { transition: transform 0.3s; }
</style>
```

### React：framer-motion

```tsx
import { AnimatePresence, motion } from 'framer-motion'

<ul>
  <AnimatePresence>
    {items.map(item => (
      <motion.li
        key={item.id}
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 30 }}
        transition={{ duration: 0.3 }}
        layout  // 自动处理位移动画（等价 .list-move）
      >
        {item.text}
      </motion.li>
    ))}
  </AnimatePresence>
</ul>
```

`layout` prop 自动处理列表项位置变化的过渡动画，等价于 Vue 的 `*-move` 类。

### React：react-transition-group

```tsx
import { TransitionGroup, CSSTransition } from 'react-transition-group'

<TransitionGroup component="ul">
  {items.map(item => (
    <CSSTransition key={item.id} timeout={300} classNames="list">
      <li>{item.text}</li>
    </CSSTransition>
  ))}
</TransitionGroup>
```

> 注意：`react-transition-group` 的 `TransitionGroup` 不自带 FLIP 位移动画（Vue 的 `*-move`），需要自己用 `onExiting` 钩子 + `position: absolute` 处理，或直接用 framer-motion 的 `layout`。

---

## JavaScript 钩子动画

### Vue

```vue
<Transition
  @before-enter="onBeforeEnter"
  @enter="onEnter"
  @after-enter="onAfterEnter"
  @leave="onLeave"
  :css="false"
>
  <div v-if="show">...</div>
</Transition>

<script setup>
function onEnter(el, done) {
  gsap.to(el, { opacity: 1, duration: 0.5, onComplete: done })
}
function onLeave(el, done) {
  gsap.to(el, { opacity: 0, duration: 0.5, onComplete: done })
}
</script>
```

### React：framer-motion（自定义动画）

```tsx
<AnimatePresence>
  {show && (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    />
  )}
</AnimatePresence>
```

### React：react-transition-group + GSAP

```tsx
<CSSTransition
  in={show}
  timeout={500}
  unmountOnExit
  onEnter={(node) => gsap.fromTo(node, { opacity: 0 }, { opacity: 1, duration: 0.5 })}
  onExit={(node) => gsap.to(node, { opacity: 0, duration: 0.5 })}
>
  <div>...</div>
</CSSTransition>
```

钩子映射：

| Vue 钩子 | react-transition-group 钩子 |
|---|---|
| `@before-enter` | `onEnter` |
| `@enter` | `onEntering` |
| `@after-enter` | `onEntered` |
| `@before-leave` | `onExit` |
| `@leave` | `onExiting` |
| `@after-leave` | `onExited` |

---

## 路由切换动画

### Vue

```vue
<router-view v-slot="{ Component }">
  <Transition name="page">
    <component :is="Component" />
  </Transition>
</router-view>
```

### React：framer-motion + React Router

```tsx
import { useLocation, useOutlet } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'

const AnimatedOutlet: FC = () => {
  const location = useLocation()
  const outlet = useOutlet()

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.2 }}
      >
        {outlet}
      </motion.div>
    </AnimatePresence>
  )
}
```

---

## 与 Tailwind 配合的简单过渡

对于不需要卸载延迟的简单过渡（等价 `v-show` + transition），Tailwind 足够：

```tsx
// 下拉菜单展开
<div
  className={clsx(
    'transition-all duration-200 ease-out origin-top',
    open
      ? 'opacity-100 scale-y-100'
      : 'opacity-0 scale-y-95 pointer-events-none',
  )}
>
  {/* menu content */}
</div>
```

常用 Tailwind 过渡工具类：

| 用途 | 类名 |
|---|---|
| 过渡属性 | `transition-all` / `transition-opacity` / `transition-transform` |
| 时长 | `duration-150` / `duration-300` / `duration-500` |
| 缓动 | `ease-in` / `ease-out` / `ease-in-out` |
| 变换原点 | `origin-top` / `origin-center` |

---

## 对照速查

| Vue | React（推荐） |
|---|---|
| `<Transition name="fade">` | `<AnimatePresence>` + `<motion.div>` |
| `<TransitionGroup>` | `<AnimatePresence>` + `layout` prop |
| `v-show` + CSS transition | Tailwind `transition-*` + 条件 class |
| JS 钩子（`@enter` / `@leave`） | framer-motion 的 `initial/animate/exit` 或 CSSTransition 钩子 |
| `<Transition mode="out-in">` | `<AnimatePresence mode="wait">` |
| `<Transition mode="in-out">` | `<AnimatePresence mode="popLayout">` |
| `appear` prop | framer-motion: 组件首次渲染时自动播放 `initial → animate` |

---

## 安装

```bash
# 推荐
npm i framer-motion

# 或轻量方案
npm i react-transition-group @types/react-transition-group
```

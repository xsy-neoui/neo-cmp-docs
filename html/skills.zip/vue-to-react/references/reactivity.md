# 响应式系统 → React 状态/派生映射

## 目录

- 核心理念差异（代理式 vs 不可变 + 重渲染）
- ref / data → useState
- reactive → useState / useReducer
- computed → useMemo / 派生值
- watch / watchEffect → useEffect
- 深层更新与不可变更新技巧
- toRefs / toRef 的 React 做法

---

## 核心理念差异

**这是最重要的一点**：

- Vue 基于 **Proxy 代理**，你可以直接 `obj.a = 1`，框架自动收集依赖、按需更新
- React 基于 **不可变 + 重渲染**：state 永远要用"新引用"替换，组件函数会从头再跑一遍

所以下列模式在 Vue 能用、在 React 会**不更新 UI**：

```tsx
// ❌ 错误
const [user, setUser] = useState({ name: 'a' })
user.name = 'b'         // 直接改属性
setUser(user)           // 同一个引用，React 不会重渲染
```

```tsx
// ✅ 正确
setUser({ ...user, name: 'b' })
// 或
setUser((prev) => ({ ...prev, name: 'b' }))
```

---

## ref / data → useState

### Vue 2 Options API

```js
export default {
  data() {
    return { count: 0, text: 'hi' }
  },
  methods: {
    add() { this.count++ }
  }
}
```

### Vue 3 Composition API

```ts
const count = ref(0)
const text = ref('hi')
function add() { count.value++ }
```

### React 函数组件

```tsx
const [count, setCount] = useState(0)
const [text, setText] = useState('hi')
const add = () => setCount(c => c + 1)
```

### React 类组件

```tsx
class MyCmp extends Component {
  state = { count: 0, text: 'hi' }
  add = () => this.setState(s => ({ count: s.count + 1 }))
}
```

> 用函数式更新（`setCount(c => c + 1)`）可以避免闭包陷阱，尤其在异步回调和 `useEffect` 里。

---

## reactive → useState / useReducer

Vue 3 `reactive` 用于对象/数组的深层响应式：

```ts
const user = reactive({ name: 'a', address: { city: 'BJ' } })
user.address.city = 'SH'  // 自动触发更新
```

React 选择：

### 选项 A：`useState` + 展开（简单场景）

```tsx
const [user, setUser] = useState({ name: 'a', address: { city: 'BJ' } })

// 深层更新要一层层展开
setUser((prev) => ({
  ...prev,
  address: { ...prev.address, city: 'SH' }
}))
```

### 选项 B：`useReducer`（状态变更类型固定、多分支）

```tsx
type Action =
  | { type: 'setName'; value: string }
  | { type: 'setCity'; value: string }

function reducer(state: User, action: Action): User {
  switch (action.type) {
    case 'setName': return { ...state, name: action.value }
    case 'setCity': return { ...state, address: { ...state.address, city: action.value } }
  }
}

const [user, dispatch] = useReducer(reducer, { name: 'a', address: { city: 'BJ' } })
dispatch({ type: 'setCity', value: 'SH' })
```

### 选项 C：Immer（深层嵌套频繁）

```tsx
import { useImmer } from 'use-immer'

const [user, setUser] = useImmer({ name: 'a', address: { city: 'BJ' } })
setUser(draft => { draft.address.city = 'SH' })
```

**经验规则**：
- 扁平对象、改动少 → `useState` + 展开
- 动作类型明确（表单/向导/多分支）→ `useReducer`
- 深层嵌套频繁改 → `useImmer`
- **全局跨组件共享** → 用 MobX（见 state-management.md）

---

## computed → useMemo / 派生值

### 纯计算、无副作用

```ts
// Vue
const double = computed(() => count.value * 2)
const fullName = computed(() => `${first.value} ${last.value}`)
```

```tsx
// React
const double = useMemo(() => count * 2, [count])
const fullName = useMemo(() => `${first} ${last}`, [first, last])
```

### 什么时候**不需要** useMemo

计算极轻（一个加法、字符串拼接、简单 filter），直接在渲染中写即可：

```tsx
const fullName = `${first} ${last}`         // 没问题
const active = items.filter(i => i.active)  // 列表小的话也没问题
```

过度 `useMemo` 本身有内存和比对成本，反而可能更慢。用它的判据：
- 计算涉及**大数组/复杂对象**（排序、深度处理）
- 结果作为**子组件的 prop**，需要稳定引用避免无谓重渲（配合 `React.memo`）
- 结果进入**另一个 `useMemo/useEffect` 的依赖数组**

### 可写 computed

Vue 的 `computed({ get, set })`：

```ts
const name = computed({
  get: () => user.value.name,
  set: (v) => { user.value.name = v }
})
```

React 直接拆成 getter + setter 对：

```tsx
const name = user.name
const setName = (v: string) => setUser(u => ({ ...u, name: v }))
```

---

## watch / watchEffect → useEffect

Vue 的 `watch` 是**副作用**（订阅、请求、DOM 操作等），React 侧对应 `useEffect`。

### 监听单个源

```ts
// Vue
watch(id, (newId, oldId) => {
  fetchUser(newId)
})
```

```tsx
// React
useEffect(() => {
  fetchUser(id)
}, [id])
```

> 注意 React 的 `useEffect` 不直接提供 "oldValue"。如果确实需要，用 `useRef` 手动保存：
> ```tsx
> const prevId = useRef(id)
> useEffect(() => {
>   const oldId = prevId.current
>   prevId.current = id
>   // 此时能拿到 oldId
> }, [id])
> ```

### 监听多个源

```ts
watch([a, b], ([newA, newB]) => { ... })
```

```tsx
useEffect(() => { ... }, [a, b])
```

### watchEffect

自动收集依赖，启动时立即执行：

```ts
watchEffect(() => {
  console.log(count.value)
})
```

```tsx
useEffect(() => {
  console.log(count)
}, [count])   // 需手动列依赖，ESLint 的 react-hooks/exhaustive-deps 会提示
```

### immediate: true / flush: 'post'

- `immediate: true` → `useEffect` 默认就是挂载时执行，天然满足
- `flush: 'post'`（DOM 更新后执行）→ `useEffect` 默认就是这个时机；若需要布局前（如测量 DOM），用 `useLayoutEffect`

### 深度监听（deep: true）

```ts
watch(obj, cb, { deep: true })
```

React 里一般通过 **替换引用**来触发更新（见上文），所以 `useEffect(..., [obj])` 会在每次新引用时触发。如果你依然需要"值相等才触发"（避免结构不变但引用变），可以用 `useDeepCompareEffect`（第三方）或手动 `JSON.stringify` 比较（有代价）。

### 清理副作用

```ts
// Vue
onBeforeUnmount(() => { clearInterval(timer) })
```

```tsx
useEffect(() => {
  const timer = setInterval(...)
  return () => clearInterval(timer)   // cleanup
}, [])
```

---

## toRefs / toRef

Vue 3 用 `toRefs` 解构 reactive 对象同时保持响应式。React 里本质不存在此问题 —— 对象本身就是引用，解构取出的是快照值，每次重渲染都会重新取：

```tsx
const { name, age } = user   // 每次 render 都是最新的
```

如果你要把**单个字段**传给子组件并希望它单独响应变化，React 的做法是直接传 `name` 这个值，React 比对前后 prop 决定是否更新子组件。

---

## 数组/集合更新备忘

| 操作 | Vue | React |
|---|---|---|
| push | `arr.push(x)` | `setArr(a => [...a, x])` |
| unshift | `arr.unshift(x)` | `setArr(a => [x, ...a])` |
| 按索引改 | `arr[i] = x`（Vue 2 要 `$set`） | `setArr(a => a.map((v, idx) => idx === i ? x : v))` |
| splice 删 | `arr.splice(i, 1)` | `setArr(a => a.filter((_, idx) => idx !== i))` |
| sort | `arr.sort(cmp)` | `setArr(a => [...a].sort(cmp))`（先拷贝） |
| Map/Set 修改 | 直接 `.set/.add` | 创建新实例：`setM(m => new Map(m).set(k, v))` |

---

## 对照表速查

| Vue | React 函数 | React 类 |
|---|---|---|
| `data() { ... }` | `useState` | `this.state` + `this.setState` |
| `ref(x)` | `useState(x)` | 同上 |
| `reactive(obj)` | `useState(obj)` / `useReducer` / `useImmer` | `this.state = obj` |
| `computed(() => ...)` | `useMemo(() => ..., [deps])` | 渲染时计算 or getter |
| `watch(a, cb)` | `useEffect(cb, [a])` | `componentDidUpdate` |
| `watchEffect(cb)` | `useEffect(cb, [...依赖])` | 同上 |
| `onBeforeUnmount` cleanup | `useEffect` 返回的函数 | `componentWillUnmount` |

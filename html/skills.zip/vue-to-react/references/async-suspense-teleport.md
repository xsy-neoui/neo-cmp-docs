# 异步组件 / Suspense / Teleport → React 对应

## 目录

- 异步组件（defineAsyncComponent → React.lazy）
- Suspense（Vue 3 → React）
- Teleport（Vue 3 → createPortal）

---

## 异步组件

### Vue 3

```ts
import { defineAsyncComponent } from 'vue'

const AsyncChart = defineAsyncComponent({
  loader: () => import('./Chart.vue'),
  loadingComponent: LoadingSpinner,
  errorComponent: ErrorDisplay,
  delay: 200,        // 延迟显示 loading（避免闪烁）
  timeout: 10000,    // 超时
})
```

简写：

```ts
const AsyncChart = defineAsyncComponent(() => import('./Chart.vue'))
```

### Vue 2（异步组件工厂）

```js
const AsyncChart = () => ({
  component: import('./Chart.vue'),
  loading: LoadingSpinner,
  error: ErrorDisplay,
  delay: 200,
  timeout: 10000,
})
```

### React：`React.lazy` + `Suspense`

```tsx
import { lazy, Suspense } from 'react'

const Chart = lazy(() => import('./Chart'))

// 使用
<Suspense fallback={<LoadingSpinner />}>
  <Chart />
</Suspense>
```

### 对照映射

| Vue | React |
|---|---|
| `defineAsyncComponent(() => import(...))` | `lazy(() => import(...))` |
| `loadingComponent` | `<Suspense fallback={...}>` |
| `errorComponent` | 用 `ErrorBoundary` 包裹 |
| `delay`（延迟显示 loading） | 无内建；可自定义 fallback 组件内部用 `setTimeout` 延迟显示 |
| `timeout` | 无内建；在 loader 里自己实现超时逻辑 |

### 完整等价（含错误处理和延迟）

```tsx
// DelayedFallback：延迟显示 loading，避免闪烁
const DelayedFallback: FC<{ delay?: number }> = ({ delay = 200 }) => {
  const [show, setShow] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setShow(true), delay)
    return () => clearTimeout(t)
  }, [delay])
  return show ? <LoadingSpinner /> : null
}

// 使用
<ErrorBoundary fallback={(e) => <ErrorDisplay error={e} />}>
  <Suspense fallback={<DelayedFallback />}>
    <Chart />
  </Suspense>
</ErrorBoundary>
```

### 命名导出的懒加载

`React.lazy` 默认只支持 default export。如果模块是命名导出：

```tsx
const Chart = lazy(() =>
  import('./Chart').then(mod => ({ default: mod.Chart }))
)
```

### 预加载（Prefetch）

```tsx
// 鼠标悬停时预加载
const chartLoader = () => import('./Chart')
const Chart = lazy(chartLoader)

<button onMouseEnter={() => chartLoader()}>
  Show Chart
</button>
```

---

## Suspense

### Vue 3 Suspense

```vue
<Suspense>
  <template #default>
    <AsyncPage />
  </template>
  <template #fallback>
    <LoadingSpinner />
  </template>
</Suspense>
```

Vue 3 的 `<Suspense>` 等待子组件的 `async setup()` 完成。

### React Suspense

```tsx
<Suspense fallback={<LoadingSpinner />}>
  <AsyncPage />
</Suspense>
```

React 的 `Suspense` 捕获子树中抛出的 Promise（由 `lazy`、数据获取库如 React Query/SWR 的 suspense 模式触发）。

### 关键差异

| 特性 | Vue 3 Suspense | React Suspense |
|---|---|---|
| 触发条件 | `async setup()` 返回的 Promise | 子组件 throw Promise（lazy / 数据库 suspense 模式） |
| 嵌套 Suspense | 支持，最近的 Suspense 捕获 | 支持，同理 |
| 错误处理 | `onErrorCaptured` | `ErrorBoundary` |
| 数据获取 | `async setup` 里 await | 需配合 React Query / SWR / use() hook |
| 过渡 | `<Suspense>` 有 `@pending` / `@resolve` 事件 | `useTransition` + `startTransition` |

### React 数据获取 + Suspense（React 18+）

```tsx
// 使用 React Query 的 suspense 模式
import { useSuspenseQuery } from '@tanstack/react-query'

const UserProfile: FC<{ id: string }> = ({ id }) => {
  const { data } = useSuspenseQuery({
    queryKey: ['user', id],
    queryFn: () => fetchUser(id),
  })
  return <div>{data.name}</div>
}

// 父组件
<Suspense fallback={<Skeleton />}>
  <UserProfile id={userId} />
</Suspense>
```

---

## Teleport → createPortal

### Vue 3

```vue
<Teleport to="body">
  <div class="modal-overlay">
    <div class="modal">{{ content }}</div>
  </div>
</Teleport>

<!-- 条件 Teleport -->
<Teleport to="#modals" :disabled="inline">
  <Modal />
</Teleport>
```

### React：`createPortal`

```tsx
import { createPortal } from 'react-dom'

const Modal: FC<{ children: ReactNode }> = ({ children }) => {
  return createPortal(
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6">{children}</div>
    </div>,
    document.body,
  )
}

// 使用
{showModal && <Modal>内容</Modal>}
```

### 条件 Portal（对应 `:disabled`）

```tsx
interface PortalProps {
  children: ReactNode
  container?: Element | null
  disabled?: boolean
}

const ConditionalPortal: FC<PortalProps> = ({
  children,
  container,
  disabled = false,
}) => {
  if (disabled || !container) return <>{children}</>
  return createPortal(children, container)
}

// 使用
<ConditionalPortal container={document.getElementById('modals')} disabled={inline}>
  <Modal />
</ConditionalPortal>
```

### 指定目标容器

```tsx
// Vue: <Teleport to="#modals">
// React:
createPortal(<Modal />, document.getElementById('modals')!)

// Vue: <Teleport to=".sidebar">
// React:
const sidebarEl = document.querySelector('.sidebar')
if (sidebarEl) createPortal(<Widget />, sidebarEl)
```

### Portal 内的事件冒泡

**重要差异**：React 的 Portal 中，事件会沿 **React 组件树**冒泡（而非 DOM 树）。这意味着即使 Portal 渲染到 `document.body`，其内部的事件仍然能被 React 父组件捕获。Vue 的 Teleport 则是按 DOM 树冒泡。

```tsx
// 父组件能捕获 Portal 内的 click
<div onClick={() => console.log('caught!')}>
  {createPortal(<button onClick={() => {}}>Click</button>, document.body)}
</div>
// 点击 button 后，'caught!' 会被打印
```

### 常见 Portal 使用场景

| 场景 | 实现 |
|---|---|
| Modal / Dialog | Portal 到 body + 固定定位 |
| Tooltip / Popover | Portal 到 body + 绝对定位（配合 Floating UI） |
| Toast / Notification | Portal 到专用容器 `#toast-root` |
| 全屏 Overlay | Portal 到 body |

---

## 对照速查

| Vue | React |
|---|---|
| `defineAsyncComponent(() => import(...))` | `lazy(() => import(...))` |
| `<Suspense>` + `#fallback` | `<Suspense fallback={...}>` |
| `async setup()` | 数据获取库的 suspense 模式 / `use()` hook |
| `<Teleport to="body">` | `createPortal(jsx, document.body)` |
| `<Teleport :disabled="x">` | 条件判断：disabled 时直接渲染，否则 Portal |
| `<Teleport to="#target">` | `createPortal(jsx, document.getElementById('target'))` |

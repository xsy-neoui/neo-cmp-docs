# 路由：Vue Router → React Router v5 / v6

本技能目标 React 16，默认推荐 **React Router v5**（与 React 16 完全兼容）。如果项目允许且团队熟悉 v6，也可使用 React Router v6（需 React 16.8+）。下文同时给出两个版本的映射。

## 目录

- 路由定义（v5 / v6）
- 组件映射（RouterView / RouterLink / NavLink）
- 编程式导航（push / replace / back）
- 路由参数 / 查询参数
- 嵌套路由
- 命名路由 / 路径匹配
- 路由守卫（beforeEach / beforeEnter）
- 路由元信息（meta）
- 懒加载 / 代码分割
- 404 / 重定向

---

## 路由定义

### Vue Router

```ts
import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', component: Home },
    { path: '/users/:id', component: User, name: 'user' },
    { path: '/admin', component: AdminLayout, children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'settings', component: Settings },
    ]},
  ],
})
```

### React Router v5（推荐，兼容 React 16）

```tsx
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom'

<BrowserRouter>
  <Switch>
    <Route exact path="/" component={Home} />
    <Route path="/users/:id" component={User} />
    <Route path="/admin" component={AdminLayout} />
  </Switch>
</BrowserRouter>
```

AdminLayout 内部嵌套路由：

```tsx
// AdminLayout.tsx
import { Switch, Route, useRouteMatch } from 'react-router-dom'

const AdminLayout: FC = () => {
  const { path } = useRouteMatch()
  return (
    <div className="flex">
      <aside>...</aside>
      <main>
        <Switch>
          <Route path={`${path}/dashboard`} component={Dashboard} />
          <Route path={`${path}/settings`} component={Settings} />
        </Switch>
      </main>
    </div>
  )
}
```

### React Router v6（数据路由 API）

```tsx
import { createBrowserRouter, RouterProvider } from 'react-router-dom'

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/users/:id', element: <User /> },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: [
      { path: 'dashboard', element: <Dashboard /> },
      { path: 'settings', element: <Settings /> },
    ],
  },
])

<RouterProvider router={router} />
```

---

## 组件映射

| Vue Router | React Router v5 | React Router v6 |
|---|---|---|
| `<router-view>` | `<Switch>` + `<Route>` | `<Outlet />` |
| `<router-link to="/x">` | `<Link to="/x">` | `<Link to="/x">` |
| `<router-link :to="{ name: 'user', params: { id } }">` | `` <Link to={`/users/${id}`}> `` | 同左 |
| active class | `<NavLink activeClassName="active">` | `<NavLink className={({isActive}) => ...}>` |

### v5 NavLink 示例

```tsx
import { NavLink } from 'react-router-dom'

<NavLink to="/users" activeClassName="active" className="nav-link">
  Users
</NavLink>
```

### v6 NavLink 示例

```tsx
<NavLink to="/users" className={({ isActive }) => clsx('nav-link', isActive && 'active')}>
  Users
</NavLink>
```

---

## 编程式导航

### Vue

```js
this.$router.push('/users/1')
this.$router.push({ name: 'user', params: { id: 1 } })
this.$router.replace('/login')
this.$router.back()
this.$router.go(-2)
```

### React Router v5

```tsx
import { useHistory } from 'react-router-dom'

const history = useHistory()
history.push('/users/1')
history.replace('/login')
history.goBack()
history.go(-2)
```

类组件里可以用 `withRouter` HOC：

```tsx
import { withRouter, RouteComponentProps } from 'react-router-dom'

class MyComponent extends Component<Props & RouteComponentProps> {
  navigate = () => {
    this.props.history.push('/users/1')
  }
}

export default withRouter(MyComponent)
```

### React Router v6

```tsx
import { useNavigate } from 'react-router-dom'

const navigate = useNavigate()
navigate('/users/1')
navigate('/login', { replace: true })
navigate(-1)    // back
navigate(-2)
```

---

## 路由参数

```tsx
// 路径：/users/:id
import { useParams } from 'react-router-dom'

const User: FC = () => {
  const { id } = useParams<{ id: string }>()   // 注意始终是 string
  return <div>User #{id}</div>
}
```

查询参数（对应 Vue 的 `$route.query`）：

```tsx
import { useSearchParams } from 'react-router-dom'

const [params, setParams] = useSearchParams()
const page = Number(params.get('page') ?? 1)
setParams({ page: String(page + 1) })
```

---

## 嵌套路由 + Outlet

```tsx
// AdminLayout.tsx
import { Outlet, Link } from 'react-router-dom'

const AdminLayout: FC = () => (
  <div className="flex">
    <aside>
      <Link to="dashboard">Dashboard</Link>
      <Link to="settings">Settings</Link>
    </aside>
    <main>
      <Outlet />   {/* 相当于 <router-view /> */}
    </main>
  </div>
)
```

子路由传参给父级：用 Context / outlet context：

```tsx
<Outlet context={{ user }} />
// 子组件
const { user } = useOutletContext<{ user: User }>()
```

---

## 路由守卫

Vue Router 的 `beforeEach` / `beforeEnter` / `beforeRouteEnter` 在 React Router 里没有直接的全局钩子，替代方案有三种：

### 方案 1：包装组件（最常用）

```tsx
const RequireAuth: FC<PropsWithChildren> = ({ children }) => {
  const { user } = useAuth()
  const location = useLocation()
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }
  return <>{children}</>
}

// 使用
{ path: '/admin', element: <RequireAuth><AdminLayout /></RequireAuth> }
```

### 方案 2：loader（数据路由 API）

```tsx
{
  path: '/admin',
  loader: async () => {
    const user = await getUser()
    if (!user) throw redirect('/login')
    return { user }
  },
  element: <AdminLayout />,
}
```

组件里用 `useLoaderData()` 获取数据。

### 方案 3：路由级 useEffect

不推荐全局用，但对单页面可行：

```tsx
useEffect(() => {
  if (!user) navigate('/login', { replace: true })
}, [user])
```

### 全局前置守卫的近似实现

在根布局里用 `useLocation` + `useEffect` 统一拦截：

```tsx
const RootLayout: FC = () => {
  const location = useLocation()
  useEffect(() => {
    // 每次路由变化
    reportAnalytics(location.pathname)
  }, [location])
  return <Outlet />
}
```

---

## 路由元信息（meta）

Vue Router 的 `meta` 在 React Router 中没有内建字段，可以自己扩展：

```tsx
interface AppRouteObject extends RouteObject {
  meta?: { title?: string; requiresAuth?: boolean }
  children?: AppRouteObject[]
}

const routes: AppRouteObject[] = [
  { path: '/admin', element: <Admin />, meta: { requiresAuth: true, title: '管理' } },
]
```

然后写一个 handle 或者在遍历 routes 时读取 meta 应用规则。`createBrowserRouter` 还支持 `handle` 字段，搭配 `useMatches()` 消费：

```tsx
{ path: '/admin', element: <Admin />, handle: { title: '管理' } }

// 在根组件
const matches = useMatches()
const title = matches.reverse().find(m => (m.handle as any)?.title)?.handle.title
```

---

## 懒加载 / 代码分割

### Vue

```js
{ path: '/about', component: () => import('./About.vue') }
```

### React Router（数据路由 API）

```tsx
{
  path: '/about',
  lazy: async () => {
    const { About } = await import('./About')
    return { element: <About /> }
  },
}
```

或经典方式 `React.lazy` + `Suspense`：

```tsx
const About = lazy(() => import('./About'))

<Route
  path="/about"
  element={
    <Suspense fallback={<Loading />}>
      <About />
    </Suspense>
  }
/>
```

---

## 404 / 重定向

### Vue

```js
{ path: '/:pathMatch(.*)*', component: NotFound }
{ path: '/old', redirect: '/new' }
```

### React Router

```tsx
{ path: '*', element: <NotFound /> }
{ path: '/old', element: <Navigate to="/new" replace /> }
```

---

## 滚动行为

Vue Router 的 `scrollBehavior`，React Router 没内建。手写：

```tsx
const ScrollToTop: FC = () => {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname])
  return null
}

// 放在 RouterProvider 旁边或 Layout 顶层
```

---

## 类型安全的路由常量

为避免魔法字符串，推荐集中定义路径并导出 helper：

```ts
// routes/paths.ts
export const PATHS = {
  home: '/',
  login: '/login',
  user: (id: string | number) => `/users/${id}`,
  admin: {
    dashboard: '/admin/dashboard',
    settings: '/admin/settings',
  },
} as const
```

使用：`navigate(PATHS.user(123))`。

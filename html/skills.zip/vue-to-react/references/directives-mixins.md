# 指令与 Mixin 的 React 替代

## 目录

- 内置指令一览
- 自定义指令 → 自定义 hook（首选）/ HOC / 组件包装
- mixin → 自定义 hook（首选）/ HOC（涉及渲染/props 注入时）
- 过滤器（filter）→ 普通函数或 hook
- 全局方法 / `Vue.prototype.$xxx` → Context hook / 直接 import

---

## 内置指令速查

| Vue | React |
|---|---|
| `v-if` / `v-else` | 三元 / `&&` |
| `v-show` | `hidden` 属性 / Tailwind `hidden` / `style={{ display }}` |
| `v-for` | `.map()` |
| `v-on` / `@` | `onXxx` |
| `v-bind` / `:` | `{}` 绑定 |
| `v-model` | 受控 `value` + `onChange` |
| `v-html` | `dangerouslySetInnerHTML={{ __html }}`（务必 sanitize） |
| `v-text` | `{text}` |
| `v-pre` | 不需要 |
| `v-cloak` | 不需要 |
| `v-once` | `useMemo` 或纯组件 + `React.memo` |
| `v-slot` / `#` | children / 具名 prop / render prop |

---

## 自定义指令 → 自定义 Hook（首选）

大部分 Vue 自定义指令的职责是"对某个 DOM 元素做附加行为"。React 里用 **自定义 hook + ref** 就能覆盖绝大多数场景。

### 示例 1：v-click-outside

Vue：

```js
// directives/click-outside.js
export default {
  mounted(el, binding) {
    el._clickOutside = (e) => { if (!el.contains(e.target)) binding.value(e) }
    document.addEventListener('mousedown', el._clickOutside)
  },
  unmounted(el) {
    document.removeEventListener('mousedown', el._clickOutside)
  },
}

// 使用
<div v-click-outside="onClose" />
```

React hook：

```tsx
// hooks/useClickOutside.ts
export function useClickOutside<T extends HTMLElement>(
  ref: RefObject<T>,
  handler: (e: MouseEvent) => void,
) {
  useEffect(() => {
    const listener = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        handler(e)
      }
    }
    document.addEventListener('mousedown', listener)
    return () => document.removeEventListener('mousedown', listener)
  }, [ref, handler])
}

// 使用
const boxRef = useRef<HTMLDivElement>(null)
useClickOutside(boxRef, onClose)
return <div ref={boxRef}>...</div>
```

### 示例 2：v-focus（自动聚焦）

```tsx
// hooks/useAutoFocus.ts
export function useAutoFocus<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  useEffect(() => { ref.current?.focus() }, [])
  return ref
}

// 使用
const inputRef = useAutoFocus<HTMLInputElement>()
<input ref={inputRef} />
```

### 示例 3：v-lazy（图片懒加载）

可以用 hook，也可以封装成专用组件：

```tsx
// 组件方案
interface LazyImgProps extends ImgHTMLAttributes<HTMLImageElement> {
  src: string
  placeholder?: string
}
export const LazyImg: FC<LazyImgProps> = ({ src, placeholder, ...rest }) => {
  const [loaded, setLoaded] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)
  useEffect(() => {
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setLoaded(true)
        io.disconnect()
      }
    })
    if (imgRef.current) io.observe(imgRef.current)
    return () => io.disconnect()
  }, [])
  return <img ref={imgRef} src={loaded ? src : placeholder} {...rest} />
}
```

### 何时用 HOC 而不是 hook

当你需要**注入 props**、**包裹渲染结构**、或在**类组件**里使用时，HOC 更合适：

```tsx
// withLoading HOC
export function withLoading<P extends { loading?: boolean }>(
  Cmp: ComponentType<P>,
) {
  return function Wrapped(props: P) {
    if (props.loading) return <Spinner />
    return <Cmp {...props} />
  }
}

const UserCardWithLoading = withLoading(UserCard)
```

---

## Mixin → 自定义 Hook（首选）

Vue 2 的 mixin 是经典的代码复用机制，但有命名冲突、来源不清等问题。React 侧几乎都可以用**自定义 hook**优雅替代。

### Vue 2 Mixin 示例

```js
// mixins/timer.js
export const timerMixin = {
  data() { return { elapsed: 0 } },
  mounted() {
    this._timer = setInterval(() => { this.elapsed++ }, 1000)
  },
  beforeDestroy() {
    clearInterval(this._timer)
  },
}

// 使用
export default {
  mixins: [timerMixin],
  // 这个组件自动拥有 this.elapsed 并每秒 +1
}
```

### 等价 React Hook

```tsx
// hooks/useTimer.ts
export function useTimer(intervalMs = 1000) {
  const [elapsed, setElapsed] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), intervalMs)
    return () => clearInterval(t)
  }, [intervalMs])
  return elapsed
}

// 使用
const elapsed = useTimer()
return <div>{elapsed}</div>
```

### 涉及渲染结构的 mixin → HOC

如果原 mixin 不仅有数据、还改变渲染/注入 props（较罕见），用 HOC：

```tsx
// Vue mixin 里有一个 provide 了某个 service
// 在 React 里：
export function withAnalytics<P>(Cmp: ComponentType<P & { track: (e: string) => void }>) {
  return (props: P) => {
    const track = useCallback((e: string) => analytics.track(e), [])
    return <Cmp {...props} track={track} />
  }
}
```

### 多 mixin 组合

Vue 多 mixin 合并（有潜在冲突）→ React 多 hook 调用（显式、无冲突）：

```tsx
const user = useUser()
const theme = useTheme()
const elapsed = useTimer()
```

这正是 hook 相对 mixin 的最大优势：**来源显式、可组合、TypeScript 友好**。

---

## 过滤器（filter）

Vue 2 的 `{{ price | currency }}` 在 Vue 3 已被弃用，React 里同样不需要特殊语法 —— **直接调用函数**：

```ts
// utils/format.ts
export function currency(n: number, locale = 'zh-CN', currency = 'CNY') {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(n)
}
```

```tsx
<span>{currency(price)}</span>
```

如果格式化需要响应语言/区域变化，用 hook：

```tsx
// hooks/useFormatters.ts
export function useFormatters() {
  const locale = useLocale()   // 从 Context 拿
  return useMemo(() => ({
    currency: (n: number) => new Intl.NumberFormat(locale, { style: 'currency', currency: 'CNY' }).format(n),
    date: (d: Date) => new Intl.DateTimeFormat(locale).format(d),
  }), [locale])
}

// 使用
const { currency } = useFormatters()
<span>{currency(price)}</span>
```

---

## 全局方法 / `Vue.prototype.$xxx`

Vue 2 常见的扩展：

```js
Vue.prototype.$http = axios
Vue.prototype.$toast = toastService
// 组件里：this.$toast.success('ok')
```

React 侧的几种方案：

### 方案 1：直接 import（推荐给"纯工具"）

```ts
// services/http.ts
export const http = axios.create({ baseURL: '/api' })
```

```tsx
import { http } from '@/services/http'
http.get('/users')
```

纯工具函数无需通过 Context，直接 import 最简单。

### 方案 2：Context + hook（推荐给"需要注入的服务"）

带有副作用且可能被替换（测试、多租户）的服务，用 Context：

```tsx
const ToastContext = createContext<ToastService | null>(null)
export const useToast = () => {
  const t = useContext(ToastContext)
  if (!t) throw new Error('useToast must be used within ToastProvider')
  return t
}

// 使用
const toast = useToast()
toast.success('ok')
```

### 方案 3：全局单例 + hook

结合两者的简单做法：

```ts
// toast.ts
class ToastService { success(msg: string) { /* ... */ } }
export const toast = new ToastService()
export const useToast = () => toast
```

测试时可以 mock `toast` 模块。

---

## 全局组件注册

Vue 2 的 `Vue.component('BaseButton', BaseButton)` 让组件全局可用。React 里**没有全局注册**的概念，所有组件都要 `import`。

迁移做法：
- 在 `components/` 建立组件库，逐个导出
- 使用 `index.ts` 统一 re-export：`export { BaseButton } from './BaseButton'`
- 必要时配 `@/components` 路径别名（`tsconfig.paths` + Vite alias）

---

## 小结

- **九成的自定义指令 / mixin** → 自定义 hook
- **需要包渲染 / 注入 props / 在类组件里用** → HOC
- **过滤器** → 普通函数或 hook
- **全局方法** → import 或 Context + hook
- **全局组件** → 不存在，老老实实 import

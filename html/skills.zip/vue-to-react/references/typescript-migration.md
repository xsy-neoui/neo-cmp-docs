# TypeScript 迁移：Vue TS 写法 → React TS

## 目录

- Vue 2 的 TS 方案概览
- Vue.extend → React 函数/类组件
- vue-class-component → React 类组件
- vue-property-decorator → React 类组件
- Vue 3 `<script setup lang="ts">` → React FC
- 类型定义最佳实践
- 泛型组件
- 类型工具与常用模式

---

## Vue 2 的 TS 方案概览

Vue 2 有三种 TS 写法：

1. **`Vue.extend`**：最基础，类型推断有限
2. **`vue-class-component`**：用 class 语法写组件
3. **`vue-property-decorator`**：在 class-component 基础上加装饰器（`@Prop`、`@Watch`、`@Emit`）

---

## Vue.extend → React

### Vue

```ts
import Vue from 'vue'

export default Vue.extend({
  props: {
    title: { type: String, required: true },
    count: { type: Number, default: 0 },
  },
  data() {
    return { internal: '' }
  },
  computed: {
    display(): string {
      return `${this.title}: ${this.count}`
    },
  },
  methods: {
    handleClick(): void {
      this.$emit('click', this.count)
    },
  },
})
```

### React 函数组件

```tsx
interface Props {
  title: string
  count?: number
  onClick?: (count: number) => void
}

export const MyComponent: FC<Props> = ({ title, count = 0, onClick }) => {
  const [internal, setInternal] = useState('')
  const display = useMemo(() => `${title}: ${count}`, [title, count])

  const handleClick = () => onClick?.(count)

  return <div onClick={handleClick}>{display}</div>
}
```

---

## vue-class-component → React 类组件

### Vue

```ts
import { Component, Vue } from 'vue-class-component'

@Component
export default class UserCard extends Vue {
  // data
  loading = false
  user: User | null = null

  // computed
  get displayName(): string {
    return this.user?.name ?? 'Guest'
  }

  // lifecycle
  mounted() {
    this.fetchUser()
  }

  // methods
  async fetchUser() {
    this.loading = true
    this.user = await api.getUser()
    this.loading = false
  }
}
```

### React 类组件

```tsx
interface Props {}
interface State {
  loading: boolean
  user: User | null
}

export class UserCard extends Component<Props, State> {
  state: State = { loading: false, user: null }

  get displayName(): string {
    return this.state.user?.name ?? 'Guest'
  }

  componentDidMount() {
    this.fetchUser()
  }

  fetchUser = async () => {
    this.setState({ loading: true })
    const user = await api.getUser()
    this.setState({ user, loading: false })
  }

  render() {
    return <div>{this.displayName}</div>
  }
}
```

---

## vue-property-decorator → React

### Vue

```ts
import { Component, Prop, Watch, Emit, Vue } from 'vue-property-decorator'

@Component
export default class SearchBox extends Vue {
  @Prop({ type: String, required: true }) readonly value!: string
  @Prop({ type: Boolean, default: false }) readonly disabled!: boolean

  query = ''

  @Watch('value', { immediate: true })
  onValueChange(v: string) {
    this.query = v
  }

  @Emit('search')
  handleSearch() {
    return this.query
  }

  @Emit('input')
  handleInput(e: Event) {
    return (e.target as HTMLInputElement).value
  }
}
```

### React 函数组件

```tsx
interface SearchBoxProps {
  value: string
  disabled?: boolean
  onSearch?: (query: string) => void
  onInput?: (value: string) => void
}

export const SearchBox: FC<SearchBoxProps> = ({
  value,
  disabled = false,
  onSearch,
  onInput,
}) => {
  const [query, setQuery] = useState(value)

  // @Watch('value', { immediate: true })
  useEffect(() => {
    setQuery(value)
  }, [value])

  // @Emit('search')
  const handleSearch = () => onSearch?.(query)

  // @Emit('input')
  const handleInput = (e: ChangeEvent<HTMLInputElement>) => {
    onInput?.(e.target.value)
  }

  return (
    <input
      value={query}
      disabled={disabled}
      onChange={handleInput}
      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
    />
  )
}
```

### 装饰器映射

| vue-property-decorator | React 等价 |
|---|---|
| `@Prop()` | interface Props 的字段 |
| `@Prop({ default: x })` | 解构默认值 `= x` |
| `@Watch('x')` | `useEffect(..., [x])` |
| `@Watch('x', { immediate: true })` | `useEffect(..., [x])`（默认就是 immediate） |
| `@Watch('x', { deep: true })` | `useEffect` + 引用变更触发 |
| `@Emit('event')` | 回调 prop `onEvent?.()` |
| `@Ref('el')` | `useRef()` |
| `@Provide() / @Inject()` | Context + useContext |
| `@Model('change', { type: String })` | `value` + `onChange` prop |

---

## Vue 3 `<script setup lang="ts">` → React FC

### Vue 3

```vue
<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'

interface Props {
  items: Item[]
  selected?: string
}

const props = withDefaults(defineProps<Props>(), {
  selected: '',
})

const emit = defineEmits<{
  (e: 'select', id: string): void
  (e: 'delete', id: string): void
}>()

const search = ref('')
const filtered = computed(() =>
  props.items.filter(i => i.name.includes(search.value))
)

watch(() => props.selected, (id) => {
  console.log('selected changed:', id)
})

onMounted(() => { /* ... */ })
</script>
```

### React

```tsx
interface Props {
  items: Item[]
  selected?: string
  onSelect?: (id: string) => void
  onDelete?: (id: string) => void
}

export const ItemList: FC<Props> = ({
  items,
  selected = '',
  onSelect,
  onDelete,
}) => {
  const [search, setSearch] = useState('')

  const filtered = useMemo(
    () => items.filter(i => i.name.includes(search)),
    [items, search],
  )

  useEffect(() => {
    console.log('selected changed:', selected)
  }, [selected])

  useEffect(() => { /* mounted */ }, [])

  return (/* JSX */)
}
```

---

## 类型定义最佳实践

### Props 类型

```tsx
// 基础 props
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  children: ReactNode
  onClick?: (e: MouseEvent<HTMLButtonElement>) => void
}

// 继承原生 HTML 属性
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost'
  loading?: boolean
}

// 排除冲突属性
interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange'> {
  size?: 'sm' | 'md' | 'lg'
  onChange?: (value: string) => void
}
```

### 事件类型

```tsx
import { MouseEvent, ChangeEvent, KeyboardEvent, FormEvent } from 'react'

// 事件处理函数类型
const handleClick = (e: MouseEvent<HTMLButtonElement>) => {}
const handleChange = (e: ChangeEvent<HTMLInputElement>) => {}
const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {}
const handleSubmit = (e: FormEvent<HTMLFormElement>) => {}
```

### Ref 类型

```tsx
const divRef = useRef<HTMLDivElement>(null)
const inputRef = useRef<HTMLInputElement>(null)
const timerRef = useRef<number | null>(null)    // 存非 DOM 值
```

### State 类型

```tsx
// 简单
const [count, setCount] = useState(0)                    // 自动推断 number
const [user, setUser] = useState<User | null>(null)      // 需要显式标注

// 复杂
interface FormState {
  name: string
  email: string
  errors: Record<string, string>
}
const [form, setForm] = useState<FormState>({ name: '', email: '', errors: {} })
```

---

## 泛型组件

### Vue 3（泛型组件）

```vue
<script setup lang="ts" generic="T extends { id: string }">
defineProps<{ items: T[]; selected?: T }>()
defineEmits<{ (e: 'select', item: T): void }>()
</script>
```

### React 泛型组件

```tsx
interface ListProps<T> {
  items: T[]
  selected?: T
  onSelect?: (item: T) => void
  renderItem: (item: T) => ReactNode
  keyExtractor: (item: T) => string
}

export function List<T>({
  items,
  selected,
  onSelect,
  renderItem,
  keyExtractor,
}: ListProps<T>) {
  return (
    <ul>
      {items.map(item => (
        <li
          key={keyExtractor(item)}
          onClick={() => onSelect?.(item)}
          className={item === selected ? 'bg-blue-50' : ''}
        >
          {renderItem(item)}
        </li>
      ))}
    </ul>
  )
}

// 使用时自动推断 T
<List
  items={users}
  renderItem={(user) => <span>{user.name}</span>}
  keyExtractor={(user) => user.id}
  onSelect={(user) => setSelected(user)}
/>
```

> 注意：泛型组件不能用 `FC` 类型（它不支持泛型参数），直接用普通函数声明。

---

## 常用类型工具

```tsx
import {
  FC,
  PropsWithChildren,
  ReactNode,
  ComponentType,
  ComponentProps,
  RefObject,
  ForwardedRef,
} from 'react'

// 获取组件的 props 类型
type BtnProps = ComponentProps<typeof Button>

// 带 children 的 props
type LayoutProps = PropsWithChildren<{ sidebar?: ReactNode }>

// HOC 类型
function withAuth<P extends object>(Cmp: ComponentType<P>) {
  return (props: P) => {
    const user = useAuth()
    if (!user) return <Navigate to="/login" />
    return <Cmp {...props} />
  }
}

// forwardRef 类型
const Input = forwardRef<HTMLInputElement, InputProps>((props, ref) => (
  <input ref={ref} {...props} />
))
```

---

## 从 Vue TS 迁移的常见坑

1. **Vue 的 `this` 类型推断** → React 类组件里 `this.props` / `this.state` 有完整类型；函数组件通过参数解构获得类型

2. **Vue 的 `PropType<T>`** → 直接用 TS interface，不需要运行时类型声明

3. **`$refs` 类型** → `useRef<HTMLElement>(null)` 需要显式泛型参数

4. **事件参数类型** → Vue 的 `$event` 是原生事件；React 的是 `SyntheticEvent` 包装，类型更严格

5. **Vuex/Pinia 的类型** → MobX class 天然有完整类型推断，无需额外类型声明

6. **模板里的类型** → Vue 模板里类型检查依赖 Volar；React JSX 里 TS 直接检查，更严格

---

## 对照速查

| Vue TS 概念 | React TS 等价 |
|---|---|
| `Vue.extend({ ... })` | `FC<Props>` 或 `class extends Component<P, S>` |
| `@Component` | 不需要装饰器 |
| `@Prop() x!: string` | `interface Props { x: string }` |
| `PropType<T>` | TS 类型直接写 |
| `defineProps<Props>()` | 函数参数解构 |
| `defineEmits<{...}>()` | Props 里的回调函数类型 |
| `ref<T>(v)` | `useState<T>(v)` |
| `Ref<T>` | `[T, Dispatch<SetStateAction<T>>]` |
| `ComputedRef<T>` | `T`（useMemo 返回值） |
| `ComponentPublicInstance` | `ComponentType<P>` |
| `defineExpose<{...}>()` | `useImperativeHandle` + `forwardRef` |

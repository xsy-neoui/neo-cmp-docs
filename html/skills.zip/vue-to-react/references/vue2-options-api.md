# Vue 2 Options API 逐字段到 React 的映射

本文是"主攻方向：Vue 2 → React"的详细手册。用于 1:1 机械地翻译 Options API 各字段。

## 目录

- name
- props
- data
- computed
- methods
- watch
- 生命周期（参见 lifecycle.md）
- filters
- mixins
- directives
- components
- provide / inject
- model（v-model 定制）
- inheritAttrs
- 完整示例：一个带全字段的组件

---

## name

Vue：

```js
export default { name: 'UserCard' }
```

React：函数名/类名自动作为 `displayName`，无需单独字段。用于 React DevTools：

```tsx
export const UserCard: FC<Props> = (props) => { /* ... */ }
UserCard.displayName = 'UserCard'   // 通常可省略
```

---

## props

### Vue

```js
props: {
  name: { type: String, required: true },
  age: { type: Number, default: 18 },
  tags: { type: Array, default: () => [] },
  status: {
    type: String,
    validator: (v) => ['ok', 'bad'].includes(v),
  },
}
```

### React

```tsx
interface UserCardProps {
  name: string
  age?: number
  tags?: string[]
  status?: 'ok' | 'bad'
}

export const UserCard: FC<UserCardProps> = ({
  name,
  age = 18,
  tags = [],
  status,
}) => { /* ... */ }
```

对应关系：

- `type` → TS 类型
- `required` → 非可选（无 `?`）
- `default` → 解构默认值
- `validator` → **用 TS 字面量联合类型**（编译期检查）；若需运行时校验，用 zod 或 yup

### 复杂对象校验

```ts
// Vue validator
{ type: Object, validator: (v) => v && typeof v.id === 'string' }
```

```ts
// React + zod（运行时）
import { z } from 'zod'
const UserSchema = z.object({ id: z.string() })
// 在使用点校验：UserSchema.parse(data)
```

---

## data

### Vue

```js
data() {
  return { count: 0, user: null }
}
```

### React 函数组件

```tsx
const [count, setCount] = useState(0)
const [user, setUser] = useState<User | null>(null)
```

### React 类组件

```tsx
state: { count: number; user: User | null } = {
  count: 0,
  user: null,
}
```

> 多个字段要不要合并成一个 state 对象？React 函数组件里推荐**按逻辑分组**拆多个 `useState`；类组件则是一个 state 对象，用 `this.setState({ ... })` 合并更新。

---

## computed

### 只读 computed

```js
computed: {
  fullName() { return `${this.first} ${this.last}` },
}
```

函数组件：

```tsx
const fullName = useMemo(() => `${first} ${last}`, [first, last])
// 简单计算甚至可以：
const fullName = `${first} ${last}`
```

类组件：

```tsx
get fullName() { return `${this.state.first} ${this.state.last}` }
```

### 可写 computed

```js
computed: {
  name: {
    get() { return this.user.name },
    set(v) { this.user.name = v },
  },
}
```

函数组件：

```tsx
const name = user.name
const setName = (v: string) => setUser(u => u ? { ...u, name: v } : u)
```

---

## methods

### Vue

```js
methods: {
  greet() { alert(`hi ${this.name}`) },
}
```

### React 函数组件

```tsx
const greet = () => alert(`hi ${name}`)
// 如果要传给子组件并避免无意义重渲染：
const greet = useCallback(() => alert(`hi ${name}`), [name])
```

### React 类组件

```tsx
greet = () => alert(`hi ${this.state.name}`)    // 箭头函数属性，自动绑定 this
```

---

## watch

### 简单 watch

```js
watch: {
  id(newV, oldV) { this.loadUser(newV) },
}
```

函数组件：

```tsx
useEffect(() => {
  loadUser(id)
}, [id])
```

### immediate + deep + handler

```js
watch: {
  filter: {
    immediate: true,
    deep: true,
    handler(v) { this.query(v) },
  },
}
```

函数组件：

```tsx
// immediate: 默认 useEffect 就会在挂载时跑
// deep: 引用变更即触发；若要真正的"结构相等不触发"，用 useDeepCompareEffect 或自己判断
useEffect(() => { query(filter) }, [filter])
```

### 字符串路径 watch

```js
watch: { 'user.name'(v) { /* ... */ } }
```

函数组件：

```tsx
useEffect(() => { /* 用 user.name */ }, [user?.name])
```

### 数组形式多 handler

```js
watch: {
  id: [
    { handler: 'loadUser', immediate: true },
    (v) => console.log('id 变了', v),
  ],
}
```

函数组件：拆成多个 `useEffect`，每个职责单一。

---

## filters（Vue 2 独有）

```js
filters: {
  currency(v) { return `¥${v.toFixed(2)}` },
}
// {{ price | currency }}
```

迁移：抽成工具函数，直接在 JSX 里调用。详见 `directives-mixins.md` 的"过滤器"章节。

---

## mixins

详见 `directives-mixins.md` 的"Mixin → 自定义 Hook"。核心：

- 有数据/生命周期/方法 → 自定义 hook
- 需要改变渲染 / 注入 props → HOC

---

## directives（组件级）

```js
directives: {
  focus: {
    inserted(el) { el.focus() },
  },
}
```

React 里不存在"组件级指令注册"，迁移方式：

- 写成 hook（`useAutoFocus`）
- 或写成小组件（`<AutoFocus>...</AutoFocus>`，在 `useEffect` 里对 ref 操作）

---

## components（局部注册）

```js
components: { UserCard, Button }
```

React 不需要注册，`import` 就能用。

---

## provide / inject

详见 `communication.md`。映射为 `React.createContext` + `useContext`。

### Vue 2 写法

```js
// 祖先
provide() { return { theme: this.theme } }
// 后代
inject: ['theme']
```

### 注意 Vue 2 非响应式默认

Vue 2 的 `provide/inject` 默认**不是响应式**（需要 provide ref 或函数才响应）。React Context 的 value 只要变就会让消费者重渲染，行为更直观。

---

## model（v-model 定制）

Vue 2：

```js
model: {
  prop: 'checked',
  event: 'change',
}
```

React 里就是改 prop 和事件名字，自己约定即可：

```tsx
interface Props {
  checked: boolean
  onChange: (v: boolean) => void
}
```

---

## inheritAttrs

```js
inheritAttrs: false,
// 自己决定 $attrs 落到哪里
```

React 里用解构 + 剩余参数显式落地：

```tsx
const Button: FC<ButtonProps> = ({ variant, children, ...rest }) => (
  // rest 默认不会"自动落到"根节点，你要自己写上
  <button {...rest}>{children}</button>
)
```

---

## 完整示例：Vue 2 Options API → React

### 原 Vue 2 组件

```vue
<template>
  <div :class="['user-card', { 'is-active': active }]" @click="handleClick">
    <img :src="user.avatar" :alt="user.name">
    <h3>{{ user.name }}</h3>
    <p>{{ age | years }}</p>
    <slot name="footer" />
  </div>
</template>

<script>
import { timerMixin } from '@/mixins/timer'

export default {
  name: 'UserCard',
  mixins: [timerMixin],
  props: {
    user: { type: Object, required: true },
    active: { type: Boolean, default: false },
  },
  data() {
    return { clickCount: 0 }
  },
  computed: {
    age() { return new Date().getFullYear() - this.user.birthYear },
  },
  watch: {
    'user.id'(newId) {
      this.clickCount = 0
      this.$emit('change', newId)
    },
  },
  methods: {
    handleClick() {
      this.clickCount++
      this.$emit('click', this.user)
    },
  },
  mounted() {
    console.log('mounted', this.user.id)
  },
  beforeDestroy() {
    console.log('destroy')
  },
  filters: {
    years(n) { return `${n} 岁` },
  },
}
</script>

<style scoped>
.user-card { padding: 12px; border-radius: 8px; border: 1px solid #eee; }
.user-card.is-active { background: #eef; }
</style>
```

### React 函数组件版

```tsx
// UserCard/UserCard.tsx
import { FC, ReactNode, useCallback, useEffect, useMemo, useState } from 'react'
import clsx from 'clsx'
import { useTimer } from '@/hooks/useTimer'

interface User {
  id: string
  name: string
  avatar: string
  birthYear: number
}

export interface UserCardProps {
  user: User
  active?: boolean
  footer?: ReactNode
  onClick?: (user: User) => void
  onChange?: (id: string) => void
}

const years = (n: number) => `${n} 岁`

export const UserCard: FC<UserCardProps> = ({
  user,
  active = false,
  footer,
  onClick,
  onChange,
}) => {
  const [clickCount, setClickCount] = useState(0)
  const elapsed = useTimer()   // 原 mixin 提供的数据

  const age = useMemo(
    () => new Date().getFullYear() - user.birthYear,
    [user.birthYear],
  )

  // watch 'user.id'
  useEffect(() => {
    setClickCount(0)
    onChange?.(user.id)
  }, [user.id])   // onChange 故意不列入依赖，按需决定

  useEffect(() => {
    console.log('mounted', user.id)
    return () => console.log('destroy')
  }, [])

  const handleClick = useCallback(() => {
    setClickCount(c => c + 1)
    onClick?.(user)
  }, [onClick, user])

  return (
    <div
      className={clsx(
        'p-3 rounded-lg border border-gray-200 cursor-pointer',
        active && 'bg-indigo-50',
      )}
      onClick={handleClick}
    >
      <img src={user.avatar} alt={user.name} />
      <h3>{user.name}</h3>
      <p>{years(age)}</p>
      {footer}
    </div>
  )
}
```

### 如果该组件复杂到适合用类组件

参考 `class-vs-function.md` 的判据，以下是同一个组件的类组件版：

```tsx
interface State { clickCount: number }

export class UserCard extends Component<UserCardProps, State> {
  static defaultProps = { active: false }
  state: State = { clickCount: 0 }

  get age() {
    return new Date().getFullYear() - this.props.user.birthYear
  }

  componentDidMount() {
    console.log('mounted', this.props.user.id)
  }

  componentDidUpdate(prev: UserCardProps) {
    if (prev.user.id !== this.props.user.id) {
      this.setState({ clickCount: 0 })
      this.props.onChange?.(this.props.user.id)
    }
  }

  componentWillUnmount() {
    console.log('destroy')
  }

  handleClick = () => {
    this.setState(s => ({ clickCount: s.clickCount + 1 }))
    this.props.onClick?.(this.props.user)
  }

  render() {
    const { user, active, footer } = this.props
    return (
      <div
        className={clsx(
          'p-3 rounded-lg border border-gray-200 cursor-pointer',
          active && 'bg-indigo-50',
        )}
        onClick={this.handleClick}
      >
        <img src={user.avatar} alt={user.name} />
        <h3>{user.name}</h3>
        <p>{`${this.age} 岁`}</p>
        {footer}
      </div>
    )
  }
}
```

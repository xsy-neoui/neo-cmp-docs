# 生命周期对照

## 目录

- Vue 2 / Vue 3 / React 函数 / React 类 全量对照表
- 常见场景写法（拉数据、定时器、事件订阅、DOM 测量）
- 错误边界（errorCaptured → ErrorBoundary）
- activated / deactivated（keep-alive）→ React 没有直接等价物
- useLayoutEffect 与 useEffect 的区别

---

## 全量对照表

| Vue 2 | Vue 3 | React 函数组件 | React 类组件 | 典型用途 |
|---|---|---|---|---|
| `beforeCreate` | `setup` 前 | 无（组件函数还没执行） | `constructor` 前 | — |
| `created` | `setup` 体 | 函数体顶部（在 return 之前） | `constructor` | 初始化 state |
| `beforeMount` | `onBeforeMount` | 无 | 无 | 很少用 |
| `mounted` | `onMounted` | `useEffect(() => {...}, [])` | `componentDidMount` | 请求初始数据、添加事件监听、初始化第三方库 |
| `beforeUpdate` | `onBeforeUpdate` | 无 | `getSnapshotBeforeUpdate` | DOM 更新前测量 |
| `updated` | `onUpdated` | `useEffect(() => {...})`（无依赖数组） | `componentDidUpdate` | 观察变化后动作（慎用，容易死循环） |
| `beforeDestroy` / `beforeUnmount` | `onBeforeUnmount` | `useEffect` 的 cleanup | `componentWillUnmount` | 清理定时器、解绑事件、取消请求 |
| `destroyed` / `unmounted` | `onUnmounted` | 同上 cleanup | 同上 | 同上 |
| `errorCaptured` | `onErrorCaptured` | **无**（须用类组件实现 ErrorBoundary） | `componentDidCatch` + `getDerivedStateFromError` | 错误兜底 |
| `activated` | `onActivated` | 无直接等价物 | 无 | 路由缓存恢复（React 没有 keep-alive） |
| `deactivated` | `onDeactivated` | 无 | 无 | 同上 |

---

## 场景实战

### 1. 挂载时拉数据

```ts
// Vue 3
onMounted(async () => {
  data.value = await fetchData(id.value)
})
```

```tsx
// React 函数组件
useEffect(() => {
  let canceled = false
  ;(async () => {
    const d = await fetchData(id)
    if (!canceled) setData(d)
  })()
  return () => { canceled = true }   // 卸载或 id 变化时取消
}, [id])
```

```tsx
// React 类组件
componentDidMount() {
  this._canceled = false
  fetchData(this.props.id).then((d) => {
    if (!this._canceled) this.setState({ data: d })
  })
}
componentDidUpdate(prev: Props) {
  if (prev.id !== this.props.id) {
    // 处理 id 变化
  }
}
componentWillUnmount() {
  this._canceled = true
}
```

> **不要**在 `useEffect` 里直接 `async () => {...}`（这会把 Promise 当 cleanup 函数）。正确写法是在内部定义 async 函数再调用。

### 2. 定时器

```ts
onMounted(() => { timer = setInterval(tick, 1000) })
onBeforeUnmount(() => clearInterval(timer))
```

```tsx
useEffect(() => {
  const timer = setInterval(tick, 1000)
  return () => clearInterval(timer)
}, [])
```

### 3. 事件订阅

```ts
onMounted(() => window.addEventListener('resize', onResize))
onBeforeUnmount(() => window.removeEventListener('resize', onResize))
```

```tsx
useEffect(() => {
  window.addEventListener('resize', onResize)
  return () => window.removeEventListener('resize', onResize)
}, [onResize])
// 或把 onResize 放进 useRef / useCallback 保持稳定，避免频繁解绑
```

### 4. DOM 测量（需要在浏览器绘制前）

```tsx
useLayoutEffect(() => {
  const rect = ref.current!.getBoundingClientRect()
  setHeight(rect.height)
}, [])
```

- `useEffect`：浏览器绘制**之后**异步执行（大多数场景）
- `useLayoutEffect`：DOM 更新**之后、绘制之前**同步执行（适合测量 DOM、避免闪烁）

---

## errorCaptured → ErrorBoundary

**React 目前只能用类组件实现错误边界**。这是类组件少数"必须存在"的场景之一。

```tsx
interface State { hasError: boolean; error?: Error }
interface Props { fallback: (e: Error) => ReactNode; children: ReactNode }

class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // 上报日志
    console.error('[ErrorBoundary]', error, info)
  }

  render() {
    if (this.state.hasError) return this.props.fallback(this.state.error!)
    return this.props.children
  }
}
```

使用：

```tsx
<ErrorBoundary fallback={(e) => <div>出错啦：{e.message}</div>}>
  <App />
</ErrorBoundary>
```

> React 的 `ErrorBoundary` 不能捕获事件处理函数里的错误（用 try/catch）、异步错误（用 .catch 或 try/catch + setState）、SSR 错误。

---

## 更新钩子的替代（beforeUpdate / updated）

Vue 的 `updated` 每次重渲染后都触发。React 的等价是**不带依赖数组的 useEffect**：

```tsx
useEffect(() => {
  console.log('每次重渲染后都会跑')
})
```

> 务必小心：如果在里面 `setState`，就是**死循环**。绝大多数场景你想要的是"某个值变了之后"，用带依赖数组的 effect。

类组件对应：

```tsx
componentDidUpdate(prevProps: Props, prevState: State) {
  if (prevProps.id !== this.props.id) {
    // 只在 id 变化时做事
  }
}
```

---

## activated / deactivated

Vue 的 `<keep-alive>` 缓存组件实例，`activated`/`deactivated` 分别在显示/隐藏时触发。**React 没有官方 keep-alive**。迁移策略：

- **如果是 tab 切换**：别卸载组件，用 `hidden` 属性或 CSS 控制显示（状态保留）
  ```tsx
  <div hidden={tab !== 'a'}><TabA /></div>
  <div hidden={tab !== 'b'}><TabB /></div>
  ```
- **如果是路由切换需要保活**：用 `react-activation` 第三方库，提供 `<KeepAlive>` 组件
- **如果只是想缓存数据**：把状态提升到外层 Store / URL 参数 / React Router loader 缓存

---

## 执行时机速查

```
挂载:    constructor/函数体 → render → ref 生效 → useLayoutEffect → 浏览器绘制 → useEffect
更新:    render → ref 更新 → useLayoutEffect cleanup → useLayoutEffect → 绘制 → useEffect cleanup → useEffect
卸载:    useLayoutEffect cleanup → useEffect cleanup → componentWillUnmount
```

Vue 侧对应：

```
挂载:    beforeCreate → created → beforeMount → mounted
更新:    beforeUpdate → updated
卸载:    beforeUnmount → unmounted
```

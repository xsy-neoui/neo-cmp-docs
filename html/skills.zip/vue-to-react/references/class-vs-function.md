# 函数组件 vs 类组件：决策指南

React 侧的偏好：

- **简单功能组件**：函数组件 + hooks（推荐，默认）
- **复杂功能组件**：类组件

本技能不主张"函数组件万能"或"类组件过时"，而是**按组件复杂度选择**，并给出明确判据。

## 目录

- 决策流程图
- 何时用函数组件
- 何时用类组件
- 判定清单
- 混合使用
- 从函数组件重构到类组件（迁移）

---

## 决策流程

```
┌──────────────────────────────────┐
│ 这个组件需要什么能力？              │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ 需要 ErrorBoundary？              │──── 是 ───▶ 类组件（唯一选择）
└──────────┬───────────────────────┘
           │ 否
           ▼
┌──────────────────────────────────┐
│ 逻辑规模（state + effect 条数）    │
└──────────┬───────────────────────┘
           │
   ≤ 5 条 ──▶ 函数组件 + hooks
           │
   > 5 条 且 有以下任一 ──▶ 类组件
     - 多个 effect 依赖交织
     - getSnapshotBeforeUpdate 需求
     - 生命周期逻辑重
     - 原 Vue 是 Options API 重结构
           │
   其他情况 ──▶ 函数组件 + hooks（可抽自定义 hook）
```

---

## 何时用函数组件（默认）

**绝大多数组件都应该是函数组件**。适用场景：

- 展示型组件（卡片、列表项、按钮、标签）
- 表单字段（输入框、选择器、受控组件）
- 轻量容器（页面骨架、简单布局）
- 逻辑可以用 2-3 个 `useState` + 1-2 个 `useEffect` 清晰表达
- 需要高度复用逻辑（抽自定义 hook 共享）

**标志性特征**：

```tsx
// 一个"理想的函数组件"大致长这样
export const SearchBox: FC<Props> = ({ value, onChange, placeholder }) => {
  const [focused, setFocused] = useState(false)

  return (
    <div className={clsx('search', focused && 'focused')}>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
      />
    </div>
  )
}
```

简洁、无副作用交织、状态清晰。

---

## 何时用类组件

### 硬性要求（必须用类）

- **实现 ErrorBoundary**：`getDerivedStateFromError` + `componentDidCatch` 仅在类里可用
- **使用 `getSnapshotBeforeUpdate`**：DOM 更新前读取旧信息（滚动位置、文本选择范围等）。函数组件里无等价实现

### 软性建议（用类更顺）

1. **多生命周期交织且相互依赖**
   ```
   componentDidMount: 订阅 A、拉数据 B、初始化 C
   componentDidUpdate: 根据 props 差异更新 A，重新拉 B，重配置 C
   componentWillUnmount: 解绑 A、取消 B、销毁 C
   ```
   用函数组件会有多个 useEffect，依赖数组交错，极易出 bug。类组件的 `componentDidUpdate` 能用 `prevProps`/`prevState` 精确比对。

2. **复杂的内部状态 + 方法集群**
   - 内部状态 > 5 个、方法 > 10 个
   - 方法之间通过 `this` 共享状态，用 hook 会需要大量 `useCallback` / `useRef`
   - 原 Vue 组件是 Options API 大文件，1:1 对齐成类最顺滑

3. **需要 `this` 形式的稳定引用**
   - 类方法定义即绑定，传给子组件/DOM 时引用永远稳定，无需 `useCallback`
   - 大量回调传递的场景可以省去心智负担

4. **测试同学更熟悉类实例**（Enzyme 残留、遗留测试栈）

### 具体示例：适合类的重逻辑组件

```tsx
interface Props { roomId: string }
interface State {
  messages: Message[]
  input: string
  connected: boolean
  typing: string[]
  loading: boolean
  error?: Error
}

export class ChatRoom extends Component<Props, State> {
  state: State = {
    messages: [],
    input: '',
    connected: false,
    typing: [],
    loading: true,
  }

  private socket?: WebSocket
  private reconnectTimer?: number
  private typingTimer?: number

  async componentDidMount() {
    await this.loadHistory()
    this.connect()
  }

  async componentDidUpdate(prev: Props) {
    if (prev.roomId !== this.props.roomId) {
      this.disconnect()
      this.setState({ messages: [], loading: true })
      await this.loadHistory()
      this.connect()
    }
  }

  componentWillUnmount() {
    this.disconnect()
    window.clearTimeout(this.reconnectTimer)
    window.clearTimeout(this.typingTimer)
  }

  private loadHistory = async () => { /* ... */ }
  private connect = () => { /* ... */ }
  private disconnect = () => { /* ... */ }
  private send = () => { /* ... */ }
  private onInputChange = (e: ChangeEvent<HTMLInputElement>) => { /* ... */ }
  private onTyping = () => { /* ... */ }

  render() {
    // ...
  }
}
```

用函数组件来写这个，你会有 4-5 个 `useEffect`、若干 `useRef`（存 socket、timer）、若干 `useCallback`，依赖数组容易出错。

---

## 判定清单

遇到一个要迁移的 Vue 组件时，逐条检查：

| 检查项 | 是 → 倾向类 | 否 → 倾向函数 |
|---|---|---|
| 需要 ErrorBoundary？ | ✅ | — |
| 需要 `getSnapshotBeforeUpdate`？ | ✅ | — |
| 生命周期钩子（mounted/updated/destroy）总共 > 2 个？ | ✅ | — |
| state 字段 > 5 个？ | ✅ | — |
| 方法 > 8 个且多方法共享状态？ | ✅ | — |
| 原 Vue 组件文件 > 400 行？ | ✅ | — |
| 需要集成老旧第三方库（jQuery 插件、命令式 API）？ | ✅ | — |
| 在表格/列表/网格里大量复用？ | — | ✅（函数组件 + `React.memo` 更优） |
| 组件纯展示？ | — | ✅ |
| 需要抽出多个自定义 hook 复用？ | — | ✅ |

**规则**：有两条以上 "✅ 倾向类" 时，用类组件；否则首选函数组件。

---

## 混合使用是允许的

一个项目里两种形态并存没有任何问题。常见模式：

- 大部分展示/表单组件是函数组件
- 少数核心业务容器（列表页、编辑器、会话）是类组件
- 错误边界统一用类实现并复用

```tsx
// 函数组件作为子组件，类组件作为容器
class EditorPage extends Component { /* 复杂 */ }
const FieldInput: FC = () => { /* 简单 */ }
```

---

## 从函数组件重构到类组件（迁移时）

如果你在迁移时先写了函数组件，后来发现依赖交错、useEffect 混乱，可以重构。对照迁移：

| 函数组件 | 类组件 |
|---|---|
| `const [x, setX] = useState(v)` | `state = { x: v }` + `this.setState({ x: ... })` |
| `useRef(v)` | `private xxx = v`（类字段） |
| `useEffect(cb, [])` | `componentDidMount` |
| `useEffect(cb, [a])` | `componentDidUpdate(prev)` 里比较 `prev.a !== this.props.a` |
| `useEffect(return cleanup, [])` | `componentWillUnmount` |
| `useMemo(() => x, deps)` | `get x()` 或在 `render` 里算 |
| `useCallback(fn, deps)` | 类字段箭头函数（引用天然稳定） |
| `useContext(Ctx)` | `static contextType = Ctx` + `this.context`（单 Context） 或 `<Ctx.Consumer>` |

**注意**：
- 类组件使用 Context 只能用一个 `contextType` 或多个 Consumer；hooks 可以任意多次 `useContext`，这是函数组件优势
- 订阅 MobX store：类组件用 `mobx-react` 的 `observer` 包裹 + `inject`，函数组件用 `mobx-react-lite` 的 `observer` + `useStore`

---

## 关于"不要混用 hooks 和类组件"

明确一点：**单个组件内**不能混用（hooks 只能在函数组件顶层调用）。但一个项目、一棵组件树里可以自由混搭。需要在类组件里用某个 hook 的能力时：

1. 把 hook 包进一个函数组件 / 小包装器
2. 或把类组件内部逻辑抽出一段给函数子组件

```tsx
// 类组件无法直接用 useParams，用小函数组件转发：
function WithParams<P>(Cmp: ComponentType<P & { params: Record<string, string> }>) {
  return (props: P) => {
    const params = useParams() as Record<string, string>
    return <Cmp {...props} params={params} />
  }
}

// 使用
export default WithParams(ClassComponent)
```

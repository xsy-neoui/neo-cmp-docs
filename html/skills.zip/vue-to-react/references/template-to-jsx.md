# 模板语法 → JSX 映射

## 目录

- 条件渲染（v-if / v-else / v-else-if / v-show）
- 列表渲染（v-for）
- 属性绑定（v-bind / :class / :style）
- 事件（v-on / 修饰符 / 按键修饰符）
- 双向绑定（v-model）
- 插槽（默认 / 具名 / 作用域）
- 特殊内置（v-html / v-text / v-pre / v-cloak / v-once）
- 动态组件（`<component :is>`）
- 模板 ref（`ref="xxx"`）

---

::: v-pre

## 条件渲染

### v-if / v-else / v-else-if

```html
<div v-if="status === 'loading'">Loading</div>
<div v-else-if="status === 'error'">Error</div>
<div v-else>Done</div>
```

```tsx
{status === 'loading' ? (
  <div>Loading</div>
) : status === 'error' ? (
  <div>Error</div>
) : (
  <div>Done</div>
)}
```

嵌套较深时推荐抽出函数：

```tsx
const renderStatus = () => {
  if (status === 'loading') return <div>Loading</div>
  if (status === 'error') return <div>Error</div>
  return <div>Done</div>
}
return <section>{renderStatus()}</section>
```

### v-show

Vue 的 `v-show` 只是切换 `display`，DOM 不卸载。

```html
<div v-show="visible">hi</div>
```

```tsx
// 方式一：Tailwind
<div className={visible ? '' : 'hidden'}>hi</div>

// 方式二：style
<div style={{ display: visible ? undefined : 'none' }}>hi</div>
```

**不要**用 `{visible && <div>hi</div>}` 去替换 `v-show` —— 那是 `v-if` 的语义（会卸载/重挂）。

---

## 列表渲染（v-for）

```html
<li v-for="(item, index) in list" :key="item.id">
  {{ index }} - {{ item.name }}
</li>
```

```tsx
{list.map((item, index) => (
  <li key={item.id}>
    {index} - {item.name}
  </li>
))}
```

遍历对象：

```html
<li v-for="(val, key) in obj" :key="key">{{ key }}: {{ val }}</li>
```

```tsx
{Object.entries(obj).map(([key, val]) => (
  <li key={key}>{key}: {val}</li>
))}
```

遍历数字区间：

```html
<li v-for="n in 5" :key="n">{{ n }}</li>
```

```tsx
{Array.from({ length: 5 }, (_, i) => (
  <li key={i + 1}>{i + 1}</li>
))}
```

**key 规则**与 Vue 一致：稳定、唯一。避免用数组索引当 key（除非列表永远不增删/不排序）。

---

## 属性绑定

### 动态属性

```html
<img :src="url" :alt="desc">
```

```tsx
<img src={url} alt={desc} />
```

### class

```html
<div :class="['base', { active: isActive, 'is-error': hasError }]"></div>
```

```tsx
// 手动拼：
<div className={['base', isActive && 'active', hasError && 'is-error'].filter(Boolean).join(' ')} />

// 推荐：用 clsx
import clsx from 'clsx'
<div className={clsx('base', { active: isActive, 'is-error': hasError })} />
```

### style

```html
<div :style="{ color: c, fontSize: size + 'px' }"></div>
```

```tsx
<div style={{ color: c, fontSize: `${size}px` }} />
```

注意 React 的 `style` 必须是对象，属性名用 camelCase；单位不会自动补 `px`，需自己拼字符串（但像 `width: 100` 对数字型属性 React 会自动补 px）。

---

## 事件

### 基础

```html
<button @click="onClick">Go</button>
```

```tsx
<button onClick={onClick}>Go</button>
```

React 事件采用 camelCase 命名，传入函数而不是表达式。

### 事件修饰符（核心）

| Vue 修饰符 | React 做法 |
|---|---|
| `.stop` | `e.stopPropagation()` |
| `.prevent` | `e.preventDefault()` |
| `.self` | `if (e.target !== e.currentTarget) return` |
| `.capture` | 使用 `onClickCapture`（所有事件都有 `XxxCapture` 版本） |
| `.once` | 用 `useRef` 记录是否已触发过，或解绑（手动） |
| `.passive` | React 的合成事件默认不是 passive；如需 passive，用原生 `addEventListener` + `{ passive: true }` |

组合示例：

```html
<button @click.stop.prevent="onClick">Go</button>
```

```tsx
<button onClick={(e) => {
  e.stopPropagation()
  e.preventDefault()
  onClick()
}}>Go</button>
```

### 按键修饰符

```html
<input @keyup.enter="submit" @keyup.esc="cancel">
```

```tsx
<input
  onKeyUp={(e) => {
    if (e.key === 'Enter') submit()
    if (e.key === 'Escape') cancel()
  }}
/>
```

### 鼠标按键 / 系统修饰键

| Vue | React |
|---|---|
| `@click.left` | 默认 `onClick` 就是左键；或判断 `e.button === 0` |
| `@click.right` | 用 `onContextMenu` |
| `@click.middle` | `onMouseDown` + `e.button === 1` |
| `@click.ctrl` | `onClick` + `if (!e.ctrlKey) return` |

---

## v-model（双向绑定）

Vue 的 `v-model` 本质是 `value` + `input` 事件的语法糖。React 里改成**受控组件**：

```html
<input v-model="text" />
```

```tsx
const [text, setText] = useState('')
<input value={text} onChange={(e) => setText(e.target.value)} />
```

### 复选框

```html
<input type="checkbox" v-model="checked" />
```

```tsx
<input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} />
```

### select

```html
<select v-model="selected">
  <option value="a">A</option>
</select>
```

```tsx
<select value={selected} onChange={(e) => setSelected(e.target.value)}>
  <option value="a">A</option>
</select>
```

### 组件 v-model

Vue 3 组件 `v-model` 默认是 `modelValue` + `update:modelValue`：

```html
<MyInput v-model="text" />
```

```tsx
// React 用 value + onChange 约定
<MyInput value={text} onChange={setText} />
```

子组件实现：

```tsx
interface MyInputProps {
  value: string
  onChange: (v: string) => void
}
const MyInput: FC<MyInputProps> = ({ value, onChange }) => (
  <input value={value} onChange={(e) => onChange(e.target.value)} />
)
```

### 修饰符

| Vue | React |
|---|---|
| `v-model.lazy` | 改用 `onBlur` 同步而不是 `onChange` |
| `v-model.number` | `onChange={(e) => setX(Number(e.target.value))}` |
| `v-model.trim` | `onChange={(e) => setX(e.target.value.trim())}` |

---

## 插槽

### 默认插槽

```html
<!-- Child.vue -->
<div><slot>默认内容</slot></div>

<!-- Parent -->
<Child>真实内容</Child>
```

```tsx
// Child.tsx
const Child: FC<PropsWithChildren> = ({ children }) => (
  <div>{children ?? '默认内容'}</div>
)

// Parent
<Child>真实内容</Child>
```

### 具名插槽

```html
<!-- Layout.vue -->
<header><slot name="header" /></header>
<main><slot /></main>
<footer><slot name="footer" /></footer>

<!-- Parent -->
<Layout>
  <template #header><h1>标题</h1></template>
  <p>正文</p>
  <template #footer><small>版权</small></template>
</Layout>
```

```tsx
interface LayoutProps {
  header?: ReactNode
  footer?: ReactNode
  children?: ReactNode
}
const Layout: FC<LayoutProps> = ({ header, footer, children }) => (
  <>
    <header>{header}</header>
    <main>{children}</main>
    <footer>{footer}</footer>
  </>
)

// Parent
<Layout
  header={<h1>标题</h1>}
  footer={<small>版权</small>}
>
  <p>正文</p>
</Layout>
```

### 作用域插槽

Vue 作用域插槽让子组件向父级传递渲染数据：

```html
<!-- List.vue -->
<li v-for="item in items" :key="item.id">
  <slot :item="item" :index="index" />
</li>

<!-- Parent -->
<List :items="list">
  <template #default="{ item }">
    <strong>{{ item.name }}</strong>
  </template>
</List>
```

React 用 **render props**（函数作为 children 或 props）：

```tsx
interface ListProps<T> {
  items: T[]
  children: (item: T, index: number) => ReactNode
}
function List<T extends { id: string | number }>({ items, children }: ListProps<T>) {
  return (
    <ul>
      {items.map((item, index) => (
        <li key={item.id}>{children(item, index)}</li>
      ))}
    </ul>
  )
}

// Parent
<List items={list}>
  {(item) => <strong>{item.name}</strong>}
</List>
```

---

## 特殊内置指令

| Vue | React |
|---|---|
| `v-html="html"` | `<div dangerouslySetInnerHTML={{ __html: html }} />`（注意 XSS，务必先 sanitize） |
| `v-text="str"` | `<div>{str}</div>` |
| `v-pre` | React 里不需要，原样就是原样 |
| `v-cloak` | 不需要，React 是先 JS 渲染再显示 |
| `v-once` | 用 `useMemo` 缓存节点；或拆成纯组件 + `React.memo` |

---

## 动态组件

```html
<component :is="currentTab" />
```

```tsx
const TABS = { Home, About, Contact }
const Current = TABS[currentTab]
return <Current />
```

如果组件集合是动态的（非预定义），用 map 查表 + 类型约束：

```tsx
type TabKey = 'home' | 'about'
const tabs: Record<TabKey, FC> = { home: Home, about: About }
const Current = tabs[currentTab]
```

---

## 模板 ref

```html
<input ref="input" />
<script setup>
import { ref, onMounted } from 'vue'
const input = ref(null)
onMounted(() => input.value.focus())
</script>
```

```tsx
const inputRef = useRef<HTMLInputElement>(null)
useEffect(() => { inputRef.current?.focus() }, [])
return <input ref={inputRef} />
```

暴露自定义实例给父组件：

```tsx
// Vue: defineExpose({ focus })
// React:
const MyInput = forwardRef<{ focus: () => void }, {}>((props, ref) => {
  const inner = useRef<HTMLInputElement>(null)
  useImperativeHandle(ref, () => ({
    focus: () => inner.current?.focus(),
  }))
  return <input ref={inner} />
})
```

:::
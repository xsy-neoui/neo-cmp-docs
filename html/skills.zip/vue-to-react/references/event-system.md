# 全局事件 / 自定义事件系统迁移

## 目录

- Vue 2 事件系统概览（$on / $off / $once / EventBus）
- 为什么 React 不推荐事件总线
- 迁移策略选型
- 方案 1：提升状态 + 回调 props（首选）
- 方案 2：Context + useContext（跨层级同子树）
- 方案 3：MobX Store 订阅（全局跨组件）
- 方案 4：轻量 EventEmitter（过渡方案）
- mitt / tiny-emitter 迁移
- 常见场景迁移示例
- 清理与内存泄漏防范

---

## Vue 2 事件系统概览

Vue 2 实例自带事件 API：

```js
// 任何 Vue 实例都可以作为事件中心
this.$on('event-name', handler)       // 监听
this.$once('event-name', handler)     // 监听一次
this.$off('event-name', handler)      // 取消监听
this.$emit('event-name', payload)     // 触发
```

### EventBus 模式（Vue 2 常见）

```js
// bus.js
import Vue from 'vue'
export const bus = new Vue()

// 组件 A（发送）
bus.$emit('user:updated', user)

// 组件 B（接收）
bus.$on('user:updated', (user) => { this.user = user })
// 销毁时
bus.$off('user:updated', this.handler)
```

### 第三方事件库

Vue 3 移除了实例事件 API，社区转向：
- **mitt**：极简（200B），无实例依赖
- **tiny-emitter**：类似 Node EventEmitter

```js
import mitt from 'mitt'
const emitter = mitt()
emitter.on('event', handler)
emitter.emit('event', data)
emitter.off('event', handler)
```

---

## 为什么 React 不推荐事件总线

React 的核心理念是**单向数据流**：

- 数据从父到子通过 props 传递
- 子到父通过回调 props 通知
- 跨层级通过 Context 或全局 Store

事件总线的问题：
1. **数据流不可追踪**：任何组件都能发/收事件，调试困难
2. **内存泄漏风险**：忘记 off 导致已卸载组件的 handler 仍被调用
3. **与 React 渲染模型冲突**：事件触发不会自动触发重渲染，需要手动 setState
4. **TypeScript 类型安全差**：事件名是字符串，payload 类型难约束

**迁移原则**：能用 React 原生模式（props/Context/Store）解决的，不要用事件总线。

---

## 迁移策略选型

| 原 Vue 事件场景 | React 推荐方案 |
|---|---|
| 父子组件通信（`$emit`） | 回调 props（`onChange`、`onSubmit`） |
| 兄弟组件通信 | 提升状态到共同父级 |
| 跨层级通信（同子树） | Context + useContext |
| 全局状态变更通知 | MobX Store（observer 自动响应） |
| 全局一次性事件（toast/notification） | Context + hook 或全局 Store |
| 模块间解耦通信（非 UI 层） | 轻量 EventEmitter（仅限非组件逻辑） |
| 大量遗留 EventBus 代码（过渡期） | 封装 EventEmitter + useEvent hook |

---

## 方案 1：提升状态 + 回调 props（首选）

### Vue EventBus 场景

```js
// 组件 A（兄弟）
bus.$emit('filter:change', { keyword: 'test' })

// 组件 B（兄弟）
bus.$on('filter:change', (filter) => { this.filter = filter })
```

### React：提升到父级

```tsx
// Parent
const Parent: FC = () => {
  const [filter, setFilter] = useState({ keyword: '' })
  return (
    <>
      <FilterBar onChange={setFilter} />
      <DataList filter={filter} />
    </>
  )
}

// FilterBar
const FilterBar: FC<{ onChange: (f: Filter) => void }> = ({ onChange }) => (
  <input onChange={(e) => onChange({ keyword: e.target.value })} />
)

// DataList
const DataList: FC<{ filter: Filter }> = ({ filter }) => {
  // 直接使用 filter，无需订阅事件
  return <div>keyword: {filter.keyword}</div>
}
```

---

## 方案 2：Context + useContext（跨层级同子树）

### Vue provide/inject + 事件

```js
// 祖先
provide() { return { notify: this.notify } }
methods: { notify(msg) { /* ... */ } }

// 后代
inject: ['notify']
mounted() { this.notify('ready') }
```

### React Context

```tsx
interface NotificationCtx {
  notify: (msg: string, type?: 'success' | 'error') => void
}
const NotificationContext = createContext<NotificationCtx | null>(null)

export function useNotification() {
  const ctx = useContext(NotificationContext)
  if (!ctx) throw new Error('useNotification requires NotificationProvider')
  return ctx
}

// Provider
export const NotificationProvider: FC<PropsWithChildren> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([])

  const notify = useCallback((msg: string, type: 'success' | 'error' = 'success') => {
    const id = Date.now()
    setMessages(prev => [...prev, { id, msg, type }])
    setTimeout(() => setMessages(prev => prev.filter(m => m.id !== id)), 3000)
  }, [])

  return (
    <NotificationContext.Provider value={{ notify }}>
      {children}
      <div className="fixed top-4 right-4 space-y-2">
        {messages.map(m => <Toast key={m.id} {...m} />)}
      </div>
    </NotificationContext.Provider>
  )
}

// 任意后代组件
const MyComponent: FC = () => {
  const { notify } = useNotification()
  return <button onClick={() => notify('保存成功')}>Save</button>
}
```

---

## 方案 3：MobX Store 订阅（全局跨组件）

当事件本质是"全局状态变更"时，用 MobX 最自然：

### Vue EventBus 场景

```js
// 登录成功后通知所有组件
bus.$emit('auth:login', user)
bus.$on('auth:login', (user) => { this.currentUser = user })
```

### MobX Store

```ts
// stores/auth.ts
import { makeAutoObservable } from 'mobx'

export class AuthStore {
  user: User | null = null
  isLoggedIn = false

  constructor() { makeAutoObservable(this) }

  login(user: User) {
    this.user = user
    this.isLoggedIn = true
  }

  logout() {
    this.user = null
    this.isLoggedIn = false
  }
}
```

```tsx
// 任何组件，用 observer 包裹后自动响应变化
import { observer } from 'mobx-react-lite'

const Header = observer(() => {
  const { user, isLoggedIn } = useAuthStore()
  return isLoggedIn ? <span>{user!.name}</span> : <LoginButton />
})
```

**优势**：不需要手动订阅/取消订阅，`observer` 自动处理；精细到字段级别的更新。

---

## 方案 4：轻量 EventEmitter（过渡方案）

如果遗留代码量大、短期内无法全部重构为 React 模式，可以保留一个类型安全的 EventEmitter 作为过渡：

### 类型安全的 EventEmitter

```ts
// lib/eventBus.ts
type EventMap = {
  'user:updated': User
  'theme:change': 'light' | 'dark'
  'notification:show': { message: string; type: 'success' | 'error' }
}

type Handler<T> = (payload: T) => void

class TypedEventBus<E extends Record<string, any>> {
  private listeners = new Map<keyof E, Set<Handler<any>>>()

  on<K extends keyof E>(event: K, handler: Handler<E[K]>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set())
    }
    this.listeners.get(event)!.add(handler)
    // 返回取消订阅函数
    return () => this.off(event, handler)
  }

  once<K extends keyof E>(event: K, handler: Handler<E[K]>): () => void {
    const wrapper: Handler<E[K]> = (payload) => {
      handler(payload)
      this.off(event, wrapper)
    }
    return this.on(event, wrapper)
  }

  off<K extends keyof E>(event: K, handler: Handler<E[K]>): void {
    this.listeners.get(event)?.delete(handler)
  }

  emit<K extends keyof E>(event: K, payload: E[K]): void {
    this.listeners.get(event)?.forEach(h => h(payload))
  }

  clear(): void {
    this.listeners.clear()
  }
}

export const eventBus = new TypedEventBus<EventMap>()
```

### 配套 React Hook（自动清理）

```tsx
// hooks/useEvent.ts
import { useEffect, useRef } from 'react'
import { eventBus } from '@/lib/eventBus'

type EventMap = Parameters<typeof eventBus.on>[0] extends infer K ? K : never

export function useEvent<K extends keyof EventMap>(
  event: K,
  handler: (payload: EventMap[K]) => void,
) {
  const handlerRef = useRef(handler)
  handlerRef.current = handler

  useEffect(() => {
    const unsubscribe = eventBus.on(event, (payload) => {
      handlerRef.current(payload)
    })
    return unsubscribe  // 组件卸载时自动取消订阅
  }, [event])
}
```

### 使用

```tsx
// 发送
eventBus.emit('user:updated', updatedUser)

// 接收（自动清理，无内存泄漏）
const UserProfile: FC = () => {
  const [user, setUser] = useState<User | null>(null)
  useEvent('user:updated', setUser)
  return user ? <div>{user.name}</div> : null
}
```

---

## mitt / tiny-emitter 迁移

### 从 mitt 迁移

如果 Vue 3 项目已经在用 mitt：

```ts
// Vue 3 + mitt
import mitt from 'mitt'
type Events = { 'foo': string; 'bar': number }
const emitter = mitt<Events>()
emitter.on('foo', (v) => { /* ... */ })
emitter.emit('foo', 'hello')
```

迁移选择：
1. **直接替换为上面的 TypedEventBus**（零依赖，行为一致）
2. **继续用 mitt + useEvent hook**（如果不想改底层）：

```tsx
// 保留 mitt，加 hook 包装
import mitt from 'mitt'

type Events = { 'foo': string; 'bar': number }
export const emitter = mitt<Events>()

export function useEmitterEvent<K extends keyof Events>(
  event: K,
  handler: (payload: Events[K]) => void,
) {
  const handlerRef = useRef(handler)
  handlerRef.current = handler

  useEffect(() => {
    const fn = (payload: Events[K]) => handlerRef.current(payload)
    emitter.on(event, fn)
    return () => emitter.off(event, fn)
  }, [event])
}
```

3. **最终目标**：逐步将事件替换为 MobX Store 或 Context，消除 EventBus

### 从 tiny-emitter 迁移

tiny-emitter 的 API 与 Vue 2 的 `$on/$off/$emit` 几乎一致，迁移方式同上。

---

## 常见场景迁移示例

### 场景 1：全局 Loading 状态

**Vue EventBus：**
```js
bus.$emit('loading:show')
bus.$emit('loading:hide')
bus.$on('loading:show', () => { this.loading = true })
```

**React（Context）：**
```tsx
const LoadingContext = createContext({ show: () => {}, hide: () => {} })

export const LoadingProvider: FC<PropsWithChildren> = ({ children }) => {
  const [loading, setLoading] = useState(false)
  const value = useMemo(() => ({
    show: () => setLoading(true),
    hide: () => setLoading(false),
  }), [])

  return (
    <LoadingContext.Provider value={value}>
      {children}
      {loading && <FullScreenSpinner />}
    </LoadingContext.Provider>
  )
}

export const useLoading = () => useContext(LoadingContext)
```

### 场景 2：跨页面数据刷新

**Vue EventBus：**
```js
// 编辑页保存后
bus.$emit('list:refresh')
// 列表页
bus.$on('list:refresh', () => { this.fetchList() })
```

**React（MobX Store）：**
```ts
class ListStore {
  refreshFlag = 0
  constructor() { makeAutoObservable(this) }
  triggerRefresh() { this.refreshFlag++ }
}

// 编辑页
listStore.triggerRefresh()

// 列表页（observer 自动响应）
const ListPage = observer(() => {
  const { refreshFlag } = useListStore()
  useEffect(() => { fetchList() }, [refreshFlag])
  return /* ... */
})
```

### 场景 3：全局快捷键

**Vue EventBus：**
```js
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key === 's') bus.$emit('shortcut:save')
})
bus.$on('shortcut:save', () => { this.save() })
```

**React（自定义 Hook）：**
```tsx
// hooks/useHotkey.ts
export function useHotkey(key: string, modifiers: string[], handler: () => void) {
  const handlerRef = useRef(handler)
  handlerRef.current = handler

  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      const match = e.key === key
        && (!modifiers.includes('ctrl') || e.ctrlKey)
        && (!modifiers.includes('shift') || e.shiftKey)
        && (!modifiers.includes('alt') || e.altKey)
      if (match) {
        e.preventDefault()
        handlerRef.current()
      }
    }
    document.addEventListener('keydown', listener)
    return () => document.removeEventListener('keydown', listener)
  }, [key, ...modifiers])
}

// 使用
useHotkey('s', ['ctrl'], () => save())
```

### 场景 4：$once（一次性事件）

**Vue：**
```js
bus.$once('init:complete', () => { /* 只执行一次 */ })
```

**React（useRef 标记）：**
```tsx
const handled = useRef(false)
useEvent('init:complete', () => {
  if (handled.current) return
  handled.current = true
  // 只执行一次的逻辑
})
```

或直接用 TypedEventBus 的 `once` 方法 + useEffect：

```tsx
useEffect(() => {
  return eventBus.once('init:complete', () => { /* ... */ })
}, [])
```

---

## 清理与内存泄漏防范

### Vue 2 的问题

```js
// 常见 bug：忘记在 beforeDestroy 里 $off
mounted() { bus.$on('event', this.handler) }
// 缺少 beforeDestroy → 内存泄漏
```

### React 的保障

使用 `useEffect` 的 cleanup 机制天然防止泄漏：

```tsx
useEffect(() => {
  const unsubscribe = eventBus.on('event', handler)
  return unsubscribe   // 组件卸载时自动清理
}, [])
```

**规则**：
- 所有事件订阅必须在 `useEffect` 内完成
- 必须返回 cleanup 函数
- 使用 `useEvent` hook 封装后，调用方无需关心清理

---

## 迁移清单

1. **盘点**：列出项目中所有 `$on` / `$off` / `$emit` / `bus.on` / `emitter.on` 调用
2. **分类**：按上面的"迁移策略选型"表格，给每个事件分配目标方案
3. **优先级**：
   - 父子通信 → 立即改为回调 props（最简单）
   - 全局状态 → 改为 MobX Store
   - 跨层级 UI 通知 → 改为 Context
   - 剩余复杂场景 → 用 TypedEventBus + useEvent hook 过渡
4. **逐步消除**：每次迭代减少 EventBus 使用，最终目标是零 EventBus

---

## 对照速查

| Vue 事件 API | React 推荐替代 |
|---|---|
| `this.$emit('event', data)` | `props.onEvent(data)` |
| `bus.$on('event', handler)` | MobX observer / Context / useEvent hook |
| `bus.$off('event', handler)` | useEffect cleanup（自动） |
| `bus.$once('event', handler)` | useRef 标记 / eventBus.once + useEffect |
| `mitt` / `tiny-emitter` | TypedEventBus + useEvent hook（过渡）→ 最终用 Store/Context |
| 全局状态变更通知 | MobX Store（observer 自动响应） |
| UI 通知（toast/modal） | Context + Provider |
| 快捷键 | useHotkey 自定义 hook |

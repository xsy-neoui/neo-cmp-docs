# vue-to-react Skill 说明

## 技能边界（三技能路由）

本技能只做**Vue 源码 → React 源码**的语法层迁移，**不**直接产出合规的 Neo 自定义组件：

| 用户意图 | 应使用的技能 |
|---|---|
| 输入有 **Vue 源码**，要求"把 Vue 组件 / 项目改成 React 自定义组件 / SFC 转 JSX / Vuex 转 MobX / Options API 转 hooks" | **`vue-to-react`（本技能）** |
| 从零**开发 / 实现**一个新的 Neo 自定义组件功能（没有 Vue 源码输入） | `neo-cmp-dev` |
| 仅**执行 `neo` 命令**（创建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 登录） | `neo-cmp-cli` |

**与 `neo-cmp-dev` 的交接**：本技能完成语法迁移后，若目标落到 Neo 自定义组件，必须由 `neo-cmp-dev` 接手做平台规范落地（类组件 + `BaseCmp`、目录 `__c` 后缀、根类名 = 目录名、SCSS + BEM 样式隔离、`propsSchema` 平台真实类型、事件动作、`xObject` / `customApi`、发布走 `neo-cmp-cli`）。本技能默认的 Tailwind + CSS Modules 样式仅是通用 React 项目的过渡方案，进入 neo 工程前需要改为 SCSS + BEM。

## 设计思路

严格遵循 skill-creator 规范的**三层渐进式披露（progressive disclosure）**：

- **第 1 层 — metadata**（`SKILL.md` frontmatter 的 `name` + `description`）：覆盖"Vue 迁移 React / Vue 改 React / Vue 转 React 自定义组件 / SFC 转 JSX/TSX / v-if·v-for 转 JSX"等多种触发表达，明确即便用户没说"迁移"，只要提出把 Vue 组件/项目改成 React 也务必启用，降低欠触发风险
- **第 2 层 — `SKILL.md` 主文档**（310 行，低于 500 行上限）：只保留**迁移范围界定、技术栈映射、组件形态决策、核心映射速查、迁移执行清单、常见陷阱**，让 Claude 在触发后立即知道"怎么选、去哪查"
- **第 3 层 — `references/` 专题文件**：按领域组织 17 个深度参考文件，按需加载，避免一次性把所有内容塞进上下文

## 结构

```
vue-to-react/
├── SKILL.md                              # 主文档（frontmatter + 决策 + 速查）
├── README.md                             # 本文件（设计思路与目录索引）
└── references/
    ├── template-to-jsx.md                # 模板语法（v-if/v-for/插槽/事件修饰符/v-model/refs）
    ├── reactivity.md                     # ref/reactive/computed/watch → useState/useMemo/useEffect
    ├── lifecycle.md                      # 生命周期对照（含 ErrorBoundary、useLayoutEffect、keep-alive 替代）
    ├── communication.md                  # props/emits/v-model/provide-inject/refs/eventBus
    ├── state-management.md               # Pinia / Vuex → MobX（RootStore 组合、持久化）
    ├── routing.md                        # Vue Router → React Router v6（数据路由、守卫、懒加载）
    ├── directives-mixins.md              # 自定义指令/mixin → 自定义 hook / HOC / 过滤器
    ├── sfc-splitting.md                  # SFC → .tsx + Tailwind / CSS Modules 拆分策略
    ├── class-vs-function.md              # 函数组件 vs 类组件（决策流程图、判定清单）
    ├── vue2-options-api.md               # Vue 2 Options API 逐字段 1:1 映射
    ├── event-system.md                   # 全局事件总线 / $emit 链 → Context / store / emitter
    ├── form-validation.md                # 表单与校验（VeeValidate/ElementUI → RHF + zod）
    ├── i18n.md                           # Vue I18n → react-i18next
    ├── transition-animation.md           # <transition> / TransitionGroup → framer-motion / CSS
    ├── async-suspense-teleport.md        # <Suspense>/<Teleport>/异步组件 → React.lazy/Portal
    ├── typescript-migration.md           # Vue + TS → React + TS 的类型迁移要点
    └── engineering-neo-cli.md            # 工程化：neo-cmp-cli 脚手架 / 打包 / 联调
```

## 覆盖的需求

| # | 用户要求 | 实现位置 |
|---|---|---|
| 1 | 模板语法到 JSX | `references/template-to-jsx.md`（v-if/v-for/插槽/事件修饰符/v-model/refs 全覆盖） |
| 2 | 响应式系统转换 | `references/reactivity.md`（含不可变更新、Immer、useReducer 取舍） |
| 3 | 生命周期对照 | `references/lifecycle.md`（含 ErrorBoundary、useLayoutEffect、keep-alive 替代） |
| 4 | 组件通信 | `references/communication.md`（含 forwardRef + useImperativeHandle、Context 性能陷阱） |
| 5 | 状态管理 → MobX | `references/state-management.md`（Pinia/Vuex 双路径、RootStore 组合、持久化） |
| 6 | 路由 → React Router | `references/routing.md`（v6.4 数据路由、守卫三种方案、懒加载） |
| 7 | 指令/mixin 替代 | `references/directives-mixins.md`（hook 首选、HOC 补位、全局方法方案） |
| 8 | SFC 拆分策略 | `references/sfc-splitting.md`（Tailwind + CSS Modules 决策树、完整 Button 示例） |
| 9 | Vue 2 主攻方向 | `references/vue2-options-api.md`（Options API 每个字段 1:1 映射 + 完整示例） |
| 10 | 函数组件 vs 类组件 | `references/class-vs-function.md`（决策流程图、判定清单、硬性/软性判据） |
| 11 | Tailwind 样式偏好 | 贯穿 `SKILL.md` + `sfc-splitting.md`（clsx、tailwind-variants） |
| 12 | 其他补充 | 事件系统、表单校验、i18n、过渡动画、Suspense/Teleport、TS 迁移、neo-cmp-cli 工程化 |

## 对齐的规范

- **skill-creator 规范**：
  - 采用 `SKILL.md` + `references/` 目录约定
  - YAML frontmatter 带 `name` / `description`，描述带触发推导语气
  - 主文档行数控制在 500 以内（当前 310 行）
  - 引用 references 时给出"进入时机"（在主文档每节末尾点明对应文件）
  - 迁移范围界定写在主文档开头，避免 Claude 对纯 JS/TS 工具文件做无意义改写
- **组件形态偏好**：简单功能组件用函数组件 + hooks，复杂场景用类组件（错误边界、重生命周期、多状态交织），`class-vs-function.md` 给出判定清单
- **状态管理偏好**：MobX（`makeAutoObservable` + `observer`），因其响应式心智与 Vue 接近、精细订阅、迁移成本低
- **样式偏好**：Tailwind 为主，CSS Modules 做补充（动画、伪元素、深层选择器）
- **工程化**：`engineering-neo-cli.md` 对齐仓库内 `neo-cmp-cli` 脚手架的 `preview` / `linkDebug` / `build` / `pushCmp` 命令

## 使用方式

触发后 Claude 会先读主文档 `SKILL.md`，按以下顺序工作：

1. 按"迁移范围界定"筛出需要改写的 `.vue` / Vuex / router / 指令 / mixin 文件（普通 JS/TS 不动）
2. 依"迁移执行清单"8 步推进：盘点 → 建基础设施 → 迁 store → 迁路由 → 自底向上迁组件 → 处理指令/mixin → 处理全局能力 → 验证清理
3. 遇到具体子问题时进入对应 `references/*.md`（比如用到动画就进 `transition-animation.md`）
4. 按"函数组件 vs 类组件"决策表选择组件形态

## 可选的下一步

- 按 skill-creator 完整流程，可新建 `evals/evals.json` 写 2-3 个真实测试 prompt（例："把这个 Vuex user 模块转成 MobX""把这个 Options API 的 UserCard.vue 转成 .tsx"），然后用 `eval-viewer/generate_review.py` 跑迭代
- 或直接试用：把一份真实 `.vue` 文件丢进来跑一遍实际迁移，在反馈中再补参考文件

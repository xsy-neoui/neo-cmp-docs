---
name: vue-to-react
description: 将 Vue 组件或整个 Vue 项目（主攻 Vue 2 Options API，兼容 Vue 3 Composition API）**改造 / 转换 / 迁移**成 React 16 + TypeScript 的语法层技能，最终落点是 Neo 平台自定义组件（由 neo-cmp-dev 做平台规范对齐）。仅当用户输入是 **Vue 源码**、并要求"把 Vue 组件 / 项目改成 React 自定义组件"或类似迁移意图时使用。覆盖：SFC 拆分、模板 → JSX、响应式（ref/reactive/computed/watch）→ useState/useMemo/useEffect、生命周期对照、通信（props/emits/v-model/provide-inject/$refs）、全局事件总线、Vuex/Pinia → MobX、Vue Router → React Router、自定义指令 / mixin → 自定义 hook / HOC、过渡动画、Suspense/Teleport、TS 迁移、工程配置迁移到 neo-cmp-cli。**不用于**：从零开发一个全新的自定义组件（没有 Vue 源码输入时，直接用 neo-cmp-dev）；仅执行 neo 命令的场景（→ neo-cmp-cli）。**完成 Vue → React 语法迁移后，必须由 neo-cmp-dev 技能接手做平台规范落地**（propsSchema、事件动作、BaseCmp、目录与根类名约定、样式隔离、发布），本技能不负责平台规范层。触发关键词：Vue 迁移 React、Vue 改 React、Vue 转自定义组件、Vue 改自定义组件、SFC 转 JSX、SFC 转 TSX、v-if / v-for 转 JSX、Vuex 转 MobX、Pinia 转 MobX、Vue Router 转 React Router、Options API 转 hooks、Composition API 转 hooks、把 Vue 项目改成 Neo 自定义组件。
---

# Vue → React 迁移技能（以 Vue 2 为主）

这项技能用于把 Vue 项目（尤其是 Vue 2 + Options API / Vuex / Vue Router）系统性地改写成 React 16 + TypeScript 项目。它提供：

- 一套**明确的等价映射表**，覆盖模板语法、响应式、生命周期、通信、状态、路由、指令、mixin、样式、动画、事件系统等
- 一条**清晰的决策路径**，告诉你"这段代码在 React 里应该用函数组件+hooks 还是类组件"
- 每个主题都有独立的**深度参考文件**（见 `references/`），按需阅读以避免主文档臃肿

::: v-pre

## 技能边界（与 `neo-cmp-cli` / `neo-cmp-dev` 的分工）

本技能只做"**Vue 源码 → React 源码**"的**语法层迁移**，目标是让迁移产物能在 neo-cmp-cli 工程里被 `neo-cmp-dev` 进一步改造。它**不是**一个通用的"Vue 迁移 React"项目迁移指南，也**不直接产出**合规的 Neo 自定义组件。

| 用户意图 | 应使用的技能 | 与本技能的分工 |
|---|---|---|
| 输入有 **Vue 源码**，要求"把 Vue 组件 / 项目改成 React 自定义组件 / SFC 转 JSX / Vuex 转 MobX / ..." | **`vue-to-react`（本技能）** | 负责语法层 1:1 迁移；迁移完再交给 `neo-cmp-dev` 做平台规范落地 |
| 从零**开发 / 实现**一个新的 Neo 自定义组件功能（没有 Vue 源码输入） | **`neo-cmp-dev`** | 本技能不介入；直接用 `neo-cmp-dev` 的 11 步开发流程 |
| 仅**执行 `neo` 命令**（创建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 登录） | **`neo-cmp-cli`** | 本技能不介入；迁移过程中如需要创建工程骨架或发布，调用 `neo-cmp-cli` 的命令 |

**关键判别词**（必须命中左列才进入本技能）：

- **进入本技能**：用户给出 / 指向 `.vue` 文件、Vuex store、Pinia store、`vue.config.js` / `vite.config.ts`、Vue Router 配置，**并**要求"改成 / 转成 / 迁移成"React 或自定义组件；出现"SFC 转 JSX"、"v-if / v-for 转 JSX"、"Options API 转 hooks"、"Composition API 转 hooks"、"Vuex / Pinia 转 MobX"、"Vue Router 转 React Router"等表述。
- **不进入本技能，转 `neo-cmp-dev`**：用户没有 Vue 源码，只是"帮我写 / 实现 / 开发一个 xx 功能的自定义组件"。
- **不进入本技能，转 `neo-cmp-cli`**："创建项目"、"新建组件骨架"、"发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 登录"等纯命令场景。

## 与 `neo-cmp-dev` 的交接（必读）

本技能默认的"React 侧偏好"（函数组件 + Hooks、Tailwind + CSS Modules、React Router v5/v6）适合**通用 React 项目**；但 Neo 平台自定义组件对组件形态和样式有**硬约束**，迁移产物进入工程后**必须**由 `neo-cmp-dev` 按下面 4 点做二次改造，本技能不在迁移阶段强行对齐，以免丢失 Vue 原语义：

1. **组件形态**：需要事件动作 / 组件动作 / ErrorBoundary 的组件，`neo-cmp-dev` 要求**类组件 + `extends BaseCmp`**（见 `neo-cmp-dev/references/component-form.md`）。本技能产出的函数组件要在交接阶段转成类组件。
2. **目录与根类名**：平台约定目录名 = 根类名 = cmpType，统一 `__c` 后缀（如 `orderCard__c`）；根节点 DOM 必须合并 `props.className`（平台用它注入 `design-hide`）。本技能输出的文件名 / 根类名不一定符合该约定，由 `neo-cmp-dev` 统一重命名。
3. **样式方案**：平台使用 **SCSS + BEM + 样式隔离**（根类名等于目录名），**不是** Tailwind + CSS Modules。Vue `<style scoped>` 在本技能里可先临时转成 Tailwind 作为过渡，但**进入 neo 工程前**必须由 `neo-cmp-dev` 按 SCSS + BEM 重写；若用户明确要求一步到位，本技能也可直接输出 SCSS（`index.scss` + BEM）以减少二次工作。
4. **属性面板 / 事件动作 / 数据源**：Vue 里的 `props` / `emits` / `axios` / Vuex 迁移后，**不等于**自定义组件的 `propsSchema` / `events` / `functions` / `xObject` / `customApi`。这一层平台语义由 `neo-cmp-dev` 补齐，本技能只负责把 Vue 侧逻辑**结构完整地**搬到 React 侧。

**标准交接流程**：

1. 本技能完成语法层迁移，产出可编译的 React + TS 代码（函数组件 / 类组件、MobX、React Router、Tailwind 或 SCSS）；
2. 切换到 `neo-cmp-dev` 技能：按其 11 步流程把产物改造成合规的 `src/components/<cmpName>__c/`（目录、`index.tsx`、`model.ts`、`propsSchema`、事件动作、SCSS + BEM、`props.className` 合并、`src/common/` 自研 UI、`src/utils/` 工具函数）；
3. 切换到 `neo-cmp-cli` 技能：执行 `neo create cmp`（若还未创建骨架）、`neo preview` / `neo linkDebug`、`neo login`、`neo push cmp`。

## 总体迁移策略

### 迁移范围界定

**只迁移 Vue 特有代码**，项目中的普通 JS/TS 模块（工具函数、常量定义、纯逻辑类、API 请求封装、数据转换等）**不需要处理**，直接保留原文件即可。判断标准：

- ❌ **不需要迁移**：没有 `import Vue`、没有使用 Vue 响应式 API（`ref`/`reactive`/`computed`）、没有 Vue 生命周期、没有 `export default { ... }` 组件定义的 `.js` / `.ts` 文件
- ✅ **需要迁移**：`.vue` 单文件组件、Vuex/Pinia store 文件、Vue Router 配置、Vue 插件、包含 `Vue.extend` / `defineComponent` 的文件、使用了 Vue 特有 API（`Vue.set`、`this.$emit`、`this.$refs` 等）的模块

简言之：**如果一个文件去掉 Vue 依赖后逻辑完全不变，就不要动它。** 这类文件在迁移后的 React 项目中可以直接 import 使用。

### 技术栈映射（默认选择）

| Vue 侧 | React 侧（本技能推荐） |
|---|---|
| Vue 2 Options API / Vue 3 Composition API | **React 16 + TypeScript** |
| `<template>` | JSX / TSX |
| `data` / `ref` / `reactive` | `useState` / `useReducer`（类组件用 `this.state`） |
| `computed` | `useMemo`（纯计算） / 派生状态 |
| `watch` | `useEffect`（副作用） / `useMemo`（派生值） |
| `methods` | 普通函数 / `useCallback`（需要稳定引用时） |
| 生命周期钩子 | `useEffect` / 类组件生命周期 |
| `props` + `emits` | `props`（回调函数向上通信） |
| `provide` / `inject` | `React.createContext` + `useContext` |
| `mixins` / 自定义指令 | 自定义 hooks / HOC / render props |
| Vuex / Pinia | **MobX**（`makeAutoObservable` + `observer`） |
| Vue Router | React Router v5（兼容 React 16） |
| `<style scoped>` | Tailwind CSS（首选） + CSS Modules（局部定制） |
| `.vue` SFC | `.tsx`（逻辑 + JSX） + `*.module.css`（如需） |
| Vue CLI / Vite (Vue) | **neo-cmp-cli**（基于 AKFun + Webpack） |
| `$on` / `$off` / `$emit` / EventBus | 回调 props / Context / MobX Store / 自定义 hook |
| `<Transition>` / `<TransitionGroup>` | framer-motion / react-transition-group |
| `<Teleport>` | `ReactDOM.createPortal` |
| `defineAsyncComponent` / `<Suspense>` | `React.lazy` + `Suspense` |
| vue-i18n | react-i18next |
| VeeValidate / Vuelidate | React Hook Form + Zod |

### 关于 React 16

本技能目标版本为 **React 16.8+**（支持 Hooks 的最低版本）。与 React 18 的主要差异：

- 无 `useId`、`useDeferredValue`、`useTransition` 等 React 18 新 hooks
- 无自动批处理（React 16 中只有事件处理函数内的 setState 会批处理）
- `ReactDOM.render` 而非 `createRoot`
- `Suspense` 仅支持 `React.lazy`（不支持数据获取的 suspense 模式）
- 无 `startTransition` / `useTransition`

这些差异不影响核心迁移逻辑，绝大部分映射关系保持一致。

### 组件形态选择（React 侧）

这是迁移时的核心判断，**请先决定再动手**：

- **简单功能组件 → 函数组件 + hooks（推荐）**
  - 判定条件（满足大部分即可）：
    - 状态 ≤ 2 个、只读取 props 或少量 context
    - 没有复杂的异步编排、没有多生命周期交叉逻辑
    - 不需要 `getDerivedStateFromError` / `getSnapshotBeforeUpdate` 之类的能力
- **复杂功能组件 → 类组件**
  - 判定条件（任一命中）：
    - 生命周期交织（挂载拉数据 + 更新对比 + 卸载清理 + 错误兜底）
    - 需要 `ErrorBoundary`（React 目前只能用类组件实现）
    - 大量内部状态 + 多个相互依赖的副作用，用 hooks 反而会让依赖数组难以维护
    - 原 Vue 组件是重逻辑的 Options API 结构，1:1 对齐成类更顺滑

当拿不准时，默认先写函数组件，出现依赖地狱或 `useEffect` 嵌套混乱再改成类。

### 样式方案

- **默认 Tailwind**：大部分布局、间距、颜色、响应式、状态变体（hover/focus/dark）直接用 class 写在 JSX 上
- **CSS Modules 作为补充**：需要复杂选择器、动画关键帧、伪元素定制、或组件级私有样式时使用 `Button.module.css`
- **不推荐**默认上 styled-components / emotion（除非项目已有），原因是 Tailwind 已足够且性能/可读性更好
- Vue 的 `<style scoped>` → 优先转成 Tailwind class；若原样式逻辑复杂（深层选择器、动态主题），保留为 CSS Modules

> **例外：目标是 Neo 平台自定义组件时**，平台硬约束使用 **SCSS + BEM + 样式隔离**（根类名等于组件目录名、合并 `props.className`），Tailwind / CSS Modules 不适用。建议：
> - **已明确交付为自定义组件**：本阶段直接输出 `index.scss`（BEM，根类名 = 目标目录名，如 `orderCard__c`），跳过 Tailwind 过渡；
> - **暂未确定是否落地自定义组件 / 先要跑通语法迁移**：允许本阶段先用 Tailwind，交接到 `neo-cmp-dev` 时再按其 `references/styling.md` 重写为 SCSS + BEM。

### 工程配置（neo-cmp-cli）

迁移后的 React 项目**统一使用 neo-cmp-cli** 作为工程化工具：

- **构建工具**：Webpack（通过 AKFun 封装），零配置开箱即用
- **配置文件**：`neo.config.js`（替代 `vue.config.js` / `vite.config.ts`）
- **环境变量**：`envParams` 字段（替代 `.env.*` 文件），使用 `#变量名#` 占位符
- **代理**：`dev.proxyTable`（语法与 webpack-dev-server proxy 一致）
- **别名**：`webpack.resolve.alias`（默认 `@` → `src`）
- **命令**：`neo preview`（开发）、`neo build`（构建）、`neo build2lib`（UMD）、`neo build2esm`（ESM）

详见 `references/engineering-neo-cli.md`。

## 核心映射速查

下面是最常用的几条"一眼对照"映射，详细语义与边界情况请进入对应的 references 文件。

### 1. 模板语法（详见 `references/template-to-jsx.md`）

```html
<!-- Vue -->
<div v-if="ok">A</div>
<div v-else>B</div>

<ul>
  <li v-for="item in list" :key="item.id">{{ item.name }}</li>
</ul>

<button @click.stop.prevent="onClick">Go</button>

<Child>
  <template #header><h1>Hi</h1></template>
  <p>默认插槽</p>
</Child>
```

```tsx
// React
{ok ? <div>A</div> : <div>B</div>}

<ul>
  {list.map(item => <li key={item.id}>{item.name}</li>)}
</ul>

<button onClick={(e) => { e.stopPropagation(); e.preventDefault(); onClick(); }}>
  Go
</button>

<Child header={<h1>Hi</h1>}>
  <p>默认插槽</p>
</Child>
```


### 2. 响应式（详见 `references/reactivity.md`）

```ts
// Vue 3 Composition API
const count = ref(0)
const user = reactive({ name: 'a' })
const double = computed(() => count.value * 2)
watch(count, (n) => console.log(n))
```

```tsx
// React 函数组件
const [count, setCount] = useState(0)
const [user, setUser] = useState({ name: 'a' })
const double = useMemo(() => count * 2, [count])
useEffect(() => { console.log(count) }, [count])
```

> Vue 2 的 `data() { return { count: 0 } }` → 类组件 `this.state = { count: 0 }` / 函数组件 `useState`。

### 3. 生命周期（详见 `references/lifecycle.md`）

| Vue 2 | Vue 3 | React 函数组件 | React 类组件 |
|---|---|---|---|
| `beforeCreate` / `created` | `setup` 体 | 函数体顶部 | `constructor` |
| `mounted` | `onMounted` | `useEffect(() => {...}, [])` | `componentDidMount` |
| `updated` | `onUpdated` | `useEffect(() => {...})`（无依赖） | `componentDidUpdate` |
| `beforeDestroy`/`unmounted` | `onBeforeUnmount` | `useEffect` 返回的 cleanup | `componentWillUnmount` |
| `errorCaptured` | `onErrorCaptured` | 无（须用类组件 ErrorBoundary） | `componentDidCatch` |

### 4. 通信（详见 `references/communication.md`）

- `props` → `props`
- `$emit('change', v)` → `props.onChange(v)`（父组件以回调传入）
- `v-model` → `value` + `onChange` 受控对
- `provide/inject` → `React.createContext` + `useContext`
- 兄弟组件事件总线 → 提升状态 / Context / MobX store
- `$refs` → `useRef` + `forwardRef` + `useImperativeHandle`

### 5. 全局事件系统（详见 `references/event-system.md`）

Vue 2 的 `$on` / `$off` / `$once` / EventBus / mitt 在 React 中的替代：

| Vue 事件模式 | React 推荐替代 |
|---|---|
| `this.$emit('event', data)` | `props.onEvent(data)`（回调 prop） |
| `bus.$on('event', handler)` | MobX observer / Context / useEvent hook |
| `bus.$off('event', handler)` | useEffect cleanup（自动） |
| `bus.$once('event', handler)` | useRef 标记 / eventBus.once + useEffect |
| 全局状态变更通知 | MobX Store（observer 自动响应） |
| UI 通知（toast/modal） | Context + Provider |

**迁移原则**：能用 React 原生模式（props/Context/Store）解决的，不要用事件总线。如果遗留代码量大，可用类型安全的 EventEmitter + `useEvent` hook 作为过渡方案。

### 6. 状态管理（详见 `references/state-management.md`）

Vuex / Pinia → **MobX**。映射原则：

- Vuex `state` / Pinia `state` → `class Store { @observable } ` 或 `makeAutoObservable(this)`
- `getters` → `get xxx()`（计算属性）
- `mutations` / `actions` → 普通方法（action），异步直接 `async`
- `modules` → 多个 Store 组合到 `RootStore`

组件用 `observer` 包裹，`useStore` 或构造时注入。

### 7. 路由（详见 `references/routing.md`）

- `<router-link to="/x">` → `<Link to="/x">`
- `<router-view>` → `<Switch>` + `<Route>`（React Router v5）
- `this.$route.params.id` / `useRoute()` → `useParams()`
- `this.$router.push()` → `useHistory().push()`（v5）
- 路由守卫 `beforeEach` → 自定义 `RequireAuth` 包裹组件 / `<Route render>` 拦截
- 嵌套路由 → `<Route>` 嵌套 + `<Switch>`

> 注意：React 16 兼容 React Router v5。如果项目允许，也可使用 React Router v6（需 React 16.8+）。

### 8. 指令与 mixin（详见 `references/directives-mixins.md`）

- 内置指令：`v-show` → 条件 `style={{ display: ... }}` 或 Tailwind `hidden`；`v-html` → `dangerouslySetInnerHTML`；`v-model` → 受控组件
- 自定义指令（`v-click-outside` 等）→ **自定义 hook**（`useClickOutside(ref, cb)`）
- `mixins` → 优先 **自定义 hook**；需要覆盖渲染或注入 props 时用 **HOC**（`withXxx`）

### 9. 单文件组件拆分（详见 `references/sfc-splitting.md`）

```
Button.vue                          Button/
├── <template>         →            ├── Button.tsx          （JSX）
├── <script setup>     →            ├── useButton.ts        （可选，抽 hook）
└── <style scoped>     →            ├── Button.module.css   （或完全用 Tailwind）
                                    └── index.ts            （re-export）
```

拆分原则：
- 逻辑超过 ~50 行或被复用 → 抽到 `useXxx.ts` 自定义 hook
- 类型定义集中在 `Button.types.ts` 或组件文件顶部
- 仅组件内使用的子组件放同级，跨组件复用的提到 `components/` 共享目录

### 10. 动画与过渡（详见 `references/transition-animation.md`）

| Vue | React |
|---|---|
| `<Transition name="fade">` | `framer-motion` 的 `AnimatePresence` + `motion.div` |
| `<TransitionGroup>` | `AnimatePresence` + `layout` prop |
| `v-show` + CSS transition | Tailwind `transition-*` + 条件 class |
| JS 钩子（`@enter` / `@leave`） | framer-motion 或 CSSTransition 钩子 |

### 11. 异步组件 / Teleport（详见 `references/async-suspense-teleport.md`）

| Vue | React |
|---|---|
| `defineAsyncComponent(() => import(...))` | `React.lazy(() => import(...))` |
| `<Suspense>` + `#fallback` | `<Suspense fallback={...}>` |
| `<Teleport to="body">` | `ReactDOM.createPortal(jsx, document.body)` |

## 迁移执行清单

对一个 Vue 项目/组件，按顺序执行：

1. **盘点**：列出所有 `.vue` 组件、Vuex/Pinia store、router 配置、自定义指令、mixin、全局过滤器、EventBus 事件。**同时标记出不需要迁移的普通 JS/TS 模块**（工具函数、常量、纯逻辑类、API 封装等），这些文件直接复制到新项目即可
2. **建基础设施**：使用 `neo init` 创建 React + TS 项目，安装 `react@16`、`react-dom@16`、`react-router-dom@5`、`mobx`、`mobx-react-lite`、`tailwindcss`
3. **迁移工程配置**：将 `vue.config.js` / `vite.config.ts` 的 proxy、alias、env 等迁移到 `neo.config.js`
4. **迁移 store**（Vuex/Pinia → MobX）：这是最基础的依赖，先做完组件迁移才方便
5. **迁移路由**：先把骨架搭起来（React Router v5 的 `<BrowserRouter>` + `<Switch>`），页面组件用占位
6. **自底向上迁移组件**：从叶子组件开始，一个 `.vue` → 一个 `.tsx`（+ 可选 `.module.css`）
   - 每个组件迁移时判断函数组件 vs 类组件（按上文决策）
   - 先搬模板（转 JSX） → 再搬 script（转 state/hooks） → 最后搬 style（转 Tailwind / CSS Module）
7. **处理指令和 mixin**：封装成自定义 hook 或 HOC，在使用点替换
8. **处理全局事件系统**：盘点所有 `$on/$off/$emit`/EventBus 调用，按策略替换为 props/Context/MobX/useEvent hook
9. **处理全局能力**：`Vue.prototype.$xxx` → Context + hook，或直接 import；过滤器 → 普通函数或 hook
10. **验证**：类型检查（`tsc --noEmit`）、ESLint、按页面冒烟走查、对照关键业务流跑一遍
11. **清理**：删除 Vue 残留、`@vue/*` 依赖、`vue-` 前缀工具、旧的 `vue.config.js` / `vite.config.ts`
12. **交接给 `neo-cmp-dev`**：语法层迁移到此结束。**若目标是 Neo 平台自定义组件**，切换到 `neo-cmp-dev` 技能，按其 11 步开发流程做平台规范落地：
    - 组件形态：需要事件动作 / 组件动作 / ErrorBoundary 时改成 **类组件 + `extends BaseCmp`**；
    - 目录：放到 `src/components/<cmpName>__c/`，根节点 `className` 与目录名一致并合并 `props.className`；
    - 样式：若本阶段产出的是 Tailwind / CSS Modules，按 `neo-cmp-dev/references/styling.md` 重写为 **SCSS + BEM**；
    - 模型：补 `model.ts`（`label` / `targetDevice` / `defaultComProps` / `propsSchema` / `events` / `functions`）；
    - 数据源：把 `axios` / Vuex 的数据调用按 `neo-cmp-dev/references/open-api.md` 改成 `xObject` / `customApi`；
    - 发布命令：统一走 `neo-cmp-cli` 技能的非交互式参数执行（`neo create cmp` / `neo preview` / `neo linkDebug` / `neo login` / `neo push cmp`）。

## 常见陷阱

- **不要过度迁移**：普通 JS/TS 工具模块（utils、constants、API 封装、纯逻辑类）不依赖 Vue，无需改写，直接在 React 项目中 import 使用
- **Vue 的响应式是"代理"而 React 是"不可变 + 重渲染"**：不要直接 `state.xxx = y`，永远返回新引用
- **`v-if` vs 条件渲染**：Vue 的 `v-if` 销毁 DOM，React 的 `&&` 或三元也会卸载组件；但要注意 `v-show` 对应的是 `display:none` 而不是卸载
- **事件回调引用稳定性**：传给子组件的函数若依赖 state，注意 `useCallback` 以避免子组件无谓重渲（和 `React.memo` 配合）
- **Vue 2 的数组变更检测坑**（`Vue.set`、`splice`）→ React 里不存在此问题，但要用新数组替换
- **`this` 在类组件里需要绑定**：事件处理函数用箭头函数属性定义或在 `constructor` 里 `bind`
- **SFC 里 `<style scoped>` 的属性选择器** → Tailwind/CSS Module 下不再需要，直接干净写
- **React 16 无自动批处理**：在 setTimeout / Promise 回调中多次 setState 会触发多次渲染，必要时用 `ReactDOM.unstable_batchedUpdates` 包裹
- **EventBus 迁移遗漏**：忘记清理事件订阅是 Vue 2 项目的常见 bug，迁移到 React 时务必用 useEffect cleanup 或 useEvent hook 确保自动清理

## 参考文件（按需进入）

当主文档不够用时，打开对应 references：

- `references/template-to-jsx.md` — 模板语法（v-if / v-for / 插槽 / 事件修饰符 / v-model / refs）
- `references/reactivity.md` — ref / reactive / computed / watch 的 React 对应实现与坑
- `references/lifecycle.md` — 全量生命周期对照 + 错误边界实现
- `references/communication.md` — props / emits / v-model / provide-inject / eventBus / $refs
- `references/event-system.md` — **全局事件系统迁移**：$on/$off/$once/EventBus/mitt → React 模式（props/Context/MobX/useEvent hook）
- `references/state-management.md` — Pinia / Vuex 到 MobX 的结构映射与最佳实践
- `references/routing.md` — Vue Router 到 React Router 的映射（含守卫、懒加载、嵌套）
- `references/directives-mixins.md` — 自定义指令、mixin、过滤器、全局方法的 React 等价写法
- `references/sfc-splitting.md` — SFC 拆分成 `.tsx` + Tailwind/CSS Modules 的具体策略和目录约定
- `references/vue2-options-api.md` — Vue 2 Options API 逐字段到 React 的映射（data/methods/computed/watch/filters/mixins）
- `references/class-vs-function.md` — 何时选类组件、何时选函数组件的详细判据与示例
- `references/transition-animation.md` — Vue Transition/TransitionGroup → framer-motion / react-transition-group
- `references/async-suspense-teleport.md` — 异步组件 / Suspense / Teleport → React.lazy / createPortal
- `references/form-validation.md` — VeeValidate / Vuelidate → React Hook Form + Zod
- `references/i18n.md` — vue-i18n → react-i18next 国际化迁移
- `references/typescript-migration.md` — Vue TS 写法（Vue.extend / class-component / decorator）→ React TS
- `references/engineering-neo-cli.md` — **工程配置迁移**：Vue CLI / Vite(Vue) → neo-cmp-cli（env 变量、proxy、alias、构建命令）

:::

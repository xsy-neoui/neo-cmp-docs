# customApi__c — 自定义 API 示例

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 演示的能力

1. **`BaseCmp` 类组件**：支持事件动作的基类
2. **`NeoEvent.function`**：暴露 `loadData` 函数供外部通过事件动作调用
3. **`customApi.run` 通用代理调用**：通过平台通用代理转发请求到外部 API
4. **`propsSchema.customApi`**：让业务方在设计器里绑定自定义 API
5. **`componentDidUpdate` + `isEqual`**：当 `fetchConfig` 变化时自动重新加载
6. **错误处理**：`normalizePostsResult` 函数处理多种响应格式，展示错误状态
7. **`antd Table`**：使用 antd 表格展示列表数据，含分页功能

/**
 * @file 自定义 API（通用代理）示例组件
 * @description 通过平台「通用代理」自定义 API 转发请求，获取第三方列表数据并以表格展示
 */
import * as React from 'react';
import { Table, Spin, Empty } from 'antd';
// @ts-ignore
import { customApi } from 'neo-open-api';
// @ts-ignore
import { BaseCmp } from 'neo-ui-common';
// @ts-ignore
import { NeoEvent } from 'neo-ui-common';
// @ts-ignore
import isEqual from 'lodash/isEqual';

import './style.scss';

const DEFAULT_POSTS_URL = 'https://jsonplaceholder.typicode.com/posts';
/**
 * 其他可测试的接口
常用列表接口（直接访问）：
文章列表：https://jsonplaceholder.typicode.com/posts
用户列表：https://jsonplaceholder.typicode.com/users
待办列表：https://jsonplaceholder.typicode.com/todos
评论列表：https://jsonplaceholder.typicode.com/comments
 */

interface CustomApiCmpProps {
  fetchConfig?: any; // 自定义API配置
  data?: any;
  className?: string;
  title?: string;
}

interface CustomApiCmpState {
  dataSource: any[];
  loading: boolean;
  error: string | null;
}

const POST_COLUMNS = [
  { title: '用户 ID', dataIndex: 'userId', key: 'userId', width: 88 },
  { title: '标题', dataIndex: 'title', key: 'title', ellipsis: true },
  { title: '正文', dataIndex: 'body', key: 'body', ellipsis: true },
];

function normalizePostsResult(result: any): { rows: any[]; errorMsg?: string } {
  if (result === null || result === undefined) {
    return { rows: [], errorMsg: '接口无返回' };
  }
  // SDK / 通用代理有时直接将第三方响应解析为数组
  if (Array.isArray(result)) {
    return { rows: result };
  }
  if (result.status === false) {
    return { rows: [], errorMsg: result.msg || '请求失败' };
  }
  const raw = result.data;
  if (Array.isArray(raw)) {
    return { rows: raw };
  }
  if (raw && Array.isArray(raw.records)) {
    return { rows: raw.records };
  }
  if (raw && Array.isArray(raw.list)) {
    return { rows: raw.list };
  }
  return { rows: [], errorMsg: '返回数据格式不是列表' };
}

export default class CustomApiCmp extends BaseCmp<
  CustomApiCmpProps,
  CustomApiCmpState
> {
  constructor(props: CustomApiCmpProps) {
    super(props);
    this.state = {
      dataSource: [],
      loading: false,
      error: null,
    };
    this.loadData = this.loadData.bind(this);
  }

  componentDidMount() {
    this.loadData();
  }

  componentDidUpdate(prevProps: CustomApiCmpProps) {
    if (!isEqual(prevProps.fetchConfig, this.props.fetchConfig)) {
      this.loadData();
    }
  }

  @NeoEvent.function
  async loadData() {
    const { fetchConfig } = this.props;
    const targetUrl = DEFAULT_POSTS_URL;

    this.setState({ loading: true, error: null });

    let result: any = {};

    try {
      // 通过自定义API获取数据
      if (fetchConfig) {
        // 根据用户配置的自定义API相关数据获取数据
        result = await customApi.run(fetchConfig);
        const { rows, errorMsg } = normalizePostsResult(result);
        if (errorMsg) {
          this.setState({ dataSource: [], loading: false, error: errorMsg });
          return;
        }
        this.setState({ dataSource: rows, loading: false, error: null });
        return;
      } else {
        result = await customApi.run({
          apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', // 平台通用接口代理
          methodType: 'POST',
          data: {
            url: targetUrl,
            method: 'GET',
            data: { test: 333 },
          },
        });
      }

      const { rows, errorMsg } = normalizePostsResult(result);
      if (errorMsg) {
        this.setState({ dataSource: [], loading: false, error: errorMsg });
        return;
      }
      this.setState({ dataSource: rows, loading: false, error: null });
    } catch (error: any) {
      this.setState({
        dataSource: [],
        loading: false,
        error: error?.message || '获取数据失败',
      });
    }
  }

  render() {
    const { dataSource, loading, error } = this.state;
    const { className, title: propsTitle } = this.props;
    const displayTitle = propsTitle || '自定义 API 示例';

    return (
      <div className={`customApi__c ${className || ''}`}>
        <div className="table-wrapper">
          <div className="panel-header">
            <div className="panel-header-text">
              <h3>{displayTitle}</h3>
            </div>
          </div>
          <div className="table-container">
            <Spin spinning={loading} tip="加载数据中...">
              {error ? (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <div>
                      <div style={{ color: '#ff4d4f', marginBottom: 8 }}>
                        {error}
                      </div>
                    </div>
                  }
                />
              ) : (
                <Table
                  columns={POST_COLUMNS}
                  dataSource={dataSource}
                  rowKey="id"
                  pagination={{
                    pageSize: 10,
                    showSizeChanger: true,
                    showTotal: (total) => `共 ${total} 条`,
                  }}
                  scroll={{ y: 'max-content' }}
                />
              )}
            </Spin>
          </div>
        </div>
      </div>
    );
  }
}

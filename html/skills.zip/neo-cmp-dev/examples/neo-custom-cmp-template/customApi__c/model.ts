/**
 * @file 自定义 API（通用代理）示例 — 编辑器描述
 */
export class CustomApiCmpModel {
  label: string = '自定义API示例';

  description: string =
    '通过通用代理请求外部数据接口，并以表格形式展示外部接口数据';

  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  targetPage: string[] = ['all'];

  targetDevice: string = 'web';

  defaultComProps = {
    title: '自定义 API 示例',
    fetchConfig: {
      apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward',
      methodType: 'POST',
      data: {
        url: 'https://jsonplaceholder.typicode.com/posts',
        method: 'GET',
        data: { test: 111 },
      },
    },
  };

  functions = [
    {
      apiKey: 'loadData',
      label: '刷新表格',
      helpTextKey: '刷新当前表格数据',
    },
  ];

  propsSchema = [
    {
      type: 'panelInput',
      name: 'title',
      label: '表格标题',
      placeholder: '请输入表格标题',
    },
    {
      type: 'customApi',
      name: 'fetchConfig',
      label: '自定义API',
      description: '请选择自定义API；Data 中 Value 可填 JSON。',
    },
  ];
}

export default CustomApiCmpModel;

# entityForm__c — 实体表单

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 演示的能力

1. **`NeoEvent.dispatch`**：声明 `onSubmit` 事件，表单提交后触发事件动作
2. **`xObjectDataApi` 配置项**：在 `propsSchema` 中使用 `xObjectDataApi` 类型
3. **`xObject.getDesc`**：获取实体字段描述以动态生成表单控件
4. **`xObject.create`**：调用平台新增接口创建实体数据
5. **`xObject.getEntityTypeList`**：获取业务类型列表供选择
6. **按字段类型动态生成表单控件**：文本/数字/日期/下拉/多选/多行文本/关联字段等
7. **关联字段选择**：通过 `EntityPickerList` 公共组件实现关联数据选择
8. **`antd Form`**：使用 antd 表单组件的验证和布局能力
9. **多列布局**：支持 1~3 列表单布局

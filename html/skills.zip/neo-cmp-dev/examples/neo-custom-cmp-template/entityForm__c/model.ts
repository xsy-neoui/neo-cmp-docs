/**
 * @file Object Form 表单组件对接编辑器的描述文件
 * @description 定义组件在 Neo 平台编辑器中的配置信息
 * @author Neo Custom Widget CLI
 * @version 1.0.0
 */
export class EntityFormModel {
  /**
   * 组件类型标识
   * 用于标识组件的唯一性，在构建时根据当前组件目录名称自动生成
   * 注意：此字段在构建时会被自动替换，不需要手动设置
   */
  // cmpType: string = 'entityForm';

  /** 组件名称，用于设置在编辑器左侧组件面板中展示的名称 */
  label: string = '实体表单';

  /** 组件描述，用于设置在编辑器左侧组件面板中展示的描述 */
  description: string = '基于 XObject 的实现的对象表单组件，可用于新增实体业务数据';

  /** 分类标签，用于设置在编辑器左侧组件面板哪个分类中展示 */
  // tags: string[] = ['自定义组件'];

  /**
   * 用于设置组件支持的页面类型
   *
   * 当前 NeoCRM 平台存在的页面类型：
   * all:	1	全页面
   * entityFormPage:	4	实体表单页
   * customPage:	6	自定义页面
   */
  targetPage: string[] = ['all'];

  /**
   * 用于设置组件支持的终端类型
   *
   * 当前 NeoCRM 平台存在的终端类型：
   * web:	网页端
   * mobile: 移动端
   */
  targetDevice: string = 'web';

  enableDuplicate: boolean = true;

  /** 组件图标，用于设置在编辑器左侧组件面板中展示的图标 */
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/custom-form.svg';

  /** 初次插入页面的默认属性数据 */
  defaultComProps = {
    formTitle: '新增数据表单',
    showResetButton: true,
    columnCount: 2,
    xObjectDataApi: {
      xObjectApiKey: 'contact',
      fields: [
        'entityType',
        'contactName',
        'accountId',
        'depart',
        'mobile',
        'email',
        'comment',
      ],
    },
  };

  /**
   * 声明当前组件会触发的所有事件
   * 备注：页面设计器端可用于进行事件绑定，在组件属性配置模式中配置事件动作
   */
  events = [
    {
      apiKey: 'onSubmit', // 事件名称
      label: '提交表单后', // 事件
      helpText: '表单提交后触发该事件', // 信息icon hover 时的提示文本
    },
  ];

  /**
   * 组件属性配置模式
   * 支持静态配置：propsSchema，优先级比 propsSchemaCreator 低
   * 定义组件在编辑器中可配置的属性
   */
  propsSchema = [
    {
      type: 'panelInput',
      name: 'formTitle',
      label: '表单标题',
      value: '新增数据表单',
      placeholder: '请输入表单标题',
    },
    {
      type: 'xObjectDataApi', // 用于获取实体业务数据列表的配置项
      name: 'xObjectDataApi',
      label: '实体数据源',
      placeholder: '请选择实体数据源',
      custom: true,
      showPage: false,
      showPageSize: false,
      showAutoFetchData: false,
    },
    {
      type: 'panelSelect',
      name: 'columnCount',
      label: '表单列数',
      value: 1,
      placeholder: '请选择表单列数',
      options: [
        {
          label: '单列',
          value: 1,
        },
        {
          label: '双列',
          value: 2,
        },
        {
          label: '三列',
          value: 3,
        },
      ],
    },
    {
      type: 'panelSwitch',
      name: 'showResetButton',
      label: '显示重置按钮',
      defaultChecked: true,
    },
  ];
}

export default EntityFormModel;

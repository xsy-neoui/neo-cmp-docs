/**
 * @file XObject 表格组件对接编辑器的描述文件
 * @description 定义组件在 Neo 平台编辑器中的配置信息
 */
export class EntityTableModel {
  /**
   * 组件类型标识
   * 用于标识组件的唯一性，在构建时根据当前组件目录名称自动生成
   * 注意：此字段在构建时会被自动替换，不需要手动设置
   */
  // cmpType: string = 'entityTable';

  /** 组件名称，用于设置在编辑器左侧组件面板中展示的名称 */
  label: string = '实体数据表格';

  /** 组件描述，用于设置在编辑器左侧组件面板中展示的描述 */
  description: string = '基于 XObject 实现的实体数据表格组件，支持实体数据的增删改查操作';

  /** 分类标签，用于设置在编辑器左侧组件面板哪个分类中展示  */
  // tags: string[] = ['自定义组件'];

  /** 组件图标，用于设置在编辑器左侧组件面板中展示的图标 */
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  /**
   * 用于设置组件支持的页面类型
   *
   * 当前 NeoCRM 平台存在的页面类型：
   * all:	1	全页面
   * entityFormPage:	4	实体表单页
   * customPage:	6	自定义页面
   */
  targetPage: string[] = ['all'];

  /**
   * 用于设置组件支持的终端类型
   *
   * 当前 NeoCRM 平台存在的终端类型：
   * web:	网页端
   * mobile: 移动端
   */
  targetDevice: string = 'web';

  /** 初次插入页面的默认属性数据 */
  defaultComProps = {
    title: '实体数据表格',
    showAddButton: true,
    showEditButton: true,
    showDeleteButton: true,
    xObjectDataApi: {
      xObjectApiKey: 'contact',
      fields: [
        'contactName',
        'accountId',
        'depart',
        'post',
        'phone',
        'email',
        'wxPosition',
        'comment',
      ],
    },
  };

  // 当前组件支持的函数列表（其他组件可触发当前组件的函数）
  functions = [
    {
      apiKey: 'loadData',
      label: '刷新表格',
      helpTextKey: '刷新当前表格数据',
    },
    {
      apiKey: 'handleDelete',
      label: '删除记录',
      helpTextKey: '删除表格中指定记录',
      funcInParams: [
        {
          apiKey: 'id',
          label: '记录ID',
          type: 'String',
          required: true,
        },
      ],
    },
  ];

  /**
   * 组件属性配置模式
   * 支持静态配置：propsSchema，优先级比 propsSchemaCreator 低
   * 定义组件在编辑器中可配置的属性
   */
  propsSchema = [
    {
      type: 'xObjectDataApi', // 用于获取实体业务数据列表的配置项
      name: 'xObjectDataApi',
      label: '实体数据源',
      value: {
        xObjectApiKey: 'customContact__c',
        fields: ['name', 'phone__c'],
      },
      placeholder: '请选择实体数据源',
      custom: true,
    },
    {
      type: 'panelSwitch',
      name: 'showAddButton',
      label: '显示新增按钮',
    },
    {
      type: 'panelSwitch',
      name: 'showEditButton',
      label: '显示编辑按钮',
    },
    {
      type: 'panelSwitch',
      name: 'showDeleteButton',
      label: '显示删除按钮',
    },
  ];
}

export default EntityTableModel;

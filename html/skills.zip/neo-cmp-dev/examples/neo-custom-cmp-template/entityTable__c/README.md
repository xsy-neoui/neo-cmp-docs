# entityTable__c — 实体数据表格

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 演示的能力

1. **`BaseCmp` 类组件**：支持事件动作的基类，所有方法 `bind(this)`
2. **`NeoEvent.function`**：暴露 `loadData` 函数供外部通过事件动作调用
3. **`xObjectDataApi` 配置项**：在 `propsSchema` 中使用 `xObjectDataApi` 类型
4. **`xObject.query`**：分页查询实体数据列表
5. **`xObject.create`**：新增实体数据
6. **`xObject.update`**：更新实体数据（PATCH）
7. **`xObject.delete`**：删除实体数据
8. **`xObject.getDesc`**：获取字段描述以动态生成表格列和表单控件
9. **`xObject.getEntityTypeList`**：获取业务类型列表
10. **`componentDidUpdate` + `isEqual`**：当实体或字段配置变化时自动重新加载
11. **`antd Table`**：使用 antd 表格展示数据，含分页、排序
12. **关联字段选择**：通过 `EntityPickerList` 公共组件实现关联数据选择
13. **编辑模态框**：Modal 内嵌 Form，支持新增和编辑两种模式
14. **`objectValueToString` 工具函数**：处理对象类型字段的展示

import * as React from 'react';
import { Spin, Empty, Button, Tag, Divider, Typography } from 'antd';
import {
  ReloadOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons';
// @ts-ignore
import { xObject } from 'neo-open-api'; // Neo OpenAPI SDK
import './style.scss';

const { Title } = Typography;

interface EntityDetailProps {
  title?: string;
  xObjectDetailApi?: {
    xObjectApiKey: string;
    objectId: string;
    fieldDescList?: any[];
    fields?: string[];
    autoFetchData?: boolean;
  };
  columnCount?: number;
  showTitle?: boolean;
  data?: any;
  entityData?: any;
  className?: string;
}

interface FieldDescription {
  apiKey: string;
  label: string;
  type: string;
  [key: string]: any;
}

interface EntityDetailState {
  detailData: any;
  fieldDescriptions: FieldDescription[];
  loading: boolean;
  error: string | null;
}

export default class EntityDetail extends React.PureComponent<
  EntityDetailProps,
  EntityDetailState
> {
  constructor(props: EntityDetailProps) {
    super(props);

    this.state = {
      detailData: {},
      fieldDescriptions: [],
      loading: false,
      error: null,
    };

    this.loadEntityDetail = this.loadEntityDetail.bind(this);
    this.loadFieldDescriptions = this.loadFieldDescriptions.bind(this);
  }

  componentDidMount() {
    this.loadData();
  }

  componentDidUpdate(prevProps: EntityDetailProps) {
    const { xObjectDetailApi } = this.props;
    if (
      xObjectDetailApi?.xObjectApiKey !==
        prevProps.xObjectDetailApi?.xObjectApiKey ||
      xObjectDetailApi?.objectId !== prevProps.xObjectDetailApi?.objectId
    ) {
      this.loadData();
    }
  }

  async loadData() {
    const { xObjectDetailApi } = this.props;
    if (!xObjectDetailApi?.xObjectApiKey || !xObjectDetailApi?.objectId) {
      this.setState({
        error: '缺少必要参数：实体类型或业务数据ID',
        loading: false,
      });
      return;
    }

    await Promise.all([this.loadFieldDescriptions(), this.loadEntityDetail()]);
  }

  async loadFieldDescriptions() {
    const xObjectDetailApi: any = this.props.xObjectDetailApi || {};
    const { autoFetchData } = xObjectDetailApi;

    if (autoFetchData) {
      // 方式一：直接从 props.xObjectDetailApi 中获取字段描述（当开启「自动获取数据」时可用）
      if (xObjectDetailApi && xObjectDetailApi.fieldDescList) {
        this.setState({ fieldDescriptions: xObjectDetailApi.fieldDescList });
      }
    } else {
      // 方式二：自行通过 OpenAPI SDK 获取字段描述
      if (!xObjectDetailApi.xObjectApiKey) return;
      const result = await xObject.getDesc(xObjectDetailApi.xObjectApiKey);
      if (result?.status) {
        const fields = result.data?.fields || [];
        this.setState({ fieldDescriptions: fields });
      }
    }
  }

  async loadEntityDetail() {
    const xObjectDetailApi: any = this.props.xObjectDetailApi || {};
    if (!xObjectDetailApi.xObjectApiKey || !xObjectDetailApi.objectId) return;
    const { autoFetchData } = xObjectDetailApi;

    if (autoFetchData) {
      // 方式一：直接从 props 中取实体数据源相关数据
      const { entityData: detailData } = this.props;
      if (detailData) {
        this.setState({ detailData });
      }
    } else {
      // 方式二：使用 Neo Open API SDK 获取详情数据
      this.setState({ loading: true, error: null });

      const result = await xObject.get(xObjectDetailApi);

      if (result?.status) {
        const data = result.data || {};
        this.setState({
          detailData: data,
          loading: false,
        });
      } else {
        this.setState({
          error: result?.msg || '获取详情数据失败',
          loading: false,
        });
      }
    }
  }

  getFieldLabel(apiKey: string): string {
    const { fieldDescriptions } = this.state;
    const field = fieldDescriptions.find((f) => f.apiKey === apiKey);
    return field?.label || apiKey;
  }

  getFieldType(apiKey: string): string {
    const { fieldDescriptions } = this.state;
    const field = fieldDescriptions.find((f) => f.apiKey === apiKey);
    return field?.type || 'text';
  }

  renderFieldValue(value: any, fieldType: string) {
    if (value === null || value === undefined || value === '') {
      return <span className="info-value-empty">-</span>;
    }

    // 根据字段类型渲染不同的值
    switch (fieldType) {
      case 'boolean':
        return value ? (
          <Tag icon={<CheckCircleOutlined />} color="success">
            是
          </Tag>
        ) : (
          <Tag icon={<CloseCircleOutlined />} color="default">
            否
          </Tag>
        );
      case 'date':
      case 'datetime':
        return new Date(value).toLocaleString('zh-CN');
      case 'number':
      case 'currency':
      case 'percent':
        return typeof value === 'number'
          ? value.toLocaleString('zh-CN')
          : value;
      case 'url':
        return (
          <a href={value} target="_blank" rel="noopener noreferrer">
            {value}
          </a>
        );
      case 'email':
        return <a href={`mailto:${value}`}>{value}</a>;
      case 'phone':
        return <a href={`tel:${value}`}>{value}</a>;
      default:
        return String(value);
    }
  }

  renderDetailContent() {
    const { detailData } = this.state;
    const { columnCount = 3, xObjectDetailApi } = this.props;

    if (!detailData || Object.keys(detailData).length === 0) {
      return (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="暂无详情数据"
        />
      );
    }

    // 根据 xObjectDetailApi.fields 过滤字段，如果指定了 fields 则只显示这些字段
    let displayFields: string[] = [];

    if (xObjectDetailApi?.fields && xObjectDetailApi.fields.length > 0) {
      // 方式一：如果指定了 fields，则只显示这些字段（即使值为 undefined 也显示）
      displayFields = xObjectDetailApi.fields.filter(
        (key) => !key.startsWith('_'), // 过滤系统字段
      );
    } else {
      // 方式二：如果没有指定 fields，则显示所有非系统字段和空字段
      displayFields = Object.keys(detailData).filter(
        (key) =>
          // 可以根据需要自定义过滤规则
          !key.startsWith('_') && detailData[key] !== undefined,
      );
    }

    // 将字段分成多组，每组对应一列
    const fieldsPerColumn = Math.ceil(displayFields.length / columnCount);
    const columnGroups: string[][] = [];

    for (let i = 0; i < columnCount; i++) {
      const start = i * fieldsPerColumn;
      const end = start + fieldsPerColumn;
      columnGroups.push(displayFields.slice(start, end));
    }

    return (
      <div className="detail-info-body">
        <div className="info-grid">
          {columnGroups.map((fields, colIndex) => (
            <div key={colIndex} className="info-column">
              {fields.map((fieldKey) => {
                const fieldType = this.getFieldType(fieldKey);
                const fieldLabel = this.getFieldLabel(fieldKey);
                const fieldValue = detailData[fieldKey];

                return (
                  <div key={fieldKey} className="info-item">
                    <div className="info-label">{fieldLabel}</div>
                    <div className="info-value">
                      {this.renderFieldValue(fieldValue, fieldType)}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  }

  render() {
    const { title, showTitle = true, className } = this.props;
    const { loading, error } = this.state;
    const curAmisData = this.props.data || {};
    const systemInfo = curAmisData.__NeoSystemInfo || {};
    console.log('this.props：', this.props);

    return (
      <div className={['entityDetail__c', className].filter(Boolean).join(' ')}>
        {showTitle && (
          <div className="detail-header">
            <div className="header-content">
              <Title level={4} className="header-title">
                {title || '实体详情数据'}
              </Title>
              <Button
                type="primary"
                icon={<ReloadOutlined />}
                onClick={this.loadEntityDetail}
                loading={loading}
                className="refresh-button"
                size="small"
              >
                刷新
              </Button>
            </div>
            <Divider style={{ margin: '12px 0' }} />
          </div>
        )}

        <div className="detail-content">
          <Spin spinning={loading} tip="加载详情数据中...">
            {error ? (
              <div className="error-container">
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <div>
                      <div style={{ color: '#ff4d4f', marginBottom: 8 }}>
                        {error}
                      </div>
                      <Button type="primary" onClick={this.loadEntityDetail}>
                        重新加载
                      </Button>
                    </div>
                  }
                />
              </div>
            ) : (
              this.renderDetailContent()
            )}
          </Spin>
        </div>
      </div>
    );
  }
}

/**
 * @file 实体数据详情组件对接编辑器的描述文件
 * @description 定义组件在 Neo 平台编辑器中的配置信息
 */
export class EntityDetailModel {
  /**
   * 组件类型标识
   * 用于标识组件的唯一性，在构建时根据当前组件目录名称自动生成
   * 注意：此字段在构建时会被自动替换，不需要手动设置
   */
  // cmpType: string = 'entityDetail';

  /** 组件名称，用于设置在编辑器左侧组件面板中展示的名称 */
  label: string = '实体数据详情';

  /** 组件描述，用于设置在编辑器左侧组件面板中展示的描述 */
  description: string = '实体详情信息展示，支持多列布局';

  /** 分类标签，用于设置在编辑器左侧组件面板哪个分类中展示  */
  // tags: string[] = ['自定义组件'];

  /**
   * 用于设置组件支持的页面类型
   *
   * 当前 NeoCRM 平台存在的页面类型：
   * all:	1	全页面
   * entityFormPage:	4	实体表单页
   * customPage:	6	自定义页面
   */
  // targetPage: string[] = ['all'];

  /**
   * 用于设置组件支持的终端类型
   *
   * 当前 NeoCRM 平台存在的终端类型：
   * web:	网页端
   * mobile: 移动端
   */
  targetDevice: string = 'web';

  /** 组件图标，用于设置在编辑器左侧组件面板中展示的图标 */
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/detail.svg';

  /** 初次插入页面的默认属性数据 */
  defaultComProps = {
    title: '实体数据详情',
    xObjectDetailApi: {
      xObjectApiKey: 'account',
      objectId: '',
    },
    columnCount: 3,
    showTitle: true,
  };

  /**
   * 组件属性配置模式
   * 定义组件在编辑器中可配置的属性
   */
  propsSchema = [
    {
      type: 'panelInput',
      name: 'title',
      label: '标题',
      value: '实体数据详情',
      placeholder: '请输入标题',
    },
    {
      type: 'panelSwitch',
      name: 'showTitle',
      label: '显示标题栏',
      value: true,
    },
    {
      type: 'xObjectDetailApi', // 用于选取对象业务详情数据的配置项
      name: 'xObjectDetailApi',
      label: '业务详情数据',
      showPage: false,
      showPageSize: false,
    },
    {
      type: 'panelSelect',
      name: 'columnCount',
      label: '列数',
      value: 3,
      options: [
        {
          label: '1列',
          value: 1,
        },
        {
          label: '2列',
          value: 2,
        },
        {
          label: '3列',
          value: 3,
        },
        {
          label: '4列',
          value: 4,
        },
      ],
    },
  ];
}

export default EntityDetailModel;

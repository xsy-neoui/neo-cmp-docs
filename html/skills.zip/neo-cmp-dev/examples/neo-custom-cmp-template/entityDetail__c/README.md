# entityDetail__c — 实体数据详情

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 演示的能力

1. **`xObjectDetailApi` 配置项**：在 `propsSchema` 中使用 `xObjectDetailApi` 类型让业务方选择实体详情数据源
2. **`xObject.getDesc`**：获取实体字段描述以展示中文标签和类型渲染
3. **`xObject.get`**：获取单条实体详情数据
4. **按字段类型渲染**：布尔/日期/数字/URL/邮箱/电话等类型有不同的展示方式
5. **多列布局**：支持 1~4 列网格布局展示详情字段
6. **`componentDidUpdate`**：当实体或对象 ID 变化时自动重新加载
7. **`props.data.__NeoSystemInfo`**：读取运行时系统信息

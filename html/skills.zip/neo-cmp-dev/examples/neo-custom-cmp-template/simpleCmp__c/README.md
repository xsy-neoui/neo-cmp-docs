# simpleCmp__c — 简单示例组件

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 演示的能力

1. **最小化类组件**：`React.PureComponent` + TypeScript 接口定义
2. **运行时上下文**：通过 `props.env.ctx` 获取系统语言并做国际化展示
3. **`className` 合并**：将 `props.className` 合并到根节点（设计器"是否显示"功能依赖）
4. **基本 `propsSchema`**：使用 `textarea` 类型配置描述文本
5. **样式隔离**：根类名 `simpleCmp__c` 与目录名一致

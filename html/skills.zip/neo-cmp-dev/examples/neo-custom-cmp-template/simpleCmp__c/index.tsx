import * as React from 'react';
// 引入 neo-ui-common / BaseCmp
// @ts-ignore
// import { BaseCmp } from 'neo-ui-common';

import './style.scss'; // 组件内容样式

interface CustomCmpProps {
  description: string;
  data?: any;
  env?: any;
  className?: string;
}

interface CustomCmpStates {
  [key: string]: any;
}

export default class CustomCmp extends React.PureComponent<
  CustomCmpProps,
  CustomCmpStates
> {
  constructor(props: CustomCmpProps) {
    super(props);
  }

  render() {
    const { description, className, env, ...restProps } = this.props;
    const ctx = (env || {}).ctx;
    let languageCode = 'zh-CN'; // 默认中文
    // 从上下文中 获取系统语言
    if (ctx && ctx.system && ctx.system.language) {
      languageCode = ctx.system.language;
    }
    console.log('当前自定义组件：', this.props);

    return (
      <div className={['simpleCmp__c', className].filter(Boolean).join(' ')}>
        <div className="news-title">
          {languageCode === 'zh-CN' ? '你好，销售易！' : 'Hello NeoCRM!'}
        </div>
        <p>{description}</p>
      </div>
    );
  }
}

/**
 * @file 自定义组件对接编辑器的描述文件
 */
export class CmpModel {
  // 组件名称，用于设置在编辑器左侧组件面板中展示的名称
  label: string = '简单示例组件';

  // 组件描述，用于设置在编辑器左侧组件面板中展示的描述
  description: string = '简单示例组件';

  // 分类标签，用于设置在编辑器左侧组件面板哪个分类中展示
  // tags: string[] = ['自定义组件'];

  /**
   * 用于设置组件支持的页面类型
   *
   * 当前 NeoCRM 平台存在的页面类型：
   * all:	1	全页面
   * entityFormPage:	4	实体表单页
   * customPage:	6	自定义页面
   */
  targetPage: string[] = ['all'];

  /**
   * 用于设置组件支持的终端类型
   *
   * 当前 NeoCRM 平台存在的终端类型：
   * web:	网页端
   * mobile: 移动端
   */
  targetDevice: string = 'web';

  // 组件图标，用于设置在编辑器左侧组件面板中展示的图标
  iconUrl: string = 'https://neo-widgets.bj.bcebos.com/custom-widget.svg';

  // 初次插入页面的默认属性数据
  defaultComProps = {
    description:
      '营销服全场景智能CRM，帮助企业搭建数字化客户经营平台，实现业绩高质量增长。',
  };

  /**
   * 组件面板配置，用于生成编辑器右侧属性配置面板内容
   */
  propsSchema = [
    {
      type: 'textarea',
      name: 'description',
      label: '组件内容',
      value: '',
    },
  ];
}

export default CmpModel;

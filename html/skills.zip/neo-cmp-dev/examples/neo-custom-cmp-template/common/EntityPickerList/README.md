# common/EntityPickerList — 关联字段选择器

**来源模板**：`neo-custom-cmp-template`（`neo init -t neo`）

## 用途

基于平台 `NeoEntityGrid`（PC 端大列表组件）的 Picker 模式实现的关联字段选择器，用于在 `entityForm__c` 和 `entityTable__c` 中选择关联实体数据。

## 演示的能力

1. **平台预置组件 `NeoEntityGrid`**：以 `pattern="pickView"` 模式使用平台列表组件
2. **`render` 透传**：`NeoEntityGrid` 必须通过 `render` props 透传平台注入的渲染函数
3. **跨组件复用**：作为 `src/common/` 下的公共子组件被多个业务组件引用
4. **Picker 选择模式**：支持单选/多选，选中后回填表单

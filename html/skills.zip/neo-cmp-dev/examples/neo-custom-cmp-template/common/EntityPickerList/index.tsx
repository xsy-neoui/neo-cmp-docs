import * as React from 'react';
import './style.scss';
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

export interface EntityPickerListReferData {
  referObjectApiKey: string;
  referItemApiKey: string;
}

export interface EntityPickerListProps {
  /** 列表实体 objectApiKey，默认 account */
  objectApiKey?: string;
  className?: string;
  /** Picker 关联上下文，未传时使用内置默认关联，业务侧应传入真实外键 */
  referData?: EntityPickerListReferData;
  /** 单选 / 多选，默认 single */
  selectionMode?: 'single' | 'multiple' | string;
  /** 选中行后是否关闭弹层，默认 true */
  shouldCloseDialog?: boolean;
  /** NeoEntityGrid 必填 render */
  render: (name: string, schema: any) => React.ReactNode;
  /** 行选中回调 */
  onRowSelected?: (data: any[], event: any) => void;
  onSelectedCall?: (...args: any[]) => void;
  onCancel?: (...args: any[]) => void;
  hiddenHeader?: boolean;
  disableSearch?: boolean;
  canCreate?: boolean;
  withOrder?: boolean;
  withCheck?: boolean;
  disablePagination?: boolean;
  paginationPageSize?: number;
  autoHeight?: boolean;
  height?: string;
  /** 多选时底部相关展示，默认 3 */
  selectedCount?: number;
  [key: string]: any;
}

const defaultReferData: EntityPickerListReferData = {
  referObjectApiKey: 'opportunity',
  referItemApiKey: 'accountId',
};

/**
 * 基于 NeoEntityGrid 的 Picker 列表（pickView），供多个业务组件复用，不作为独立设计器组件注册。
 */
export default class EntityPickerList extends React.PureComponent<EntityPickerListProps> {
  render() {
    const { className = '', onRowSelected, referData, objectApiKey, ...neoRest } = this.props;
    const mergedRefer = referData ?? defaultReferData;

    return (
      <div className={`entity-picker-list ${className}`.trim()}>
        <NeoEntityGrid
          {...neoRest}
          objectApiKey={objectApiKey || 'account'}
          pattern="pickView"
          referData={mergedRefer}
          selectionMode={neoRest.selectionMode ?? 'single'}
          shouldCloseDialog={neoRest.shouldCloseDialog ?? true}
          onRowSelected={(data: any[], event: any) => onRowSelected?.(data, event)}
          hiddenHeader={neoRest.hiddenHeader ?? false}
          disableSearch={neoRest.disableSearch ?? false}
          canCreate={neoRest.canCreate ?? true}
          withOrder={neoRest.withOrder ?? true}
          withCheck={neoRest.withCheck ?? true}
          disablePagination={neoRest.disablePagination ?? false}
          paginationPageSize={neoRest.paginationPageSize ?? 20}
          autoHeight={neoRest.autoHeight ?? false}
          height={neoRest.height ?? '500px'}
          selectedCount={neoRest.selectedCount ?? 3}
        />
      </div>
    );
  }
}

# entityGrid__c — 基础大列表

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **平台预置组件 `NeoEntityGrid`**：使用 `pattern="entityView"` 模式展示平台实体列表
2. **`xObjectEntityList` 配置项**：让业务方在设计器中选择实体对象
3. **`dataViewIdSelect` 配置项**：让业务方选择列表视图
4. **丰富的功能开关**：通过 `propsSchema` 中的 `panelSwitch` 控制头部/搜索/视图切换/工具栏/新建/导入/导出/序号/多选/单元格编辑/分页等功能的显隐
5. **自定义工具栏插槽**：`customToolbarButtons` 支持头部和底部扩展自定义按钮
6. **`customRender` 自定义渲染**：工具栏中的「同步状态」指示器使用 `customRender` 渲染自定义 UI
7. **`render` 透传**：必传 `render={this.props.render}` 给 `NeoEntityGrid`
8. **空态自定义**：通过 `customEmptyMsg` 配置空数据提示文案

/**
 * @file 自定义组件对接编辑器的描述文件
 */
export class NeoEntityGridModel {
  /**
   * cmpType 为自定义组件名称，用于标识组件的唯一性
   * 在构建时根据当前组件目录名称自动生成
   */
  // cmpType: string = 'entityList__c';

  // 组件名称，用于设置在编辑器左侧组件面板中展示的名称
  label: string = '基础大列表';

  // 组件描述，用于设置在编辑器左侧组件面板中展示的描述
  description: string =
    '基于平台 NeoEntityGrid 实现的数据列表: 支持 视图切换、搜索、新增、导出、分页等显隐控制，支持自定义工具栏和空占位等配置';

  // 分类标签，用于设置在编辑器左侧组件面板哪个分类中展示
  // tags: string[] = ['自定义组件'];

  /**
   * 用于设置组件支持的页面类型
   *
   * 当前 NeoCRM 平台存在的页面类型：
   * all:	1	全页面
   * entityFormPage:	4	实体表单页
   * customPage:	6	自定义页面
   */
  // targetPage: string[] = ['all'];

  /**
   * 用于设置组件支持的终端类型
   *
   * 当前 NeoCRM 平台存在的终端类型：
   * web:	网页端
   * mobile: 移动端
   */
  targetDevice: string = 'web';

  // 组件图标，用于设置在编辑器左侧组件面板中展示的图标
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  // 初次插入页面的默认属性数据
  defaultComProps = {
    objectApiKey: 'account',
    funPermission: true,
    hiddenHeader: false,
    showView: true,
    enableChangeView: true,
    enableToolbar: true,
    canCreate: true,
    canImport: true,
    withOrder: true,
    withCheck: true,
    editable: true,
    disableSearch: false,
    disableExport: false,
    disablePagination: false,
    paginationPageSize: 20,
    autoHeight: false,
    height: '500px',
  };

  /**
   * 组件面板配置，用于生成编辑器右侧属性配置面板内容
   */
  propsSchema = [
    {
      type: 'xObjectEntityList',
      name: 'objectApiKey',
      label: '实体对象',
    },
    {
      type: 'dataViewIdSelect',
      name: 'defaultViewId',
      xObjectApiKey: 'objectApiKey',
      label: '列表视图',
    },
    {
      type: 'panelSwitch',
      name: 'hiddenHeader',
      label: '隐藏头部',
      defaultChecked: false,
    },
    {
      type: 'panelSwitch',
      name: 'disableSearch',
      label: '禁用搜索',
      defaultChecked: false,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'showView',
      label: '显示列表视图控制栏',
      defaultChecked: true,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'enableChangeView',
      label: '支持列表视图切换',
      defaultChecked: true,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'enableToolbar',
      label: '显示工具栏（含刷新、导出等）',
      defaultChecked: true,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'canCreate',
      label: '支持新建',
      defaultChecked: true,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'canImport',
      label: '支持导入',
      defaultChecked: false,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'disableExport',
      label: '禁用导出',
      defaultChecked: false,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'withOrder',
      label: '显示序号列',
      defaultChecked: true,
    },
    {
      type: 'panelSwitch',
      name: 'withCheck',
      label: '显示多选列',
      defaultChecked: true,
    },
    {
      type: 'panelSwitch',
      name: 'editable',
      label: '支持单元格编辑',
      defaultChecked: true,
    },
    {
      type: 'panelSwitch',
      name: 'disablePagination',
      label: '是否禁用分页',
      defaultChecked: false,
    },
    {
      type: 'panelNumber',
      name: 'paginationPageSize',
      label: '每页展示条数',
      visibleOn: '!disablePagination',
      value: 20,
    },
    {
      type: 'panelSwitch',
      name: 'autoHeight',
      label: '高度自适应（根据父容器高度自动适配）',
      defaultChecked: false,
    },
    {
      type: 'panelInput',
      name: 'height',
      label: '高度',
      visibleOn: '!autoHeight',
    },
  ];
}

export default NeoEntityGridModel;

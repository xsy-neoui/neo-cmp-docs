import * as React from 'react';
import './style.scss'; // 组件内容样式
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

interface NeoEntityGridProps {
  objectApiKey: string;
  disableSearch?: boolean;
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
  [key: string]: any;
}

export default class NeoEntityGridCmp extends React.PureComponent<NeoEntityGridProps> {
  constructor(props: NeoEntityGridProps) {
    super(props);
  }

  render() {
    const {
      className,
      objectApiKey,
      pattern,
      hiddenHeader,
      showView,
      enableChangeView,
      defaultViewId,
      disableSearch,
      canCreate,
      canImport,
      editable,
      withOrder,
      withCheck,
      enableToolbar,
      disableExport,
      disablePagination,
      paginationPageSize,
      autoHeight,
      height,
      additionalConditions,
      onRecordChange,
      ...restProps
    } = this.props;
    console.log('entityGrid__c: ', this.props, this);

    return (
      <div className={`entityGrid__c ${className}`}>
        <NeoEntityGrid
          render={this.props.render}
          objectApiKey={objectApiKey || 'account'}
          pattern={'entityView'}
          // defaultViewId="default_view"
          hiddenHeader={hiddenHeader ?? false}
          showView={showView ?? true}
          enableChangeView={enableChangeView ?? true}
          defaultViewId={defaultViewId ?? 'default_view'}
          disableSearch={disableSearch ?? false}
          canCreate={canCreate ?? true}
          canImport={canImport ?? true}
          editable={editable ?? true}
          withOrder={withOrder ?? true}
          withCheck={withCheck ?? true}
          enableToolbar={enableToolbar ?? true}
          disableExport={disableExport ?? false}
          disablePagination={disablePagination ?? false}
          paginationPageSize={paginationPageSize ?? 20}
          autoHeight={autoHeight ?? false}
          height={height ?? '500px'}
          customEmptyMsg="暂无数据，请点击「新建」按钮创建"
        />
      </div>
    );
  }
}

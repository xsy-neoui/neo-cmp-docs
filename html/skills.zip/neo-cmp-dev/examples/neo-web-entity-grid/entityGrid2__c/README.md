# entityGrid2__c — 自定义筛选列表

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **`BaseCmp` + `NeoEvent.function`**：暴露 `handleCustomSearchEvent` 函数供外部组件调用
2. **`NeoEvent.listen` 广播监听**：在 `componentDidMount` 中监听 `customSearchEvent` 广播事件
3. **`additionalConditions` 动态筛选**：接收筛选条件并传给 `NeoEntityGrid` 实现列表联动
4. **`xObjectEntityList` + `dataViewIdSelect`**：与 `entityGrid__c` 一致的数据源配置
5. **`xObjectApiKey` 校验**：接收条件时校验 `xObjectApiKey` 是否匹配，避免跨实体误筛

import * as React from 'react';
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';
// 引入 neo-ui-common / BaseCmp
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';
import './style.scss';

/** 与 NeoEntityGrid additionalConditions、searchForm customSearchEvent 约定一致 */
export interface AdditionalConditionItem {
  apiKey: string;
  type: number;
  value: unknown;
  item?: number;
  [key: string]: unknown;
}

interface NeoEntityGridProps {
  objectApiKey: string;
  disableSearch?: boolean;
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
  additionalConditions?: AdditionalConditionItem[];
  [key: string]: any;
}

interface NeoEntityGridCmpState {
  additionalConditions: AdditionalConditionItem[];
}

export default class NeoEntityGridCmp extends BaseCmp<
  NeoEntityGridProps,
  NeoEntityGridCmpState
> {
  constructor(props: NeoEntityGridProps) {
    super(props);
    this.state = {
      additionalConditions: props.additionalConditions ?? [],
    };
    this.handleCustomSearchEvent = this.handleCustomSearchEvent.bind(this);
  }

  componentDidMount() {
    try {
      // 监听 customSearchEvent 广播事件
      NeoEvent.listen('customSearchEvent', this.handleCustomSearchEvent);
    } catch {
      console.error(' NeoEvent.listen / 广播事件 不可用。');
    }
  }

  /**
   * 接收 searchForm 等组件发出的 customSearchEvent（payload 含 xObjectApiKey、conditions）
   */
  @NeoEvent.function
  handleCustomSearchEvent(eventData: any) {
    console.log('设置自定义筛选条件: ', eventData, this.props);

    if (!eventData) {
      this.setState({ additionalConditions: [] });
      return;
    }
    if (Array.isArray(eventData)) {
      this.setState({
        additionalConditions: eventData as AdditionalConditionItem[],
      });
      return;
    }
    const payload = eventData as {
      xObjectApiKey?: string;
      conditions?: AdditionalConditionItem[];
    };
    const { xObjectApiKey, conditions } = payload;
    const gridKey = this.props.objectApiKey;
    if (xObjectApiKey && gridKey && xObjectApiKey !== gridKey) {
      return;
    }
    this.setState({
      additionalConditions: Array.isArray(conditions) ? conditions : [],
    });
  }

  render() {
    const {
      className,
      objectApiKey,
      hiddenHeader,
      showView,
      enableChangeView,
      defaultViewId,
      disableSearch,
      canCreate,
      canImport,
      editable,
      withOrder,
      withCheck,
      enableToolbar,
      disableExport,
      disablePagination,
      paginationPageSize,
      autoHeight,
      height,
      ...restProps
    } = this.props;

    return (
      <div className={`entityGrid2__c ${className}`}>
        <NeoEntityGrid
          render={this.props.render}
          objectApiKey={objectApiKey || 'account'}
          pattern={'entityView'}
          hiddenHeader={hiddenHeader ?? false}
          showView={showView ?? true}
          enableChangeView={enableChangeView ?? true}
          defaultViewId={defaultViewId ?? 'default_view'}
          disableSearch={disableSearch ?? false}
          canCreate={canCreate ?? true}
          canImport={canImport ?? true}
          editable={editable ?? true}
          withOrder={withOrder ?? true}
          withCheck={withCheck ?? true}
          enableToolbar={enableToolbar ?? true}
          disableExport={disableExport ?? false}
          disablePagination={disablePagination ?? false}
          paginationPageSize={paginationPageSize ?? 20}
          autoHeight={autoHeight ?? false}
          height={height ?? '500px'}
          customEmptyMsg="暂无数据，请点击「新建」按钮创建"
          additionalConditions={this.state.additionalConditions}
        />
      </div>
    );
  }
}

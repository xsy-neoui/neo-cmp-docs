# searchForm__c — 自定义查询表单

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **`NeoEvent.dispatch`**：声明 `onQuery` 事件，携带 `{ xObjectApiKey, conditions }` 条件数据
2. **`xObjectDataApi` 配置项**：在 `propsSchema` 中使用 `xObjectDataApi` 类型
3. **查询条件映射**：按字段类型自动选择查询运算符（等于 1 / 包含 3）
4. **值归一化**：日期时间转时间戳、多选用逗号拼接、空值过滤
5. **关联字段选择**：Modal 内嵌 `entityGrid3__c`（Picker 列表）实现关联字段筛选
6. **配合 `entityGrid2__c` 使用**：查询表单与自定义筛选列表联动
7. **动态表单控件**：按字段类型渲染不同的 antd 控件
8. **表单事件参数**：`events[].eventParams` 定义事件携带的数据结构

## 跨组件依赖

`searchForm__c` 的关联字段选择弹窗中嵌入了 `entityGrid3__c`（Picker 列表）作为子组件。代码中使用 `import NeoEntityGrid from 'entityGrid3__c'` 直接引用。

**`neo.config.js` 中必须配置远程依赖**，否则运行时无法加载 `entityGrid3__c`：

```js
// neo.config.js
module.exports = {
  neoCommonModule: {
    remoteDeps: ['entityGrid3__c'], // 远程依赖组件（按 cmpType 填写）
    externals: ['entityGrid3__c'],  // 构建时剔除，运行时从远程加载
  },
  // ... 其他配置
};
```

详见 `references/module-sharing.md`「消费方（组件 B）：`remoteDeps` + `externals`」章节。

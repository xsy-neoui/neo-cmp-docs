/**
 * @file SearchForm 自定义查询表单组件
 * @description 基于 Neo 平台的 XObject 字段元数据渲染筛选表单，点击查询输出 conditions
 */
import * as React from 'react';
import {
  Form, Input, Select, Button, message, DatePicker, InputNumber, Spin, Empty, Row, Col, Modal,
} from 'antd';
import { SearchOutlined, ReloadOutlined } from '@ant-design/icons';
// @ts-ignore
import { xObject } from 'neo-open-api';
// @ts-ignore
import isEqual from 'lodash/isEqual';
// @ts-ignore
import { NeoEvent } from 'neo-ui-common';
// @ts-ignore
import NeoEntityGrid from 'entityGrid3__c';
import './style.scss';

const { Option } = Select;

export interface CustomQueryCondition { apiKey: string; type: 1 | 3; value: unknown; }
export interface CustomQueryPayload { xObjectApiKey: string; conditions: CustomQueryCondition[]; data?: Object; }

interface SearchFormProps {
  xObjectDataApi: { xObjectApiKey: string; fields?: string[]; fieldDescList?: any[] };
  data?: any; formTitle?: string; showResetButton?: boolean; columnCount?: 1 | 2;
  onSuccess?: (data: CustomQueryPayload) => void; className?: string;
  render?: (name: string, schema: any) => React.ReactNode;
}

interface FieldInfo {
  name: string; label: string; apiKey: string; type: string; itemType: string;
  checkitem: any[]; selectitem?: any[]; required: boolean;
  referTo?: { apiKey: string; [key: string]: any };
}

interface SearchFormState {
  title?: string; fieldList: FieldInfo[]; loading: boolean; submitting: boolean; error: string | null;
  form: any; entityTypeList: any[]; referModalVisible: boolean;
  currentReferField: FieldInfo | null; referSelectedLabels: Record<string, string>;
}

export default class SearchForm extends React.PureComponent<SearchFormProps, SearchFormState> {
  constructor(props: SearchFormProps) {
    super(props);
    this.state = {
      fieldList: [], loading: false, submitting: false, error: null, form: null,
      entityTypeList: [], referModalVisible: false, currentReferField: null, referSelectedLabels: {},
    };
    this.loadFieldList = this.loadFieldList.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleReset = this.handleReset.bind(this);
    this.openReferModal = this.openReferModal.bind(this);
    this.closeReferModal = this.closeReferModal.bind(this);
  }

  componentDidMount() {
    const key = this.props.xObjectDataApi?.xObjectApiKey;
    if (key) { this.getEntityTypeList(key); this.loadFieldList(); }
  }

  async componentDidUpdate(prevProps: SearchFormProps) {
    const cur = this.props.xObjectDataApi || {};
    const pre = prevProps.xObjectDataApi || {};
    if (cur.xObjectApiKey !== pre.xObjectApiKey || !isEqual(cur.fields, pre.fields)) {
      if (cur.xObjectApiKey) { await this.loadFieldList(); await this.getEntityTypeList(cur.xObjectApiKey); }
      else { this.setState({ fieldList: [], error: null }); }
    }
  }

  async getEntityTypeList(key?: string) {
    const k = key || this.props.xObjectDataApi?.xObjectApiKey;
    try { const r = await xObject.getEntityTypeList(k); if (r?.status) this.setState({ entityTypeList: r.data || [] }); }
    catch (e) { console.error('获取业务类型列表失败:', e); }
  }

  async loadFieldList() {
    const { xObjectDataApi } = this.props;
    this.setState({ loading: true, error: null });
    try {
      if (xObjectDataApi?.fieldDescList) { this.setState({ fieldList: xObjectDataApi.fieldDescList, loading: false }); }
      else if (xObjectDataApi?.xObjectApiKey) {
        const r = await xObject.getDesc(xObjectDataApi.xObjectApiKey);
        if (r?.status) { this.setState({ fieldList: r.data?.fields || [], title: r.data?.label, loading: false }); }
        else { this.setState({ error: '获取字段列表失败', loading: false }); }
      } else { this.setState({ loading: false }); }
    } catch (e) { message.error('获取字段列表失败'); this.setState({ error: '获取字段列表失败', loading: false }); }
  }

  private static getConditionType(fieldType: string): 1 | 3 {
    return ['entityType', 'entitytype', 'picklist', 'multipicklist', 'date', 'datetime', 'time'].has(fieldType) ? 1 : 3;
  }

  private normalizeQueryValue(field: FieldInfo, raw: unknown): unknown {
    if (raw == null) return raw;
    if (Array.isArray(raw)) return raw.length ? raw.join(',') : raw;
    const t = field.type;
    if (['date', 'datetime', 'time'].includes(t) && raw !== '' && typeof raw === 'object' && typeof (raw as any).valueOf === 'function') return (raw as any).valueOf();
    if (['date', 'datetime', 'time'].includes(t) && raw !== '' && typeof raw !== 'number') { const n = new Date(raw as string).getTime(); return isNaN(n) ? raw : n; }
    return raw;
  }

  private isEmptyQueryValue(v: unknown): boolean { return v == null || v === '' || (Array.isArray(v) && v.length === 0); }

  @NeoEvent.dispatch
  onQuery(searchData?: CustomQueryPayload) {}

  handleSubmit() {
    const form = this.state.form;
    if (!form) return;
    const { xObjectApiKey } = this.props.xObjectDataApi || {};
    if (!xObjectApiKey) { message.error('请先选择要操作的对象'); return; }
    this.setState({ submitting: true });
    form.validateFields().then((values: Record<string, unknown>) => {
      const conditions: CustomQueryCondition[] = [];
      Object.keys(values).forEach((apiKey) => {
        const field = this.state.fieldList.find((f) => f.apiKey === apiKey);
        if (!field) return;
        const raw = values[apiKey];
        if (this.isEmptyQueryValue(raw)) return;
        const value = this.normalizeQueryValue(field, raw);
        if (this.isEmptyQueryValue(value)) return;
        const isRefer = field.referTo && field.type !== 'entityType' && field.type !== 'entitytype';
        conditions.push({ apiKey, type: isRefer ? 1 : SearchForm.getConditionType(field.type), value });
      });
      const payload: CustomQueryPayload = { xObjectApiKey, conditions, data: { xObjectApiKey, conditions } };
      this.onQuery(payload);
      this.props.onSuccess?.(payload);
    }).catch(() => {}).finally(() => this.setState({ submitting: false }));
  }

  handleReset() { this.state.form?.resetFields(); this.setState({ referSelectedLabels: {} }); message.info('表单已重置'); }
  openReferModal(f: FieldInfo) { this.setState({ referModalVisible: true, currentReferField: f }); }
  closeReferModal() { this.setState({ referModalVisible: false, currentReferField: null }); return false; }

  renderForm() {
    const { fieldList, entityTypeList, referModalVisible, currentReferField, referSelectedLabels } = this.state;
    const { xObjectDataApi } = this.props;
    const { xObjectApiKey, fields } = xObjectDataApi || {};
    const { columnCount = 1 } = this.props;
    let curFieldList = fieldList;
    if (fields?.length) curFieldList = fieldList.filter((f) => fields.includes(f.apiKey));
    if (!xObjectApiKey) return <Empty description="请先选择要操作的对象" image={Empty.PRESENTED_IMAGE_SIMPLE} />;
    if (!curFieldList.length) return <Empty description="暂无可用字段" image={Empty.PRESENTED_IMAGE_SIMPLE} />;

    return (
      <>
        <Form ref={(f) => this.setState({ form: f })} layout="horizontal"
          labelCol={columnCount === 2 ? { span: 8 } : { span: 4 }} wrapperCol={columnCount === 2 ? { span: 16 } : { span: 20 }}>
          <Row gutter={16}>
            {curFieldList.map((field) => {
              if (field.apiKey === 'id') return null;
              const colSpan = columnCount === 2 ? 12 : 24;
              if (field.referTo && field.type !== 'entityType' && field.type !== 'entitytype') {
                return (
                  <Col span={colSpan} key={field.apiKey}>
                    <Form.Item label={field.label}>
                      <Input.Group compact style={{ display: 'flex' }}>
                        <Form.Item name={field.apiKey} noStyle><Input type="hidden" /></Form.Item>
                        <Input readOnly value={referSelectedLabels[field.apiKey] || ''} placeholder={`请点击选择${field.label}`} style={{ flex: 1, cursor: 'pointer' }} onClick={() => this.openReferModal(field)} />
                        <Button type="primary" onClick={() => this.openReferModal(field)}>选择</Button>
                      </Input.Group>
                    </Form.Item>
                  </Col>
                );
              }
              let input: React.ReactNode;
              switch (field.type) {
                case 'entityType': case 'entitytype':
                  input = <Select placeholder="请选择业务类型" allowClear>{entityTypeList.map((i) => <Option key={i.apiKey} value={i.id} disabled={!i.active}>{i.label}</Option>)}</Select>; break;
                case 'picklist': input = <Select placeholder={`请选择${field.label}`} allowClear>{(field.selectitem || []).map((i) => <Option key={i.apiKey} value={i.id}>{i.label}</Option>)}</Select>; break;
                case 'textarea': input = <Input.TextArea placeholder={`请输入${field.label}`} rows={3} showCount maxLength={500} />; break;
                case 'multipicklist': input = <Select placeholder={`请选择${field.label}`} mode="multiple" allowClear>{(field.checkitem || []).map((i) => <Option key={i.apiKey} value={i.id}>{i.label}</Option>)}</Select>; break;
                case 'datetime': input = <DatePicker placeholder={`请选择${field.label}`} format="YYYY/MM/DD HH:mm:ss" showTime style={{ width: '100%' }} />; break;
                case 'date': input = <DatePicker placeholder={`请选择${field.label}`} format="YYYY/MM/DD" style={{ width: '100%' }} />; break;
                case 'time': input = <DatePicker placeholder={`请选择${field.label}`} format="HH:mm:ss" showTime style={{ width: '100%' }} />; break;
                case 'int': case 'float': input = <InputNumber placeholder={`请输入${field.label}`} style={{ width: '100%' }} />; break;
                case 'email': input = <Input placeholder={`请输入${field.label}`} type="email" />; break;
                case 'url': input = <Input placeholder={`请输入${field.label}`} type="url" />; break;
                case 'phone': input = <Input placeholder={`请输入${field.label}`} type="tel" />; break;
                default: input = <Input placeholder={`请输入${field.label}`} maxLength={200} />;
              }
              return (
                <Col span={colSpan} key={field.apiKey}>
                  <Form.Item name={field.apiKey} label={field.label}>{input}</Form.Item>
                </Col>
              );
            })}
          </Row>
        </Form>

        <Modal open={referModalVisible} onCancel={this.closeReferModal} footer={null} width={900} title={`选择${currentReferField?.label || ''}`} destroyOnClose>
          {currentReferField?.referTo && (
            <NeoEntityGrid render={this.props.render} objectApiKey={currentReferField.referTo.apiKey}
              referData={{ referObjectApiKey: xObjectDataApi?.xObjectApiKey, referItemApiKey: currentReferField.apiKey }}
              selectedCount={1} hiddenHeader onCancel={this.closeReferModal}
              onSelectedCall={(selectedData: any) => {
                const curField = this.state.currentReferField;
                if (!curField) return;
                const items = Array.isArray(selectedData) ? selectedData : [selectedData];
                const first = items[0];
                const id = first?.id ?? first;
                const name = first[`${curField.referTo?.apiKey}Name`] || first?.label || first?.name || first?.id;
                if (id != null) {
                  this.state.form?.setFieldsValue({ [curField.apiKey]: id });
                  this.setState((prev) => ({ referSelectedLabels: { ...prev.referSelectedLabels, [curField.apiKey]: String(name ?? '') }, referModalVisible: false, currentReferField: null }));
                }
                return false;
              }}
            />
          )}
        </Modal>
      </>
    );
  }

  render() {
    const { title, loading, submitting, error } = this.state;
    const { formTitle, className, showResetButton = true } = this.props;
    const { xObjectApiKey } = this.props.xObjectDataApi || {};
    return (
      <div className={`searchForm__c ${className || ''}`.trim()}>
        <div className="form-header"><div className="form-header-text"><h3 className="form-title">{formTitle || title || '自定义筛选条件'}</h3></div></div>
        <div className="form-content">
          <Spin spinning={loading} tip="加载字段信息...">
            {error ? (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={<div><div style={{ color: '#ff4d4f', marginBottom: 8 }}>{error}</div><Button type="primary" onClick={this.loadFieldList}>重新加载</Button></div>} />
            ) : (
              <>
                {this.renderForm()}
                <div className="form-actions">
                  {showResetButton && <Button icon={<ReloadOutlined />} onClick={this.handleReset} disabled={submitting}>重置</Button>}
                  <Button type="primary" icon={<SearchOutlined />} onClick={this.handleSubmit} loading={submitting} disabled={!xObjectApiKey}>{submitting ? '查询中...' : '查询'}</Button>
                </div>
              </>
            )}
          </Spin>
        </div>
      </div>
    );
  }
}

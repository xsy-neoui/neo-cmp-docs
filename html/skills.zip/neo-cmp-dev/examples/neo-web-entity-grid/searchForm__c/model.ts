/**
 * @file 自定义查询表单 — 编辑器描述文件
 */
export class SearchFormModel {
  label: string = '自定义查询表单';
  description: string = '对象数据查询表单，用于设置自定义筛选条件';
  targetPage: string[] = ['all'];
  targetDevice: string = 'web';
  enableDuplicate: boolean = true;
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/custom-form.svg';

  defaultComProps = {
    formTitle: '自定义查询表单',
    showResetButton: true,
    columnCount: 2,
    xObjectDataApi: {
      xObjectApiKey: 'contact',
      fields: ['entityType', 'contactName', 'accountId', 'depart', 'mobile', 'email', 'comment'],
    },
  };

  events = [{
    apiKey: 'onQuery',
    label: '点击查询后',
    helpText: '点击「查询」后触发；事件参数为 { xObjectApiKey, conditions }',
    eventParams: [{
      apiKey: 'eventParam',
      children: [{ apiKey: 'data', label: '当前表单数据', type: 'Object' }],
      label: '事件入参',
      type: 'Object',
    }],
  }];

  propsSchema = [
    { type: 'panelInput', name: 'formTitle', label: '表单标题', value: '自定义查询表单', placeholder: '请输入表单标题' },
    { type: 'xObjectDataApi', name: 'xObjectDataApi', label: '实体数据源', placeholder: '请选择实体数据源', custom: true, showPage: false, showPageSize: false, showAutoFetchData: false },
    { type: 'panelSelect', name: 'columnCount', label: '表单列数', value: 1, options: [{ label: '单列', value: 1 }, { label: '双列', value: 2 }, { label: '三列', value: 3 }] },
    { type: 'panelSwitch', name: 'showResetButton', label: '显示重置按钮', defaultChecked: true },
  ];
}

export default SearchFormModel;

import * as React from 'react';
import './style.scss';
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

interface NeoEntityGridProps {
  objectApiKey: string;
  disableSearch?: boolean;
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
  [key: string]: any;
}

export default class NeoEntityGridCmp extends React.PureComponent<NeoEntityGridProps> {
  constructor(props: NeoEntityGridProps) {
    super(props);
  }

  render() {
    const {
      className,
      objectApiKey,
      hiddenHeader,
      disableSearch,
      canCreate,
      withOrder,
      withCheck,
      disablePagination,
      paginationPageSize,
      autoHeight,
      height,
      selectionMode,
      selectedCount,
      onCancel,
      onSelectedCall,
      ...restProps
    } = this.props;

    const referData = this.props.referData || {
      referObjectApiKey: 'opportunity',
      referItemApiKey: 'accountId',
    };

    return (
      <div className={`entityGrid3__c ${className}`}>
        <NeoEntityGrid
          render={this.props.render}
          objectApiKey={objectApiKey || 'account'}
          pattern={'pickView'}
          referData={referData}
          selectionMode={selectionMode ?? 'single'}
          shouldCloseDialog={restProps.shouldCloseDialog ?? true}
          onRowSelected={(data: any, event: any) => {
            const selectedIds = data.map(({ data }: any) => data.id);
            const selectedNames = data.map(({ data }: any) => data.name);
            console.log('已选中条数：', data.length);
            console.log('已选中 ID：', selectedIds);
            console.log('已选中名称：', selectedNames);
          }}
          hiddenHeader={hiddenHeader ?? false}
          disableSearch={disableSearch ?? false}
          canCreate={canCreate ?? true}
          withOrder={withOrder ?? true}
          withCheck={withCheck ?? true}
          disablePagination={disablePagination ?? false}
          paginationPageSize={paginationPageSize ?? 20}
          autoHeight={autoHeight ?? false}
          height={height ?? '500px'}
          selectedCount={selectedCount ?? 3}
          onCancel={onCancel}
          onSelectedCall={onSelectedCall}
        />
      </div>
    );
  }
}

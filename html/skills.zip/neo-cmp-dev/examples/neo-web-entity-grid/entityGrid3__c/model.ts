/**
 * @file 自定义组件对接编辑器的描述文件
 */
export class NeoEntityGridModel {
  label: string = 'Picker列表';

  description: string =
    '基于平台 NeoEntityGrid 实现的自定义Picker列表: Picker 列表模式的列表数据选择器，支持在其他自定义组件中使用，支持单选和多选。不支持在页面设计器端直接使用。';

  exposedToDesigner: boolean = false; // 不在设计器中显示，仅作为子组件使用

  targetDevice: string = 'web';

  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  defaultComProps = {
    objectApiKey: 'account',
    funPermission: true,
    hiddenHeader: true,
    canCreate: true,
    withOrder: true,
    withCheck: true,
    disableSearch: false,
    disablePagination: false,
    paginationPageSize: 20,
    autoHeight: false,
    height: '500px',
  };

  propsSchema = [
    { type: 'xObjectEntityList', name: 'objectApiKey', label: '实体对象' },
    { type: 'panelSwitch', name: 'hiddenHeader', label: '隐藏头部', defaultChecked: false },
    { type: 'panelSwitch', name: 'disableSearch', label: '禁用搜索', defaultChecked: false, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'canCreate', label: '支持新建', defaultChecked: true, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'withOrder', label: '显示序号列', defaultChecked: true },
    { type: 'panelSwitch', name: 'withCheck', label: '显示多选列', defaultChecked: true },
    { type: 'panelNumber', name: 'paginationPageSize', label: '每页展示条数', visibleOn: '!disablePagination', value: 20 },
    { type: 'panelSwitch', name: 'autoHeight', label: '高度自适应', defaultChecked: false },
    { type: 'panelInput', name: 'height', label: '高度', visibleOn: '!autoHeight' },
  ];
}

export default NeoEntityGridModel;

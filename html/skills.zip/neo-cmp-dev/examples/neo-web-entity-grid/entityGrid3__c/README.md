# entityGrid3__c — Picker 列表

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **`exposedToDesigner: false`**：不在设计器中展示，仅作为子组件嵌入其他组件使用
2. **`NeoEntityGrid` Picker 模式**：`pattern="pickView"` 用作数据选择器
3. **单选/多选**：支持 `selectionMode` 配置
4. **`referData` 关联上下文**：配置关联对象信息实现外键选择
5. **`onRowSelected` 选中回调**：获取选中数据的 ID 和名称
6. **`selectedCount` 控制**：多选时底部展示选中数量

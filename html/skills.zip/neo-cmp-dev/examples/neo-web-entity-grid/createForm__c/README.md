# createForm__c — 新增数据表单

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **`NeoEvent.dispatch`**：声明 `onSubmit` 事件携带 `{ xObjectApiKey, data }` 数据
2. **`xObjectDataApi` 配置项**：在 `propsSchema` 中使用 `xObjectDataApi` 类型
3. **`xObject.getDesc` + `xObject.create`**：获取字段描述、新增实体数据
4. **`xObject.getEntityTypeList`**：获取业务类型列表
5. **关联字段选择**：Modal 内嵌 `entityGrid3__c`（Picker 列表）实现关联选择
6. **动态表单控件**：按字段类型（文本/数字/日期/下拉/多选/多行文本/关联字段）渲染不同的 antd 控件
7. **表单事件参数**：`events[].eventParams` 定义事件携带的数据结构，方便后续事件动作配置
8. **多列布局**：支持 1~3 列表单布局

## 跨组件依赖

`createForm__c` 的关联字段选择弹窗中嵌入了 `entityGrid3__c`（Picker 列表）作为子组件。代码中使用 `import NeoEntityGrid from 'entityGrid3__c'` 直接引用。

**`neo.config.js` 中必须配置远程依赖**，否则运行时无法加载 `entityGrid3__c`：

```js
// neo.config.js
module.exports = {
  neoCommonModule: {
    remoteDeps: ['entityGrid3__c'], // 远程依赖组件（按 cmpType 填写）
    externals: ['entityGrid3__c'],  // 构建时剔除，运行时从远程加载
  },
  // ... 其他配置
};
```

详见 `references/module-sharing.md`「消费方（组件 B）：`remoteDeps` + `externals`」章节。
·
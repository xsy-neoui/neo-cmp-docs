/**
 * @file 新增数据表单 — 编辑器描述文件
 */
export class CreateFormModel {
  label: string = '新增数据表单';
  description: string = '用于创建实体业务数据的表单组件';
  targetPage: string[] = ['all'];
  targetDevice: string = 'web';
  enableDuplicate: boolean = true;
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/custom-form.svg';

  defaultComProps = {
    formTitle: '新增数据表单',
    showResetButton: true,
    columnCount: 2,
    xObjectDataApi: {
      xObjectApiKey: 'opportunity',
      fields: ['entityType', 'ownerId', 'opportunityName', 'accountId', 'money', 'closeDate'],
    },
  };

  events = [{
    apiKey: 'onSubmit',
    label: '提交表单后',
    helpText: '表单提交后触发该事件',
    eventParams: [{
      apiKey: 'eventParam',
      children: [{ apiKey: 'data', label: '当前表单数据', type: 'Object' }],
      label: '事件入参',
      type: 'Object',
    }],
  }];

  propsSchema = [
    { type: 'panelInput', name: 'formTitle', label: '表单标题', value: '新增数据表单', placeholder: '请输入表单标题' },
    { type: 'xObjectDataApi', name: 'xObjectDataApi', label: '实体数据源', placeholder: '请选择实体数据源', custom: true, showPage: false, showPageSize: false, showAutoFetchData: false },
    { type: 'panelSelect', name: 'columnCount', label: '表单列数', value: 2, options: [{ label: '单列', value: 1 }, { label: '双列', value: 2 }, { label: '三列', value: 3 }] },
    { type: 'panelSwitch', name: 'showResetButton', label: '显示重置按钮', defaultChecked: true },
  ];
}

export default CreateFormModel;

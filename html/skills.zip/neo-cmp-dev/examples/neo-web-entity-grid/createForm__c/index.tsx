/**
 * @file Object Form 对象表单组件
 * @description 基于 Neo 平台的 XObject 实体对象数据表单组件，用于新增数据
 */
import * as React from 'react';
import {
  Form, Input, Select, Button, message, DatePicker, InputNumber, Spin, Empty, Row, Col, Modal,
} from 'antd';
import { SaveOutlined, ReloadOutlined, CheckCircleOutlined } from '@ant-design/icons';
// @ts-ignore
import { xObject } from 'neo-open-api';
// @ts-ignore
import isEqual from 'lodash/isEqual';
// @ts-ignore
import { NeoEvent } from 'neo-ui-common';

// 使用 Picker 列表组件
// @ts-ignore
import NeoEntityGrid from 'entityGrid3__c';

import './style.scss';

const { Option } = Select;

interface CreateFormProps {
  xObjectDataApi: { xObjectApiKey: string; fields?: string[]; fieldDescList?: any[] };
  data?: any;
  formTitle?: string;
  showResetButton?: boolean;
  columnCount?: 1 | 2;
  onSuccess?: (data: any) => void;
  className?: string;
  render?: (name: string, schema: any) => React.ReactNode;
}

interface FieldInfo {
  name: string; label: string; apiKey: string; type: string; itemType: string;
  checkitem: any[]; selectitem?: any[]; required: boolean;
  referTo?: { apiKey: string; [key: string]: any };
}

interface CreateFormState {
  title?: string; fieldList: FieldInfo[]; loading: boolean; submitting: boolean; error: string | null;
  form: any; entityTypeList: any[]; submitSuccess: boolean;
  referModalVisible: boolean; currentReferField: FieldInfo | null;
  referSelectedLabels: Record<string, string>;
}

export default class CreateEntityForm extends React.PureComponent<CreateFormProps, CreateFormState> {
  constructor(props: CreateFormProps) {
    super(props);
    this.state = {
      fieldList: [], loading: false, submitting: false, error: null, form: null,
      entityTypeList: [], submitSuccess: false, referModalVisible: false,
      currentReferField: null, referSelectedLabels: {},
    };
    this.loadFieldList = this.loadFieldList.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleReset = this.handleReset.bind(this);
    this.openReferModal = this.openReferModal.bind(this);
    this.closeReferModal = this.closeReferModal.bind(this);
  }

  componentDidMount() {
    const apiKey = this.props.xObjectDataApi?.xObjectApiKey;
    if (apiKey) {
      this.getEntityTypeList(apiKey);
      this.loadFieldList();
    }
  }

  async componentDidUpdate(prevProps: CreateFormProps) {
    const cur = this.props.xObjectDataApi || {};
    const pre = prevProps.xObjectDataApi || {};
    if (cur.xObjectApiKey !== pre.xObjectApiKey || !isEqual(cur.fields, pre.fields)) {
      if (cur.xObjectApiKey) {
        await this.loadFieldList();
        await this.getEntityTypeList(cur.xObjectApiKey);
      } else {
        this.setState({ fieldList: [], error: null });
      }
    }
  }

  async getEntityTypeList(xObjectApiKey?: string) {
    const key = xObjectApiKey || this.props.xObjectDataApi?.xObjectApiKey;
    try {
      const result = await xObject.getEntityTypeList(key);
      if (result?.status) this.setState({ entityTypeList: result.data || [] });
    } catch (error) { console.error('获取业务类型列表失败:', error); }
  }

  async loadFieldList() {
    const { xObjectDataApi } = this.props;
    this.setState({ loading: true, error: null });
    try {
      if (xObjectDataApi?.fieldDescList) {
        this.setState({ fieldList: xObjectDataApi.fieldDescList, loading: false });
      } else if (xObjectDataApi?.xObjectApiKey) {
        const res = await xObject.getDesc(xObjectDataApi.xObjectApiKey);
        if (res?.status) {
          this.setState({ fieldList: res.data?.fields || [], title: res.data?.label, loading: false });
        } else {
          this.setState({ error: '获取字段列表失败', loading: false });
        }
      } else {
        this.setState({ loading: false });
      }
    } catch (error) {
      message.error('获取字段列表失败');
      this.setState({ error: '获取字段列表失败', loading: false });
    }
  }

  @NeoEvent.dispatch
  onSubmit(eventData?: any) {}

  handleSubmit() {
    this.state.form?.validateFields().then(async (values: any) => {
      const { xObjectApiKey } = this.props.xObjectDataApi || {};
      if (!xObjectApiKey) { message.error('请先选择要操作的对象'); return; }
      this.setState({ submitting: true });
      try {
        this.state.fieldList.forEach((field) => {
          if (['date', 'datetime', 'time'].includes(field.type) && values[field.apiKey]) {
            values[field.apiKey] = new Date(values[field.apiKey]).getTime();
          }
        });
        const response = await xObject.create(xObjectApiKey, { data: values, method: 'POST' });
        if (response?.code === 200 || response?.code === '200') {
          message.success('创建成功');
          this.setState({ submitting: false, submitSuccess: true });
          this.state.form.resetFields();
          setTimeout(() => this.setState({ submitSuccess: false }), 2000);
          this.props.onSuccess?.(response.data);
        } else {
          message.error(response?.message || '创建失败');
          this.setState({ submitting: false });
        }
      } catch (error) {
        message.error('创建失败');
        this.setState({ submitting: false });
      }
      this.onSubmit({ xObjectApiKey, data: values });
    });
  }

  handleReset() {
    this.state.form?.resetFields();
    this.setState({ submitSuccess: false, referSelectedLabels: {} });
    message.info('表单已重置');
  }

  openReferModal(field: FieldInfo) { this.setState({ referModalVisible: true, currentReferField: field }); }
  closeReferModal() { this.setState({ referModalVisible: false, currentReferField: null }); return false; }

  renderForm() {
    const { fieldList, entityTypeList, submitSuccess, referModalVisible, currentReferField, referSelectedLabels } = this.state;
    const { xObjectDataApi } = this.props;
    const { xObjectApiKey, fields } = xObjectDataApi || {};
    const { columnCount = 1 } = this.props;
    let curFieldList = fieldList;
    if (fields?.length) curFieldList = fieldList.filter((f) => fields.includes(f.apiKey));
    if (!xObjectApiKey) return <Empty description="请先选择要操作的对象" image={Empty.PRESENTED_IMAGE_SIMPLE} />;
    if (!curFieldList.length) return <Empty description="暂无可用字段" image={Empty.PRESENTED_IMAGE_SIMPLE} />;

    const layout = columnCount === 2 ? { labelCol: { span: 8 }, wrapperCol: { span: 16 } } : { labelCol: { span: 4 }, wrapperCol: { span: 20 } };

    return (
      <>
        <Form ref={(f) => this.setState({ form: f })} layout="horizontal" {...layout}>
          <Row gutter={16}>
            {curFieldList.map((field) => {
              if (field.apiKey === 'id') return null;
              const colSpan = columnCount === 2 ? 12 : 24;
              if (field.referTo && field.type !== 'entityType' && field.type !== 'entitytype') {
                return (
                  <Col span={colSpan} key={field.apiKey}>
                    <Form.Item label={field.label} required={field.required ?? false}>
                      <Input.Group compact style={{ display: 'flex' }}>
                        <Form.Item name={field.apiKey} noStyle rules={[{ required: field.required, message: `请选择${field.label}` }]}>
                          <Input type="hidden" />
                        </Form.Item>
                        <Input readOnly value={referSelectedLabels[field.apiKey] || ''} placeholder={`请点击选择${field.label}`} style={{ flex: 1, cursor: 'pointer' }} onClick={() => this.openReferModal(field)} />
                        <Button type="primary" onClick={() => this.openReferModal(field)}>选择</Button>
                      </Input.Group>
                    </Form.Item>
                  </Col>
                );
              }

              let input: React.ReactNode;
              switch (field.type) {
                case 'entityType': case 'entitytype':
                  input = <Select placeholder="请选择业务类型" allowClear>{entityTypeList.map((item) => <Option key={item.apiKey} value={item.id} disabled={!item.active}>{item.label}</Option>)}</Select>; break;
                case 'picklist':
                  input = <Select placeholder={`请选择${field.label}`} allowClear>{(field.selectitem || []).map((item) => <Option key={item.apiKey} value={item.id}>{item.label}</Option>)}</Select>; break;
                case 'textarea': input = <Input.TextArea placeholder={`请输入${field.label}`} rows={3} showCount maxLength={500} />; break;
                case 'multipicklist': input = <Select placeholder={`请选择${field.label}`} mode="multiple" allowClear>{(field.checkitem || []).map((item) => <Option key={item.apiKey} value={item.id}>{item.label}</Option>)}</Select>; break;
                case 'datetime': input = <DatePicker placeholder={`请选择${field.label}`} format={'YYYY/MM/DD HH:mm:ss'} showTime style={{ width: '100%' }} />; break;
                case 'date': input = <DatePicker placeholder={`请选择${field.label}`} format={'YYYY/MM/DD'} style={{ width: '100%' }} />; break;
                case 'time': input = <DatePicker placeholder={`请选择${field.label}`} format={'HH:mm:ss'} showTime style={{ width: '100%' }} />; break;
                case 'int': case 'float': input = <InputNumber placeholder={`请输入${field.label}`} style={{ width: '100%' }} />; break;
                case 'email': input = <Input placeholder={`请输入${field.label}`} type="email" />; break;
                case 'url': input = <Input placeholder={`请输入${field.label}`} type="url" />; break;
                case 'phone': input = <Input placeholder={`请输入${field.label}`} type="tel" />; break;
                default: input = <Input placeholder={`请输入${field.label}`} maxLength={200} />;
              }
              return (
                <Col span={colSpan} key={field.apiKey}>
                  <Form.Item name={field.apiKey} label={field.label} required={field.required ?? false}
                    rules={[{ required: field.required, message: `请${['picklist', 'multipicklist', 'entityType', 'entitytype', 'date', 'datetime', 'time'].includes(field.type) ? '选择' : '输入'}${field.label}` }]}>
                    {input}
                  </Form.Item>
                </Col>
              );
            })}
          </Row>
          {submitSuccess && <div className="submit-success-message"><CheckCircleOutlined /> 数据已成功提交</div>}
        </Form>

        <Modal open={referModalVisible} onCancel={this.closeReferModal} footer={null} width={900} title={`选择${currentReferField?.label || ''}`} destroyOnClose>
          {currentReferField?.referTo && (
            <NeoEntityGrid render={this.props.render} objectApiKey={currentReferField.referTo.apiKey}
              referData={{ referObjectApiKey: xObjectDataApi?.xObjectApiKey, referItemApiKey: currentReferField.apiKey }}
              selectedCount={1} hiddenHeader onCancel={this.closeReferModal}
              onSelectedCall={(selectedData: any) => {
                const curField = this.state.currentReferField;
                if (!curField) return;
                const items = Array.isArray(selectedData) ? selectedData : [selectedData];
                const first = items[0];
                const id = first?.id ?? first;
                const name = first[`${curField.referTo?.apiKey}Name`] || first?.label || first?.name || first?.id;
                if (id != null) {
                  this.state.form?.setFieldsValue({ [curField.apiKey]: id });
                  this.setState((prev) => ({ referSelectedLabels: { ...prev.referSelectedLabels, [curField.apiKey]: name }, referModalVisible: false, currentReferField: null }));
                }
                return false;
              }}
            />
          )}
        </Modal>
      </>
    );
  }

  render() {
    const { title, loading, submitting, error } = this.state;
    const { formTitle, className, showResetButton = true } = this.props;
    const { xObjectApiKey } = this.props.xObjectDataApi || {};
    return (
      <div className={`createForm__c ${className}`}>
        <div className="form-header"><h3 className="form-title">{formTitle || title || '新增数据'}</h3></div>
        <div className="form-content">
          <Spin spinning={loading} tip="加载字段信息...">
            {error ? (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={<div><div style={{ color: '#ff4d4f', marginBottom: 8 }}>{error}</div><Button type="primary" onClick={this.loadFieldList}>重新加载</Button></div>} />
            ) : (
              <>
                {this.renderForm()}
                <div className="form-actions">
                  {showResetButton && <Button icon={<ReloadOutlined />} onClick={this.handleReset} disabled={submitting}>重置</Button>}
                  <Button type="primary" icon={<SaveOutlined />} onClick={this.handleSubmit} loading={submitting} disabled={!xObjectApiKey}>{submitting ? '提交中...' : '提交'}</Button>
                </div>
              </>
            )}
          </Spin>
        </div>
      </div>
    );
  }
}

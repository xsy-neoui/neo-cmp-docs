# entityGrid4__c — 大列表/自定义工具栏

**来源模板**：`neo-web-entity-grid`（`neo init -t neo-web-entity-grid`）

## 演示的能力

1. **`customToolbarButtons` 自定义工具栏**：在 `NeoEntityGrid` 中配置头部和底部自定义按钮
2. **`customRender` 工具栏自定义渲染**：底部「同步状态」指示器使用 `customRender` 渲染 antd `Tooltip` + Icon
3. **与 `entityGrid__c` 一致的配置**：相同的 `propsSchema` 和功能开关
4. **antd 组件使用**：`Tooltip`、`CheckCircleOutlined`、`CloseCircleOutlined`
5. **BEM 样式隔离**：自定义工具栏样式使用 `entityGrid4__c-status-indicator` 命名空间

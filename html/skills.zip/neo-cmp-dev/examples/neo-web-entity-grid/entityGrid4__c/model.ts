/**
 * @file 自定义组件对接编辑器的描述文件
 */
export class NeoEntityGridModel {
  label: string = '大列表/自定义工具栏';

  description: string = '基于平台 NeoEntityGrid 实现的数据列表示例: 支持自定义工具栏';

  targetDevice: string = 'web';

  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  defaultComProps = {
    objectApiKey: 'account',
    funPermission: true,
    hiddenHeader: false,
    showView: true,
    enableChangeView: true,
    enableToolbar: true,
    canCreate: true,
    canImport: true,
    withOrder: true,
    withCheck: true,
    editable: true,
    disableSearch: false,
    disableExport: false,
    disablePagination: false,
    paginationPageSize: 20,
    autoHeight: false,
    height: '500px',
  };

  propsSchema = [
    { type: 'xObjectEntityList', name: 'objectApiKey', label: '实体对象' },
    { type: 'dataViewIdSelect', name: 'defaultViewId', xObjectApiKey: 'objectApiKey', label: '列表视图' },
    { type: 'panelSwitch', name: 'hiddenHeader', label: '隐藏头部', defaultChecked: false },
    { type: 'panelSwitch', name: 'disableSearch', label: '禁用搜索', defaultChecked: false, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'showView', label: '显示列表视图控制栏', defaultChecked: true, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'enableChangeView', label: '支持列表视图切换', defaultChecked: true, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'enableToolbar', label: '显示工具栏', defaultChecked: true, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'canCreate', label: '支持新建', defaultChecked: true, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'canImport', label: '支持导入', defaultChecked: false, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'disableExport', label: '禁用导出', defaultChecked: false, hiddenOn: 'hiddenHeader' },
    { type: 'panelSwitch', name: 'withOrder', label: '显示序号列', defaultChecked: true },
    { type: 'panelSwitch', name: 'withCheck', label: '显示多选列', defaultChecked: true },
    { type: 'panelSwitch', name: 'editable', label: '支持单元格编辑', defaultChecked: true },
    { type: 'panelSwitch', name: 'disablePagination', label: '是否禁用分页', defaultChecked: false },
    { type: 'panelNumber', name: 'paginationPageSize', label: '每页展示条数', visibleOn: '!disablePagination', value: 20 },
    { type: 'panelSwitch', name: 'autoHeight', label: '高度自适应', defaultChecked: false },
    { type: 'panelInput', name: 'height', label: '高度', visibleOn: '!autoHeight' },
  ];
}

export default NeoEntityGridModel;

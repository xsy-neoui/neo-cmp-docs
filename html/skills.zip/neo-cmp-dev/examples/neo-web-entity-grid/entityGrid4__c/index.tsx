import * as React from 'react';
import { Tooltip } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';
import './style.scss';
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

interface NeoEntityGridProps {
  objectApiKey: string;
  disableSearch?: boolean;
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
  [key: string]: any;
}

export default class NeoEntityGridCmp extends React.PureComponent<NeoEntityGridProps> {
  constructor(props: NeoEntityGridProps) {
    super(props);
  }

  render() {
    const {
      className,
      objectApiKey,
      hiddenHeader,
      showView,
      enableChangeView,
      defaultViewId,
      disableSearch,
      canCreate,
      canImport,
      editable,
      withOrder,
      withCheck,
      enableToolbar,
      disableExport,
      disablePagination,
      paginationPageSize,
      autoHeight,
      height,
      ...restProps
    } = this.props;

    return (
      <div className={`entityGrid4__c ${className}`}>
        <NeoEntityGrid
          render={this.props.render}
          objectApiKey={objectApiKey || 'account'}
          pattern={'entityView'}
          hiddenHeader={hiddenHeader ?? false}
          showView={showView ?? true}
          enableChangeView={enableChangeView ?? true}
          defaultViewId={defaultViewId ?? 'default_view'}
          disableSearch={disableSearch ?? false}
          canCreate={canCreate ?? true}
          canImport={canImport ?? true}
          editable={editable ?? true}
          withOrder={withOrder ?? true}
          withCheck={withCheck ?? true}
          enableToolbar={enableToolbar ?? true}
          disableExport={disableExport ?? false}
          disablePagination={disablePagination ?? false}
          paginationPageSize={paginationPageSize ?? 20}
          autoHeight={autoHeight ?? false}
          height={height ?? '500px'}
          customEmptyMsg="暂无数据，请点击「新建」按钮创建"
          customToolbarButtons={{
            header: [
              {
                id: 'approve-btn',
                label: '批量审批',
                icon: 'CheckOne',
                tooltip: '对选中记录批量审批',
                onClick: () => {
                  console.log('批量审批');
                },
              },
            ],
            footer: [
              {
                id: 'export-pdf-btn',
                label: '导出 PDF',
                icon: 'FilePdf',
                onClick: () => console.log('导出 PDF'),
              },
              {
                id: 'status-indicator',
                label: '同步状态',
                customRender: (button: any = { syncStatus: 'ok' }) => {
                  const ok = button.syncStatus === 'ok';
                  const tip = ok ? '已同步' : '同步失败';
                  const Icon = ok ? CheckCircleOutlined : CloseCircleOutlined;
                  return (
                    <li key={button.id} className="entityGrid4__c-status-indicator">
                      <Tooltip title={tip} placement="top" mouseEnterDelay={0.1}>
                        <button
                          type="button"
                          className={`entityGrid4__c-status-indicator__btn entityGrid4__c-status-indicator__btn--${ok ? 'ok' : 'error'}`}
                          aria-label={`同步状态：${tip}`}
                        >
                          <Icon className="entityGrid4__c-status-indicator__icon" aria-hidden />
                        </button>
                      </Tooltip>
                    </li>
                  );
                },
              },
            ],
          }}
        />
      </div>
    );
  }
}

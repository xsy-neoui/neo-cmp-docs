---
name: neo-cmp-dev
description: 在 neo-cmp-cli 创建的工程里做**组件开发 / Neo 平台自定义组件开发**（React 16 + TypeScript）。凡是用户意图是"写 / 开发 / 改造 / 增强 / 实现一个组件的内部实现"——**不论用户是否显式说'自定义组件'**——统一走本技能：覆盖组件目录与 `index.tsx` 入口、`model.ts` 模型、`propsSchema` 真实类型与自定义配置项、事件动作（@NeoEvent + BaseCmp）、运行时上下文（props.env.ctx / props.data.__Neo*）、平台预置组件、平台实体数据源与自定义 API（xObject / customApi / 通用代理 forward）、SCSS + BEM 样式隔离、模板选型、工程规范（Airbnb + stylelint）。**字段兜底规则**：**未登录状态**：用户未登录 Neo 平台时，组件代码中必须通过运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段，**不得**凭直觉杜撰字段名。**已登录状态**：用户已登录 Neo 平台时，若未明确说明要使用实体的哪些字段，通过 `neo-cmp-cli/scripts/fetchEntityDesc.js` 或运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段，**不得**凭直觉杜撰字段名。**`xObject.query`/`xObject.get` 的 `fields` 参数优先级**：① 用户需求中明确提及的字段优先；② 用户未提及字段时，根据登录状态使用上述对应方式获取字段列表，取前 10 个字段。**首次创建自定义组件项目**：优先走 `neo create project`（空项目骨架），**仅当用户明确要求"基于某个内置模板起步"**（如 echarts / antd / neo-h5-cmps / neo-bi-cmps 等）时才改用 `neo init -t <type>`；具体命令由 `neo-cmp-cli` 执行。**开发完成后**（组件代码、模型、样式齐备后），本技能**必须**向用户提示"预览 / linkDebug / 发布"三选项（可多选），并**按用户选择转交 `neo-cmp-cli` 技能**执行对应的安装依赖、格式化、命令执行等操作（`neo preview` / `neo linkDebug` / `neo push cmp`），不在本技能内直接拼命令。**不用于**：只是执行 `neo` 命令（创建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 登录）且**不写任何组件内部代码**的场景（→ neo-cmp-cli）；把 Vue 组件或整个 Vue 项目改造 / 转换 / 迁移成自定义组件的前半段语法迁移（→ vue-to-react，迁移完成后再回到本技能落地平台规范）。触发关键词：组件开发、开发组件、写组件、实现组件、React 组件开发、实现 / 开发 / 编写 / 改造 Neo 自定义组件功能、加属性面板配置项、自定义配置项开发、被其他组件调用的组件动作、读写平台实体数据、调用自定义 API / 外部接口。**实体识别关键词**：客户、联系人、销售机会、订单、合同、销售线索、产品、任务、用户、部门、审批、商品、回款、发票、库存、采购、报表、日程、公告、服务工单、巡访记录、活动记录、预算、费用、报销、资产、项目以及所有 Neo 标准实体名称（见 `references/standard-entities.md`）。

---

# Neo 平台 React 自定义组件开发技能

本技能在 neo-cmp-cli 工程中，按平台规范开发 **React 16 + TypeScript** 自定义组件。覆盖五件事：
- **落地规范**：目录约定、model.ts、propsSchema 真实类型、根节点 className 与样式隔离、平台预置依赖、**依赖 props 的响应式约束**
- **对接平台能力**：事件动作（`@NeoEvent` + `BaseCmp`）、运行时上下文（`props.env.ctx` / `props.data.__Neo*`）、平台预置组件（`NeoEntityList` / `NeoEntityGrid`）、`neo-open-api` 数据源（`xObject` / `customApi`）
- **收敛开发步骤**：一张 12 步清单覆盖「需求→选型→模型→属性面板→实现→样式→**代码审查（强制）**→安装/格式化（转交 neo-cmp-cli）→询问用户下一步」
- **对齐工程规范**：Airbnb ESLint + stylelint-config-standard
- **完成后交接**：必须向用户确认「预览/linkDebug/发布」并转交 [`neo-cmp-cli`](../neo-cmp-cli/SKILL.md) 执行

> **命令执行层**：所有 `neo` 命令的交互式参数与非交互式映射由 [`neo-cmp-cli`](../neo-cmp-cli/SKILL.md) 承载；本技能第 3/11/12 步涉及的命令以 `neo-cmp-cli` 为准。

## 技能边界（四技能路由）

| 用户意图 | 应使用的技能 |
|---|---|
| 只是**执行命令**（创建项目/骨架/预览/调试/发布/拉取/删除/登录） | **`neo-cmp-cli`** |
| **实现/开发/改造组件内部功能**（属性面板、事件动作、数据对接、样式） | **`neo-cmp-dev`（本技能）** |
| "开发组件/写组件/做组件"（在 neo 工程中默认即是自定义组件） | **`neo-cmp-dev`（本技能）** |
| 把**现有 Vue 组件/项目**迁移成自定义组件 | **`vue-to-react`**（先）→ **本技能**（后） |
| **审查组件代码是否满足规范**（步骤 9 后做规范对齐检查） | **`neo-code-review`** |

**同时表达"创建+实现"**：先走 `neo-cmp-cli` 的 `neo create cmp` 生成骨架，再由本技能接管其余步骤。

**开发与审查循环**：组件代码实现→`neo-code-review` 审查→发现问题回本技能修复→再次审查，循环直至全部通过。

## 技术栈

| 维度 | 选择 |
|---|---|
| 框架 | **React 16.13.1**（与平台预置对齐） |
| 组件形态 | 需要事件动作/组件函数 → **类组件 + `extends BaseCmp`**；纯展示 → 函数组件 + Hooks |
| PC 端 UI | **antd ^4.9.4**（externals 剔除，直接 import） |
| H5 端 UI | **antd-mobile 2.3.4**（externals 剔除，直接 import） |
| 平台运行时 | `neo-ui-common`（BaseCmp, NeoEvent）+ `neo-open-api`（xObject, customApi, request） |
| 平台预置组件 | PC: `NeoEntityGrid`（`neo-ui-component-web`）；H5: `NeoEntityList` / `GlobalSearchInput`（`neo-ui-component-h5`） |
| 状态管理 | 组件内 `useState` / `useReducer` / `this.state`；跨组件优先**事件动作** |
| 样式 | **SCSS** + BEM（根类名=组件目录名） |
| 代码规范 | Airbnb（工程 `.eslintrc.js` 已继承） |
| 构建 | `neo preview` / `neo linkDebug` / `neo push cmp` |

> `neo-ui-common` / `neo-ui-component-*` 都是**平台运行时注入的虚拟模块**，不要在 `package.json` 安装；`import` 时加 `// @ts-ignore`。
>
> `neo-open-api` 是**真实 NPM 包**（平台 SDK），**必须**在 `package.json` 的 `dependencies` 中添加依赖（如 `"neo-open-api": "^1.2.13"`），不可当作虚拟模块跳过安装。详见 `references/platform-deps.md`。

## 硬性约束

### 约束 1：UI 组件库与端对齐

| 端 | 必须优先使用 | 自研兜底 |
|---|---|---|
| PC（`web`） | **antd ^4.9.4** | `antd`/`antd-mobile` 无对应能力时，自研子组件放 `src/common/`，在 README 说明原因；**禁止**引入 Element/MUI/Semi/Arco/Vant/NutUI 等其他 UI 库替代 |
| H5（`mobile`） | **antd-mobile 2.3.4** | 同上 |
| 通用（`all`） | 按实际渲染端择一，避免混用两套风格 | 拆两个组件或分支渲染 |

### 约束 2：平台列表类数据源优先使用平台列表组件

- H5：**`NeoEntityList`**（`neo-ui-component-h5`）→ 需传 `render={this.props.render}`
- PC：**`NeoEntityGrid`**（`neo-ui-component-web`）→ 需传 `render={this.props.render}`
- **禁止**为绕过学习成本/样式定制而用 `antd Table` + `xObject.query` 自研列表
- **例外**：显著偏离列表语义（卡片墙、看板、日历、地图等）且平台组件扩展点覆盖不到时可用 `antd Table`/`antd-mobile List`，需在 README 说明原因
- 配置项使用 `xObjectEntityList` / `xObjectDataApi` 等数据源类类型，避免写死 apiKey

### 约束 3：工具类方法统一放 `src/utils/`

通用逻辑、纯函数、格式化、校验、解析、常量、SDK 包装等**必须**下沉到 `src/utils/`，禁止塞在 `index.tsx` / `components/*.tsx` / `model.ts` 里。按领域分文件（`date.ts` / `number.ts` / `entity.ts` / `proxy.ts`），命名导出。组件级私有辅助可放组件目录的 `helpers.ts`。

### 约束 4：`propsSchema` 的 `type` 必须来自平台真实类型

- **允许的 type** 仅两类：**表单类**（`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `neoCheckbox` / `neoCascader` / `neoTreeSelect` / `neoDatePicker` / `neoTimePicker` / `neoRate` / `neoSlider` / `neoUpload` / `neoTransfer`）和**数据源类**（`xObjectEntityList` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `selectFieldDescApi` / `dataViewIdSelect` / `customApi`）
- `name` 必须与 `defaultComProps` 和组件 props 字段严格对齐
- 选不到合适类型 → 按 `references/custom-props-item.md` 走 `@FormItem` 注册自定义配置项，**禁止**写未注册的 `type` 或用 `panelInput` + JSON 凑合
- 事件回调不进 `propsSchema`，由 `model.events` 声明

### 约束 5：依赖 props 属性的方法必须支持响应式

类组件中所有依赖 `this.props` 特定字段的方法（如根据属性面板配置项变化重新查询数据、切换展示模式、重置本地状态等），**必须在 `componentDidUpdate` 中监听对应 props 字段的变化并执行**。典型实现模式：

```tsx
// 类组件 + extends BaseCmp
public componentDidUpdate(prevProps: Readonly<ICmpProps>): void {
  // 监听单个字段
  if (prevProps.apiKey !== this.props.apiKey) {
    this.fetchData();
  }
  // 监听多个字段
  if (
    prevProps.viewMode !== this.props.viewMode ||
    prevProps.filterCondition !== this.props.filterCondition
  ) {
    this.updateDisplay();
  }
}
```

**约束细则**：
- 函数组件使用 `useEffect` + 依赖数组实现同等效果，**禁止**忽略依赖数组或使用空数组 `[]` 跳过 prop 响应
- `propsSchema` 中所有可配置项（通过属性面板可改的字段）对应的组件 props，**必须考虑其运行时变化的场景**，不能仅在 `componentDidMount` 一次性执行
- 组件挂载时首次执行的初始化逻辑与 props 变化后的响应逻辑应解耦，优先从 `componentDidUpdate` 统一收口，避免在多个方法中分散判断条件
- 如果仅在组件挂载时需执行一次、与 props 无关的逻辑（如注册全局事件监听），放在 `componentDidMount`，无需进 `componentDidUpdate`

### 约束 6：字段获取规范（登录状态决定获取方式）

组件开发中获取实体字段列表时，根据用户登录状态决定获取方式：

- **未登录状态**：用户未登录 Neo 平台时，组件代码中**必须**通过运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段，**不得**凭直觉杜撰字段名。
- **已登录状态**：用户已登录 Neo 平台时，可通过 `neo-cmp-cli/scripts/fetchEntityDesc.js` 或运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段（`data` 中的 `apiKey` 为字段 key 值），**不得**凭直觉杜撰字段名。

### 约束 7：`neo-open-api` 使用规范（依赖 + 入参 + 返回值）

**7.1 依赖管理：`neo-open-api` 是真实 NPM 包，非虚拟模块**
- `neo-open-api`（`xObject` / `customApi` / `request`）是**平台 SDK 真实 NPM 包**，**必须**在 `package.json` 的 `dependencies` 中添加依赖（如 `"neo-open-api": "^1.2.9"`）
- 与 `neo-ui-common` / `neo-ui-component-*` 等平台虚拟模块**不同**，`neo-open-api` 需要实际安装，不可当作虚拟模块跳过依赖安装
- import 时统一加 `// @ts-ignore`（安全兜底），注释写明"平台 SDK"

```tsx
// @ts-ignore 平台 SDK
import { xObject, customApi, request } from 'neo-open-api';
```

**7.2 数据入口规范：必须使用 `neo-open-api` 获取实体数据**
- 读/写平台实体数据**必须**使用 `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` / `getFileds` / `getEntityList` 等方法
- 调用平台自定义 API**必须**使用 `customApi.run` / `customApi.getList`
- **禁止**手写 `axios` / `fetch` 直接调用平台实体接口（丢失登录态、权限、审计）

**7.3 返回值校验规范**
- 所有 `neo-open-api` 方法统一以 `status === true` 判断成功（**不依赖** `code === 0` 或 `code === 200`）
- `xObject.query` 返回结构 `{ status, code, msg, totalSize, data: any[] }`，`data` 即为列表数据（数组），取值方式：`result.data || []`
- `xObject.get` 返回结构 `{ status, code, msg, data: Object }`，`data` 为单条记录详情对象
- `xObject.create` / `xObject.update` 返回结构 `{ status, code, msg, data: Object }`，`data` 为操作后的记录对象
- `xObject.delete` 返回结构 `{ status, code, msg }`，无 `data`
- `customApi.run` 返回结构 `{ status, code, msg, data: any }`，`data` 格式由 API 发布者定义
- 异步调用必须用 `try-catch` 包裹，`catch` 中提供兜底错误文案

**返回结构速查表**：

| 方法 | `status` 判断 | `data` 类型 | 说明 |
|---|---|---|---|
| `xObject.query` | `result.status` | `any[]` | 列表数据 |
| `xObject.get` | `result.status` | `Object` | 单条详情 |
| `xObject.create` | `result.status` | `Object` | 新建记录 |
| `xObject.update` | `result.status` | `Object` | 更新后记录 |
| `xObject.delete` | `result.status` | 无 | 仅 status/msg |
| `xObject.getDesc` | `result.status` | `Object` | 实体元数据 |
| `xObject.getFileds` | `result.status` | `FieldItem[]` | 字段定义数组 |
| `xObject.getEntityList` | `result.status` | `EntityDesc[]` | 实体描述列表 |
| `customApi.run` | `result.status` | `any` | 格式自定义 |
| `customApi.getList` | `result.status` | `Array` | 自定义 API 列表 |

## 组件目录约定

```
src/components/<cmpName>__c/     # 目录名=组件名=cmpType（__c 后缀）
├── index.tsx                     # 必须：入口
├── model.ts                      # 必须：设计器配置（propsSchema/events/functions）
├── index.scss                    # 可选：样式（CLI 做样式隔离）
├── common.scss                   # 可选：弹层类样式（不隔离）
└── types.ts / hooks/ / components/ / helpers.ts / README.md  # 可选
src/common/<SubCmpName>/          # 自研功能子组件（跨组件复用）
src/utils/                        # 工具类方法（按领域分文件）
```

**硬约束**：目录名必须与 `cmpType` 一致（`__c` 后缀）；根节点 `className` 必须与目录名一致且合并 `props.className`（否则「是否显示」失效）。

## 开发关键步骤（12 步）

按顺序走完以下步骤，产出符合规范的组件。

### 步骤 1：需求分析 & 模板选型

明确组件解决的问题、可配置项、`targetPage` 与 `targetDevice`。**需求→模板快速映射**：PC 列表/筛选/Picker → `neo-web-entity-grid`；H5 业务组件 → `neo-h5-cmps`；通用业务组件 → `neo`；BI 指标 → `neo-bi-cmps`；图表 → `echarts`；地图 → `amap`；表单 → `neo-web-form`。按硬约束逐条自检 UI 库、列表组件、工具方法沉淀、propsSchema 类型。

### 步骤 2：实体识别 + 数据接入决策（关键）

**先完成实体识别，再进行数据接入决策。**

**实体识别**：扫描需求中的业务对象关键词 → 匹配 `references/standard-entities.md` 确定 apiKey。有歧义时向用户确认。

**字段兜底规则（用户未指定字段时）**：

> 用户没说用哪些字段？ → 根据当前登录状态决定获取方式：
> 
> **未登录状态**：用户未登录 Neo 平台时，组件代码中必须通过运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段，**不得**凭直觉杜撰。
> 
> **已登录状态**：用户已登录 Neo 平台时，遵循以下优先级：
> 1. **用户需求中明确提及的字段**优先使用。
> 2. **写入 `xObject.query`/`xObject.get` 的 `fields` 参数时**：通过 `neo-cmp-cli/scripts/fetchEntityDesc.js` 或运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段（`data` 中的 `apiKey` 为字段 key 值）。
> 3. **选取组件展示/交互字段时**：先通过 `neo-cmp-cli/scripts/fetchEntityDesc.js` 或运行时 `xObject.getFileds('<apiKey>')` 获取实体已有字段列表，从查询结果的字段清单中按场景挑选（列表→常用展示字段、搜索→过滤键、录入→必填字段），**不得凭直觉杜撰**。

**数据接入决策**：

| 需求特征 | 首选 API | propsSchema 配置项 |
|---|---|---|
| 读/写平台实体数据（CRUD） | `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` / `getFileds` | `xObjectEntityList` + `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` |
| 调平台自定义 API | `customApi.run` | `customApi` |
| 调外部 HTTP 接口（CORS） | **通用代理**：`customApi.run({ apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', ... })`（先部署 `forward.zip`） | `panelInput` 或 `customApi` |

**硬性约束**：能用 `xObject` 不用手写 `axios`；propsSchema 优先暴露数据源类配置项让业务方设计器选字段；错误处理以 `status` 判断成功（不依赖 `code === 0`）。

### 步骤 3：初始化组件目录

**预检约束**：先运行 `neo -v` 验证当前电脑是否已安装 `neo-cmp-cli`。
- `neo -v` 成功（已安装）→ 跳过安装，继续后续操作。
- `neo -v` 失败（未安装）→ **先转交 `neo-cmp-cli` 技能**执行全局安装 `npm i -g neo-cmp-cli`，安装完成后再继续。

安装确认后：
- 若尚无 neo 工程（无 `neo.config.js`）→ 交 `neo-cmp-cli` 执行 `neo create project --name=<name>`（默认空项目）或 `neo init -t <type> -n <name>`（用户指定模板时）。
- 已有工程 → 交 `neo-cmp-cli` 执行 `neo create cmp -n <name> -d <all|web|mobile>`。

### 步骤 4：定义组件模型

填 `model.ts`：`label` / `description` / `iconUrl` / `targetDevice` / `defaultComProps` / `propsSchema` / `events` / `functions`（详细见 `references/model-file.md`）。

> **约束：禁止自行添加 `tags`**，如用户有分类需求，提示用户在组件模型文件（`model.ts`）中自行添加 `tags`。

> **约束：`defaultComProps` 中跳过数据源对象类型字段**。生成 `defaultComProps` 时，若 `propsSchema` 中某配置项为数据源类类型（`xObjectDataApi` / `xObjectDetailApi` / `customApi`）且其数值为对象类型，**不将该字段添加到 `defaultComProps`**。因为这些字段的值由业务方在设计器中通过数据源配置面板绑定产生，预设空对象 `{}` 无意义且可能引发生命周期判断歧义。对于 `xObjectEntityList`（值为 `string`）和 `dataViewIdSelect`（值为 `string`）等非对象数值的数据源类配置项，仍可正常添加默认值。

### 步骤 5：选择组件形态

需要组件动作/事件动作 → **类组件 + `extends BaseCmp`**；纯展示 → 函数组件 + Hooks（详细见 `references/component-form.md`）。

### 步骤 6：实现组件主体

props 类型与 propsSchema 对齐；按步骤 2 决策调用 `xObject` / `customApi` / `request`；PC 用 antd、H5 用 antd-mobile（缺失时自研放 `src/common/`）；平台实体列表优先用 `NeoEntityList`/`NeoEntityGrid`；纯函数下沉到 `src/utils/`。

> **响应式约束**：所有依赖 `this.props` 字段的方法（如属性面板配置项变化后重新查询、切换展示模式等），必须在 `componentDidUpdate` 中根据相关 props 变化执行。参见「约束 5：依赖 props 属性的方法必须支持响应式」。

### 步骤 7：绑定属性面板

`propsSchema` 的 `type` 从平台真实类型中挑选（约束 4）；`name` 与组件 props 字段一一对应；挑不到时按 `references/custom-props-item.md` 开发自定义配置项。

### 步骤 8：接入事件动作

对外触发 → `@NeoEvent.dispatch` + `model.events`；被调用 → `@NeoEvent.function` + `model.functions` + `extends BaseCmp` + 构造函数 `bind(this)`（详细见 `references/event-action.md`）。

### 步骤 8+：实体详情页跳转

当组件需要点击实体名跳转到详情页时，使用以下 URL 格式：

```
/bff/neoweb#/entityDetail/{objectApiKey}/{recordId}?objectApiKey={...}&recordId={...}
```

可通过 `neo-cmp-cli` 的脚本生成跳转代码（转交 `neo-cmp-cli` 执行）：

```
node scripts/buildEntityDetailUrl.js --apiKey <key> --code
```

自定义实体请先用 `neo-cmp-cli/scripts/fetchEntityDesc.js` 查询字段信息。

### 步骤 9：写样式

根节点 `className` = 组件目录名，合并 `props.className`；SCSS BEM 平铺；弹层样式放 `common.scss`（详细见 `references/styling.md`）。

> **约束：禁止使用 `&-xx` 语法**（如 `&__header`、`&--primary`）。BEM 子元素和修饰符必须写成独立的完整选择器（如 `.cmpName__c__header`、`.cmpName__c--primary`），不使用 SCSS 父选择器拼接。伪类选择器（`&:hover`、`&:focus` 等）不受此限制。

> **说明**：步骤 9 是组件开发的最后一步代码编写工作。完成后**必须**进入步骤 9+ 代码审查，**禁止**跳过审查直接进入步骤 10。

### 步骤 9+：代码审查与规范对齐（强制）

**步骤 9 完成后必须执行本步骤，不可跳过。**

代码、模型、样式齐备后，**必须先转交 `neo-code-review` 技能**对当前组件进行全量规范审查，而非直接进入步骤 10。本技能在此步骤中**不得**直接执行代码审查，必须依赖 `neo-code-review` 技能完成审查工作。

**审查流程**：
1. 将开发的组件目录路径告知 `neo-code-review` 技能
2. `neo-code-review` 按 7 维度检查清单逐项校验（目录命名、index.tsx、model.ts、事件动作、样式、数据源、依赖）
3. 生成审查报告：
   - **全部通过**（无 ❌ 项）→ 继续步骤 10
   - **存在问题**（有 ❌ 项）→ 按审查报告的修复建议在本技能调整代码，调整完成后再次转交 `neo-code-review` 审查，循环直至全部通过

> **为什么需要代码审查**：组件开发中容易遗漏规范项（如未合并 `props.className`、`&-xx` 语法、虚拟模块打进 bundle 等），这些问题在运行时表现为"样式不生效、事件动作不响应、属性面板空白"等难以定位的异常。在步骤 10 之前完成审查可以尽早发现问题。

### 步骤 10：安装依赖 + 全局格式化

转交 `neo-cmp-cli` 技能执行：① 安装工程全量依赖（自动识别包管理器，淘宝源策略见 `neo-cmp-cli`）；② `npm run format`（不存在时提示补 `"format": "prettier --write ..."`）；③ 汇总结果。步骤失败时记录原因并跳过，不阻塞后续流程。

### 步骤 10+：发布前字段存在性验证

发布前转交 `neo-cmp-cli` 技能执行字段验证，确保组件代码中使用的实体字段确实存在于目标环境中：

```
node scripts/validateEntityFields.js -k <apiKey> -f field1,field2
```

- 验证通过 → 可继续发布
- 验证发现不存在的字段 → 从代码中剔除后再发布
- 字段名与实体 apiKey 大小写严格一致
- 动态字段名（运行时拼接）不在此验证范围

> 该脚本位于 `neo-cmp-cli` 中，验证逻辑由 `neo-cmp-cli` 技能代为执行。

### 步骤 11：开发完成 → 询问用户下一步

代码、模型、样式齐备后，按下方话术询问用户并转交 `neo-cmp-cli`（本技能禁止直接跑 `neo` 命令）。

## 实体识别

### 匹配规则（常见实体）

| 用户输入 | apiKey | label |
|---|---|---|
| 客户/客户列表 | `account` | 客户 |
| 联系人 | `contact` | 联系人 |
| 销售机会/商机 | `opportunity` | 销售机会 |
| 订单 | `order` | 订单 |
| 合同 | `contract` | 合同 |
| 销售线索/线索 | `lead` | 销售线索 |
| 产品 | `product` | 产品 |
| 任务 | `task` | 任务 |
| 服务工单/工单 | `serviceCase` | 服务工单 |
| 审批 | `apply` | 审批 |
| 费用/报销 | `expenseaccount` | 报销单 |
| 巡访/拜访记录 | `visitRecord` | 拜访记录 |
| 用户/员工 | `user` | 用户 |
| 部门 | `department` | 部门 |
| 活动记录/活动 | `activityrecord` | 活动记录 |
| 日程/日历 | `schedule` | 日程 |
| 回款 | `payment` | 回款记录 |
| 发票 | `receipt` | 发票 |
| 商品/库存 | `goods` | 商品 |
| 采购订单 | `purchaseOrder` | 采购订单 |
| 市场活动 | `campaign` | 市场活动 |

> `activityrecord` 和 `campaign` 都匹配"活动"，必须向用户确认。
> 完整清单见 `references/standard-entities.md`。

### 硬性规则

1. **字段兜底规则（用户未指定字段时）**：
   a. **未登录状态**：用户未登录 Neo 平台时，组件代码中必须通过运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段，**不得**凭直觉杜撰字段名。
   b. **已登录状态**：用户已登录 Neo 平台时，通过 `neo-cmp-cli/scripts/fetchEntityDesc.js` 或运行时 `xObject.getFileds('<apiKey>')` 获取字段列表，取前 10 个字段（`data` 中的 `apiKey` 为字段 key 值），**不得**凭直觉杜撰字段名。
2. **`xObject.query`/`xObject.get` 的 `fields` 参数优先级**：
   a. 用户需求中明确提及的字段优先使用。
   b. 用户未提及字段时，遵循上述字段兜底规则。
3. **选取组件展示/交互字段时**：用户未指定字段时，遵循上述字段兜底规则获取字段列表，从查询结果的字段清单中按场景挑选（列表→常用展示字段、搜索→过滤键、录入→必填字段），**不得凭直觉杜撰字段名**。
4. 有歧义时向用户确认（如"客户"可能指 `account` / `potentialCustomer` / `partner`）。
5. apiKey 区分大小写。
6. 标准实体表找不到 → 可能是自定义实体（`custom: true`），建议 `xObject.getEntityList({ custom: true })` 运行时获取，或在 propsSchema 用 `xObjectEntityList` 让业务方选。

## 平台能力对接速览

| 能力 | 入口 | 参考文件 |
|---|---|---|
| 运行时用户/租户/页面信息 | `props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` | `references/runtime-context.md` |
| 全局工具、Toast、弹窗、导航 | `props.env.ctx`（`system`/`user`/`ui`/`util`/`api`） | `references/runtime-context.md` |
| 事件动作（触发/被调用/广播） | `NeoEvent.dispatch` / `NeoEvent.function` / `NeoEvent.broadcast` / `NeoEvent.listen` | `references/event-action.md` |
| 平台实体 CRUD | `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` / `getFileds` | `references/open-api.md` |
| 自定义 API / 通用代理 | `customApi.run` / `customApi.getList` / `request` | `references/open-api.md` |
| 平台列表组件 | H5: `NeoEntityList` / `GlobalSearchInput`；PC: `NeoEntityGrid`（必传 render） | `references/platform-components.md` |
| 自定义配置项 | amis `@FormItem` 注册 + propsSchema 自定义 type | `references/custom-props-item.md` |
| 模块共享 | `neo.config.js` 的 `neoCommonModule.exports` + remoteDeps | `references/module-sharing.md` |

## 开发完成后：选择预览 / linkDebug / 发布（第 12 步展开）

先给用户简结：组件目录、targetDevice、接入的平台能力、依赖/格式化结果。然后抛出三选项（**可多选，可跳过**）：

> ✅ **组件 `<cmpName>__c` 已开发完成。接下来要做什么？**
> 1. **预览（`neo preview`）** — 本地/在线预览；纯展示选 `local`，依赖平台运行时选 `online`
> 2. **外链调试（`neo linkDebug`）** — 挂到页面设计器联调（依赖运行时必选），targetDevice → `-p pc|h5`
> 3. **发布（`neo push cmp`）** — 构建推送到 NeoCRM（确保 `version` 已递增、已登录目标环境）

**转交规则**：参数收集后统一转交 `neo-cmp-cli` 执行，本技能禁止直接跑命令。同时勾选 linkDebug+发布 → 先联调后发布。发布前自检：ESLint/stylelint/tsc 通过、version 已递增、根节点 className 与目录名一致、事件动作声明齐备。

## 常见陷阱

- **根类名与目录名不一致** → 样式隔离失效；**未合并 `props.className`** → 设计器「是否显示」失效
- **SCSS 中使用 `&-xx` 语法**（如 `&__header`、`&--primary`）→ 必须写成独立完整选择器（`.cmpName__c__header`、`.cmpName__c--primary`）
- **事件动作不生效**：未 `extends BaseCmp` / 未 `bind(this)` / `model.events`/`functions` 未声明
- **propsSchema type 写成泛名**（`input`/`select`）→ 必须用平台真实类型（`panelInput`/`panelSelect` 等）
- **需求是读/写平台实体却自己写 `axios`** → 丢失登录态/权限/审计；**展示列表却手写 antd Table** → 失去 SmartView/批量操作
- **用户未指定字段时凭直觉写字段** → 必须根据登录状态通过 `xObject.getFileds('<apiKey>')`（未登录）或 `fetchEntityDesc.js`/`xObject.getFileds`（已登录）查实体已有字段（`data` 中的 `apiKey` 为字段 key 值），从查询结果中挑选
- **调外部 API 不部署通用代理** → CORS 与白名单双重拦截
- **依赖 props 的方法未在 componentDidUpdate 响应** → 属性面板配置变化后组件不刷新、数据不重新加载。检查是否遗漏了 `componentDidUpdate` 中对应 props 字段的监听（参见约束 5）
- **`neo-open-api` 未添加到 `package.json` 的 `dependencies`** → 构建产物缺少平台 SDK，运行时 `import` 报错找不到模块。`neo-open-api` 是**真实 NPM 包**，非虚拟模块，必须在 `package.json` 中安装（参见约束 7.1）
- **`xObject.query` 返回后错误地以 `result.data` 以外的字段取列表数据** → `xObject.query` 返回的 `data` 就是列表数组（`any[]`），使用 `result.data || []` 取值，**不是** `result.list` 或 `result.records`。详见约束 7.3 返回值速查表
- **`axios` 直接调用平台实体接口** → 丢失登录态、权限校验、审计日志，一律改用 `neo-open-api` 的 `xObject` 方法（参见约束 7.2）
- **错误处理用 `code === 0` 或 `code === 200` 判断成功** → 必须用 `status === true`。不同接口的 `code` 语义不一致，`status` 是统一判断标准（参见约束 7.3）
- **淘宝源策略见 `neo-cmp-cli` 技能**——安装依赖相关的源配置由 `neo-cmp-cli` 统一管理

## 参考文件

- `references/standard-entities.md` — 标准实体 apiKey ↔ label 映射 + 常见核心字段表
- `references/props-schema.md` — propsSchema 可用 type 清单（表单类+数据源类）
- `references/event-action.md` — 事件动作机制（dispatch/function/broadcast/listen）
- `references/open-api.md` — xObject CRUD + customApi + 通用代理
- `references/runtime-context.md` — `props.data.__Neo*` / `props.env.ctx` / keyIdentifier
- `references/platform-components.md` — NeoEntityList / NeoEntityGrid / GlobalSearchInput
- `references/custom-props-item.md` — 自定义配置项开发（amis @FormItem 注册）
- `references/model-file.md` — model.ts 各字段含义与取值约束
- `references/templates.md` — 内置模板选型指南
- `references/cmp-dev-case.md` — 常见开发案例（PC/H5 列表、商机 CRUD）
- `references/common-pitfalls.md` — 27 条陷阱大全
- `references/minimal-example.md` — 最小可运行示例（infoCard__c 完整源码）
- `references/styling.md` / `references/react-essentials.md` / `references/component-form.md`
- `references/platform-deps.md` — 平台预置依赖清单 + externals 机制
- `references/module-sharing.md` / `references/neo-cli-workflow.md` / `references/faq.md`
- `references/migration-from-vue.md` / `references/spec-checklist.md`
- `examples/` — 示例组件源码（xObject CRUD、customApi、事件动作）

## 资料来源

- Neo 平台文档：[neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/)（组件开发规范/CLI/配置项/数据源/事件动作/模板）
- React 官方：[react.dev](https://react.dev/learn) / React 16 Legacy：[legacy.reactjs.org](https://legacy.reactjs.org/)
- Airbnb React/JSX Style Guide：[github.com/airbnb/javascript/tree/master/react](https://github.com/airbnb/javascript/tree/master/react)

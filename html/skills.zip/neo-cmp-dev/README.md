# neo-cmp-dev Skill 说明

## 技能边界（三技能路由）

本技能负责**自定义组件的内部实现**（含 Neo 工程里无限定词的"组件开发 / 开发组件"诉求），命令执行和 Vue 语法迁移都不在本技能内完成：

| 用户意图 | 应使用的技能 |
|---|---|
| 实现 / 开发 / 改造 / 增强某个自定义组件的**具体功能**（`index.tsx` / `model.ts` / `propsSchema` / 事件动作 / 数据源 / 样式 / 自研 UI / 自定义配置项） | **`neo-cmp-dev`（本技能）** |
| **泛化的"组件开发 / 开发组件 / 写组件 / 实现组件"**（没显式带"自定义"字样，但工程是 neo-cmp-cli 组件工程） | **`neo-cmp-dev`（本技能）**，默认视作自定义组件开发 |
| 仅**执行 `neo` 命令**：创建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 外链调试 / 登录 / 登出 | `neo-cmp-cli`（本技能在第 3 / 10 / 11 步调用其命令；**第 11 步「预览 / linkDebug / 发布」选择由本技能询问后整体转交**） |
| 把 Vue 组件或项目**改造 / 转换 / 迁移**成自定义组件（有 Vue 源码输入） | `vue-to-react` 做语法迁移，之后再由本技能做平台规范落地 |

关键判别：只要用户要求"写 / 开发 / 实现 / 改造 / 增强 / 做"组件的内部代码——不论是否带"自定义"——都进入本技能；仅命令操作的场景**不要**进入本技能。

## 结构

- `SKILL.md` — 主文档，含 frontmatter（name + description，带触发关键词），技术栈默认、目录约定（`__c` 后缀）、**11 步开发关键步骤**（需求 → 模板选型 → **数据接入决策** → 初始化目录 → 模型 → 组件形态 → 实现 → 属性面板 → 事件动作 → 样式 → **安装依赖/格式化（转交 neo-cmp-cli）** → **询问用户预览 / linkDebug / 发布并转交 neo-cmp-cli**）、最小可运行示例（`infoCard__c`，含 `index.tsx` / `index.scss` / `model.ts` + `@NeoEvent.dispatch` / `@NeoEvent.function`）、数据接入决策表（平台实体数据源 vs 平台自定义 API vs 通用代理 vs `request`）、规范对齐表、预置依赖清单、常见陷阱（含实体 / 外部 API 误用项）、**开发完成后"选择预览 / linkDebug / 发布"的标准话术与转交规则**、参考文件索引、资料来源。
- `references/spec-checklist.md` — 组件开发规范速查（对齐 [组件开发规范](https://neo-cmp-docs.netlify.app/guide/组件开发规范)）+ 发布前检查清单。
- `references/cmp-dev-case.md` — **常见开发案例（Case 库）**：PC 端客户列表 / H5 端客户列表 / 商机列表（分页 + 新增 + 删除），每个 case 完整走 11 步并列出字段复核清单。
- `references/templates.md` — **内置模板选型指南**（`neo` / `neo-h5-cmps` / `neo-web-entity-grid` / `neo-web-form` / `antd` / `echarts` / `amap` / `neo-bi-cmps` / `neo-order-cmps` / `react-ts` / `react` / `vue2`）。
- `references/model-file.md` — `model.ts` 字段详解（含 `events` / `functions`）。
- `references/props-schema.md` — **`propsSchema` 平台真实类型**（表单类：`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `neoCheckbox` / `neoCascader` / `neoDatePicker` / ... 数据源类：`xObjectEntityList` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `selectFieldDescApi` / `dataViewIdSelect` / `customApi`）。
- `references/custom-props-item.md` — **自定义配置项开发**（amis `@FormItem` 注册 + 在 `propsSchema` 里使用）。
- `references/event-action.md` — **事件动作机制**（`@NeoEvent.dispatch` / `@NeoEvent.function` / 广播 / `BaseCmp`）。
- `references/runtime-context.md` — **组件运行时上下文**（`props.data.__Neo*`、`props.env.ctx` 的 system/user/ui/util/api、`keyIdentifier`）。
- `references/platform-components.md` — **平台预置业务组件**（`NeoEntityList` / `GlobalSearchInput` / `NeoEntityGrid`）与 `render` 透传规范。
- `references/standard-entities.md` — **Neo 平台标准实体参考**（438 个标准实体的 apiKey↔label 映射 + 常见核心实体字段表），从用户需求中识别实体 apiKey。
- `references/open-api.md` — **平台实体数据源 + 平台自定义 API**（`xObject` / `customApi` / `request` / 通用代理）。
- `references/module-sharing.md` — **组件模块共享**（`neoCommonModule.exports` / `remoteDeps` / `externals`）。
- `references/component-form.md` — 函数组件 vs 类组件决策（Neo 平台倾向类组件 + BaseCmp）+ Hooks 要点。
- `references/react-essentials.md` — React 官方手册要点 + Airbnb React/JSX 规范落地。
- `references/styling.md` — SCSS + stylelint 规范 + 样式隔离（含 `props.className` 合并约束）。
- `references/platform-deps.md` — 平台预置依赖 + externals + 虚拟模块清单（`neo-ui-common` / `neo-ui-component-*`）。
- `references/neo-cli-workflow.md` — `neo init` / `create` / `login` / `preview` / `linkDebug` / `push cmp` /
 `pull cmp` / `delete cmp` + Windows 安装问题。
- `references/faq.md` — **常见问题**（CLI 安装、授权、发布、设计器渲染、事件动作不生效、根节点样式失效等）。
- `references/migration-from-vue.md` — 从 Vue 组件迁移到 Neo React 自定义组件（与 `vue-to-react` 技能互补）。
- `examples/` — **示例组件源码**（从 cli 模板抽取的完整 React + TypeScript 组件，覆盖各平台能力，含 `customApi__c` / `entityTable__c` / `entityForm__c` / `entityDetail__c` / `simpleCmp__c` / `entityGrid__c~4` / `createForm__c` / `searchForm__c` / `EntityPickerList`）。

## 覆盖 [neo-cmp-docs 在线文档](https://neo-cmp-docs.netlify.app/) 的映射

| neo-cmp-docs 在线文档 | 对应 skill 文件 |
|---|---|
| [guide/安装](https://neo-cmp-docs.netlify.app/guide/安装) | `neo-cli-workflow.md` |
| [guide/快速开始](https://neo-cmp-docs.netlify.app/guide/快速开始) | `neo-cli-workflow.md`（快速开始路径）+ 
`SKILL.md`（开发步骤） |
| [guide/组件开发规范](https://neo-cmp-docs.netlify.app/guide/组件开发规范) | `spec-checklist.md` + `model-file.md` + `props-schema.md` + `styling.md` + `platform-deps.md` |
| [guide/CLI使用说明](https://neo-cmp-docs.netlify.app/guide/CLI使用说明) | `neo-cli-workflow.md` |
| [示例模板](https://neo-cmp-docs.netlify.app/示例模板) | `templates.md` |
| [常见问题](https://neo-cmp-docs.netlify.app/常见问题) | `faq.md` |
| [使用平台组件](https://neo-cmp-docs.netlify.app/使用平台组件) | `platform-components.md` |
| [cmpDocs/H5版列表组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/H5版列表组件使用说明) | `platform-components.md`（NeoEntityList 一节） |
| [cmpDocs/H5版全局搜索组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/H5版全局搜索组件使用说明) | `platform-components.md`（GlobalSearchInput 一节） |
| [cmpDocs/PC版列表组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/PC版列表组件使用说明) | `platform-components.md`（NeoEntityGrid 一节） |
| [config/组件属性配置项](https://neo-cmp-docs.netlify.app/config/组件属性配置项) | `props-schema.md`（顶层） |
| [config/表单类配置项](https://neo-cmp-docs.netlify.app/config/表单类配置项) | `props-schema.md`（表单类一节） |
| [config/数据源类配置项](https://neo-cmp-docs.netlify.app/config/数据源类配置项) | `props-schema.md`（数据源类一节） |
| [config/自定义配置项开发](https://neo-cmp-docs.netlify.app/config/自定义配置项开发) | `custom-props-item.md` |
| [datasource/平台实体数据源](https://neo-cmp-docs.netlify.app/datasource/平台实体数据源) | `open-api.md`（xObject 部分） |
| [datasource/平台自定义API](https://neo-cmp-docs.netlify.app/datasource/平台自定义API) | `open-api.md`（customApi / request / 通用代理） |
| [tools/事件动作机制](https://neo-cmp-docs.netlify.app/tools/事件动作机制) | `event-action.md` |
| [tools/组件运行时上下文](https://neo-cmp-docs.netlify.app/tools/组件运行时上下文) | `runtime-context.md` |
| [tools/组件模块共享](https://neo-cmp-docs.netlify.app/tools/组件模块共享) | `module-sharing.md` |
| [示例模板 · 示例组件](https://neo-cmp-docs.netlify.app/示例模板) | `examples/`（本地组件源码） |

## 核心能力

### 新增：Neo 平台实体识别

本技能新增**实体识别（Entity Recognition）**能力，可从用户需求中自动识别需要操作的 Neo 平台业务对象（xObject），映射出对应的 apiKey，并生成正确的 `xObject` CRUD 代码。

**工作流程**：
1. 用户提出需求 → Agent 扫描需求中的业务关键词（如"客户"、"联系人"、"订单"）
2. Agent 在 `references/standard-entities.md` 的 438 个标准实体的 apiKey ↔ label 映射表中匹配
3. 确定 apiKey 后，在生成的组件代码中使用 `neo-open-api` 的 `xObject.query` / `get` / `create` / `update` / `delete` 操作对应实体
4. 如需字段级信息，必须运行时调用 `xObject.getFileds`（返回的 `data` 中 `apiKey` 即为字段 key 值）

**覆盖场景**：
- 用户需要读取/新增/更新/删除平台业务对象数据
- 用户提到客户、联系人、订单、合同、销售机会、销售线索、产品、任务等标准实体
- 自定义实体（非 438 个标准实体）会提示用户通过运行时 API 获取

## 遵循 skill-creator 约定

- `SKILL.md` + `references/` 目录结构
- YAML frontmatter 含 `name` / `description`，描述带触发关键词
- 主文档 <500 行；参考文件按主题分拆
- 引用参考时给出明确进入时机（开发关键步骤右侧标注）
- 覆盖用户的核心需求：
  1. **组件开发规范**：主文档 + `spec-checklist.md` + `model-file.md` + `props-schema.md` + `styling.md`
  2. **React 官方手册**：`react-essentials.md`（已改写、带链接）
  3. **vue-to-react 关键节点 → React 开发关键步骤**：主文档 11 步 + `migration-from-vue.md`
  4. **Airbnb 规范**：`react-essentials.md` 给出具体落地
  5. **stylelint 规范**：`styling.md` 对齐 `akfun/src/config/.stylelintrc`
  6. **平台能力**：事件动作、运行时上下文、数据源、预置组件、模块共享、自定义配置项（六个专题文件）
  7. **数据接入决策**：SKILL 第 2 步内置扫描流程——平台实体数据源（xObject + 数据源类 propsSchema）优先，外部接口主动提示导入通用代理（forward.zip）并用 customApi 对接
  8. **安装依赖与全局格式化**：SKILL 第 10 步统一转交 `neo-cmp-cli` 技能执行（识别包管理器 → 安装全量依赖 → `npm run format`），不再由本技能直接执行安装命令
  9. **开发完成后转交 `neo-cmp-cli`**：SKILL 第 11 步不直接跑 `neo` 命令；向用户确认「预览 / linkDebug / 发布」的多选结果后，把参数（组件名、预览模式、调试端、发布环境）整体转交 `neo-cmp-cli` 技能执行

## 校验

- `npm run docs:dev` 通过
- 发布前 checklist 见 `references/spec-checklist.md`

# Neo 平台标准实体参考（实体识别用）

> **数据来源**：`xObject.getEntityList({ custom: false, active: true })` + `xObject.getDesc(apiKey)`，共 438 个标准实体。
>
> 完整实体字段明细（含每个实体的所有字段名、label、dataType、是否必填等）需要是啥获取。本文档只保留实体列表与常见实体字段示例，供 Agent 从用户需求中快速定位实体 apiKey。

## 使用场景

当用户需求涉及**读取 / 新增 / 更新 / 删除平台业务对象的数据**时，Agent 应：

1. 从用户描述中识别出**业务对象的名称**（如"客户"、"联系人"、"订单"、"销售机会"等）；
2. 在本表中查找对应的 **apiKey**（如 `account`、`contact`、`order`、`opportunity`）；
3. 在 `xObject.query` / `xObject.get` / `xObject.create` / `xObject.update` / `xObject.delete` 的 `xObjectApiKey` 参数中填入该 apiKey；
4. 如需字段级 info，查看各实体详情的字段表，从中识别用户提到的字段名称（如"客户名称" → `accountName`）；
5. 如需更完整的字段信息，可运行 `xObject.getDesc('<apiKey>')` 获取运行时元数据。

**实体识别匹配规则**：
- **模糊匹配**：用户可能使用中文简称（"客户" ↔ `account`）、英文 apiKey（"account" ↔ `account`）、或业务上下文（"我要看待办" ↔ `task`）。
- **优先匹配 label**：在实体总览表中按 `label` 列查找与用户描述最匹配的条目；同义词也需考虑（如"合作伙伴" → `partner`、"客户" → `account`）。
- **如有歧义**：向用户确认具体指向哪个实体。
- **字段识别**：在具体实体的字段表中按 `label` 列匹配用户提到的字段名，输出对应的 `apiKey`。

## 实体总览（438 个标准实体）

| # | apiKey | label |
|---|---|---|
| 1 | `account` | 客户 |
| 2 | `accountClassificationDetail` | 分类汇总 |
| 3 | `accountTransfer` | 账户转账 |
| 4 | `activityApply` | 活动申请 |
| 5 | `activityCheck` | 活动检核 |
| 6 | `activityExecutionReport` | 活动执行报告 |
| 7 | `activityGuide` | 活动稽查 |
| 8 | `activityrecord` | 活动记录 |
| 9 | `agent` | 代理商 |
| 10 | `aiActionReview` | AI行动审核 |
| 11 | `aiActionSuggestion` | AI行动建议 |
| 12 | `aiAgentLog` | AI智能体日志 |
| 13 | `aiDocSearchLog` | 文档检索日志 |
| 14 | `aiExecuteLog` | AI执行信息 |
| 15 | `aiExecutionResult` | AI执行结果 |
| 16 | `AIPromptTemplate` | AI提问模板 |
| 17 | `aiPromptTemplateLog` | 提示词模板日志 |
| 18 | `AIPromptTemplateParameter` | AI提问模板参数 |
| 19 | `AIPromptTemplateRelatedEntity` | AI提问模板关联实体 |
| 20 | `AIPromptTemplateSample` | AI提问模板答案样例 |
| 21 | `aiVisitSummary` | AI拜访总结 |
| 22 | `announceAttachment` | 公告附件 |
| 23 | `announceAttachmentDetail` | 公告附件明细 |
| 24 | `announceDetail` | 公告明细 |
| 25 | `announcement` | 公告 |
| 26 | `apply` | 审批 |
| 27 | `applyCustomer` | 申请客户 |
| 28 | `approvedDetails` | 结案明细 |
| 29 | `asset` | 资产 |
| 30 | `assetUpgradeRecord` | 升级召回记录 |
| 31 | `attendance` | 考勤统计 |
| 32 | `authGroup` | 数据权限团队 |
| 33 | `authGroupMember` | 数据权限团队成员 |
| 34 | `batchNumber` | 批次号 |
| 35 | `batchNumberInventory` | 批次号库存明细 |
| 36 | `blockedStock` | 库存冻结 |
| 37 | `bpmInstance` | 流程实例 |
| 38 | `bpmNodeInstance` | 流程节点实例 |
| 39 | `bpmNodeTaskLog` | 流程节点任务实例 |
| 40 | `bpmNodeTimingLog` | 流程节点时效实例 |
| 41 | `bpmProcdef` | 流程定义 |
| 42 | `bpmProcdefNode` | 流程节点定义 |
| 43 | `bpmProcdefTiming` | 流程节点时效定义 |
| 44 | `bpmProcInfo` | 流程基本信息 |
| 45 | `budgetAdjustment` | 预算调整 |
| 46 | `budgetDimension` | 预算维度 |
| 47 | `budgetDimensionDetail` | 预算维度明细 |
| 48 | `budgeting` | 预算制定 |
| 49 | `budgetingDetail` | 预算制定明细 |
| 50 | `budgetLevel` | 预算层级 |
| 51 | `budgetPool` | 预算池 |
| 52 | `budgetPoolDetail` | 预算池明细 |
| 53 | `budgetSubject` | 预算科目 |
| 54 | `budgetTemplate` | 预算模板 |
| 55 | `budgetTemplateDimension` | 预算层级维度 |
| 56 | `busiType` | 定制业务类型 |
| 57 | `campaign` | 市场活动 |
| 58 | `cartProduct` | 购物车商品 |
| 59 | `case` | 服务个案 |
| 60 | `cdrInvitedVisitors` | 数字空间受邀访客 |
| 61 | `cdrRecord` | 客户数字空间 |
| 62 | `cdrTemplate` | 数字空间模板 |
| 63 | `cdrTemplateClassify` | 数字空间模板分类 |
| 64 | `cdrVisitorDetailRecord` | 数字空间访客记录明细 |
| 65 | `cdrVisitorRecord` | 数字空间访客记录 |
| 66 | `changeOrderItem` | 变更单明细关系 |
| 67 | `channelAgreement` | 渠道协议 |
| 68 | `charge` | 收费 |
| 69 | `chargeDetail` | 收费明细 |
| 70 | `colleague` | 通讯录 |
| 71 | `columnValue` | 元素值 |
| 72 | `competitor` | 竞争对手 |
| 73 | `contact` | 联系人 |
| 74 | `contactRelationShip` | 联系人关系 |
| 75 | `contactRole` | 联系人角色 |
| 76 | `contract` | 合同 |
| 77 | `correctiveSuggestion` | 整改建议 |
| 78 | `costAccount` | 成本科目 |
| 79 | `costSheet` | 项目成本 |
| 80 | `costSheetDetail` | 项目成本明细 |
| 81 | `cpqAction` | 规则行为 |
| 82 | `cpqActionGroup` | 规则行为分组 |
| 83 | `cpqCondition` | 规则条件 |
| 84 | `cpqExpression` | 表达式 |
| 85 | `cpqExpressionItem` | 表达式条目 |
| 86 | `cpqRule` | 产品价格规则 |
| 87 | `cpqTemplate` | 规则模板 |
| 88 | `customerAccount` | 账户 |
| 89 | `customerAccountDetail` | 账户明细 |
| 90 | `customerAccountSetting` | 账户模板 |
| 91 | `customerDevice` | 客户注册资产 |
| 92 | `customerUser` | 客户用户 |
| 93 | `customMapItem` | 客户信息回填对照数据规则 |
| 94 | `dashboard` | 仪表盘 |
| 95 | `dataInsight` | 数据洞察 |
| 96 | `dataInsightAction` | 洞察行动建议 |
| 97 | `dayreport` | 工作报告 |
| 98 | `dealerRelationship` | 经销商关系 |
| 99 | `deductionRelationship` | 账户明细扣减关系 |
| 100 | `deliveryRecord` | 交付记录 |
| 101 | `deliveryRecordDetail` | 交付记录明细 |
| 102 | `department` | 部门 |
| 103 | `depotRepair` | 返修单 |
| 104 | `dispatchNote` | 发运单 |
| 105 | `dispatchNoteDetail` | 发运单明细 |
| 106 | `displayAgreement` | 陈列协议 |
| 107 | `displayAgreementDetail` | 陈列明细 |
| 108 | `displayProofDetail` | 陈列举证项目 |
| 109 | `displayRules` | 陈列规则 |
| 110 | `dnsQueryLog` | 邓白氏查询日志 |
| 111 | `emailTemplate` | 邮件模板 |
| 112 | `employeeSkill` | 员工技能 |
| 113 | `enterpriseChangeNoticeUserLog` | 工商信息变更通知用户日志 |
| 114 | `enterpriseInfoChangeLog` | 工商信息变更日志 |
| 115 | `entityBelongType` | 标准业务类型 |
| 116 | `entrustSetting` | 审批流委托配置 |
| 117 | `errorCode` | 故障代码 |
| 118 | `evaluation` | 客户评价 |
| 119 | `evaluationDetail` | 评价项 |
| 120 | `evaluationItemSetting` | 评价项设置 |
| 121 | `evaluationSetting` | 评价设置 |
| 122 | `exclusivityGroup` | 独占分组 |
| 123 | `expense` | 费用 |
| 124 | `expenseaccount` | 报销单 |
| 125 | `expensePayment` | 费用核销 |
| 126 | `expensePaymentDetail` | 核销明细 |
| 127 | `expensePaymentOrder` | 核销单 |
| 128 | `feed` | 动态 |
| 129 | `feiShuGroup` | 飞书群 |
| 130 | `feiShuGroupMember` | 飞书群成员 |
| 131 | `feiShuSidebar` | 飞书侧边栏 |
| 132 | `fieldJob` | 派工单 |
| 133 | `fieldJobCheckItem` | 检查项 |
| 134 | `fieldJobDetail` | 派工物料明细 |
| 135 | `fieldJobPool` | 派工池 |
| 136 | `fieldJobSea` | 派工池配置 |
| 137 | `fieldJobSeaItem` | 派工池配置项 |
| 138 | `fieldJobSkill` | 技能 |
| 139 | `fileEvent` | 文件行为轨迹 |
| 140 | `fileSearchLog` | 知识库搜索记录 |
| 141 | `fiscalYearSetting` | 财年设置 |
| 142 | `forecast` | 销售预测 |
| 143 | `formColumn` | 表单元素 |
| 144 | `formDoc` | 表单模板 |
| 145 | `formExamination` | 测评 |
| 146 | `formInstance` | 表单 |
| 147 | `formQuestion` | 题目 |
| 148 | `formSendTask` | 问卷发送记录 |
| 149 | `formVote` | 投票 |
| 150 | `goal` | 目标简版 |
| 151 | `goalProDetail` | 目标实例明细 |
| 152 | `goods` | 商品 |
| 153 | `goodsSpecification` | 商品规格 |
| 154 | `goodsSpecificationValue` | 商品规格值 |
| 155 | `goodsUnit` | 商品单位 |
| 156 | `group` | 群组 |
| 157 | `groupMemberExtends` | 客户团队成员继承 |
| 158 | `groupSop` | 群SOP |
| 159 | `groupSopInstance` | 群SOP执行实例 |
| 160 | `groupSopInstanceTask` | 群SOP实例任务 |
| 161 | `highSea` | 公海池 |
| 162 | `inventoryVerification` | 库存盘点 |
| 163 | `investigate` | 调查 |
| 164 | `invoice` | 应收单 |
| 165 | `invoiceAdjustment` | 应收变更单 |
| 166 | `invoiceItem` | 应收单明细 |
| 167 | `invoiceItemAdjustment` | 应收变更明细 |
| 168 | `invoiceOld` | 开票记录 |
| 169 | `invoicePayment` | 应收收款 |
| 170 | `invoicePaymentRefund` | 应收收款退款 |
| 171 | `invoiceReceipt` | 应收发票 |
| 172 | `lead` | 销售线索 |
| 173 | `likeDislikeLog` | 赞踩日志 |
| 174 | `living` | 企微直播 |
| 175 | `livingDetail` | 企微直播明细 |
| 176 | `mailinRepair` | 寄修单 |
| 177 | `mailinRepairItem` | 寄修产品明细 |
| 178 | `materialConsumed` | 物料消耗 |
| 179 | `materialConsumedDetail` | 物料消耗明细 |
| 180 | `materialRequisition` | 领料单 |
| 181 | `materialRequisitionDetail` | 领料单明细 |
| 182 | `materialReturn` | 退料单 |
| 183 | `materialReturnDetail` | 退料明细 |
| 184 | `mcEmail` | 邮件 |
| 185 | `mcEmailAttachment` | 邮件附件 |
| 186 | `mcEmailBoundEmployee` | 员工绑定邮箱 |
| 187 | `mcEmailStaff` | 邮件人员 |
| 188 | `mcEmailSyncConfig` | 邮件同步配置 |
| 189 | `mcEmailTokenManager` | 邮件插件Token管理 |
| 190 | `monthreport` | 月报 |
| 191 | `multiDimsGoal` | 多维度目标 |
| 192 | `notice` | 消息 |
| 193 | `oppActivity` | 商机关键事件 |
| 194 | `oppHealthAssessmentData` | 商机健康度评估数据 |
| 195 | `oppHealthAssessmentDimensionData` | 商机健康度评估维度数据 |
| 196 | `opportunity` | 销售机会 |
| 197 | `opportunityProduct` | 商机明细 |
| 198 | `opportunityRegister` | 商机报备 |
| 199 | `opportunityRegisterContact` | 商机报备联系人 |
| 200 | `oppProcess` | 商机每条数据的阶段流程信息 |
| 201 | `oppProcessFile` | 商机阶段文件 |
| 202 | `oppStagePeriod` | 商机阶段停留时间 |
| 203 | `oppStageUser` | 商机阶段用户 |
| 204 | `optionConstraint` | 产品约束关系 |
| 205 | `optionValue` | 选项值 |
| 206 | `order` | 订单 |
| 207 | `orderDetailsPromotionRelationship` | 订单明细促销关系 |
| 208 | `orderPayment` | 订单支付关系 |
| 209 | `orderProduct` | 订单明细 |
| 210 | `orderPromotion` | 订单促销关系 |
| 211 | `packingList` | 装箱单 |
| 212 | `packingListDetail` | 装箱单明细 |
| 213 | `partA` | 甲方 |
| 214 | `partner` | 合作伙伴 |
| 215 | `partnerCompanyInfo` | 伙伴公司信息 |
| 216 | `partnerMall` | 商城配置 |
| 217 | `parts` | 配件 |
| 218 | `payment` | 回款记录 |
| 219 | `paymentApplication` | 收款单 |
| 220 | `paymentApplicationPlan` | 收款计划 |
| 221 | `paymentItem` | 收款单明细 |
| 222 | `paymentplan` | 回款计划 |
| 223 | `periodAmount` | 期间金额 |
| 224 | `personalMaterialTransfer` | 个人库物料转移 |
| 225 | `personalOutOfStorage` | 个人库出入库记录 |
| 226 | `personalWarehouse` | 个人备件库 |
| 227 | `personalWarehouseDetail` | 个人备件库明细 |
| 228 | `pointDetail` | 积分明细 |
| 229 | `pointDetailSource` | 积分来源 |
| 230 | `pointPlan` | 积分方案 |
| 231 | `pointRule` | 积分规则 |
| 232 | `potentialCustomer` | 潜在客户 |
| 233 | `preventiveMaintenance` | 维保计划 |
| 234 | `preventiveMaintenanceDetail` | 维保计划明细 |
| 235 | `priceBook` | 价格表 |
| 236 | `priceBookEntry` | 价格表明细 |
| 237 | `priceSchedule` | 阶梯价格表 |
| 238 | `priceTier` | 阶梯价格表明细 |
| 239 | `privatemessage` | 企业微信 |
| 240 | `procurementPayment` | 采购付款 |
| 241 | `procurementPlan` | 采购计划 |
| 242 | `procurementPlanDetail` | 采购计划明细 |
| 243 | `product` | 产品 |
| 244 | `productCategory` | 产品目录 |
| 245 | `productDefaultUnit` | 产品默认单位 |
| 246 | `productFeature` | 产品功能 |
| 247 | `productFeaturePriceSchedule` | 产品功能阶梯价格表 |
| 248 | `productMarket` | 产品铺市 |
| 249 | `productOption` | 产品选项 |
| 250 | `productOptionPriceSchedule` | 产品选项阶梯价格表 |
| 251 | `productPriceSchedule` | 产品阶梯价格表 |
| 252 | `productRequirement` | 产品需求 |
| 253 | `productRuleItem` | 产品设置明细 |
| 254 | `productUnit` | 产品单位 |
| 255 | `projectBaseLine` | 项目基线 |
| 256 | `projectBudget` | 项目预算 |
| 257 | `projectBudgetDetail` | 项目预算明细 |
| 258 | `projectChange` | 项目变更 |
| 259 | `projectPeriod` | 期间 |
| 260 | `projectRisk` | 项目风险 |
| 261 | `promotionLimited` | 限量限额 |
| 262 | `promotionLimitedFlow` | 限量限额流水 |
| 263 | `promotionProduct` | 促销品 |
| 264 | `purchaseOrder` | 采购订单 |
| 265 | `purchaseOrderDetail` | 采购订单明细 |
| 266 | `purchaseReturn` | 采购退货 |
| 267 | `purchaseReturnDetail` | 采购退货明细 |
| 268 | `qualityAssurance` | 质保 |
| 269 | `qualityAssuranceFile` | 质保档案 |
| 270 | `qualityAssuranceProduct` | 质保产品 |
| 271 | `questionBank` | 题库 |
| 272 | `quote` | 报价单 |
| 273 | `quoteLine` | 报价单明细 |
| 274 | `qwChatRecordStatistics` | 企微会话统计 |
| 275 | `qwContact` | 企微联系人 |
| 276 | `qwGroup` | 企微客户群 |
| 277 | `qwGroupMember` | 企微群成员 |
| 278 | `qwGroupOnJobAssignedResult` | 群转接记录 |
| 279 | `qwGroupTagLog` | 群标签日志 |
| 280 | `qwLLMInvokeRecord` | 企微大模型调用记录 |
| 281 | `qwLLMInvokeStatistics` | 企微大模型调用记录 |
| 282 | `qwSidebar` | 企微好友关系 |
| 283 | `qwTagRelation` | 企微标签关系 |
| 284 | `rebateCondition` | 返利规则条件 |
| 285 | `rebatePlan` | 返利方案 |
| 286 | `rebateRule` | 返利规则 |
| 287 | `rebateRuleItem` | 返利规则明细 |
| 288 | `rebateSchedule` | 执行档期 |
| 289 | `rebateVerification` | 返利核销 |
| 290 | `rebateVerificationDetail` | 返利核销明细 |
| 291 | `receipt` | 发票 |
| 292 | `receiptItem` | 发票明细 |
| 293 | `receiveNote` | 收货单 |
| 294 | `receiveNoteDetail` | 收货单明细 |
| 295 | `reconciliationConfiguration` | 对账配置 |
| 296 | `reconciliationDetails` | 对账明细 |
| 297 | `reconciliationStatement` | 对账单 |
| 298 | `redReceipt` | 红字发票 |
| 299 | `redReceiptItem` | 红字发票明细 |
| 300 | `refund` | 退款 |
| 301 | `refundItem` | 退款明细 |
| 302 | `relatedProduct` | 关联产品 |
| 303 | `repairJob` | 维修项 |
| 304 | `repairTask` | 维修项记录 |
| 305 | `repairTemplate` | 维修项模板 |
| 306 | `repairTemplateItem` | 维修模板条目 |
| 307 | `report` | 报表 |
| 308 | `rescenter` | 知识库 |
| 309 | `resourceHour` | 资源分配工时 |
| 310 | `resourceManagement` | 资源 |
| 311 | `returnMaterialAuthorization` | 退货授权 |
| 312 | `returnMaterialAuthorizationDetail` | 退货授权明细 |
| 313 | `ruleExecution` | 规则执行记录 |
| 314 | `ruleSet` | 规则组合 |
| 315 | `saleableScope` | 可售范围 |
| 316 | `salesanalysis` | 销售绩效分析 |
| 317 | `salesPerformanceSplit` | 销售业绩拆分 |
| 318 | `salesPromotion` | 促销活动 |
| 319 | `salesPromotionCounter` | 促销累加 |
| 320 | `salesPromotionCounterDetail` | 促销累加明细 |
| 321 | `salesPromotionMapping` | 促销活动关系 |
| 322 | `salesPromotionRule` | 促销活动规则 |
| 323 | `salesSOP` | 销售SOP |
| 324 | `salesSOPInstance` | 销售SOP执行实例 |
| 325 | `salesSOPInstanceTask` | 销售SOP任务执行记录 |
| 326 | `schedule` | 日程 |
| 327 | `scheduleMember` | 日程成员 |
| 328 | `scoreRecord` | 计分记录 |
| 329 | `scoringSummary` | 计分汇总 |
| 330 | `segmentDirectory` | 细分群组目录 |
| 331 | `segmentInsight` | 客户画像 |
| 332 | `segmentInsightView` | 客户画像视图 |
| 333 | `segmentMember` | 细分群组成员 |
| 334 | `segmentMemberLog` | 群组成员日志 |
| 335 | `segmentRule` | 细分群组 |
| 336 | `sensitiveWordInstance` | 敏感词监控 |
| 337 | `serialNumber` | 序列号 |
| 338 | `serialNumberTracking` | 序列号跟踪记录 |
| 339 | `serviceAttendance` | 现场服务考勤 |
| 340 | `serviceBill` | 结算单 |
| 341 | `serviceBillConfig` | 结算设置 |
| 342 | `serviceBillDetail` | 结算单明细 |
| 343 | `serviceCall` | 语音 |
| 344 | `serviceCase` | 服务工单 |
| 345 | `serviceEngineer` | 服务工程师 |
| 346 | `serviceKnowledge` | 知识条目 |
| 347 | `serviceOutlet` | 服务网点 |
| 348 | `serviceProject` | 服务项目 |
| 349 | `serviceReport` | 服务报告记录 |
| 350 | `serviceStage` | 服务阶段 |
| 351 | `serviceTask` | 服务任务 |
| 352 | `serviceTeam` | 服务团队 |
| 353 | `serviceVisitHistory` | 互动历史 |
| 354 | `serviceVisitor` | 访客 |
| 355 | `shippingAddress` | 收货地址 |
| 356 | `skillModel` | 评分模型 |
| 357 | `skillRequired` | 必备技能 |
| 358 | `skillScore` | 评分项 |
| 359 | `solution` | 解决方案 |
| 360 | `specification` | 规格 |
| 361 | `specificationValue` | 规格值 |
| 362 | `stagePushRank` | 商机阶段推进排行 |
| 363 | `stageTrack` | 商机阶段轨迹 |
| 364 | `statementRecord` | 申诉记录 |
| 365 | `stockIn` | 入库单 |
| 366 | `stockInDetail` | 入库单明细 |
| 367 | `stockOut` | 出库单 |
| 368 | `stockOutDetail` | 出库单明细 |
| 369 | `stockTaking` | 盘库单 |
| 370 | `stockTakingDetail` | 盘库单明细 |
| 371 | `stockTransfer` | 移库单 |
| 372 | `stockTransferDetail` | 移库单明细 |
| 373 | `substitutesProduct` | 替代产品 |
| 374 | `suggest` | 建议 |
| 375 | `suggestDetail` | 建议明细 |
| 376 | `summaryValue` | 汇总值 |
| 377 | `tableValue` | 表格值 |
| 378 | `tagGroup` | 标签目录 |
| 379 | `tagResult` | 标签结果 |
| 380 | `tagRule` | 规则标签 |
| 381 | `targetReached` | 目标达成情况 |
| 382 | `task` | 任务 |
| 383 | `taskMember` | 任务成员 |
| 384 | `taskResource` | 任务资源分配 |
| 385 | `teamMember` | 团队成员 |
| 386 | `terminal` | 终端 |
| 387 | `territory` | 区域 |
| 388 | `territoryAdministrator` | 区域管理员 |
| 389 | `territoryAssignLog` | 区域分配日志 |
| 390 | `territoryAssignLogDetail` | 区域分配日志详情 |
| 391 | `territoryCoverage` | 区域覆盖 |
| 392 | `territoryCoverageDimension` | 区域覆盖维度 |
| 393 | `territoryCoverageDimensionMember` | 区域覆盖维度值 |
| 394 | `territoryDimension` | 区域维度 |
| 395 | `territoryModel` | 区域模型 |
| 396 | `territoryModelDimension` | 区域模型维度关联 |
| 397 | `territoryObjectAssignConfig` | 区域实体资源分配 |
| 398 | `territoryObjectFollowAssign` | 区域实体跟随 |
| 399 | `territoryObjectRelation` | 区域实体关联 |
| 400 | `territoryObjectRelationship` | 区域实体预演 |
| 401 | `territoryObjectRule` | 区域特殊规则 |
| 402 | `territoryRecycleRule` | 资源规则 |
| 403 | `territoryResourceGroupMember` | 区域资源负责人 |
| 404 | `territoryResourceObjectRecycle` | 区域资源实体规则 |
| 405 | `territoryResourceRecycle` | 区域资源设置 |
| 406 | `territoryRole` | 区域角色 |
| 407 | `territoryRule` | 区域规则 |
| 408 | `territorySourceObject` | 区域实体默认权限 |
| 409 | `territoryWorkObject` | 区域模型实体关联 |
| 410 | `territoryWorkObjectAssignment` | 区域资源分配记录 |
| 411 | `territoryWorkObjectMatchingMap` | 区域实体映射 |
| 412 | `territoryWorkObjectRecycleLog` | 区域资源日志 |
| 413 | `timeSheet` | 时间表 |
| 414 | `trackanalysis` | 轨迹分析 |
| 415 | `unit` | 单位 |
| 416 | `unknownEntry` | 未知问题 |
| 417 | `user` | 用户 |
| 418 | `userprofile` | 用户Profile |
| 419 | `visit` | 巡访记录 |
| 420 | `visitcollect` | 巡访统计 |
| 421 | `visitPlan` | 拜访计划 |
| 422 | `visitPlanDetail` | 拜访日程 |
| 423 | `visitProductRule` | 产品设置 |
| 424 | `visitRecord` | 拜访记录 |
| 425 | `visitRecordNote` | 补充说明 |
| 426 | `visitRoute` | 拜访路线 |
| 427 | `visitRouteRelation` | 拜访路线关系 |
| 428 | `visitScenario` | 拜访场景 |
| 429 | `warehouse` | 仓库 |
| 430 | `warehouseDetail` | 仓库明细 |
| 431 | `weChatEmployeeChatStatistics` | 企微员工会话统计 |
| 432 | `WeChatFriendChatStatistics` | 企微好友会话统计 |
| 433 | `weChatGroupChatStatistics` | 企微群会话统计 |
| 434 | `weChatGroupMemberChatStatistics` | 企微群成员会话统计 |
| 435 | `weekreport` | 周报 |
| 436 | `workReport` | 工作报告(新) |
| 437 | `workreportstatistic` | 工作报告统计 |
| 438 | `wxVisitor` | 微信访客 |

## 常见核心实体字段参考

以下是 Neo 平台最常用的核心实体及其字段表。字段表结构：

| apiKey | label | dataType | required | description |
|---|---|---|---|---|

### 客户 `account`（76 个字段）

- **apiKey**: `account`
- **label**: 客户

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 客户类型 | entitytype | 是 |  |
| `ownerId` | 客户所有人 | owner | 否 |  |
| `accountName` | 客户名称 | text | 是 |  |
| `level` | 客户级别 | picklist | 否 |  |
| `parentAccountId` | 上级客户 | reference | 否 |  |
| `industryId` | 行业 | picklist | 否 |  |
| `fState` | 省份 | picklist | 否 |  |
| `fCity` | 市 | picklist | 否 |  |
| `fDistrict` | 区 | picklist | 否 |  |
| `longitude` | 经度 | float | 否 |  |
| `latitude` | 纬度 | float | 否 |  |
| `address` | 详细地址 | text | 否 |  |
| `phone` | 电话 | phone | 否 |  |
| `employeeNumber` | 总人数 | int | 否 |  |
| `annualRevenue` | 销售额 | currency | 否 |  |
| `accountChannel` | 来源方式 | picklist | 否 |  |
| `createdAt` | 创建日期 | datetime | 是 |  |
| `createdBy` | 创建人 | reference | 是 |  |
| `updatedAt` | 最新修改日 | datetime | 否 |  |
| `updatedBy` | 最新修改人 | reference | 否 |  |
| `comment` | 备注 | textarea | 否 |  |
| `approvalStatus` | 审批状态 | picklist | 否 |  |
| `lockStatus` | 锁定状态 | picklist | 否 |  |
| `totalWonOpportunities` | 结单商机数 | formula_aggregate | 否 |  |
| `paidAmount` | 实际收款金额 | formula_aggregate | 否 |  |
| `invoiceBalance` | 应收余额（欠款） | formula_aggregate | 否 |  |
| `totalOrderAmount` | 订单总金额 | formula_aggregate | 否 |  |
| `totalContract` | 合同数 | formula_aggregate | 否 |  |
| `visitLatestTime` | 最近拜访时间 | datetime | 否 |  |
| `visitUnvisitDay` | 未拜访天数 | int | 否 |  |

### 联系人 `contact`（约 50+ 个字段）

- **apiKey**: `contact`
- **label**: 联系人

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 联系人类型 | entitytype | 是 |  |
| `ownerId` | 联系人负责人 | owner | 否 |  |
| `accountId` | 所属客户 | reference | 否 | 关联客户 |
| `lastName` | 姓 | text | 是 |  |
| `firstName` | 名 | text | 否 |  |
| `salutation` | 称呼 | picklist | 否 |  |
| `email` | 邮箱 | email | 否 |  |
| `phone` | 电话 | phone | 否 |  |
| `mobilePhone` | 手机 | phone | 否 |  |
| `title` | 职位 | text | 否 |  |
| `department` | 部门 | text | 否 |  |
| `birthDate` | 生日 | date | 否 |  |
| `address` | 地址 | text | 否 |  |
| `weixinId` | 微信 | text | 否 |  |
| `createdAt` | 创建日期 | datetime | 否 |  |
| `createdBy` | 创建人 | reference | 是 |  |

### 销售机会 `opportunity`（约 50+ 个字段）

- **apiKey**: `opportunity`
- **label**: 销售机会

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 商机类型 | entitytype | 是 |  |
| `ownerId` | 商机负责人 | owner | 否 |  |
| `name` | 商机名称 | text | 是 |  |
| `accountId` | 客户名称 | reference | 否 | 关联客户 |
| `contactId` | 联系人 | reference | 否 | 关联联系人 |
| `amount` | 商机金额 | currency | 否 |  |
| `expectedRevenue` | 预计收入 | currency | 否 |  |
| `probability` | 赢率(%) | int | 否 |  |
| `stageName` | 销售阶段 | picklist | 否 |  |
| `closeDate` | 预计结单日期 | date | 否 |  |
| `leadSource` | 线索来源 | picklist | 否 |  |
| `description` | 描述 | textarea | 否 |  |
| `createdAt` | 创建日期 | datetime | 否 |  |
| `createdBy` | 创建人 | reference | 是 |  |

### 订单 `order`（约 20+ 个字段）

- **apiKey**: `order`
- **label**: 订单

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 订单类型 | entitytype | 是 |  |
| `ownerId` | 订单负责人 | owner | 否 |  |
| `name` | 订单编号 | text | 是 |  |
| `accountId` | 客户 | reference | 否 | 关联客户 |
| `contactId` | 联系人 | reference | 否 | 关联联系人 |
| `effectiveDate` | 生效日期 | date | 否 |  |
| `status` | 订单状态 | picklist | 否 |  |
| `totalAmount` | 订单金额 | currency | 否 |  |
| `description` | 描述 | textarea | 否 |  |
| `createdAt` | 创建日期 | datetime | 否 |  |
| `createdBy` | 创建人 | reference | 是 |  |

### 销售线索 `lead`（约 30+ 个字段）

- **apiKey**: `lead`
- **label**: 销售线索

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 线索类型 | entitytype | 是 |  |
| `ownerId` | 线索负责人 | owner | 否 |  |
| `lastName` | 姓 | text | 是 |  |
| `firstName` | 名 | text | 否 |  |
| `company` | 公司 | text | 否 |  |
| `title` | 职位 | text | 否 |  |
| `email` | 邮箱 | email | 否 |  |
| `phone` | 电话 | phone | 否 |  |
| `mobilePhone` | 手机 | phone | 否 |  |
| `leadSource` | 线索来源 | picklist | 否 |  |
| `status` | 线索状态 | picklist | 否 |  |
| `description` | 描述 | textarea | 否 |  |
| `createdAt` | 创建日期 | datetime | 否 |  |
| `createdBy` | 创建人 | reference | 是 |  |

### 合同 `contract`

- **apiKey**: `contract`
- **label**: 合同

| apiKey | label | dataType | required | description |
|---|---|---|---|---|
| `entityType` | 合同类型 | entitytype | 是 |  |
| `ownerId` | 合同负责人 | owner | 否 |  |
| `name` | 合同名称 | text | 是 |  |
| `accountId` | 客户 | reference | 否 | 关联客户 |
| `contractAmount` | 合同金额 | currency | 否 |  |
| `startDate` | 开始日期 | date | 否 |  |
| `endDate` | 结束日期 | date | 否 |  |
| `status` | 合同状态 | picklist | 否 |  |
| `createdAt` | 创建日期 | datetime | 否 |  |
| `createdBy` | 创建人 | reference | 是 |  |

## 更多实体字段

其它实体（`product` / `task` / `invoice` / `contract` / `case` 等）的完整字段明细见：

- **`scripts/output-cd/standard-entities.md`**（完整 438 个实体 × 所有字段，15973 行）
- **运行时元数据**：在组件中用 `xObject.getDesc('<apiKey>')` 动态获取字段信息

## 参考

- [neo-cmp-docs - 平台实体数据源](https://neo-cmp-docs.netlify.app/datasource/平台实体数据源)
- `neo-cmp-skills/scripts/output-cd/standard-entities.md`（完整实体明细源文件）
- `references/open-api.md`（`neo-open-api` 的 `xObject` / `customApi` / `request` 用法）

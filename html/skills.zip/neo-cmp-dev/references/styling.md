# 样式规范（SCSS + stylelint）

本工程使用 **SCSS + stylelint-config-standard**（见 `akfun/src/config/.stylelintrc`）。核心诉求：**组件样式不污染平台全局、不被其他组件污染**。

::: v-pre

## 根类名约定（样式隔离生效的前提）

- **组件最外层容器的 className 必须与组件目录名一致**（平台约定目录名使用 `__c` 后缀，如 `infoCard__c`、`button__c`）。
- **根节点必须合并 `props.className`**（设计器会向 `props.className` 注入 `design-hide` 控制显隐）：

  ```tsx
  <div className={classnames('infoCard__c', this.props.className)}>
  ```

- 组件内部其他类使用 **BEM 风格** 在根类名下派生：`infoCard__c__header`、`infoCard__c--primary`。
- 嵌套层级建议 ≤ 3 层，优先用平铺选择器。

```scss
/* ✅ BEM 平铺：独立写出完整选择器 */
.infoCard__c {
  padding: 12px;

  &:hover { background: #f5f5f5; }   /* 伪类可用 & */
}

.infoCard__c__header { font-weight: 600; }
.infoCard__c__body   { color: #333; }
.infoCard__c--sm     { padding: 8px; }

/* ❌ 禁止 &-xx 语法（父选择器拼接 BEM 子元素/修饰符） */
.infoCard__c {
  &__header { font-weight: 600; }  /* 不允许 */
  &--sm     { padding: 8px; }      /* 不允许 */
}

/* ❌ 嵌套过深 */
.infoCard__c {
  .wrapper {
    .inner {
      .row { .col { color: red; } }
    }
  }
}
```

## 构建时样式隔离

CLI 在 `push cmp` / `linkDebug` 时会把 `(index|style).(scss|less)` 的顶层规则包一层属性选择器，作用域 key 是组件目录名：

```scss
/* 源码 */
.infoCard__c { padding: 12px; }
.infoCard__c__header { font-weight: 600; }

/* 产物（示意） */
[data-scope="infoCard__c"] .infoCard__c { padding: 12px; }
[data-scope="infoCard__c"] .infoCard__c__header { font-weight: 600; }
```

CLI 会在根节点上自动加 `data-scope` 属性，**不需要手动加**。前提是根节点 className 能被顶层规则匹配。

**关闭隔离**：`neo.config.js` 设 `disableAutoAddStyleScope: true`。一般不建议关闭，因为同页面会有多个自定义组件共存，关闭后样式会相互污染。

## stylelint 规则（工程基线）

工程配置（`akfun/src/config/.stylelintrc`）：

```json
{
  "defaultSeverity": "warning",
  "extends": "stylelint-config-standard",
  "rules": {
    "string-quotes": "single",
    "no-empty-source": null,
    "at-rule-no-unknown": null,
    "property-no-unknown": [true, { "ignoreProperties": ["composes"] }],
    "selector-pseudo-class-no-unknown": [true, { "ignorePseudoClasses": ["global"] }]
  }
}
```

**要点**：

- **字符串使用单引号**：`content: 'x';`、`font-family: 'PingFang SC';`
- 继承 `stylelint-config-standard`：命名规则（kebab-case）、色值简写、零值省略、排序等都按标准来
- `at-rule-no-unknown` 已关闭 → 允许 SCSS 的 `@include` / `@mixin` 等 at-rule
- `composes` 属性允许（CSS Modules）
- `:global` 伪类允许（CSS Modules 穿透）

**常见标准规则（容易踩坑）**：

| 规则 | 说明 |
|---|---|
| `color-hex-length: short` | `#ffffff` 要写成 `#fff` |
| `color-hex-case: lower` | 颜色值小写 |
| `length-zero-no-unit` | `0px` → `0` |
| `shorthand-property-no-redundant-values` | `margin: 8px 16px 8px 16px` → `margin: 8px 16px` |
| `declaration-block-no-duplicate-properties` | 同一规则块内属性不重复 |
| `selector-class-pattern` | 类名 kebab-case（BEM 形式也满足） |
| `at-rule-empty-line-before: always` | `@include` 等前面空一行 |
| `declaration-colon-space-after: always-single-line` | 冒号后一空格 |

> 运行 `npx stylelint "src/**/*.{scss,less,css}"` 查看违规；`--fix` 可自动修复一部分。

## SCSS 使用指南

### 变量

```scss
$primary-color: #1890ff;
$text-color-base: rgba(0, 0, 0, 0.85);
$border-radius-base: 4px;

.infoCard__c {
  color: $text-color-base;
  border-radius: $border-radius-base;
  border: 1px solid $primary-color;
}
```

### 嵌套与 `&`

**约束**：禁止使用 `&-xx` 语法（父选择器拼接 BEM 子元素/修饰符）。伪类（`:hover`、`:focus`、`:disabled` 等）用 `&` 是允许的。

```scss
/* ✅ 伪类使用 & */
.btn {
  background: #fff;
  &:hover { background: #f5f5f5; }
  &:disabled { opacity: 0.5; }
}

/* ✅ 修饰符：独立完整选择器 */
.btn--primary { background: $primary-color; color: #fff; }

/* ❌ 禁止 &-xx 拼接修饰符 */
.btn {
  &--primary { background: $primary-color; color: #fff; }  /* 不允许 */
}
```

### `@mixin` / `@include`

```scss
@mixin ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.infoCard__c__title { @include ellipsis; }
```

### `@import` / `@use`

- 拆分文件；新项目推荐 `@use`（模块化）。
- 具体以 sass 版本支持为准。

## 弹层类样式放哪

antd 的 Modal / Popover / Tooltip / Dropdown / Select 等组件会把**浮层 DOM 挂到 body**，不在组件根节点下，样式隔离对它们无效。

**解决方案**：把这类样式放在 **`common.scss`** 或 **`reset.scss`**（默认**不做隔离**）：

```
src/components/infoCard__c/
├── index.tsx
├── index.scss        # 组件本体样式（会被隔离）
└── common.scss       # 弹层 / 全局覆盖样式（不会被隔离）
```

在 `index.tsx` 里一起引入：

```tsx
import './index.scss';
import './common.scss';
```

**典型弹层样式**：

```scss
/* common.scss */
.infoCard__c-popover {
  .ant-popover-inner { padding: 8px 12px; }
  .ant-popover-title { font-weight: 500; }
}

.infoCard__c-modal {
  .ant-modal-header { background: #fafafa; }
}
```

使用时给 antd 组件加对应的 className：

```tsx
<Popover overlayClassName="infoCard__c-popover" content={...}>
<Modal className="infoCard__c-modal" ...>
```

## 公共变量与全局注入

`neo.config.js` 支持 `webpack.sassResources`：把公共 SCSS 文件自动注入到每个 scss 文件编译流程里，无需每个组件手动 `@import`：

```js
// neo.config.js
module.exports = {
  webpack: {
    sassResources: [
      'src/assets/css/common.scss',
      'src/assets/css/mixin.scss',
    ],
  },
};
```

> 修改 `sassResources` 后需要重启本地调试 / linkDebug。

在 `common.scss` / `mixin.scss` 里集中声明变量和 mixin，组件直接用：

```scss
/* src/assets/css/common.scss */
$primary-color: #1890ff;
$text-primary: rgba(0, 0, 0, 0.85);

/* src/assets/css/mixin.scss */
@mixin ellipsis { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
```

```scss
/* src/components/infoCard__c/index.scss */
.infoCard__c {
  color: $text-primary;            /* 自动可用，不用 @import */
}
.infoCard__c__title { @include ellipsis; }
```

## 典型示例

```scss
/* src/components/orderCard__c/index.scss */
.orderCard__c {
  display: flex;
  flex-direction: column;
  padding: 12px 16px;
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 4px;
  transition: box-shadow 0.2s;

  &:hover {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  }
}

.orderCard__c__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  font-weight: 600;
  font-size: 14px;
}

.orderCard__c__body {
  color: rgba(0, 0, 0, 0.65);
  font-size: 13px;
  line-height: 20px;
}

.orderCard__c__amount {
  font-family: 'DIN Alternate', sans-serif;
  font-weight: 500;
}

.orderCard__c--sm { padding: 8px 12px; }
.orderCard__c--lg { padding: 16px 24px; }

.orderCard__c--dark {
  background: #1f1f1f;
  color: rgba(255, 255, 255, 0.85);
  border-color: #303030;
}
```

对应组件：

```tsx
import classnames from 'classnames';
import './index.scss';

const OrderCardC: React.FC<Props> = ({ size = 'middle', theme = 'light', className, ...rest }) => (
  <div
    className={classnames(
      'orderCard__c',
      size === 'small' && 'orderCard__c--sm',
      size === 'large' && 'orderCard__c--lg',
      theme === 'dark' && 'orderCard__c--dark',
      className,                       /* 合并平台注入的 className */
    )}
  >
    {/* ... */}
  </div>
);
```

## 常见陷阱

- **使用了 `&-xx` 语法（如 `&__header`、`&--primary`）** → 必须写成独立的完整选择器（如 `.cmpName__c__header`、`.cmpName__c--primary`）。
- **忘了在根节点写目录名 className** → 样式隔离失效，样式丢失或被覆盖。
- **根节点没合并 `props.className`** → 设计器「是否显示」设为「否」时 `design-hide` 不生效，组件仍然可见。
- **在 `index.scss` 里写弹层组件样式** → 构建产物被作用域包住，弹层上选择器不匹配 → 样式不生效。
- **单位 `0px`** → stylelint 报错，改 `0`。
- **颜色值大写** → stylelint 报错，改小写。
- **`@import 'x.scss';` 带扩展名** → 推荐省略：`@import 'x';`。
- **多用 `!important`** → 违反可维护性，优先提高选择器特异性或检查是否被 antd 全局样式覆盖。

:::

# 函数组件 vs 类组件 & Hooks 要点

::: v-pre

## 决策流程（Neo 平台特有）

```
需要事件动作（被其他组件调用）？        → 是 → 类组件 + extends BaseCmp（必须）
需要对外触发事件给其他组件？            → 是 → 类组件 + @NeoEvent.dispatch（必须）
需要组件控制 / 组件可见性能力？          → 是 → 类组件 + extends BaseCmp（必须）
需要 ErrorBoundary？                  → 是 → 类组件（React 唯一实现）
需要 getSnapshotBeforeUpdate？        → 是 → 类组件
状态 ≤ 3 个 + effect ≤ 2 个 + 无以上需求 → 是 → 函数组件 + Hooks
默认 → 函数组件 + Hooks
```

> **经验**：Neo 平台自定义组件大部分会需要事件动作，所以**默认用类组件 + `extends BaseCmp`**。纯展示的子组件（例如 `entityGrid3__c` 这种 Picker 内部使用的）才用函数组件。

## 类组件 + BaseCmp（Neo 平台推荐）

```tsx
// @ts-ignore 平台运行时注入
import { BaseCmp, NeoEvent } from 'neo-ui-common';
import * as React from 'react';
import classnames from 'classnames';
import './index.scss';

interface Props {
  title?: string;
  className?: string;
  onConfirm?: (v: string) => void;
}

interface State {
  value: string;
}

export default class MyCmpC extends BaseCmp<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { value: '' };

    // 组件动作使用 this 时必须绑定上下文
    this.handleClick = this.handleClick.bind(this);
    this.refresh = this.refresh.bind(this);
  }

  componentDidMount() {
    // 挂载副作用
  }

  componentWillUnmount() {
    // 清理
  }

  handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ value: e.target.value });
  };

  /** 对外触发的事件 */
  @NeoEvent.dispatch
  onSubmit(value: string) { return value; }

  /** 可被其他组件事件动作调用 */
  @NeoEvent.function
  async refresh() {
    // 重新拉数据、更新状态
    this.forceUpdate();
  }

  handleClick() {
    const { value } = this.state;
    const { onConfirm } = this.props;
    if (value.trim()) {
      this.onSubmit(value);
      onConfirm?.(value);
    }
  }

  render() {
    const { title = '默认', className } = this.props;
    const { value } = this.state;
    const disabled = !value.trim();

    return (
      <div className={classnames('myCmp__c', { 'myCmp__c--disabled': disabled }, className)}>
        <h3 className="myCmp__c__title">{title}</h3>
        <input className="myCmp__c__input" value={value} onChange={this.handleChange} />
        <button type="button" disabled={disabled} onClick={this.handleClick}>
          确认
        </button>
      </div>
    );
  }
}
```

**要点**：

- **`extends BaseCmp`**：事件动作、组件控制、组件可见性能力全依赖它。
- **构造函数 `super(props)` 首行**，紧接着 `this.state` 初始化，**最后 `bind(this)`**。
- 事件回调可用**类属性箭头函数**（自动绑定），**但带 `@NeoEvent.function` 装饰器的方法必须普通方法 + `bind(this)`**（装饰器只对类方法生效）。
- `render()` 把 `props.className` 合并到根节点 DOM，确保 `design-hide` 能生效。
- 根节点 className 与组件目录名一致（`myCmp__c`）。

## 函数组件 + Hooks（纯展示场景）

```tsx
import * as React from 'react';
import { useState, useEffect, useMemo, useCallback } from 'react';
import classnames from 'classnames';
import './index.scss';

interface Props {
  title?: string;
  className?: string;
  onConfirm?: (v: string) => void;
}

const MyCmpC: React.FC<Props> = (props) => {
  const { title = '默认', className, onConfirm } = props;

  const [value, setValue] = useState('');
  const disabled = useMemo(() => value.trim().length === 0, [value]);

  const handleClick = useCallback(() => {
    if (!disabled) onConfirm?.(value);
  }, [disabled, value, onConfirm]);

  useEffect(() => {
    // 挂载时副作用
    return () => {
      // 卸载时清理
    };
  }, []);

  return (
    <div className={classnames('myCmp__c', { 'myCmp__c--disabled': disabled }, className)}>
      <h3 className="myCmp__c__title">{title}</h3>
      <input
        className="myCmp__c__input"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <button type="button" disabled={disabled} onClick={handleClick}>
        确认
      </button>
    </div>
  );
};

export default MyCmpC;
```

**要点**：

- 函数组件**不能用 `@NeoEvent.dispatch` / `@NeoEvent.function` 装饰器**，因此无法暴露事件动作。
- 需要对外暴露事件 / 被其他组件调用 → **改写成类组件**。
- 所有 Hooks 在函数**顶层**调用（Rules of Hooks）。
- 合并 `className`、根节点 `className = 目录名` 同类组件规则。

## ErrorBoundary（React 16 实现方式）

React 16 的错误边界必须用**类组件**实现：

```tsx
import * as React from 'react';

interface Props { children: React.ReactNode; fallback?: React.ReactNode }
interface State { hasError: boolean }

class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State { return { hasError: true }; }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // 上报 / 打点
    // console.error(error, info);
  }

  render() {
    if (this.state.hasError) return this.props.fallback ?? <div>出错了</div>;
    return this.props.children;
  }
}

export default ErrorBoundary;
```

## Hooks 使用要点（Rules of Hooks）

1. **只在顶层调用**：不能在条件分支、循环、嵌套函数里。
2. **只在 React 函数组件或自定义 Hook 里调用**：普通函数里不行。
3. **`useEffect` 依赖数组**：把所有函数体内引用的、会变化的外部值都列进去；用 `eslint-plugin-react-hooks` 的 `exhaustive-deps` 规则检查。
4. **自定义 Hook 以 `use` 开头**。

### 常用 Hook 速查

| Hook | 典型场景 | 关键点 |
|---|---|---|
| `useState` | 单个 state | 函数式更新避免闭包陷阱：`setCount(c => c + 1)` |
| `useReducer` | 多字段联动 state | action-driven 更新 |
| `useEffect` | 挂载、更新、卸载副作用 | cleanup function 处理订阅清理 |
| `useLayoutEffect` | 浏览器绘制前同步测量 / 调整 DOM | 阻塞渲染，慎用 |
| `useMemo` | 计算开销大的派生值 | 依赖变化才重算 |
| `useCallback` | 稳定的函数引用 | 仅在传给 memoized 子组件或作为 effect 依赖时必要 |
| `useRef` | 保存可变值 / DOM 引用 | 变更不触发重渲染 |
| `useContext` | 订阅 Context | 配合 `React.createContext` |
| `useImperativeHandle` | 暴露方法给父组件 ref | 和 `forwardRef` 搭配 |

## 常见反模式

| 反模式 | 正确做法 |
|---|---|
| `useState(...)` 套条件分支 | 只在顶层调用 |
| 直接 `state.list.push(x); setState(state)` | `setState({ ...state, list: [...state.list, x] })` |
| `useEffect(() => fetch(...), [])` 不处理 cleanup | 检查订阅 / 定时器 / 请求需要取消时写 cleanup |
| 事件处理器里修改 props | props 只读，用回调通知父 |
| 把函数作为 prop 传给 memo 子组件但没用 useCallback | `useCallback` 稳定引用；或让子组件接受「值 + 回调」 |
| 类组件事件回调用 `onClick={this.handleClick}` 但没 bind | 类属性箭头函数定义，或构造函数 `bind` |
| **`@NeoEvent.function` 方法忘了 bind** | 构造函数 `this.xxx = this.xxx.bind(this)` |
| 把大对象 state 写成一个 useState | 拆多个，或用 useReducer |

## `React.memo` 与性能

- **不要默认给所有组件加 `React.memo`** —— shallow compare 本身有成本
- 只在「子组件本身渲染成本高」且「父组件高频渲染但传给子组件的 props 实际不变」时加
- 配合 `useCallback` / `useMemo` 稳定引用

## Neo 平台特有注意事项

### 类组件与事件动作

- `@NeoEvent.dispatch`：标记为对外触发的事件，**必须在 `model.events[]` 里声明**才会被设计器识别。
- `@NeoEvent.function`：标记为可被调用的组件动作，**必须继承 `BaseCmp` + 在 `model.functions[]` 里声明**。
- 带 `@NeoEvent.function` 的方法用 `this` 时，**构造函数里必须 `bind(this)`**。
- `tsconfig.json` 需要 `experimentalDecorators: true`（CLI 模板默认开启）。

### 运行时上下文

- `this.props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo`
- `this.props.env.ctx`（系统 / 用户 / UI / 工具 / API）
- `this.props.keyIdentifier` / `this.props.$com.keyIdentifier`

详见 `runtime-context.md`。

## 与 Vue 的心智差异

| Vue 思维 | React 思维 |
|---|---|
| `state.x = 1` 自动更新 | 必须 `setState(new)`，永远新引用 |
| `computed` 缓存派生 | `useMemo` 缓存派生；或每次重算（计算轻时更简单） |
| `watch` 响应变化 | `useEffect(fn, [deps])` |
| `mounted` / `beforeDestroy` | `componentDidMount` / `componentWillUnmount` 或 `useEffect(() => { /* mount */; return () => { /* unmount */ }; }, [])` |
| `$refs.foo.method()` | `forwardRef` + `useImperativeHandle` |
| `v-if` 销毁 DOM | `cond && <X />` 条件渲染；`v-show` 等价于 `style={{ display: ... }}` |
| `$emit('xxx', v)` | **React 普通组件**：`props.onXxx?.(v)` callback；**Neo 自定义组件**：`@NeoEvent.dispatch` + `model.events` |
| 全局 store（Vuex） | MobX（平台预置） / 事件动作 / Context |

## 代码组织规范（与 SKILL.md 硬约束对齐）

本技能定义了代码组织的硬性约束，所有组件代码必须遵循：

| 目录 | 用途 | 约束 |
|---|---|---|
| `src/utils/` | **纯函数 / 工具方法**（无 JSX，无 UI），按领域分文件（`date.ts`、`number.ts`、`entity.ts` 等） | 任何不依赖 `this` / `state` / `props` 的独立函数必须下沉至此；命名导出便于 Tree Shaking；禁止 `any` 兜底 |
| `src/common/` | **自研功能子组件（UI 组件）**，跨自定义组件复用，非 `antd` / `antd-mobile` 替代品 | 每个子组件自成一个目录（`index.tsx` + `index.scss` + 可选 `types.ts` / `README.md`），README 必须说明自研原因 |
| `src/components/<cmpName>__c/components/` | **当前组件私有、强耦合的内部子组件**，不会被其他组件复用 | 一旦具备复用价值或属于 UI 库替代品，立即迁到 `src/common/` |

**验收标准**：组件最终交付时，`index.tsx` 中不应存在不依赖 `this` / `state` / `props` 的独立函数；若存在，一律迁移到 `src/utils/`。

:::
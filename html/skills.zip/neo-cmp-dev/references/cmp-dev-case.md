# 常见开发案例（组件开发 Case 库）

> 本文档是 `neo-cmp-dev` 技能的**实战对照清单**。每个 case 都按主文档 [`SKILL.md` 的 11 步开发关键步骤](../SKILL.md) 走一遍：从需求拆解、**实体识别**、数据接入决策、模板选型、目录与模型、组件实现、属性面板、事件动作、样式，到**依赖安装 + 格式化**、最后向用户**确认"预览 / linkDebug / 发布"并转交 `neo-cmp-cli`**。case 中出现的字段名**全部来自** `references/standard-entities.md`，未杜撰。
>
> **Case 索引**：
>
> 1. [Case 1 — PC 端：客户列表（点击查看详情）](#case-1--pc-端客户列表点击查看详情)
> 2. [Case 2 — H5 端：客户列表（点击查看详情）](#case-2--h5-端客户列表点击查看详情)
> 3. [Case 3 — PC 端：商机列表（分页 + 新增 + 删除）](#case-3--pc-端商机列表分页--新增--删除)
>
> 每个 case 给出：需求映射 → 关键决策（硬约束落地点）→ 组件目录 → `index.tsx` / `model.ts` / `index.scss` 关键片段 → 第 10/11 步的自动动作与话术。用户需求相近时，**可直接复制同名 case 的骨架**，只改 apiKey / 字段 / `label`。

---

## Case 1 — PC 端：客户列表（点击查看详情）

### 用户需求（原话）

> 开发一个展示客户列表的组件，支持点击查看每个客户详情信息。

### 第 1 步 — 需求分析 & 模板选型

| 维度 | 决策 | 依据 |
|---|---|---|
| 端（`targetDevice`） | `web`（用户未显式说"H5"） | 默认 PC |
| 模板选型 | **`neo-web-entity-grid`** | 需求命中「PC 端列表 / 视图 / 分页 / 点击打开详情」语义 |
| UI 库 | `antd ^4.9.4` | 硬约束 1 |
| 列表能力 | **必须** `NeoEntityGrid`（`neo-ui-component-web`） | 硬约束 2：展示 xObject 列表优先用平台列表组件 |
| `pattern` | `entityView` | 单击行自动打开详情（平台内置行为） |
| 参考示例 | `examples/neo-web-entity-grid/entityGrid__c/` | 几乎是现成骨架 |

> **点击查看详情的落地方式**：`NeoEntityGrid` 在 `pattern: 'entityView'` 模式下，**点击行默认打开平台详情页**（走平台标准详情路由），不需要手写弹窗与字段渲染；如果想拦截走自定义详情，用 `onSinglerClick` 返回 `true` 即可阻止默认行为。

### 第 2 步 — 实体识别 + 数据接入决策

1. **实体识别**：用户需求提到"客户" → 在 `references/standard-entities.md` 中 `label === '客户'` 的标准实体唯一匹配到 **apiKey = `account`**。
2. **字段兜底**：用户**未明确指定字段**。按「字段兜底规则」，从 `standard-entities.md` 的 `account` 字段清单里挑选展示类核心字段，回复中列出供用户复核。这里默认把字段选择权下放给业务方 —— 使用 `dataViewIdSelect` 让业务方在设计器里选列表视图（视图本身已经带字段 / 排序 / 过滤），组件代码里**不硬编码 `fields`**。
3. **数据接入决策**：需求是「读取 + 点击详情」 → **平台实体数据源**，由 `NeoEntityGrid` 内部走 `xObject.query`，组件代码**不直接**调 `xObject.query`，遵循硬约束 2。

### 第 3 步 — 初始化目录

```
src/components/accountList__c/
├── index.tsx
├── model.ts
├── style.scss
└── README.md
```

命令走 `neo-cmp-cli`：`neo create cmp`（由 cli 技能执行，无需本技能拼命令）。

### 第 5 步 — 组件形态

`React.PureComponent`（无事件动作 / 不需要 `BaseCmp`；点击详情由 `NeoEntityGrid` 内置）。

### `index.tsx`

```tsx
import * as React from 'react';
// @ts-ignore 平台虚拟模块，无需安装
import { NeoEntityGrid } from 'neo-ui-component-web';
import './style.scss';

interface AccountListProps {
  /** 实体 apiKey，默认 account；可在设计器里切换（propsSchema: xObjectEntityList） */
  objectApiKey: string;
  /** 默认列表视图 ID（propsSchema: dataViewIdSelect） */
  defaultViewId?: string;
  /** 是否隐藏头部（视图栏 + 工具栏） */
  hiddenHeader?: boolean;
  /** 是否隐藏搜索 */
  disableSearch?: boolean;
  /** 是否支持新建 */
  canCreate?: boolean;
  /** 是否展示多选列 */
  withCheck?: boolean;
  /** 是否展示序号列 */
  withOrder?: boolean;
  /** 每页条数 */
  paginationPageSize?: number;
  /** 高度自适应（true 时 height 失效） */
  autoHeight?: boolean;
  /** 固定高度 */
  height?: string;
  /** 平台注入 */
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
}

export default class AccountListC extends React.PureComponent<AccountListProps> {
  render() {
    const {
      className,
      objectApiKey = 'account',
      defaultViewId,
      hiddenHeader = false,
      disableSearch = false,
      canCreate = true,
      withCheck = true,
      withOrder = true,
      paginationPageSize = 20,
      autoHeight = false,
      height = '500px',
      render,
    } = this.props;

    return (
      <div className={`accountList__c ${className || ''}`}>
        <NeoEntityGrid
          render={render}                         /* 硬约束：必传 */
          name="accountListGrid"
          objectApiKey={objectApiKey}             /* 'account' */
          pattern="entityView"                    /* 点击行自动打开平台详情 */
          defaultViewId={defaultViewId}
          hiddenHeader={hiddenHeader}
          disableSearch={disableSearch}
          canCreate={canCreate}
          withCheck={withCheck}
          withOrder={withOrder}
          enableToolbar
          showView
          enableChangeView
          paginationPageSize={paginationPageSize}
          autoHeight={autoHeight}
          height={height}
          customEmptyMsg="暂无客户数据，请点击「新建」按钮创建"
        />
      </div>
    );
  }
}
```

### `model.ts`

```ts
/**
 * @file 客户列表组件 — 编辑器描述文件
 * @description 基于 NeoEntityGrid 的客户列表，点击行自动打开平台客户详情页
 */
export class AccountListModel {
  label: string = '客户列表';

  description: string = '展示客户（account）列表，支持视图切换、搜索、分页；点击行打开客户详情页';

  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';

  tags: string[] = ['自定义组件'];

  /** 适配全页面 */
  targetPage: string[] = ['all'];

  /** PC 端 */
  targetDevice: string = 'web';

  /** 初次插入默认属性 */
  defaultComProps = {
    objectApiKey: 'account',          // 识别出的 apiKey
    hiddenHeader: false,
    disableSearch: false,
    canCreate: true,
    withCheck: true,
    withOrder: true,
    paginationPageSize: 20,
    autoHeight: false,
    height: '500px',
  };

  /** 属性面板：类型必须来自 references/props-schema.md 清单（硬约束 4） */
  propsSchema = [
    {
      type: 'xObjectEntityList',   // 数据源类：让业务方在设计器里切换实体
      name: 'objectApiKey',
      label: '实体对象',
      value: 'account',
    },
    {
      type: 'dataViewIdSelect',    // 数据源类：绑定到 objectApiKey 的列表视图
      name: 'defaultViewId',
      xObjectApiKey: 'objectApiKey',
      label: '默认列表视图',
    },
    { type: 'panelSwitch', name: 'hiddenHeader', label: '隐藏头部', defaultChecked: false },
    {
      type: 'panelSwitch',
      name: 'disableSearch',
      label: '禁用搜索',
      defaultChecked: false,
      hiddenOn: 'hiddenHeader',
    },
    {
      type: 'panelSwitch',
      name: 'canCreate',
      label: '支持新建客户',
      defaultChecked: true,
      hiddenOn: 'hiddenHeader',
    },
    { type: 'panelSwitch', name: 'withCheck', label: '显示多选列', defaultChecked: true },
    { type: 'panelSwitch', name: 'withOrder', label: '显示序号列', defaultChecked: true },
    { type: 'panelNumber', name: 'paginationPageSize', label: '每页条数', value: 20 },
    { type: 'panelSwitch', name: 'autoHeight', label: '高度自适应', defaultChecked: false },
    {
      type: 'panelInput',
      name: 'height',
      label: '固定高度',
      visibleOn: '!autoHeight',
    },
  ];
}

export default AccountListModel;
```

### `style.scss`

```scss
.accountList__c {
  width: 100%;
  height: 100%;
}
```

### 字段复核清单（回复用户时必列出）

> 本次未硬编码字段；具体展示哪些列、排序、过滤，由业务方在**设计器里选择"列表视图"**决定。若希望组件固定展示 `accountName` / `level` / `ownerId` / `phone` / `address` / `createdAt`，可以直接写死在组件代码里或改用 `xObjectDataApi` + `fields` 把字段选择交给设计器——以上字段均来自 `references/standard-entities.md` 的 `account` 清单，未杜撰。

### 第 10 步 — 依赖安装 + 格式化（转交 `neo-cmp-cli`）

本步骤统一转交 `neo-cmp-cli` 技能执行：
- `npm install`（识别包管理器，淘宝源策略见 `neo-cmp-cli`）
- `npm run format`（不存在时提示补 `"format": "prettier --write ..."`）

### 第 11 步 — 询问用户 → 转交 `neo-cmp-cli`

> ✅ **组件 `accountList__c` 已开发完成**（`src/components/accountList__c/` 下 `index.tsx` / `model.ts` / `style.scss` 就位）。
>
> 接下来要做什么？可多选：
>
> 1. **预览（`neo preview`）** — 推荐 `online`，因为依赖 `NeoEntityGrid`（平台运行时注入）。
> 2. **外链调试（`neo linkDebug -p pc`）** — `targetDevice: 'web'` → `pc`。
> 3. **发布（`neo push cmp -n accountList__c`）** — 先在本轮 linkDebug 通过后再做。
>
> 请回复编号与细节（预览模式 / 发布环境）。我会把选中的动作连同参数转交给 `neo-cmp-cli` 执行。

---

## Case 2 — H5 端：客户列表（点击查看详情）

### 用户需求（原话）

> 开发一个 H5 版的展示客户列表组件，支持点击查看每个客户详情信息。

### 第 1 步 — 需求分析 & 模板选型

| 维度 | 决策 | 依据 |
|---|---|---|
| 端（`targetDevice`） | `mobile` | 用户明确说"H5" |
| 模板选型 | **`neo-h5-cmps`** | H5 端业务组件 |
| UI 库 | `antd-mobile 2.3.4` | 硬约束 1 |
| 列表能力 | **必须** `NeoEntityList`（`neo-ui-component-h5`） | 硬约束 2 |
| 点击详情 | `NeoEntityList` 默认点击行打开平台详情页；若要拦截走自定义详情，`onItemClickIntercept` 返回 truthy | 平台内置行为 |

### 第 2 步 — 实体识别 + 数据接入决策

- **实体识别**："客户" → `apiKey = account`。
- **字段**：H5 列表是卡片式渲染，字段与布局由平台 `EntityList` 的视图配置驱动，**组件代码里不硬编码字段**。
- **数据接入**：平台实体数据源 → `NeoEntityList` 内部走 `xObject.query`。

### 第 3 步 — 初始化目录

```
src/components/accountListH5__c/
├── index.tsx
├── model.ts
├── style.scss
└── README.md
```

### `index.tsx`

```tsx
import * as React from 'react';
// @ts-ignore 平台虚拟模块
import { NeoEntityList } from 'neo-ui-component-h5';
import './style.scss';

interface AccountListH5Props {
  /** 实体 apiKey（propsSchema: xObjectEntityList） */
  entityApiKey: string;
  /** 隐藏标题区 */
  disableTitleView?: boolean;
  /** 是否展示视图 Picker */
  isShowTitlePicker?: boolean;
  /** 禁用搜索 */
  disableSearch?: boolean;
  /** 禁用排序 */
  disabledSort?: boolean;
  /** 禁用筛选 */
  disabledFilter?: boolean;
  /** 禁用操作按钮区 */
  disabledOperationBtn?: boolean;
  /** 禁用快捷按钮区 */
  disabledShortcutBtn?: boolean;
  /** 每页条数 */
  pageSize?: number;
  /** 禁用下拉刷新 / 上拉加载 */
  isNoRefresh?: boolean;
  /** 使用 body 滚动 */
  autoHeight?: boolean;
  className?: string;
  render: (name: string, schema: any) => React.ReactNode;
}

export default class AccountListH5C extends React.PureComponent<AccountListH5Props> {
  render() {
    const {
      className,
      entityApiKey = 'account',
      disableTitleView = false,
      isShowTitlePicker = true,
      disableSearch = false,
      disabledSort = false,
      disabledFilter = false,
      disabledOperationBtn = false,
      disabledShortcutBtn = false,
      pageSize = 20,
      isNoRefresh = false,
      autoHeight = false,
      render,
    } = this.props;

    return (
      <div className={`accountListH5__c ${className || ''}`}>
        <NeoEntityList
          render={render}                          /* 硬约束：必传 */
          entityApiKey={entityApiKey}              /* 'account' */
          disableTitleView={disableTitleView}
          isShowTitlePicker={isShowTitlePicker}
          disableSearch={disableSearch}
          disabledSort={disabledSort}
          disabledFilter={disabledFilter}
          disabledOperationBtn={disabledOperationBtn}
          disabledShortcutBtn={disabledShortcutBtn}
          pageSize={pageSize}
          isNoRefresh={isNoRefresh}
          autoHeight={autoHeight}
          /* 点击行走平台标准详情路由；不传 onItemClickIntercept 即走默认 */
        />
      </div>
    );
  }
}
```

> 如果需要**拦截默认详情逻辑、改走自定义详情页 / 弹层**，加：
>
> ```tsx
> onItemClickIntercept={(item) => {
>   // 返回 truthy 会阻止默认打开详情；这里示意用平台 util 导航到自定义页
>   // this.props.env.ctx.util.goto(`/custom-account-detail/${item.id}`);
>   // return true;
>   return false; // 否则走默认
> }}
> ```

### `model.ts`

```ts
/**
 * @file H5 客户列表组件 — 编辑器描述文件
 */
export class AccountListH5Model {
  label: string = 'H5 客户列表';

  description: string = 'H5 端基于 NeoEntityList 的客户列表，支持搜索、筛选、排序、下拉刷新、上拉加载；点击列表项打开客户详情页';

  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/list-mobile.svg';

  tags: string[] = ['自定义组件'];

  targetPage: string[] = ['all'];

  /** H5 端 */
  targetDevice: string = 'mobile';

  defaultComProps = {
    entityApiKey: 'account',
    disableTitleView: false,
    isShowTitlePicker: true,
    disableSearch: false,
    disabledSort: false,
    disabledFilter: false,
    disabledOperationBtn: false,
    disabledShortcutBtn: false,
    pageSize: 20,
    isNoRefresh: false,
    autoHeight: false,
  };

  propsSchema = [
    { type: 'xObjectEntityList', name: 'entityApiKey', label: '实体对象', value: 'account' },
    { type: 'panelSwitch', name: 'disableTitleView', label: '隐藏标题区', defaultChecked: false },
    {
      type: 'panelSwitch',
      name: 'isShowTitlePicker',
      label: '展示视图 Picker',
      defaultChecked: true,
      hiddenOn: 'disableTitleView',
    },
    { type: 'panelSwitch', name: 'disableSearch', label: '禁用搜索', defaultChecked: false },
    { type: 'panelSwitch', name: 'disabledSort', label: '禁用排序', defaultChecked: false },
    { type: 'panelSwitch', name: 'disabledFilter', label: '禁用筛选', defaultChecked: false },
    { type: 'panelSwitch', name: 'disabledOperationBtn', label: '隐藏操作按钮区', defaultChecked: false },
    { type: 'panelSwitch', name: 'disabledShortcutBtn', label: '隐藏快捷按钮区', defaultChecked: false },
    { type: 'panelNumber', name: 'pageSize', label: '每页条数', value: 20 },
    { type: 'panelSwitch', name: 'isNoRefresh', label: '禁用下拉刷新 / 上拉加载', defaultChecked: false },
    { type: 'panelSwitch', name: 'autoHeight', label: '使用 body 滚动（autoHeight）', defaultChecked: false },
  ];
}

export default AccountListH5Model;
```

### `style.scss`

```scss
.accountListH5__c {
  width: 100%;
  height: 100%;
  background: #f5f5f5;

  :global(.am-list-body) {
    background: transparent;
  }
}
```

### 字段复核清单

卡片展示字段 / 排序 / 过滤均由平台**列表视图**驱动（业务方在 admin / 设计器里维护），组件代码不硬编码。若需要固定字段，可参考 Case 3 里 `xObject.query` + 自绘卡片的模式，并从 `references/standard-entities.md` 的 `account` 字段清单中挑选（`accountName` / `level` / `ownerId` / `phone` / `address`）。

### 第 11 步 — 询问用户 → 转交 `neo-cmp-cli`

> ✅ **组件 `accountListH5__c` 已开发完成**。
>
> 1. 预览：推荐 `online`（依赖 `NeoEntityList` 平台虚拟模块）。
> 2. 外链调试：`targetDevice: 'mobile'` → `neo linkDebug -p h5`。
> 3. 发布：`neo push cmp -n accountListH5__c`。
>
> 多选请回复编号 + 细节，我会转交 `neo-cmp-cli` 执行。

---

## Case 3 — PC 端：商机列表（分页 + 新增 + 删除）

### 用户需求（原话）

> 开发一个展示商机列表的组件，支持分页展示，支持新增和删除操作。

### 第 1 步 — 需求分析 & 模板选型

这个需求里"新增 / 删除 / 分页"都能由 `NeoEntityGrid` 原生覆盖（`canCreate` + 内置行操作 + 分页），**最规范的落地是直接用 `NeoEntityGrid`**，就像 Case 1 的模式。下面给出**两种落地方式**，任选其一，**默认走方式 A**：

- **方式 A（推荐）**：复用 `NeoEntityGrid`（`pattern: 'entityView'` + `canCreate: true`，删除走平台行操作）。骨架几乎同 Case 1，仅需把 `objectApiKey` 换成 `opportunity`、`label` 换成"商机列表"。适合 95% 场景。
- **方式 B（演示级，用户希望"自绘 antd Table"）**：参考 `examples/neo-custom-cmp-template/entityTable__c/`，用 `antd Table` + `xObject.query` / `create` / `delete` 自建 CRUD。**仅当用户明确说"不要用 NeoEntityGrid"或需要卡片墙 / 看板等平台列表覆盖不到的形态才选此方式**（硬约束 2 例外兜底）。

> **决策建议**：把两种方式都告诉用户，默认走 A。下面完整展开方式 B，因为 A 只是 Case 1 的 apiKey 替换（复用 Case 1 的代码骨架即可）。

### 第 2 步 — 实体识别 + 数据接入决策

- **实体识别**：用户需求提到"商机"。`references/standard-entities.md` 中 `label === '销售机会'` 的标准实体是 **apiKey = `opportunity`**（注意：匹配规则里"商机" → `opportunity`）。
- **字段兜底**：用户**未指定字段**。按字段兜底规则，从 `opportunity` 字段清单挑展示 + 新增必填：
  - **列表展示列**：`name`（商机名称）/ `accountId`（客户名称，关联字段）/ `amount`（商机金额）/ `stageName`（销售阶段）/ `closeDate`（预计结单日期）/ `ownerId`（商机负责人）/ `createdAt`（创建日期）。
  - **新增表单字段**：`entityType`（商机类型，必填）/ `ownerId` / `name`（必填）/ `accountId` / `amount` / `stageName` / `closeDate` / `description`。
  - **以上字段全部来自** `references/standard-entities.md` 的 `opportunity` 条目，未杜撰。回复用户时必须列出该清单供复核。
- **数据接入**：**平台实体数据源**。方式 A 由 `NeoEntityGrid` 内部处理；方式 B 自行调 `xObject.query` / `xObject.create` / `xObject.delete`（硬约束：能用 SDK 就不写 `axios`）。

### 方式 A（推荐）— 基于 `NeoEntityGrid` 的规范实现

直接复用 Case 1 代码骨架，下面仅列出差异：

```ts
// model.ts（差异部分）
export class OpportunityListModel {
  label = '商机列表';
  description = '展示商机（opportunity）列表，支持视图切换、搜索、新建、删除、分页';
  targetDevice = 'web';
  defaultComProps = {
    objectApiKey: 'opportunity',      // ← 实体切换
    canCreate: true,                  // ← 新建：平台默认按钮
    withCheck: true,                  // ← 多选：配合批量删除
    paginationPageSize: 20,           // ← 分页
    // ...其余与 Case 1 相同
  };
  // propsSchema 同 Case 1
}
```

```tsx
// index.tsx（差异部分）
<NeoEntityGrid
  render={render}
  name="opportunityListGrid"
  objectApiKey={objectApiKey /* 'opportunity' */}
  pattern="entityView"
  canCreate                           /* 平台工具栏自动出现"新建"按钮 */
  withCheck                           /* 多选列用于批量删除 */
  enableToolbar                       /* 工具栏（含刷新、导出、批量操作） */
  paginationPageSize={paginationPageSize}
  /* 删除能力：行操作菜单由平台基于 opportunity 实体权限自动渲染 */
/>
```

> **分页**：`paginationPageSize` 控制每页条数；`disablePagination` 设为 `false`（默认），平台分页组件自动出现。
> **新增**：`canCreate=true` 时平台工具栏自动渲染"新建"按钮，点击走标准新建流程（实体表单）。
> **删除**：`withCheck=true` 开启多选，工具栏自动出现"删除"等批量操作（受实体权限控制）；也可用 `customToolbarButtons.header` 自定义按钮 + 自己写批量删除回调（见下方片段）。

```tsx
// 可选：自定义批量删除按钮（方式 A 的扩展写法）
// @ts-ignore
import { xObject } from 'neo-open-api';
import { message, Modal } from 'antd';

/* 组件字段保存 gridModel */
private gridModel: any = null;

private handleDeleteSelected = async () => {
  if (!this.gridModel) return;
  const selected: any[] = this.gridModel.getSelectedRows?.() || [];
  if (!selected.length) { message.info('请先勾选要删除的商机'); return; }
  Modal.confirm({
    title: `确认删除选中的 ${selected.length} 条商机？`,
    okText: '删除', cancelText: '取消', okType: 'danger',
    onOk: async () => {
      for (const row of selected) {
        /* 从 standard-entities.md 确认 opportunity 的主键就是 id */
        await xObject.delete('opportunity', row.id);
      }
      message.success('删除成功');
      this.gridModel.reloadGrid(false);
    },
  });
};

/* 在 NeoEntityGrid 上 */
onGridReady={(gridModel: any) => { this.gridModel = gridModel; }}
customToolbarButtons={{
  header: [
    { id: 'batch-delete', label: '批量删除', icon: 'DeleteOne', onClick: this.handleDeleteSelected },
  ],
}}
```

### 方式 B — 基于 `antd Table` 自绘 CRUD（仅在用户要求时走）

> **仅当明确偏离平台列表语义时才选 B**；大多数场景选 A 更合规。方式 B 的完整骨架基本是 `examples/neo-custom-cmp-template/entityTable__c/` 的复用，下面只列需求相关部分。

#### 目录

```
src/components/opportunityListCustom__c/
├── index.tsx
├── model.ts
├── style.scss
├── modal.scss          # 弹层样式（不参与样式隔离）
└── README.md
```

#### `index.tsx`（关键片段）

```tsx
import * as React from 'react';
import {
  Table, Button, Space, Modal, Form, Input, Select, DatePicker, InputNumber,
  message, Popconfirm, Spin,
} from 'antd';
import { PlusOutlined, DeleteOutlined, ReloadOutlined } from '@ant-design/icons';
import moment from 'moment';
// @ts-ignore
import { xObject } from 'neo-open-api';
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';
import './style.scss';
import './modal.scss';

interface OpportunityListProps {
  /** 每页条数（propsSchema: panelNumber） */
  pageSize?: number;
  /** 是否显示新增按钮（propsSchema: panelSwitch） */
  showAddButton?: boolean;
  /** 是否显示删除按钮（propsSchema: panelSwitch） */
  showDeleteButton?: boolean;
  className?: string;
  data?: any;
  env?: any;
}

interface OpportunityRow {
  id: string;
  name?: string;
  accountId?: any;          // reference：可能是对象 { id, label }
  amount?: number;
  stageName?: string;
  closeDate?: number;       // datetime：时间戳
  ownerId?: any;            // owner
  createdAt?: number;
}

interface State {
  dataSource: OpportunityRow[];
  loading: boolean;
  page: number;
  pageSize: number;
  total: number;
  addVisible: boolean;
  form: any;
  submitting: boolean;
}

/* 以下字段全部来自 references/standard-entities.md 的 opportunity 条目 */
const OBJECT_API_KEY = 'opportunity';
const LIST_FIELDS = ['name', 'accountId', 'amount', 'stageName', 'closeDate', 'ownerId', 'createdAt'];

export default class OpportunityListCustomC extends BaseCmp<OpportunityListProps, State> {
  constructor(props: OpportunityListProps) {
    super(props);
    this.state = {
      dataSource: [],
      loading: false,
      page: 1,
      pageSize: props.pageSize || 20,
      total: 0,
      addVisible: false,
      form: null,
      submitting: false,
    };
    /* 组件动作使用 this，构造函数里必须 bind（硬约束） */
    this.loadData = this.loadData.bind(this);
    this.handleAdd = this.handleAdd.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount() {
    this.loadData(1, this.state.pageSize);
  }

  /** 对外暴露「刷新列表」（被其他组件事件动作调用时用） */
  @NeoEvent.function
  async loadData(page = 1, pageSize = 20) {
    this.setState({ loading: true });
    try {
      const res = await xObject.query({
        xObjectApiKey: OBJECT_API_KEY,
        fields: LIST_FIELDS,
        page,
        pageSize,
      });
      if (res && res.status) {
        this.setState({
          dataSource: res.data || [],
          total: res.totalSize || 0,
          page,
          pageSize,
        });
      } else {
        message.error(res?.msg || '获取商机列表失败');
      }
    } finally {
      this.setState({ loading: false });
    }
  }

  handleAdd() { this.setState({ addVisible: true }); }

  async handleDelete(id: string) {
    const res = await xObject.delete(OBJECT_API_KEY, id);
    if (res && (res.code === 200 || res.code === '200' || res.status)) {
      message.success('删除成功');
      this.loadData(this.state.page, this.state.pageSize);
    } else {
      message.error(res?.msg || res?.message || '删除失败');
    }
  }

  async handleSubmit() {
    const { form } = this.state;
    const values = await form.validateFields();
    /* closeDate 从 moment 转时间戳 */
    if (values.closeDate) {
      values.closeDate = values.closeDate.valueOf();
    }
    this.setState({ submitting: true });
    try {
      const res = await xObject.create(OBJECT_API_KEY, { data: values, method: 'POST' });
      if (res && (res.code === 200 || res.code === '200' || res.status)) {
        message.success('新增成功');
        this.setState({ addVisible: false });
        form.resetFields();
        this.loadData(1, this.state.pageSize);
      } else {
        message.error(res?.msg || res?.message || '新增失败');
      }
    } finally {
      this.setState({ submitting: false });
    }
  }

  /** 表格列：字段全部来自 standard-entities.md 的 opportunity */
  get columns() {
    const { showDeleteButton = true } = this.props;
    const cols: any[] = [
      { title: '商机名称', dataIndex: 'name', key: 'name', ellipsis: true },
      {
        title: '客户',
        dataIndex: 'accountId',
        key: 'accountId',
        render: (v: any) => (v && typeof v === 'object' ? v.label || v.name || v.id : v),
      },
      { title: '商机金额', dataIndex: 'amount', key: 'amount' },
      { title: '销售阶段', dataIndex: 'stageName', key: 'stageName' },
      {
        title: '预计结单日期',
        dataIndex: 'closeDate',
        key: 'closeDate',
        render: (v: number) => (v ? moment(v).format('YYYY-MM-DD') : '-'),
      },
      {
        title: '负责人',
        dataIndex: 'ownerId',
        key: 'ownerId',
        render: (v: any) => (v && typeof v === 'object' ? v.label || v.name : v),
      },
      {
        title: '创建日期',
        dataIndex: 'createdAt',
        key: 'createdAt',
        render: (v: number) => (v ? moment(v).format('YYYY-MM-DD HH:mm') : '-'),
      },
    ];
    if (showDeleteButton) {
      cols.push({
        title: '操作', key: 'action', width: 100,
        render: (_: any, row: OpportunityRow) => (
          <Popconfirm title="确认删除这条商机？" onConfirm={() => this.handleDelete(row.id)} okText="删除" cancelText="取消">
            <Button type="link" danger icon={<DeleteOutlined />} size="small">删除</Button>
          </Popconfirm>
        ),
      });
    }
    return cols;
  }

  renderAddForm() {
    /* 新增表单字段：来自 standard-entities.md，确保 name 必填 */
    return (
      <Form ref={(f) => this.setState({ form: f })} layout="vertical">
        <Form.Item name="name" label="商机名称" rules={[{ required: true, message: '请输入商机名称' }]}>
          <Input placeholder="请输入商机名称" />
        </Form.Item>
        <Form.Item name="amount" label="商机金额">
          <InputNumber placeholder="请输入金额" style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item name="stageName" label="销售阶段">
          {/* 真实选项应来自 xObject.getDesc('opportunity') 里 stageName 的 selectitem；
              这里仅为静态示意，生产环境应动态加载 */}
          <Select placeholder="请选择销售阶段" allowClear />
        </Form.Item>
        <Form.Item name="closeDate" label="预计结单日期">
          <DatePicker style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item name="description" label="描述">
          <Input.TextArea rows={3} />
        </Form.Item>
      </Form>
    );
  }

  render() {
    const { showAddButton = true, className } = this.props;
    const { dataSource, loading, page, pageSize, total, addVisible, submitting } = this.state;

    return (
      <div className={`opportunityListCustom__c ${className || ''}`}>
        <div className="opportunityListCustom__c__header">
          <h3>商机列表</h3>
          <Space>
            {showAddButton && (
              <Button type="primary" icon={<PlusOutlined />} onClick={this.handleAdd}>新增商机</Button>
            )}
            <Button icon={<ReloadOutlined />} onClick={() => this.loadData(page, pageSize)} loading={loading}>刷新</Button>
          </Space>
        </div>
        <Spin spinning={loading}>
          <Table
            rowKey="id"
            columns={this.columns}
            dataSource={dataSource}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              showQuickJumper: true,
              showTotal: (t, r) => `第 ${r[0]}-${r[1]} 条 / 共 ${t} 条`,
              onChange: (p, ps) => this.loadData(p, ps),
            }}
          />
        </Spin>

        <Modal
          wrapClassName="opportunityListCustom__c-add-modal"
          title="新增商机"
          visible={addVisible}
          onOk={this.handleSubmit}
          onCancel={() => this.setState({ addVisible: false })}
          confirmLoading={submitting}
          destroyOnClose
          okText="保存"
          cancelText="取消"
        >
          {this.renderAddForm()}
        </Modal>
      </div>
    );
  }
}
```

> **关键硬约束落地点自检**：
>
> - 根节点 `className = 'opportunityListCustom__c'`（与目录同名） + 合并 `props.className`。✅
> - `extends BaseCmp` + `@NeoEvent.function loadData` + 构造函数 `bind(this)`。✅
> - 新增 / 删除均走 `xObject.create` / `xObject.delete`，没写 `axios`。✅
> - `propsSchema` 的 `type` 全部使用平台真实类型（`panelNumber` / `panelSwitch`）。✅
> - 字段名（`name` / `accountId` / `amount` / `stageName` / `closeDate` / `ownerId` / `createdAt` / `description`）均来自 `references/standard-entities.md` 的 `opportunity` 条目。✅
> - 弹层样式放 `modal.scss`（不参与样式隔离）。✅

#### `model.ts`

```ts
export class OpportunityListCustomModel {
  label: string = '商机列表（自绘 Table）';
  description: string = '基于 antd Table + xObject 的商机（opportunity）列表，支持分页、新增、删除';
  iconUrl: string = 'https://custom-widgets.bj.bcebos.com/table.svg';
  tags: string[] = ['自定义组件'];
  targetPage: string[] = ['all'];
  targetDevice: string = 'web';

  defaultComProps = {
    pageSize: 20,
    showAddButton: true,
    showDeleteButton: true,
  };

  /** 对外暴露：被事件动作面板调用 */
  functions = [
    {
      apiKey: 'loadData',
      label: '刷新列表',
      helpTextKey: '重新拉取当前页商机数据',
      funcInParams: [
        { apiKey: 'page', label: '页码', type: 'Number' },
        { apiKey: 'pageSize', label: '每页条数', type: 'Number' },
      ],
    },
  ];

  propsSchema = [
    { type: 'panelNumber', name: 'pageSize', label: '每页条数', value: 20 },
    { type: 'panelSwitch', name: 'showAddButton', label: '显示新增按钮', defaultChecked: true },
    { type: 'panelSwitch', name: 'showDeleteButton', label: '显示删除按钮', defaultChecked: true },
  ];
}

export default OpportunityListCustomModel;
```

#### `style.scss`

```scss
.opportunityListCustom__c {
  padding: 12px 16px;
  background: #fff;

  &__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;

    h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
    }
  }
}
```

#### `modal.scss`（弹层样式，不参与样式隔离）

```scss
/* 注意：弹层样式放这里，避免被组件的 [data-scope=opportunityListCustom__c] 隔离规则误伤 */
.opportunityListCustom__c-add-modal {
  .ant-modal-body {
    max-height: 60vh;
    overflow: auto;
  }
}
```

### 字段复核清单（回复用户时必列出）

本 case 实现里出现的字段（均来自 `references/standard-entities.md` 的 `opportunity` 条目，未杜撰）：

- **列表列**：`name`（商机名称，`text`，必填）、`accountId`（客户，`reference`）、`amount`（商机金额，`currency`）、`stageName`（销售阶段，`picklist`）、`closeDate`（预计结单日期，`date`）、`ownerId`（商机负责人，`owner`）、`createdAt`（创建日期，`datetime`）。
- **新增表单**：`name`（必填）、`amount`、`stageName`、`closeDate`、`description`（描述，`textarea`）。
- **可选补充**：`entityType`（商机类型，`entitytype`，必填）、`contactId`（联系人，`reference`）、`probability`（赢率，`int`）、`leadSource`（线索来源，`picklist`）、`expectedRevenue`（预计收入，`currency`）—— 如需完整字段请让业务方补充 / 或改走方式 A 的"实体表单"标准新建。

### 第 10 步 — 依赖安装 + 格式化（转交 `neo-cmp-cli`）

本步骤统一转交 `neo-cmp-cli` 技能执行：
- `npm install`（识别包管理器，淘宝源策略见 `neo-cmp-cli`）
- `npm run format`（不存在时提示补 `"format": "prettier --write ..."`）

### 第 11 步 — 询问用户 → 转交 `neo-cmp-cli`

> ✅ **商机列表组件已开发完成**（方式 A 或方式 B 根据选择；当前工程下目录为 `opportunityListCustom__c` / `opportunityList__c`）。
>
> 接下来要做什么？可多选：
>
> 1. **预览（`neo preview`）** — 依赖 `neo-ui-common` / `xObject`，**必须选 `online` 模式**（`local` 跑不起来）。
> 2. **外链调试（`neo linkDebug -p pc`）** — `targetDevice: 'web'` → `pc`。
> 3. **发布（`neo push cmp -n <cmpName>__c`）** — 发布前再次确认 `package.json.version` 已递增。
>
> 请回复编号与细节，我会转交 `neo-cmp-cli` 执行。

---

## 通用收尾：Case 级自检清单（每个 case 完成后必走）

> 对照 `references/spec-checklist.md` 的发布前检查；本列表针对上面三个 case 的共性项。

- [ ] 目录名以 `__c` 结尾，与 `cmpType` 一致；根节点 `className` 同名并合并 `props.className`。
- [ ] `model.ts` 的 `targetDevice` 与端选型（Case 1/3 = `web`、Case 2 = `mobile`）一致。
- [ ] `propsSchema[].type` 全部来自平台真实类型；`name` 与 `defaultComProps` 和 props 字段一一对应。
- [ ] 展示 xObject 列表：PC 用 `NeoEntityGrid`，H5 用 `NeoEntityList`（硬约束 2）；自绘 Table 仅在用户明确要求或平台列表能力不覆盖时走。
- [ ] 所有字段名来自 `references/standard-entities.md`；未在文档列出则提示用户走 `xObject.getDesc` 或 `selectFieldsApi`。
- [ ] 使用 `BaseCmp` + `@NeoEvent.function` 的组件，构造函数内 `bind(this)`。
- [ ] 第 10 步：已转交 `neo-cmp-cli` 执行安装依赖与格式化。
- [ ] 第 11 步：**不在本技能内执行任何 `neo` 命令**，只询问 + 转交 `neo-cmp-cli`。

## 参考

- `SKILL.md` — 11 步开发关键步骤、硬约束、实体识别、数据接入决策
- `references/standard-entities.md` — `account` / `opportunity` / `contact` 等实体字段清单
- `references/platform-components.md` — `NeoEntityGrid` / `NeoEntityList` 完整 props
- `references/open-api.md` — `xObject.query` / `create` / `delete` 用法
- `references/props-schema.md` — 平台真实 `type` 清单
- `examples/neo-web-entity-grid/entityGrid__c/` — Case 1 / Case 3 方式 A 的骨架来源
- `examples/neo-custom-cmp-template/entityTable__c/` — Case 3 方式 B 的骨架来源

# `model.ts` 模型文件详解

组件模型文件由 `neo init` / `neo create cmp` 自动生成，决定**组件在页面设计器里的外观与行为**。所有设计器侧的配置都写在这里。

::: v-pre

## 目录

- 字段一览
- `tags` 与分类
- 适配范围：`targetPage` / `targetObject` / `targetApplication` / `targetDevice`
- `defaultComProps` 与 `propsSchema` 的关系
- `events`（对外触发事件） / `functions`（可被调用的组件动作）
- 最小 / 完整示例
- TypeScript 类型建议

---

## 字段一览

| 字段 | 默认值 | 必填 | 说明 |
|---|---|---|---|
| `cmpType` | 构建时按目录名自动生成 | ❌（自动） | 组件类型唯一标识；写在 model 里会被构建覆盖 |
| `label` | - | ✅ | 设计器左侧组件面板显示的名称 |
| `description` | - | ✅ | 设计器左侧组件面板显示的描述 |
| `iconUrl` | - | ❌ | 设计器面板图标（平台图标 URL 或本地 base64） |
| `tags` | `['自定义组件']` | ❌ | 分类标签数组 |
| `exposedToDesigner` | `true` | ❌ | 是否在设计器中可见（`false` 表示作为子组件使用，不直接拖拽） |
| `enableDuplicate` | `true` | ❌ | 是否允许同页面多次拖入 |
| `targetPage` | `['all']` | ❌ | 适配的页面类型，见下 |
| `targetObject` | `['all']` | ❌ | 支持的实体类型 |
| `targetApplication` | `['all']` | ❌ | 支持的应用类型 |
| `targetDevice` | `'all'` | ❌ | 支持的设备类型：`all` / `web` / `mobile` |
| `defaultComProps` | - | ✅（强烈建议） | 首次拖入时的默认 props |
| `propsSchema` | `[]` | ✅ | 属性面板配置；详见 `props-schema.md` |
| `events` | - | ❌ | 对外触发的事件列表，`[{ apiKey, label, helpText }]`；与组件内 `@NeoEvent.dispatch` 对应 |
| `functions` | - | ❌ | 可被调用的组件动作列表，`[{ apiKey, label, helpTextKey }]`；与组件内 `@NeoEvent.function` 对应 |

> `events` / `functions` 只是「声明」，真正实现靠 `@NeoEvent.dispatch` / `@NeoEvent.function` 装饰器 + `extends BaseCmp`（详见 `event-action.md`）。

## `tags` 与分类

`tags` 决定组件出现在设计器左侧的哪个分类下。默认 `['自定义组件']`。

- 业务域分类：`['订单', '自定义组件']`、`['BI', '自定义组件']`
- 功能域分类：`['表单', '自定义组件']`、`['列表', '自定义组件']`

建议总带上 `'自定义组件'`，便于平台统一筛选。

> **约束：开发过程中禁止在 `model.ts` 中自行添加 `tags` 字段。如用户有分类需求，提示用户在组件模型文件（`model.ts`）中自行添加 `tags`。

## 适配范围

### `targetPage`

| 取值 | 含义 |
|---|---|
| `all` | 所有页面 |
| `indexPage` | 首页 |
| `entityListPage` | 实体列表页 |
| `entityFormPage` | 实体表单页 |
| `entityDetailPage` | 实体详情页 |
| `customPage` | 自定义页面 |
| `bizPage` | 业务页面 |

**只在特定页面才有意义的组件要严格限定**，例如「实体字段选择器」设为 `['entityFormPage', 'entityListPage']`，避免污染其他页面。

### `targetObject` / `targetApplication`

没特殊诉求保留 `['all']`。

### `targetDevice`

| 取值 | 含义 |
|---|---|
| `'all'` | 全端 |
| `'web'` | PC / Web |
| `'mobile'` | H5 |

**和 UI 库绑定**：用 `antd` → `'web'`；用 `antd-mobile` → `'mobile'`；跨端业务组件 → `'all'`（同时支持两端）。

> `neo create cmp -d web` / `-d mobile` / `-d all` 创建时会把 `targetDevice` 写到模型里。

## `defaultComProps` 与 `propsSchema` 的关系

- `defaultComProps`：首次拖入页面时给 props 的**初始值**。
- `propsSchema`：属性面板的**控件定义**（`type` / `name` / `label` / `options` / 校验等）。

**推荐约定**：

1. `propsSchema[].name` 必须是组件 props 的字段名。
2. `defaultComProps` 的每个键应在 `propsSchema` 中有对应条目。
3. 默认值尽量写在 `defaultComProps` 里，不要完全依赖组件内部 `props = {}` 解构默认值——让设计器能看到真实的初始状态。

**重要约束——跳过数据源对象类型字段**：

`defaultComProps` 中**不应包含**值为对象类型的数据源类配置项。具体来说，以下类型的字段**不要**出现在 `defaultComProps` 中：

| 类型 | 值结构 | 是否加入 defaultComProps |
|---|---|---|
| `xObjectDataApi` | `{ xObjectApiKey, fields, fieldDescList, page, pageSize }`（对象） | ❌ 跳过 |
| `xObjectDetailApi` | `{ xObjectApiKey, objectId, fields?, fieldDescList? }`（对象） | ❌ 跳过 |
| `customApi` | `{ apiUrl, methodType, headers?, data? }`（对象） | ❌ 跳过 |
| `xObjectEntityList` | `string`（实体 apiKey） | ✅ 可加默认值 `''` |
| `selectFieldsApi` | `string[]` | ✅ 可加默认值 `[]` |
| `selectFieldDescApi` | `Array<{label,value}>` | ✅ 可加默认值 `[]` |
| `dataViewIdSelect` | `string`（viewId） | ✅ 可加默认值 `''` |

> **原因**：`xObjectDataApi` / `xObjectDetailApi` / `customApi` 的值由业务方在设计器中通过数据源配置面板绑定产生。预设空对象 `{}` 既无实际意义，又可能在组件代码中引发 `if (props.entityApiKey?.xObjectApiKey)` 等条件误判。**不写入 `defaultComProps` 可让设计器在未绑定时将该字段视为 `undefined`，组件代码只需对 `undefined` 做一次守卫判断即可**。

## `events` / `functions`（事件动作）

```ts
export class MyCmpModel {
  // 对外触发的事件（其他组件可订阅）
  events = [
    { apiKey: 'onSubmit', label: '提交表单后', helpText: '表单提交后触发' },
  ];

  // 可被其他组件调用的组件动作
  functions = [
    { apiKey: 'refreshListData', label: '刷新列表数据', helpTextKey: '重新拉取表格数据' },
  ];
}
```

对应组件代码（详见 `event-action.md`）：

```tsx
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';

class MyCmp extends BaseCmp<Props, State> {
  @NeoEvent.dispatch
  onSubmit(data) { return data; }

  @NeoEvent.function
  refreshListData(page = 1, pageSize = 10) { /* ... */ }
}
```

## 最小示例

```ts
// model.ts
const model = {
  label: '信息卡片',
  description: '展示标题与业务信息',
  tags: ['展示', '自定义组件'],
  defaultComProps: {
    title: '标题',
  },
  propsSchema: [
    { type: 'panelInput', name: 'title', label: '标题' },
  ],
};

export default model;
```

## 完整示例（class 形态）

平台模板常用 `class` 导出，便于集成 TS 类型与扩展：

```ts
// model.ts
export class OrderCardModel {
  label = '订单卡片';
  description = '展示单个订单的核心信息，支持点击跳转详情';
  iconUrl = 'https://cdn.example.com/icons/order-card.svg';
  tags = ['订单', '自定义组件'];
  exposedToDesigner = true;
  enableDuplicate = true;
  targetPage = ['indexPage', 'customPage', 'bizPage'];
  targetObject = ['all'];
  targetApplication = ['all'];
  targetDevice = 'web';

  defaultComProps = {
    title: '订单号',
    showAmount: true,
    theme: 'light',
    amountColor: '#f5222d',
    // 注意：xObjectDataApi 类型（entityApiKey）不加入 defaultComProps
  };

  events = [
    { apiKey: 'onRowClick', label: '点击订单行', helpText: '点击某条订单时触发' },
  ];

  functions = [
    { apiKey: 'refresh', label: '刷新订单', helpTextKey: '重新拉取列表数据' },
  ];

  propsSchema = [
    { type: 'panelInput', name: 'title', label: '标题' },
    { type: 'panelSwitch', name: 'showAmount', label: '显示金额' },
    {
      type: 'panelSelect', name: 'theme', label: '主题',
      options: [
        { label: '浅色', value: 'light' },
        { label: '深色', value: 'dark' },
      ],
    },
    { type: 'panelColor', name: 'amountColor', label: '金额颜色' },
    { type: 'xObjectDataApi', name: 'entityApiKey', label: '绑定订单实体' },
  ];
}

export default OrderCardModel;
```

## TypeScript 类型建议

为获得 IDE 提示，可在 `@types/` 或工程内定义：

```ts
// @types/cmp-model.d.ts
export interface CmpEvent { apiKey: string; label: string; helpText?: string }
export interface CmpFunction { apiKey: string; label: string; helpTextKey?: string }

export interface CmpModel<P = Record<string, any>> {
  label: string;
  description: string;
  iconUrl?: string;
  tags?: string[];
  exposedToDesigner?: boolean;
  enableDuplicate?: boolean;
  targetPage?: Array<
    'all' | 'indexPage' | 'entityListPage' | 'entityFormPage'
    | 'entityDetailPage' | 'customPage' | 'bizPage'
  >;
  targetObject?: string[];
  targetApplication?: string[];
  targetDevice?: 'all' | 'web' | 'mobile';
  defaultComProps?: Partial<P>;
  events?: CmpEvent[];
  functions?: CmpFunction[];
  propsSchema: Array<PropsSchemaItem>;
}

export interface PropsSchemaItem {
  type: string;       // 见 props-schema.md
  name: string;
  label: string;
  options?: Array<{ label: string; value: any }>;
  [key: string]: any; // 具体 type 的附加字段
}
```

## 常见问题

- **`cmpType` 要不要自己写？** 不需要。CLI 按目录名生成并注入。手写会被覆盖。
- **`propsSchema` 为空会怎样？** 组件能拖入但无配置面板，只能用 `defaultComProps` 的固定值。
- **设计器里看不到组件？** 检查：组件目录内是否有 `model.ts` / `model.js`；`targetPage` / `targetDevice` 是否与当前设计器匹配；是否 `exposedToDesigner: false`。

:::

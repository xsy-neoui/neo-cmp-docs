# 自定义配置项开发

> **版本说明**：本文档基于平台当前技术栈编写。UI 库版本以 `references/platform-deps.md` 为准（当前 `antd@4.9.4`）。若平台后续升级 antd 大版本，请注意相关 API 差异（如 Modal `visible` → `open`）。

当[表单类配置项](./props-schema.md) 和[数据源类配置项](./props-schema.md) 都无法满足自定义组件的特殊属性配置交互时，可在工程中开发**自定义配置项**，通过 amis 的 `@FormItem` 注册为新的 `type`，再在 `propsSchema` 中使用。

::: v-pre

## 整体流程

1. 在工程里开发自定义配置项组件（展示输入框 + 弹窗 / 抽屉等复杂编辑区）。
2. 用 `@FormItem({ type: 'xxx' })` 注册为 amis 表单项并导出。
3. 在组件的 `model.ts` 里 `import` 注册侧产物 + 在 `propsSchema` 中使用同名 `type`。

> **路径约定**：自定义配置项不要放到 `src/components/<xxx>/` 下，避免被 CLI 识别为自定义组件。放到 `src/components/<yourCmp>__c/<customPropsItem>/` 的子目录（与消费它的组件同目录），或 `src/custom-props-items/` 之类的独立目录。

## 步骤一：开发自定义配置项组件

关键约定：

| 约定 | 说明 |
|---|---|
| 当前值 | `this.props.value` 读取（与 `defaultComProps` 对应字段初始值对齐） |
| 写回表单 | 用户确认后 **必须调用 `this.props.onChange(newValue)`**，否则设计器不会持久化 |
| `detectProps` | 若渲染依赖 `data` 等上下文字段变化，要在 `@FormItem({ detectProps: ['data'] })` 声明 |
| 标签 / 布局 | `label` / `description` / 校验提示 / 表单项布局由 amis 处理，**不要**在自定义组件里重复实现 |

示例：基于 `@wibetter/json-editor` 的样式配置（摘自 `neo-bi-cmps` 的 `customStyleConfig`）：

```tsx
// @ts-ignore
import { FormItem, RendererProps } from 'amis';
import * as React from 'react';
import { Input, Button, Modal, message } from 'antd';
import { SettingOutlined } from '@ant-design/icons';
// @ts-ignore
import JSONEditor from '@wibetter/json-editor';
import '@wibetter/json-editor/lib/index.css';

import { configSchema } from './configSchema';
import './index.scss';

interface ICustomStyleConfigProps {
  onChange?: (value: unknown) => void;
  value?: unknown;
  name: string;
  viewStyle?: string;
  wideScreen?: boolean;
}

interface ICustomStyleConfigState {
  isModalVisible: boolean;
  editorValue: unknown;
}

@FormItem({
  type: 'customStyleConfig',
  detectProps: ['data'],
})
export default class CustomStyleConfigRenderer extends React.Component<
  RendererProps & ICustomStyleConfigProps,
  ICustomStyleConfigState
> {
  constructor(props: RendererProps & ICustomStyleConfigProps) {
    super(props);
    this.state = { isModalVisible: false, editorValue: props.value ?? {} };
    this.showModal = this.showModal.bind(this);
    this.handleModalOk = this.handleModalOk.bind(this);
    this.handleModalCancel = this.handleModalCancel.bind(this);
    this.handleEditorChange = this.handleEditorChange.bind(this);
    this.getDisplayValue = this.getDisplayValue.bind(this);
  }

  handleEditorChange(value: unknown) { this.setState({ editorValue: value }); }

  handleModalOk() {
    const { editorValue } = this.state;
    const { onChange } = this.props;
    try {
      onChange?.(editorValue);
      this.setState({ isModalVisible: false });
    } catch {
      message.error('保存配置失败');
    }
  }

  handleModalCancel() {
    this.setState({ isModalVisible: false, editorValue: this.props.value ?? {} });
  }

  showModal() {
    this.setState({ isModalVisible: true, editorValue: this.props.value ?? {} });
  }

  getDisplayValue() {
    const { value } = this.props;
    if (!value || typeof value !== 'object' || Object.keys(value as object).length === 0) return '';
    return '已配置自定义样式';
  }

  render() {
    const { disabled, viewStyle, wideScreen, value } = this.props;
    const { isModalVisible } = this.state;

    return (
      <div className="properties-panel-custom-style-config">
        <div className="custom-style-config-input-container">
          <Input value={this.getDisplayValue()} placeholder="请配置自定义样式" disabled={disabled} readOnly className="custom-style-config-input" />
          <Button type="text" icon={<SettingOutlined />} onClick={this.showModal} disabled={disabled} className="custom-style-config-setting-btn" />
        </div>
        <Modal
          title="自定义样式配置"
          visible={isModalVisible}
          onOk={this.handleModalOk}
          onCancel={this.handleModalCancel}
          width={800}
          centered
          okText="确定"
          cancelText="取消"
          destroyOnClose={false}
        >
          <div className="custom-style-config-modal-content">
            {isModalVisible && (
              <JSONEditor
                schemaData={configSchema}
                jsonData={value}
                onChange={this.handleEditorChange}
                viewStyle={viewStyle || 'tabs'}
                tabPosition="left"
                wideScreen={wideScreen ?? false}
              />
            )}
          </div>
        </Modal>
      </div>
    );
  }
}
```

> `@FormItem` 的 `type` 在全局需唯一，避免与平台或其他组件重复；建议加业务前缀（如 `biTargetNumberStyle__c` / `orderBoardLayout__c`）。

## 步骤二：在 `model.ts` 引入与使用

在组件模型文件里**先 side-effect 引入注册模块**，再在 `propsSchema` 中用相同的 `type`：

```ts
// 注册 amis 表单项（侧效）
import './customStyleConfig';
// 若样式放单独的文件，按需 import
import './customStyleConfig/index.scss';

export class TargetNumberModel {
  label = '数值指标';
  description = '用于展示关键数值指标';
  tags = ['业务组件'];
  iconUrl = 'https://custom-widgets.bj.bcebos.com/TargetNumber.svg';
  targetPage = ['all'];
  targetDevice = 'all';

  defaultComProps = {
    entityApiKey: '',
    targetNumberStyle: {
      baseStyle: { backgroundColor: '#ffffff' },
      titleStyle: { show: false, text: '', fontSize: 24 },
      numberStyle: { fontSize: 32, fontWeight: 600, color: '#262626' },
    },
  };

  functions = [
    { apiKey: 'loadData', label: '刷新数据', helpTextKey: '重新加载数值指标数据' },
  ];

  propsSchema = [
    {
      type: 'xObjectDetailApi',
      name: 'entityApiKey',
      label: '绑定实体业务数据',
      placeholder: '绑定实体业务数据源',
      disabledFieldSelect: true,
      disabledAutoFetchData: true,
    },
    {
      type: 'selectFieldDescApi',
      name: 'selectFieldDesc',
      xObjectApiKey: 'entityApiKey.xObjectApiKey',
      mode: 'tags',
      label: '绑定字段',
      placeholder: '请至少选择一个要显示的字段',
    },
    {
      type: 'customStyleConfig',  // 自定义配置项的 type
      name: 'targetNumberStyle',
      label: '自定义样式配置',
      viewStyle: 'tabs',          // 通过 propsSchema 继续向自定义配置项组件传参
      wideScreen: false,
    },
  ];
}

export default TargetNumberModel;
```

**关键点**：

- `type` 与 `@FormItem({ type })` 的 type 完全一致
- `name` 与组件的 `defaultComProps` / `props` 字段保持一致
- `propsSchema` 上额外写的 `viewStyle` / `wideScreen` 等字段会作为 props 传入自定义配置项组件

## 步骤三：从消费方读取值

组件代码里和其他配置项一样读取即可：

```tsx
const { targetNumberStyle } = this.props;
// targetNumberStyle => { baseStyle, titleStyle, numberStyle, ... }
```

## 目录建议

```
src/components/targetNumber__c/
├── index.tsx
├── model.ts
├── index.scss
└── customStyleConfig/          # 自定义配置项
    ├── index.tsx               # @FormItem 注册
    ├── index.scss
    └── configSchema.ts
```

> 自定义配置项可以放在消费它的组件目录里（上述结构），也可以放到独立的 `src/custom-props-items/`。关键是 **不要放在 `src/components/` 直接子目录**，因为 CLI 会把子目录识别为自定义组件。

## 常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 设计器里配置了但保存不了 | 组件没调 `onChange` | 确认 / 保存时调用 `this.props.onChange(newValue)` |
| 外部数据变了但自定义配置项没刷新 | `detectProps` 没声明 | `@FormItem({ type, detectProps: ['data'] })` |
| 多个组件都用同一个自定义 `type` | 全局冲突 | 改 `type` 名字（加业务前缀），避免重复 |
| antd 5+ 与 antd 4 Modal API 不一致 | 平台 antd 为 4.9.4 | 使用 `visible` 而非 `open`；与工程 antd 版本严格对齐 |
| 本地预览时找不到 amis | amis 是平台预置依赖 | 用 `neo preview` 或 `neo linkDebug`；不用绕过 CLI |

## 参考

- [自定义配置项开发](https://neo-cmp-docs.netlify.app/config/自定义配置项开发)
- 完整示例：[`targetNumber__c/customStyleConfig/index.tsx`](https://github.com/xsy-neoui/neo-bi-cmps/blob/master/src/components/targetNumber__c/customStyleConfig/index.tsx)
- amis 官方：[自定义 React — 表单项扩展](https://aisuda.bce.baidu.com/amis/zh-CN/docs/extend/custom-react#表单项的扩展)

:::
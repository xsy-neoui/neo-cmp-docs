# 事件动作机制（组件联动的核心）

Neo 平台自定义组件之间的数据联动与交互响应，通过 **事件动作机制** 完成：一方组件**触发事件**，另一方通过**组件动作**响应。本文档说明如何实现。

> **术语**：「组件动作」与组件模型中的 `functions` 字段是同一概念——对外暴露、可被事件调用的方法。设计器界面叫「组件函数」，模型代码里叫 `functions`，组件代码里用 `@NeoEvent.function` 标记。

::: v-pre

## 一、`NeoEvent` 的三类能力

`NeoEvent` 从 `neo-ui-common` 导入（虚拟模块，平台运行时注入）：

```tsx
// @ts-ignore 平台注入，无需 npm install
import { NeoEvent, BaseCmp } from 'neo-ui-common';
```

| API | 用途 | 与模型字段 |
|---|---|---|
| `@NeoEvent.dispatch` | 装饰器：把组件内的一个方法标记为「可对外触发的事件」 | 对应 `model.events[]` |
| `@NeoEvent.function` | 装饰器：把组件内的一个方法标记为「可被事件调用的组件动作」 | 对应 `model.functions[]`；**需继承 `BaseCmp`** |
| `NeoEvent.broadcast(name, data)` / `NeoEvent.listen(name, fn)` | 跨组件广播 / 监听（备选，不推荐作为主方案） | 不需要模型声明 |

## 二、触发事件（dispatch）

### 步骤 1：组件代码里用 `@NeoEvent.dispatch` 标记方法

```tsx
// @ts-ignore
import { NeoEvent } from 'neo-ui-common';

class EntityForm extends React.Component<Props, State> {
  // ...

  /**
   * 表单提交事件
   */
  @NeoEvent.dispatch
  onSubmit(formData: Record<string, any>) {
    // 方法体：在这里做必要的预处理
    // 装饰器会把方法标记为「可对外触发」，具体参数透传给事件绑定的目标
    console.log('触发了 onSubmit 事件', formData);
    return formData;
  }

  handleSave = async () => {
    const formData = await this.collectFormData();
    this.onSubmit(formData); // 直接调用即可触发
  };
}
```

### 步骤 2：在 `model.ts` 声明 `events`

页面设计器只认模型声明，代码里标了的事件若没声明，**设计器看不到**。

```ts
export class EntityFormModel {
  // ... 其他字段

  events = [
    {
      apiKey: 'onSubmit',            // 必须与方法名一致
      label: '提交表单后',              // 设计器里显示的事件名
      helpText: '表单提交后触发该事件',  // 鼠标悬浮提示（可选）
    },
  ];
}
```

### 步骤 3：发布后在设计器中验证

发布后，在页面设计器选中该组件，右侧属性面板会出现事件列表；业务人员可把它接到其他组件的组件动作上。

## 三、被调用的组件动作（function）

### 步骤 1：继承 `BaseCmp`

```tsx
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';

class TargetNumber extends BaseCmp<TargetNumberProps, TargetNumberState> {
  constructor(props: TargetNumberProps) {
    super(props);
    this.state = { loading: false, data: [] };

    // 若组件动作内使用 this，必须在构造函数里 bind(this)
    this.loadData = this.loadData.bind(this);
    this.refresh = this.refresh.bind(this);
  }

  @NeoEvent.function
  async loadData(page = 1, pageSize = 20) {
    this.setState({ loading: true });
    // 省略：拉取数据、setState
    this.setState({ loading: false });
  }

  @NeoEvent.function
  refresh() {
    return this.loadData();
  }

  render() { /* ... */ }
}
```

> 不继承 `BaseCmp`，事件动作 / 组件控制 / 组件可见性等能力都**不会生效**。

### 步骤 2：在 `model.ts` 声明 `functions`

```ts
export class TargetNumberModel {
  // ... 其他字段

  functions = [
    {
      apiKey: 'loadData',
      label: '加载数据',
      helpTextKey: '按分页参数重新拉取数据',
    },
    {
      apiKey: 'refresh',
      label: '刷新',
      helpTextKey: '重新加载当前数据',
    },
  ];
}
```

### 步骤 3：发布后在设计器中验证

其他组件在事件动作面板里选择「执行组件动作」→ 找到目标组件 → 选 `loadData` / `refresh`。

## 四、跨组件广播（可选，不推荐作为主方案）

适合简单场景，耦合和调试成本较高。

### 触发广播

```tsx
// @ts-ignore
import { NeoEvent } from 'neo-ui-common';

componentDidMount() {
  NeoEvent.broadcast('entityFormInit', this.props);
}
```

### 监听广播

```tsx
componentDidMount() {
  NeoEvent.listen('entityFormInit', (eventData: any) => {
    console.log('收到广播 entityFormInit:', eventData);
  });
}
```

> 推荐：**优先用 dispatch + function 的 P2P 模式**，数据流向清晰；广播只用于全局通知。

## 五、完整示例：表单触发事件 + 列表响应刷新

### 组件 A：表单（触发 `onSubmit`）

```tsx
// src/components/entityForm__c/index.tsx
import * as React from 'react';
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';

interface Props { xObjectDataApi?: any; className?: string; }
interface State { submitting: boolean; }

export default class EntityFormC extends BaseCmp<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { submitting: false };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  @NeoEvent.dispatch
  onSubmit(data: any) { return data; }

  async handleSubmit() {
    this.setState({ submitting: true });
    const data = { /* ... 收集表单 */ };
    this.onSubmit(data); // 触发事件
    this.setState({ submitting: false });
  }

  render() {
    return (
      <div className={`entityForm__c ${this.props.className ?? ''}`}>
        <button type="button" onClick={this.handleSubmit}>提交</button>
      </div>
    );
  }
}
```

```ts
// src/components/entityForm__c/model.ts
export class EntityFormModel {
  label = '实体表单';
  description = '提交实体数据的表单组件';
  tags = ['自定义组件'];
  targetDevice = 'pc';

  defaultComProps = {};
  events = [
    { apiKey: 'onSubmit', label: '提交表单后', helpText: '表单提交后触发' },
  ];
  propsSchema = [
    { type: 'xObjectDataApi', name: 'xObjectDataApi', label: '绑定实体' },
  ];
}
export default EntityFormModel;
```

### 组件 B：列表（暴露 `refresh` 动作）

```tsx
// src/components/entityTable__c/index.tsx
import * as React from 'react';
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';
// @ts-ignore
import { xObject } from 'neo-open-api';

interface Props { xObjectDataApi?: any; className?: string; }
interface State { data: any[]; loading: boolean; }

export default class EntityTableC extends BaseCmp<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { data: [], loading: false };
    this.refreshListData = this.refreshListData.bind(this);
  }

  componentDidMount() {
    this.refreshListData();
  }

  @NeoEvent.function
  async refreshListData(page = 1, pageSize = 10) {
    const { xObjectDataApi } = this.props;
    if (!xObjectDataApi?.xObjectApiKey) return;

    this.setState({ loading: true });
    const res = await xObject.query({ ...xObjectDataApi, page, pageSize });
    this.setState({ data: res.data ?? [], loading: false });
  }

  render() { /* 渲染表格略 */ return <div className={`entityTable__c ${this.props.className ?? ''}`} />; }
}
```

```ts
// src/components/entityTable__c/model.ts
export class EntityTableModel {
  label = '实体表格';
  description = '展示实体数据的表格';
  tags = ['自定义组件'];
  targetDevice = 'pc';

  defaultComProps = {};
  functions = [
    { apiKey: 'refreshListData', label: '刷新列表数据', helpTextKey: '重新拉取表格数据' },
  ];
  propsSchema = [
    { type: 'xObjectDataApi', name: 'xObjectDataApi', label: '数据源' },
  ];
}
export default EntityTableModel;
```

### 在页面设计器里连线

1. 把 `entityForm__c` 和 `entityTable__c` 都拖到页面。
2. 选中 `entityForm__c`，在「事件配置」里添加：
   - 事件：`提交表单后`
   - 动作：**执行组件动作** → 目标组件 `entityTable__c` → 组件动作 `刷新列表数据`
3. 运行：表单提交后，列表自动刷新。

## 六、常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 事件动作面板里看不到组件动作 | 未继承 `BaseCmp`；或 `model.functions` 未声明 | 组件 `extends BaseCmp` + 声明 `functions` |
| 组件动作运行时 `this` 是 undefined | 动作里用了 `this`，但构造函数没 `bind` | 构造函数里 `this.xxx = this.xxx.bind(this)` |
| 组件动作不生效 | `apiKey` 与方法名不一致 | `model.functions[i].apiKey` 严格匹配方法名 |
| 事件触发后目标组件没反应 | 装饰器 `@NeoEvent.dispatch` 写在普通函数里（没用方法调用语法） | 只能装饰在类的方法上；触发时 `this.methodName(args)` |
| `@NeoEvent` 装饰器报错 | TS 项目没开 `experimentalDecorators` | `tsconfig.json` 设 `"experimentalDecorators": true`（CLI 模板默认开启） |
| 广播监听重复触发 | 多次 `listen` 没清理 | 在 `componentWillUnmount` 里取消监听（按 API 文档，一般会返回一个 unsub 句柄） |
| 构造函数没继承 `super(props)` | `BaseCmp` 初始化失败 | 类组件构造函数必须 `super(props)` 首行 |

## 七、TypeScript 声明补充

若 TS 报 `NeoEvent` / `BaseCmp` 的类型错误，可在 `@types/` 添加最小声明：

```ts
// @types/neo-ui-common.d.ts
declare module 'neo-ui-common' {
  export class BaseCmp<P = any, S = any> extends React.Component<P, S> {}
  export namespace NeoEvent {
    export const dispatch: MethodDecorator;
    export const function: MethodDecorator;
    export function broadcast(name: string, data?: any): void;
    export function listen(name: string, handler: (data: any) => void): () => void;
  }
}
```

或者简单点，用 `// @ts-ignore` 在 import 行忽略。

## 八、与 BaseCmp 其他能力的关系

继承 `BaseCmp` 后，组件额外获得：

- **组件控制 / 组件可见性**：其他组件可通过事件动作设置当前组件的 `visible` / `disabled`
- **组件动作（`functions`）** 能被设计器识别
- 组件实例会挂到平台运行时的组件注册中心，可通过 `keyIdentifier` 找到

不继承 `BaseCmp` 时，以上能力全部失效——所以**任何需要联动的组件都应该继承 `BaseCmp`**。

:::

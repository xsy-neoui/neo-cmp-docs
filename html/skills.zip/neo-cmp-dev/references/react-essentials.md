# React 核心要点 + Airbnb React/JSX 规范落地

本文汇集 React 开发必须掌握的核心要点，并以 Airbnb React/JSX Style Guide（[airbnb/javascript#react](https://github.com/airbnb/javascript/tree/master/react)）为基准，给出在本工程里**要落地的具体规则**。

> 内容结合 React 官方手册（`https://react.dev/learn` 与 `https://legacy.reactjs.org/docs/getting-started.html`）整理，并与 Airbnb 规范合并。Airbnb 原文经改写以规避许可证长段复制限制。内容已做改写以符合使用规范。

::: v-pre

## 目录

- 基本规则
- 声明 & 命名
- JSX 编写格式
- Props 使用
- Refs
- 方法与生命周期顺序
- 无障碍（a11y）
- ESLint 对齐

---

## 基本规则

- **一个文件一个组件**：同一个源文件只导出一个组件（允许同文件多个纯展示 / 无状态的辅助子组件）。对应 eslint 规则：`react/no-multi-comp`。
- **始终使用 JSX 语法**（不要写 `React.createElement`）。
- **Neo 平台自定义组件默认使用类组件 + `extends BaseCmp`**（需要事件动作 / 组件控制 / 组件可见性时必须）；纯展示子组件可用函数组件 + Hooks。
- 通用 React 开发默认**函数组件 + Hooks**；只在需要 ErrorBoundary 或复杂生命周期时才用类组件。
- **不使用 mixins**（历史包袱 + 污染命名空间 + 隐式依赖）。
- **不使用 `createReactClass`**（老 API，已弃用）。

## 声明 & 命名

### 文件与组件命名

- 文件名用 PascalCase：`InfoCard.tsx`、`OrderList.tsx`
- **本工程约定**：`src/components/<cmpName>__c/index.tsx`——文件名固定为 `index.tsx`；**目录名**使用 `<cmpName>__c` 形式（平台约定 `__c` 后缀），且与 `cmpType` 对齐
- 组件名 PascalCase：`const InfoCard: React.FC<Props> = ...`
- 实例 / 变量 camelCase：`const infoCard = <InfoCard />`
- HOC 命名：`withAuth(BaseCmp)` 生成的内部组件 `displayName` 应为 `withAuth(BaseCmp)`
- 避免用 `displayName` 决定组件名——让组件本身带 name 就够

### Props 命名

- props 字段用 **camelCase**：`onConfirm`、`maxLength`、`disabled`
- 只有当 prop 值本身是 React 组件时才用 PascalCase：`<Form Component={TextInput} />`
- 事件回调用 `onXxx` 开头：`onClick`、`onChange`、`onConfirm`

### 声明组件

```tsx
// ✅ 推荐：函数声明（默认导出 + 命名导出）
const InfoCard: React.FC<InfoCardProps> = (props) => { /* ... */ };
export default InfoCard;
export { InfoCard };
```

```tsx
// ✅ 类组件
class InfoCard extends React.Component<Props, State> { /* ... */ }
export default InfoCard;
```

不要用 `React.createClass`。

## JSX 编写格式

### 缩进与换行

- 多属性时每个 prop 一行，缩进 2 空格：

```tsx
<Button
  type="primary"
  size="large"
  disabled={disabled}
  onClick={handleClick}
>
  确认
</Button>
```

- 单 prop / 自闭合短标签可以一行：`<Icon type="info" />`

### 引号

- JSX 属性使用**双引号**：`<a href="https://x" />`
- JS / TS 代码使用**单引号**：`const a = 'text'`（工程 ESLint 已约束）

### 自闭合标签

- 没有 children 的标签必须自闭合：`<Icon />` 而不是 `<Icon></Icon>`
- 自闭合前有一个空格：`<Icon />`

### 括号

- 多行 JSX return 用括号包住：

```tsx
return (
  <div>
    <Header />
    <Body />
  </div>
);
```

### 键属性（`key`）

- 列表渲染**必须**给 `key`，且**避免用数组下标做 key**（会引发 state 与 DOM 错配）
- 使用数据里的稳定标识：`key={item.id}`

```tsx
// ❌
items.map((it, i) => <Row key={i} data={it} />)

// ✅
items.map((it) => <Row key={it.id} data={it} />)
```

### 条件渲染

- 二选一：三元 `cond ? A : B`
- 单侧显示：`cond && <X />`——注意 `cond` 如果是 `0` 会渲染出 `0`；用 `Boolean(cond) && ...` 或 `!!cond && ...` 规避

### 事件处理

- 内联箭头函数在高频渲染场景下会每次生成新引用，传给 memo 子组件会失效；一般场景可接受，必要时 `useCallback`
- 修饰符（Vue 的 `.stop` / `.prevent`）在 React 里手动：

```tsx
<button onClick={(e) => { e.stopPropagation(); e.preventDefault(); onClick(); }}>
```

## Props 使用

### 必要 vs 可选

- 用 TypeScript 的 `interface Props { title?: string }` 表达可选性；**不**和 `defaultProps` / 解构默认值混用
- **函数组件优先用解构默认值**：

  ```tsx
  const Cmp: FC<Props> = ({ size = 'middle', disabled = false }) => { /* ... */ };
  ```

- 类组件用 `static defaultProps: Partial<Props> = { ... }`

### 类型

- 优先用 TypeScript **代替** `prop-types`
- 遇到无法用 TS 表达的运行时校验场景（如历史纯 JS 组件），才引入 `prop-types`

### 展开 props 的限制

- 只在**对外透传**的情况下用 `{...rest}`（例如把原生 HTML 属性转给底层元素）
- 不要 `{...props}` 透传所有 props——这会把你没预期的字段也传下去，DOM 上冒出 `unknownProp` 警告

### 稳定引用

- 对象 / 数组 / 函数 prop 放在组件体顶层就会每次重建；需要稳定引用时用 `useMemo` / `useCallback`
- 只在被 `React.memo` 包裹的子组件或 effect 依赖项里才值得"手动稳定"

## Refs

- 函数组件用 `useRef()`；类组件用 `React.createRef()`
- DOM 引用：`ref={myRef}`；实例方法暴露：`forwardRef` + `useImperativeHandle`
- 不要用字符串 ref（`ref="input"`）——已废弃

```tsx
// 函数组件 forwardRef 模式
export interface InputHandle { focus: () => void; }

const MyInput = React.forwardRef<InputHandle, Props>((props, ref) => {
  const inputRef = useRef<HTMLInputElement>(null);
  useImperativeHandle(ref, () => ({
    focus: () => inputRef.current?.focus(),
  }));
  return <input ref={inputRef} {...props} />;
});
```

## 方法与生命周期顺序

**类组件内部顺序（Airbnb 建议）**：

1. 可选的 `static` 方法（`static defaultProps`、`static getDerivedStateFromProps` 等）
2. `constructor`
3. `componentDidMount`
4. `shouldComponentUpdate`
5. `componentDidUpdate`
6. `componentWillUnmount`
7. 事件处理函数（`handleXxx`）
8. `getXxx` 等帮助函数
9. 可选的 `render` 子方法（`renderHeader()` / `renderBody()`）
10. `render`

**函数组件内部顺序**：

1. 解构 props / 默认值
2. `useState` / `useReducer`（状态类）
3. `useRef` / `useContext`（引用/上下文类）
4. `useMemo`（派生值）
5. `useCallback`（稳定回调）
6. `useEffect` / `useLayoutEffect`（副作用）
7. 事件处理函数（普通函数或 `useCallback` 包装）
8. 早期 return / 条件分支
9. `return (...)`（JSX）

> 这不是硬规则，但保持一致能让 diff / review 更顺。

## 无障碍（a11y）

- 交互元素优先使用原生语义（`<button>` 而非 `<div onClick>`）
- `<button>` 默认 `type="submit"`，在非 form 场景务必写 `type="button"`
- 图片必须带 `alt`（装饰性用 `alt=""`）
- 可交互自定义元素必须处理键盘（`onKeyDown` 处理 Enter/Space）
- 禁用 `autoFocus`（抢焦点的干扰性很强，除非场景真的需要）

## ESLint 对齐

工程自带 `.eslintrc.js` / `.eslintrc.ts.js` 已继承 `airbnb-base` + `prettier`，并启用了 React 相关规则：

- `react/jsx-uses-react`
- `react/jsx-uses-vars`
- `import/extensions`：`.js/.jsx/.ts/.tsx` 可省略扩展名
- `quotes`：单引号
- `max-len`：150
- `camelcase`：双峰驼命名

如需增加规则，在项目级别的 `.eslintrc.js` 里 `extends: ['airbnb', 'airbnb/hooks', 'prettier']`（`airbnb` 比 `airbnb-base` 多一套 React/JSX 规则）。推荐额外打开：

```js
rules: {
  'react/jsx-filename-extension': [1, { extensions: ['.jsx', '.tsx'] }],
  'react/prop-types': 0, // 用 TS 则关闭
  'react/require-default-props': 0,
  'react-hooks/rules-of-hooks': 'error',
  'react-hooks/exhaustive-deps': 'warn',
}
```

## React 16 相关要点

- Hooks 在 `16.8+` 可用；本工程对齐 `react ^16.13.1` → Hooks 可用
- 无 `useId` / `useDeferredValue` / `useTransition`（React 18 特性）
- 无自动批处理：`setTimeout` / Promise 回调里多次 `setState` 会多次渲染，必要时用 `ReactDOM.unstable_batchedUpdates(() => { ... })`
- `ReactDOM.render` 而非 `createRoot`
- `Suspense` 只支持 `React.lazy` 的代码分割，不支持数据获取 Suspense

## 资料来源

- React 官方手册：[react.dev/learn](https://react.dev/learn)
- React 16 Legacy 文档：[legacy.reactjs.org/docs/getting-started.html](https://legacy.reactjs.org/docs/getting-started.html)
- Airbnb React/JSX Style Guide：[github.com/airbnb/javascript/tree/master/react](https://github.com/airbnb/javascript/tree/master/react)
- Rules of Hooks：[legacy.reactjs.org/docs/hooks-rules.html](https://legacy.reactjs.org/docs/hooks-rules.html)

以上参考内容已重写，以符合许可证限制。Airbnb React/JSX Style Guide 的相关规则由作者原文（MIT 许可证）总结改写。

:::

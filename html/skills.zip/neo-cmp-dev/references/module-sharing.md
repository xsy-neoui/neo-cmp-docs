# 组件模块共享（跨自定义组件复用）

在多个自定义组件之间通过 **模块联邦** 共享公共代码：**提供方 A** 导出模块，**消费方 B** 声明远程依赖后直接 `import`。避免重复打包、统一维护。

::: v-pre

## 何时使用

- 多个自定义组件工程都用到同一份工具 / 子组件 / 第三方库（如 `moment`、`echarts`）。
- 公共逻辑频繁变动，希望统一升级，不希望每个组件各打一份。

## 术语

| 术语 | 说明 |
|---|---|
| 组件 A（**提供方**） | 导出共享模块 |
| 组件 B（**消费方**） | 声明依赖 A，直接 import A 暴露的模块 |
| `neoCommonModule.exports` | 在 A 的 `neo.config.js` 配置，列出要对外暴露的模块 |
| `remoteDeps` | 在 B 的 `neo.config.js` 配置，声明「依赖的远程自定义组件」（按 `cmpType` 填写） |
| `externals` | 在 B 的 `neo.config.js` 配置，声明「代码里 import 时不打包、运行时从远程解析」的模块名 |

## 配置

### 提供方（组件 A）：`neoCommonModule.exports`

```js
// customCmpA 的 neo.config.js
const path = require('path');

module.exports = {
  neoCommonModule: {
    // 数组写法：导出第三方依赖（如 echarts / moment）
    // exports: ['echarts'],

    // 对象写法：导出项目内子模块。key 是对外 import 名，value 用绝对路径
    exports: {
      xxModuleA: path.resolve(__dirname, './src/components/xxModuleA'),
      sharedUtils: path.resolve(__dirname, './src/shared/utils'),
    },
  },
};
```

### 消费方（组件 B）：`remoteDeps` + `externals`

```js
// customCmpB 的 neo.config.js
module.exports = {
  neoCommonModule: {
    remoteDeps: ['customCmpA'],        // 依赖哪些远程自定义组件（按 cmpType 填）
    externals: ['xxModuleA', 'sharedUtils'], // 代码里要 import 的模块名（=与 A 的 exports key 一致）
  },
};
```

> **硬约束**：`externals` 必须与 `remoteDeps` **同时配置**。否则运行时找不到远程模块。

### 消费方代码里正常 import

```tsx
import xxModuleA from 'xxModuleA';           // 像普通包一样用
import { fmtDate, fetchJson } from 'sharedUtils';
```

## `remoteDeps` vs `externals`

| 维度 | `externals` | `remoteDeps` |
|---|---|---|
| 阶段 | 构建（Webpack） | 运行前注入的全局元数据 |
| 作用 | 不把指定模块打进包；运行时按 `neoRequire(模块名)` 解析 | 告诉平台：加载本组件前要先加载哪些其它自定义组件 |
| 典型值 | 依赖的第三方包名或 A 的 `exports` key（如 `dep1` / `xxModuleA`） | 远程组件的 cmpType（如 `customCmpA` / `entityGrid3__c`） |

**组合使用**：二者缺一不可。`externals` 管打包；`remoteDeps` 管组件级依赖。

## 完整示例

**customCmpA** 导出 `dep1` / `dep2` / `dep3` 三个子模块：

```js
// customCmpA/neo.config.js
const path = require('path');
module.exports = {
  neoCommonModule: {
    exports: {
      dep1: path.resolve(__dirname, './src/shared/dep1'),
      dep2: path.resolve(__dirname, './src/shared/dep2'),
      dep3: path.resolve(__dirname, './src/shared/dep3'),
    },
  },
};
```

**customCmpB** 使用 A 的 `dep1` / `dep2`：

```js
// customCmpB/neo.config.js
module.exports = {
  neoCommonModule: {
    remoteDeps: ['customCmpA'],
    externals: ['dep1', 'dep2'],
  },
};
```

```tsx
// customCmpB/src/components/xxx/index.tsx
import { doSomething } from 'dep1';
import { doAnother } from 'dep2';
```

## 配置关系小结

| 侧 | 配置项 | 作用 |
|---|---|---|
| 组件 A | `neoCommonModule.exports` | 把本地模块映射为联邦名（`key` = 对外的 import 名） |
| 组件 B | `neoCommonModule.remoteDeps` | 声明依赖哪几个自定义组件作为远程 |
| 组件 B | `neoCommonModule.externals` | 声明本工程不打进包、由远程提供的模块名（与 A 的 key 对齐） |

## 上线流程

1. **先发布组件 A**（`neo push cmp`），确保平台能加载到 A 的共享模块。
2. **发布 / 联调组件 B**（`neo push cmp` 或 `neo linkDebug`），此时 B 能解析到 `dep1` 等模块。
3. 维护时：只升级 A，B 无需重构；但**大版本破坏性变更**需要 A / B 协调发版。

## 常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 运行时 `Cannot find module 'dep1'` | B 只配了 `externals`，没配 `remoteDeps` | 两者必须同时配置 |
| B 本地预览能跑、发布后找不到远程模块 | A 没发布 / 未加载 | 先发布 A；`neo linkDebug` 时确保 A 已运行或已上线 |
| 多个组件暴露同名模块 | 名字冲突，平台行为不确定 | 统一由一方导出，或改名加前缀 |
| A 改了导出模块签名，B 运行时报错 | A / B 发版不同步 | 约定契约，A 升级后同步升级 B |
| 对象形 `exports` value 是相对路径 | 相对路径解析失败 | 用 `path.resolve(__dirname, '...')` 绝对路径 |

## 参考

- [组件模块共享](https://neo-cmp-docs.netlify.app/tools/组件模块共享)

:::

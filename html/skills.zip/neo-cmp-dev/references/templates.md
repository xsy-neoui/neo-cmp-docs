# 内置模板选型指南

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

`neo init` 按交互菜单选择模板；也可用 `-t <type> -n <name>` 非交互创建。**从符合业务场景的模板起步，能省掉大量样板工作。**

::: v-pre

## 速查表

| 类型 `-t` | 模板仓库 | 技术栈 | 适合场景 | 内置示例组件 |
|---|---|---|---|---|
| `neo` | `neo-custom-cmp-template` | React + TS | 通用业务组件起步 | `simpleCmp__c` / `customApi__c` / `entityDetail__c` / `entityForm__c` / `entityTable__c` |
| `neo-h5-cmps` | `neo-h5-cmps` | React + TS（H5） | 移动端（H5）业务组件 | `chatPage__c` / `entityList__c` / `globalSearchInput__c` / `openChatPageBtn__c` / `entityTabs__c` |
| `neo-web-entity-grid` | `neo-web-entity-grid` | React + TS | PC 端大列表 / 筛选 / Picker / 表单 | `entityGrid__c` / `entityGrid2__c` / `entityGrid3__c` / `entityGrid4__c` / `createForm__c` / `searchForm__c` |
| `neo-web-form` | `neo-web-form` | React + TS | 表单录入 + 汇总（批量） | `batchAddTable__c` / `listSummary__c` |
| `antd` | `antd-custom-cmp-template` | React + TS + Ant Design | 基于 antd 的通用 UI 组件 | `dataDashboard__c` / `searchWidget__c` |
| `echarts` | `echarts-custom-cmp-template` | React + TS + ECharts | 图表组件 | `chartWidget__c` |
| `amap` | `map-custom-cmp-template` | React + TS + 高德地图 | 地图组件 | `mapWidget__c` |
| `neo-bi-cmps` | `neo-bi-cmps` | React + TS | BI 数值指标 / 筛选栏 | `targetNumber__c` / `filterBar__c` |
| `neo-order-cmps` | `neo-order-cmps` | React + TS | 订单类页面信息展示 | `entityInfoCard__c` / `simpleTable__c` |
| `react-ts` | `react-ts-custom-cmp-template` | React + TS | 极简 TS 起步模板 | `listWidget__c` |
| `react` | `react-custom-cmp-template` | React + JS | 极简 JS 起步模板 | `infoCard__c` |
| `vue2` | `vue2-custom-cmp-template` | Vue 2 + JS | Vue 2 起步模板（不支持事件动作） | `vueInfoCard__c` |

## 选型建议

1. **H5 端列表页面** → `neo-h5-cmps`（`entityList__c`、`entityTabs__c`）
2. **PC 端数据管理页（含筛选、工具栏、Picker、表单）** → `neo-web-entity-grid`
3. **批量录入 + 列表汇总** → `neo-web-form`
4. **AI 对话入口** → `neo-h5-cmps`（`openChatPageBtn__c` / `chatPage__c`）
5. **BI 指标 / 筛选栏** → `neo-bi-cmps`
6. **可视化图表** → `echarts` 或（自己接入 antd `Statistic` 等）
7. **地图** → `amap`
8. **通用 antd UI 组件** → `antd`
9. **自己从零写一个小组件** → `neo` 或 `react-ts`（都是最小示例）

## 使用方式

### 交互式

```bash
neo init
# 根据提示选择模板类型 / 项目名
```

### 非交互

```bash
# PC 端 + 大列表
neo init -t neo-web-entity-grid -n myWebListCmp

# H5 端业务组件
neo init -t neo-h5-cmps -n myH5Cmp

# 通用业务组件
neo init -t neo -n myNeoBizCmp

# antd
neo init -t antd -n myAntdCmp

# ECharts
neo init -t echarts -n myChartCmp

# 地图
neo init -t amap -n myMapCmp

# Vue2（不推荐，事件动作不支持）
neo init -t vue2 -n myVue2Cmp
```

## 模板典型示例组件的用途

### `neo-custom-cmp-template`（`-t neo`）

- `simpleCmp__c`：最小化示例，从零学组件开发。
- `customApi__c`：通过 `propsSchema.customApi` 绑定外部接口并以表格展示。
- `entityTable__c`：`xObjectDataApi` 绑定实体，支持 CRUD。
- `entityDetail__c`：`xObjectDetailApi` 绑定详情，支持 1~4 列布局。
- `entityForm__c`：`xObjectDataApi` 绑定实体，表单提交触发 `onSubmit`。

### `neo-h5-cmps`（`-t neo-h5-cmps`）

- `chatPage__c` / `openChatPageBtn__c`：Agent 选择（销售助理 / 营销 / 渠道 / 服务）+ AI 提问。
- `entityList__c`：`xObjectEntityList` 选实体，支持隐藏搜索 / 排序 / 筛选 / 操作按钮。
- `globalSearchInput__c`：全局搜索入口。
- `entityTabs__c`：Tabs + 列表 + AI 对话按钮。

### `neo-web-entity-grid`（`-t neo-web-entity-grid`）

- `entityGrid__c`：通用大列表（可控制所有能力显隐）。
- `entityGrid2__c`：大列表 + 自定义筛选联动（外部调 `handleCustomSearchEvent`）。
- `entityGrid3__c`：Picker 列表（`exposedToDesigner: false`，作为子组件使用）。
- `entityGrid4__c`：自定义工具栏插槽。
- `createForm__c` / `searchForm__c`：新建表单 / 查询表单，配合 `entityGrid2__c` 使用。

### `neo-web-form`（`-t neo-web-form`）

- `batchAddTable__c`：`xObjectDataApi` 绑定实体，逐行录入 + Excel 批量导入，提交触发 `onSubmit`（含所有行）。
- `listSummary__c`：`setListData` 接收列表数据，展示数量 / 金额汇总。

### `neo-bi-cmps`（`-t neo-bi-cmps`）

- `targetNumber__c`：`xObjectDetailApi` 绑定实体 + `selectFieldDescApi` 选展示字段；自定义样式配置（含 `customStyleConfig` **自定义配置项示例**，见 `custom-props-item.md`）。
- `filterBar__c`：筛选工具栏（日期范围 / 负责人 / 业务类型）；广播 `onFiltersChange`；对外暴露 `resetFilters` / `getFilters`。

### `neo-order-cmps`（`-t neo-order-cmps`）

- `entityInfoCard__c`：`xObjectDetailApi` 绑定详情，支持 2~6 列网格布局。
- `simpleTable__c`：`xObjectDataApi` 绑定数据源（只读），外部触发 `loadData` 刷新。

## 一行指引

- 不知道选什么 → 先 `neo init -t neo -n myCmp`，看 `simpleCmp__c` 入门。
- 要做列表 → H5 选 `neo-h5-cmps`，PC 选 `neo-web-entity-grid`。
- 要做 AI / 对话 → `neo-h5-cmps`。
- 要做图表 → `echarts` / `antd`（如只用 `Statistic` 等轻量组件）。
- 要做地图 → `amap`。

## 模板之外：自己从 `neo create project` 起步

```bash
neo create project          # 创建空项目，不含任何自定义组件
cd xxCmpProject
neo create cmp              # 交互创建一个自定义组件
# 或 neo create cmp --name=myCmp --targetDevice=web
```

默认在 `src/components/` 下生成 `<cmpName>/`，包含 `index.tsx` / `model.ts` / `index.scss`。

## 官方参考

- [示例模板](https://neo-cmp-docs.netlify.app/示例模板)
- [CLI使用说明 · 内置模板](https://neo-cmp-docs.netlify.app/guide/CLI使用说明#内置模板)

:::

# `propsSchema` 属性面板配置（平台真实类型）

`propsSchema` 是 `model.ts` 中**最核心的字段**——它决定业务人员在设计器右侧能改什么、怎么改。**类型必须使用平台封装的 `type` 名称**（不是 `input` / `select` / `radio` 这样的泛名）。

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

完整 type 列表与 props 请见平台文档：
- 表单类：[表单类配置项](https://neo-cmp-docs.netlify.app/config/表单类配置项)
- 数据源类：[数据源类配置项](https://neo-cmp-docs.netlify.app/config/数据源类配置项)
- 顶层说明：[组件属性配置项](https://neo-cmp-docs.netlify.app/config/组件属性配置项)

::: v-pre

## 设计原则

1. **少而精**：配置项越多，使用者理解成本越高。优先用少量语义清晰的配置项覆盖常见定制。
2. **与实现一致**：`propsSchema[].name` 必须是组件 props 字段名；`options[].value` 类型与 props TS literal union 对齐。
3. **类型与控件匹配**：文本 → `panelInput`，布尔 → `panelSwitch`，数字 → `panelNumber`，枚举 → `panelSelect` / `neoRadio`，颜色 → `panelColor`，实体相关 → `xObjectEntityList` / `xObjectDataApi` 等。
4. **合理默认值**：每个 `propsSchema` 条目都应在 `defaultComProps` 里有默认值。
5. **事件回调不进 `propsSchema`**：`onXxx` 由 `model.events` 声明，设计器通过「事件动作」面板绑定。

## 表单类配置项

| type | 适用 | props 数值类型 | 关键字段 |
|---|---|---|---|
| `panelInput` | 单行文本（标题、占位、尺寸字符串等） | `string` | `name` / `label` / `placeholder` / `value` / `disabled` / `visibleOn` / `hiddenOn` |
| `panelSelect` | 下拉单选（与 options[].value 类型一致） | `string \| number \| boolean` | `name` / `label` / `value` / `options: {label,value}[]` / `placeholder` / `disabled` |
| `panelSwitch` | 布尔开关 | `boolean` | `name` / `label` / `value` / `defaultChecked` / `checkedChildren` / `unCheckedChildren` / `size` |
| `panelNumber` | 数字 | `number \| null` | `name` / `label` / `value` / `defaultValue` / `min` / `max` / `step` / `precision` / `size` |
| `panelColor` | 颜色选择器（`#RRGGBB` / `rgba(...)`） | `string` | `name` / `label` / `value` / `defaultValue` / `disabled` / `className` |
| `neoRadio` | 单选（同组互斥） | `string \| number` | `name` / `label` / `value` / `defaultValue` / `options: {label,value}[]` / `optionType` |
| `neoCheckbox` | 多选 | `string[] \| boolean` | `name` / `label` / `value` / `defaultValue` / `options` |
| `neoCascader` | 级联单选（选中路径数组） | `string[] \| number[]` | `name` / `label` / `value` / `defaultValue` / `options`（含 children） / `allowClear` / `multiple` |
| `neoDatePicker` | 日期（含时间） | `string` / Date | `name` / `label` / `value` / `format` / `picker` / `showTime` / `allowClear` |
| `neoTimePicker` | 时间 | `string` / Date | `name` / `label` / `value` / `format` / `allowClear` |
| `neoRate` | 评分 | `number` | `name` / `label` / `value` / `count` / `allowHalf` |
| `neoSlider` | 滑动输入条（非 range 为 number，range 为 `[number,number]`） | `number \| [number,number]` | `name` / `label` / `min` / `max` / `step` / `marks` |
| `neoTransfer` | 穿梭框（targetKeys） | `string[]` | `name` / `label` / `dataSource: {key,title}[]` / `titles` / `showSearch` |
| `neoTreeSelect` | 树选择（单 / 多） | `string \| string[]` | `name` / `label` / `treeData` / `multiple` / `treeCheckable` / `showSearch` |
| `neoUpload` | 上传（URL / id / fileList） | 视平台约定 | `name` / `label` / `action` / `accept` / `maxCount` / `multiple` / `beforeUpload` |

### 联动控制

所有类型都可用 `visibleOn` / `hiddenOn` 做**条件显隐**，值为针对表单其他字段的表达式：

```ts
{ type: 'panelInput', name: 'height', label: '高度', visibleOn: '!autoHeight' }
```

## 数据源类配置项

用于绑定平台实体数据源、字段、视图与自定义 API。返回结构是**对象**，不同 type 字段不同。

| type | 作用 | value 结构（核心字段） |
|---|---|---|
| `xObjectEntityList` | 下拉选实体 | `string`（实体 `apiKey` / `xObjectApiKey`） |
| `xObjectDataApi` | 列表数据源（实体 + fields + 分页） | `{ xObjectApiKey, fields, fieldDescList, page, pageSize }` |
| `xObjectDetailApi` | 单条详情（实体 + objectId + fields） | `{ xObjectApiKey, objectId, fields?, fieldDescList? }` |
| `selectFieldsApi` | 穿梭框多选字段 apiKey（需要 `xObjectApiKey` 来源） | `string[]` |
| `selectFieldDescApi` | 下拉选字段（返回字段描述数组） | `Array<{label,value}>`（value 为字段 apiKey） |
| `dataViewIdSelect` | 选实体视图 | `string`（viewId） |
| `customApi` | 绑定平台自定义 API | `{ apiUrl, methodType, headers?, data? }` |

### 数据源配置项的依赖关系

- `xObjectEntityList` 只出实体 key；字段选择要配 `selectFieldsApi` / `selectFieldDescApi`，并用 `xObjectApiKey` 指向实体字段的路径。
- `selectFieldsApi.xObjectApiKey` 与 `selectFieldDescApi.xObjectApiKey` 可以写成路径，如 `'dataSource.xObjectApiKey'`，表示从 `props.data.dataSource.xObjectApiKey` 读取实体 key。
- `dataViewIdSelect.xObjectApiKey` 同上。
- `xObjectDataApi` 已经同时配置实体 + 字段 + 分页；单独用这个即可。

### 示例：实体列表组件

```ts
propsSchema = [
  {
    type: 'xObjectEntityList',
    name: 'xObjectApiKey',
    label: '对象实体',
    custom: false, // false 只看标准实体；true 只看自定义实体；不传则全部
  },
  {
    type: 'selectFieldDescApi',
    name: 'selectFieldDesc',
    label: '展示字段',
    xObjectApiKey: 'xObjectApiKey', // 默认就是这个，写出来更清晰
    mode: 'tags',
    placeholder: '请至少选择一个要显示的字段',
  },
  {
    type: 'dataViewIdSelect',
    name: 'defaultViewId',
    label: '默认视图',
    xObjectApiKey: 'xObjectApiKey',
    placeholder: '请选择列表视图',
  },
];
```

### 示例：详情卡片组件

```ts
propsSchema = [
  {
    type: 'xObjectDetailApi',
    name: 'entityApiKey',
    label: '绑定实体业务数据',
    placeholder: '绑定实体业务数据源',
  },
  {
    type: 'selectFieldDescApi',
    name: 'selectFieldDesc',
    label: '绑定字段',
    xObjectApiKey: 'entityApiKey.xObjectApiKey',
    mode: 'tags',
    placeholder: '请至少选择一个要显示的字段',
  },
];
```

对应 props 读取：

```tsx
const { entityApiKey, selectFieldDesc } = this.props;
// entityApiKey => { xObjectApiKey, objectId, fields?, fieldDescList? }
// selectFieldDesc => [{ label, value }]
// 调用 xObject.get(entityApiKey.xObjectApiKey, entityApiKey.objectId) 拿详情
```

### 示例：自定义 API

```ts
{
  type: 'customApi',
  name: 'fetchConfig',
  label: '自定义接口',
  description: '请选择已注册的 OpenAPI；Data 中 Value 可填 JSON。',
}
```

组件里用：

```tsx
// @ts-ignore
import { customApi } from 'neo-open-api';

const { fetchConfig } = this.props;
const result = await customApi.run(fetchConfig);
```

## `name` 与 React props 的对齐

```ts
// 组件
interface Props {
  title?: string;
  size?: 'small' | 'middle' | 'large';
  visible?: boolean;
  xObjectApiKey?: string;
}

// model.ts
defaultComProps = {
  title: '标题',
  size: 'middle',
  visible: true,
  xObjectApiKey: '',
};
propsSchema = [
  { type: 'panelInput', name: 'title', label: '标题' },
  {
    type: 'panelSelect', name: 'size', label: '尺寸',
    options: [
      { label: '小', value: 'small' },
      { label: '中', value: 'middle' },
      { label: '大', value: 'large' },
    ],
  },
  { type: 'panelSwitch', name: 'visible', label: '是否可见', defaultChecked: true },
  { type: 'xObjectEntityList', name: 'xObjectApiKey', label: '对象实体列表' },
];
```

### 嵌套对象的选择

- **数据源类** 的值天然是嵌套对象（`{ xObjectApiKey, fields, ... }`），直接读 `this.props.xxx.fieldName` 即可。
- **表单类** 配置项避免嵌套对象；能拍平就拍平：

```ts
// ❌ 不推荐
interface Props { style?: { bg: string; fg: string; size: number } }

// ✅ 推荐
interface Props { bgColor?: string; fgColor?: string; fontSize?: number }
```

## 不要把事件回调放进 `propsSchema`

回调（`onConfirm` / `onSubmit` / `onCardClick`）由平台**事件动作**绑定：

1. 组件代码里用 `@NeoEvent.dispatch` 标记；
2. `model.events` 里声明 `{ apiKey, label, helpText }`；
3. 设计器里业务人员通过「事件配置面板」把它接到其它组件的「组件动作」上。

```tsx
// ✅ 不要写进 propsSchema，写进 events
@NeoEvent.dispatch
onSubmit(payload) { /* ... */ }

// model.ts
events = [{ apiKey: 'onSubmit', label: '提交表单后', helpText: '表单提交后触发' }];
```

## `defaultComProps` 协作

- **每个 propsSchema 条目都应在 `defaultComProps` 里有默认值**（除非有意留空）；
- 不在组件里写 `props = {} 解构默认值` 兜底——让设计器看到真实的初始状态。

**例外——数据源对象类型字段不加入 `defaultComProps`**：

值为对象类型的数据源类配置项（`xObjectDataApi` / `xObjectDetailApi` / `customApi`）**不应出现在 `defaultComProps` 中**。因为这些值由业务方在设计器中通过数据源配置面板绑定产生，预设空对象 `{}` 无实际意义。组件代码只需对 `undefined` 做守卫判断：

```tsx
// ✅ 正确：xObjectDataApi 类型不写 defaultComProps，组件做 undefined 守卫
const dataSource = this.props.entityApiKey;
if (dataSource?.xObjectApiKey) {
  const result = await xObject.query(dataSource);
}
```

对于 `xObjectEntityList`（值为 `string`）、`selectFieldsApi`（值为 `string[]`）等非对象类型的数据源类配置项，仍正常添加默认值。

## 完整示例

```ts
// src/components/orderCard__c/model.ts
export class OrderCardModel {
  label = '订单卡片';
  description = '展示单个订单核心信息';
  tags = ['订单', '自定义组件'];
  targetDevice = 'pc';

  defaultComProps = {
    title: '订单号',
    size: 'middle',
    showAmount: true,
    amountColor: '#f5222d',
    emptyText: '暂无订单',
    showActions: ['view', 'cancel'],
    // 注意：xObjectDataApi 类型（entityApiKey）不加入 defaultComProps
  };

  events = [
    { apiKey: 'onRowClick', label: '点击订单行', helpText: '点击某一条订单时触发' },
  ];

  functions = [
    { apiKey: 'refresh', label: '刷新订单', helpTextKey: '重新加载列表数据' },
  ];

  propsSchema = [
    { type: 'panelInput', name: 'title', label: '标题' },
    {
      type: 'neoRadio', name: 'size', label: '尺寸',
      options: [
        { label: '小', value: 'small' },
        { label: '中', value: 'middle' },
        { label: '大', value: 'large' },
      ],
    },
    { type: 'panelSwitch', name: 'showAmount', label: '显示金额' },
    { type: 'panelColor', name: 'amountColor', label: '金额颜色' },
    { type: 'panelInput', name: 'emptyText', label: '空态文案' },
    {
      type: 'neoCheckbox', name: 'showActions', label: '操作按钮',
      options: [
        { label: '查看', value: 'view' },
        { label: '取消', value: 'cancel' },
        { label: '退款', value: 'refund' },
      ],
    },
    {
      type: 'xObjectDataApi',
      name: 'entityApiKey',
      label: '绑定订单实体',
    },
  ];
}

export default OrderCardModel;
```

## 常见陷阱

- **`type` 写成 `input` / `select` / `radio`** → 设计器找不到这个控件。必须是 `panelInput` / `panelSelect` / `neoRadio` 等平台类型。
- **`propsSchema[].name` 写错或大小写不一致** → 该字段在设计器上调不动。
- **`defaultComProps` 漏了某个 schema 字段** → 首次拖入该字段为 `undefined`，组件可能异常。
- **`options.value` 与 props 类型不一致** → `panelSelect` 选了却不生效（例如 option.value 是字符串，props 期望 number）。
- **数据源类配置项传递错了 `xObjectApiKey` 路径** → `selectFieldDescApi` 加载不出字段列表。
- **回调写进 `propsSchema`** → 设计器出现无意义的输入框；回调应由 `model.events` + 事件动作注入。

## 自定义配置项

平台内置类型不够用时（例如要做复杂的弹窗编辑、Schema 配置），可开发**自定义配置项**：用 amis 的 `@FormItem(type)` 注册，在 `propsSchema` 中用同名 `type` 引用。详见 `custom-props-item.md`。

:::

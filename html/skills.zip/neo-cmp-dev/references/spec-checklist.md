# 组件开发规范速查（React 版）

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

本文为 Neo 平台《自定义组件开发规范》在 React 技术栈下的速查。

::: v-pre

## 目录

- 工程目录速查
- 组件目录速查
- 入口文件规则
- 技术栈与版本约束
- 样式隔离工作原理
- 平台能力整合速览
- 模块共享
- 发布前验证清单

---

## 工程目录速查

| 路径 | 说明 |
|---|---|
| `src/assets/` | 静态资源；`css/common.scss`、`css/mixin.scss` 等可注入 |
| `src/assets/img/` | 图片等素材 |
| `src/components/` | **自定义组件根目录**；每个子目录为一个组件 |
| `src/components/<cmpName>__c/` | 单个组件：`index.*` + `model.*` + 可选 `index.scss` |
| `public/` | 本地预览模板 `template.html`、基础脚本与样式 |
| `@types/` | 补充类型声明（如 `neo-ui-common`、`neo-open-api`、`CTX`） |
| `package.json` | `framework: react-ts`、`preview` / `linkDebug` / `pushCmp` 脚本 |
| `tsconfig.json` | TypeScript 编译配置（需 `experimentalDecorators: true`） |
| `neo.config.js` | neo-cmp-cli 工程配置（无需显式配 `entry`，CLI 会按 `src/components/` 自动生成） |
| `commitlint.config.js` | Git 提交规范 |
| `.prettierrc.js` | Prettier 配置 |
| `.npmrc` | NPM 源配置 |

## 组件目录速查

| 路径 | 说明 |
|---|---|
| `src/components/<cmpName>__c/` | 子目录名 = 组件名 = `cmpType`；**平台约定加 `__c` 后缀** |
| `index.tsx` / `index.jsx` / `index.ts` / `index.js` | 组件实现入口（四选一，推荐 `.tsx`） |
| `model.ts` / `model.js` | 组件模型文件 |
| `index.scss` / `style.scss` | 组件样式（CLI 默认对这两类做样式隔离） |
| `common.scss` / `reset.scss` | 弹层类样式（不隔离，用于 Modal / Popover / Tooltip 等 body 挂载组件） |

## 入口文件规则

- CLI 按目录扫描 `src/components/` 自动生成 entry，**不需要手工注册**组件。
- 目录内必须包含 `index.*`（推荐 `.tsx`）作为入口。
- 目录内必须包含 `model.ts` / `model.js` 作为模型文件。
- 若 `neo.config.js` 未显式配置 `entry`，可在 CLI 运行时的控制台输出查看自动生成的入口路径。

## 技术栈与版本约束

**硬约束（版本必须对齐）**：

| 依赖 | 版本 | 备注 |
|---|---|---|
| `react` | `^16.13.1` | React 16.8+ 才有 Hooks |
| `react-dom` | `^16.13.1` | |
| `mobx` | `^6.3.0` | 优先 `makeAutoObservable` |
| `mobx-react` | `^7.0.0` | 用 `observer` 包裹 |
| `axios` | `^0.27.2` | |
| `classnames` | `^2.3.2` | |
| `qs` | `^6.11.0` | |
| `lodash` | `^4.17.21` | |
| `amis` | `^1.1.5` | |

**PC 端（Web）**：

| 依赖 | 版本 |
|---|---|
| `antd` | `4.9.4` |
| `@ant-design/icons` | `^4.8.0` |
| `neo-ui-component-web` | - |

**H5 端**：

| 依赖 | 版本 |
|---|---|
| `antd-mobile` | `2.3.4` |
| `neo-ui-component-h5` | - |

**虚拟模块（不要安装到 `package.json`）**：`neo-ui-common`、`neo-ui-component-web`、`neo-ui-component-h5`。

**平台 SDK（真实 NPM 包，必须安装到 `package.json` 的 `dependencies`）**：`neo-open-api`。

详细 externals 机制见 `platform-deps.md`。

## 样式隔离工作原理

构建时（`push cmp` / `linkDebug`），CLI 会把 `(index|style).(scss|less)` 的顶层规则包一层属性选择器：

```scss
/* 源码 */
.infoCard__c { padding: 12px; }

/* 产物（示意） */
[data-scope="infoCard__c"] .infoCard__c { padding: 12px; }
```

- **组件根节点 className 必须与组件目录名一致**（如 `infoCard__c`），否则作用域不匹配，样式失效。
- **根节点必须合并 `props.className`**：设计器隐藏组件时会注入 `design-hide` 到 `props.className`，不合并则「是否显示」失效。
- `common.scss` / `reset.scss` 默认**不被隔离**，用于需要挂到 `body` 的 antd 弹层。
- 彻底关闭隔离：`neo.config.js` 设 `disableAutoAddStyleScope: true`（不推荐）。

详见 `styling.md`。

## 平台能力整合速览

| 能力 | 位置 / 用法 | 参考文件 |
|---|---|---|
| 用户 / 租户 / 页面信息 | `this.props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` | `runtime-context.md` |
| 平台对象 `CTX`（system/user/ui/util/api） | `this.props.env.ctx` | `runtime-context.md` |
| 组件实例 ID | 运行时 / 画布：`this.props.keyIdentifier`；设计时：`this.props.$com.keyIdentifier` | `runtime-context.md` |
| 事件动作：触发 | `@NeoEvent.dispatch` + `model.events[]` | `event-action.md` |
| 事件动作：被调用 | `extends BaseCmp` + `@NeoEvent.function` + `model.functions[]` + 构造函数 `bind(this)` | `event-action.md` |
| 跨组件广播 | `NeoEvent.broadcast(name, data)` / `NeoEvent.listen(name, fn)` | `event-action.md` |
| 平台实体 CRUD | `xObject.query` / `get` / `create` / `update` / `delete` / `getDesc` / `getEntityList` / `getEntityTypeList` | `open-api.md` |
| 平台自定义 API | `customApi.run(fetchConfig)` / `customApi.getList()` | `open-api.md` |
| 白名单接口请求 | `request({ url, method, headers, data, timeout })` | `open-api.md` |
| 通用代理外部 API | `customApi.run({ apiUrl: '/.../proxy/forward', data: { url, method, data } })` | `open-api.md` |
| 平台 H5 预置组件 | `NeoEntityList` / `GlobalSearchInput`（from `neo-ui-component-h5`，必传 `render`） | `platform-components.md` |
| 平台 PC 预置组件 | `NeoEntityGrid`（from `neo-ui-component-web`，必传 `render` / `name` / `objectApiKey`） | `platform-components.md` |
| 自定义属性配置项 | amis `@FormItem(type)` + `propsSchema` 使用同名 `type` | `custom-props-item.md` |

## 模块共享

多组件项目间复用公共模块：`neo.config.js` 配置 `neoCommonModule`。

- 组件 A **导出**：`exports`（数组写法为第三方依赖；对象写法为项目子模块，value 用绝对路径）
- 组件 B **消费**：`remoteDeps`（远程组件 cmpType）+ `externals`（代码里 import 的模块名）
- `externals` 必须与 `remoteDeps` **同时配置**

具体配置与写法见 `module-sharing.md`。

## 发布前验证清单

### 目录与命名
- [ ] 组件目录名使用 `<cmpName>__c` 后缀，与 `cmpType`（构建生成）一致
- [ ] `index.tsx` + `model.ts`（+ 可选 `index.scss`）就位
- [ ] 根节点 `className = 组件目录名` **且合并** `props.className`

### 模型
- [ ] `model.ts` 含 `label` / `description` / `defaultComProps` / `propsSchema`
- [ ] `targetDevice` 与实际使用的 UI 库对齐（antd→web / antd-mobile→mobile）
- [ ] `propsSchema[].type` 使用平台真实类型（`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `xObjectDataApi` / `xObjectDetailApi` 等）
- [ ] `propsSchema[].name` 与组件 `props` 字段名一一对齐
- [ ] `defaultComProps` 与 `propsSchema` 默认值一致

### 事件动作（如有联动需求）
- [ ] `extends BaseCmp`
- [ ] `@NeoEvent.dispatch` 事件方法在 `model.events` 里声明
- [ ] `@NeoEvent.function` 组件动作在 `model.functions` 里声明
- [ ] 构造函数里对使用 `this` 的组件动作做了 `bind(this)`

### 依赖
- [ ] 平台预置依赖未被打进 bundle（特别是 `react` / `react-dom` / `antd` / `antd-mobile` / `amis`）
- [ ] 虚拟模块（`neo-ui-common` / `neo-ui-component-*`）**不在 `package.json`**
- [ ] **`neo-open-api` 在 `package.json` 的 `dependencies` 中**（真实 NPM 包，必须安装）

### 代码与样式
- [ ] ESLint（Airbnb）通过
- [ ] stylelint（standard）通过
- [ ] `tsc --noEmit` 通过
- [ ] 根节点 className 与组件目录名一致，样式隔离生效
- [ ] **使用 `neo-open-api` 的方法（如 `xObject.query` / `xObject.get` / `customApi.run`）获取实体数据，未手写 `axios`**
- [ ] **`xObject.query` 返回值的 `data` 即为列表数组（`any[]`），正确使用 `result.data || []` 取值**
- [ ] **错误判断使用 `status === true`，不依赖 `code === 0` 或 `code === 200`**

### 联调与发布
- [ ] `neo linkDebug` 在页面设计器里属性面板联动正常
- [ ] 事件动作绑定后行为正确
- [ ] `package.json` 的 `name` 在平台内唯一；`version` 每次递增
- [ ] 已 `neo login`

:::

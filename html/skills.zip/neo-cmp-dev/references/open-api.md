# 平台实体数据源 & 平台自定义 API（`neo-open-api`）

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

自定义组件通过 **`neo-open-api`** 访问平台业务数据：

- **`xObject`**：平台业务对象（实体）的 CRUD + 元数据。
- **`customApi`**：平台自定义 API（含通用代理外部接口）。
- **`request`**：axios 封装，直接发起接口请求（受路径白名单限制）。

## 数据接入决策（在实现组件前先扫描需求）

动手实现之前，先用下面这张决策表判断走哪种数据源：

| 需求特征（关键词） | 决策 | 首选 API | `propsSchema` 配置项 | 参考 |
|---|---|---|---|---|
| 读取 / 列表 / 详情 / 查询平台业务对象数据（客户、联系人、订单、自定义对象 …） | **平台实体数据源** | `xObject.query` / `xObject.get` / `xObject.getDesc` / `xObject.getFileds` | `xObjectEntityList` + `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` | 本文 `xObject` 章节 |
| 新增 / 更新 / 删除平台业务对象数据（提交表单、批量修改状态等） | **平台实体数据源** | `xObject.create` / `xObject.update` / `xObject.delete` | 同上 + 必要的表单类配置项 | 同上 |
| 调平台内已有的「自定义 API」（业务逻辑代码封装的接口） | **平台自定义 API** | `customApi.run` | `customApi`（让业务方在设计器里选择具体 API + 参数） | 本文 `customApi` 章节 |
| 调第三方 / 外部系统 HTTP 接口（天气、地图、ERP、支付…） | **通用代理 + 自定义 API**（先提示用户部署 `forward.zip`） | `customApi.run({ apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', ... })` | `panelInput`（URL / 方法 / 参数模板）或 `customApi` | 本文「通用代理」章节 |
| 外部 API 明确支持 CORS 且路径命中平台白名单 | **直接 `request`**（少见） | `neo-open-api` 的 `request` | — | 本文 `request` 章节 |

**硬性约束**：
- **能用 `xObject` 就不要手写 `axios`**。走 SDK 才能共享登录态、权限、错误码语义、灰度与审计。
- **`propsSchema` 中优先暴露数据源类配置项**（`xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `customApi`），让业务方在设计器里选对象、选字段、写过滤条件。
- **识别到外部 API 场景时必须主动提示用户**部署通用代理，再生成调用代码。
- **所有接口以 `status === true` 判断成功**，`xObject` 各方法、`customApi.run`、`customApi.getList` 必须统一遵循此规则。

::: v-pre

## 导入方式

```tsx
// @ts-ignore 平台运行时注入，无需 npm install
import { xObject, customApi, request } from 'neo-open-api';
```

## 一、`xObject`：业务对象 SDK

### 1. 查询列表 `xObject.query`

```tsx
const result = await xObject.query({
  xObjectApiKey: 'Contact',
  fields: ['name', 'phone', 'email'],
  page: 1,
  pageSize: 20,
  orderBy: 'id desc', // 仅支持对 id 排序
  where: "city = '北京' and name like '张%'", // 可选
});
// result: { status, code, msg, totalSize, data: any[] }
// 注意：status === true 表示请求成功，否则根据 msg 处理错误
```

| 参数 | 说明 |
|---|---|
| `xObjectApiKey` | 业务对象 apiKey |
| `fields` | 字段数组；自动补 `id` |
| `where` | 字符串 or 字符串数组（多条自动 `AND` 拼接）；字符串模式下可写完整 `WHERE` 子句 |
| `page` / `pageSize` | 分页，默认 `1` / `10` |
| `orderBy` | **仅支持 `id asc/desc`**，其他字段排序在客户端做 |

**where 语法要点**（与平台通用查询一致）：

- 支持：`=`、`!=`、`like`、`not like`、`>`、`<`、`>=`、`<=`、`<>`、`in`、`not in`、`between ... and ...`、`is null`、`is not null`、`and`、`or`
- **不支持**：子查询、对「多值字段」做取值条件（只能 `is null` / `is not null`）
- **不支持的字段类型**：多选、文本域、地理位置、图片、引用
- `like '%...%'` **只支持** `'xxx%'` 开头匹配，**不支持** `'%xxx'`

```tsx
// 数组写法（自动 AND）
await xObject.query({
  xObjectApiKey: 'account',
  fields: ['name', 'status'],
  where: ["status = '生效'", "name like '李%'"],
});

// OR / 括号：必须用字符串形式
await xObject.query({
  xObjectApiKey: 'account',
  fields: ['name'],
  where: "(city = '北京' or city = '上海') and level = 1",
});

**返回结构**

```typescript
{
  status: boolean;   // true 表示成功
  code: number;      // 返回码
  msg: string;       // 多为错误信息
  totalSize: number; // 总条数
  data: any[];       // 数据行数组
}
```

### 2. 单条详情 `xObject.get`

```tsx
// 方式一：对象参数
await xObject.get({ xObjectApiKey: 'account', objectId: '4255673156574812' });

// 方式二：位置参数
await xObject.get('account', '4255673156574812');
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |
| `objectId` | 记录 ID |
| `option` / `options`（可选） | 可选请求配置 |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 多为错误信息
  data: Object;     // 记录详情对象
}
```

### 3. 创建 `xObject.create`

```tsx
const r = await xObject.create('Contact', {
  data: {
    name: '王五',
    phone: '13700137000',
    email: 'wangwu@example.com',
  },
});
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |
| `options.data` | 待创建字段键值对 |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 多为错误信息
  totalSize: number;// 条数
  data: Object;     // 新建的记录对象
}
```

### 4. 更新 `xObject.update`

```tsx
await xObject.update('Contact', recordId, {
  data: { name: '王五（更新）' },
});
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 第一个参数：业务对象的 API Key |
| `xObjectId` | 第一个参数：待更新记录 ID |
| `options.data` | 第3个参数：配置项，其中 data 是待更新字段键值对 |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息
  data: Object;     // 更新后的记录对象
}
```

### 5. 删除 `xObject.delete`

```tsx
await xObject.delete('Contact', recordId);
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |
| `xObjectId` | 待删除记录 ID |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息
}
```

### 6. 元数据 `xObject.getDesc`

```tsx
// 获取业务对象描述（字段元数据）
const desc = await xObject.getDesc('Contact');
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |

**返回结构**

```typescript
{
  status: boolean;    // true 表示成功
  code: string;       // 返回码，如 "200"
  msg: string;        // 提示信息，成功时为 "OK"
  data: {             // 实体描述数据
    apiKey: string;           // 实体 API Key
    custom: boolean;          // 是否自定义对象
    label: string;            // 实体显示名称
    disabled: boolean;        // 是否已禁用
    createable: boolean;      // 是否可新建
    deletable: boolean;       // 是否可删除
    updateable: boolean;      // 是否可更新
    queryable: boolean;       // 是否可查询
    feedEnabled: boolean;     // 是否启用动态
    fields: FieldItem[];      // 字段定义列表
  }
}
```

#### data 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `apiKey` | `string` | 实体的 API Key，作为该实体在系统中的唯一标识 |
| `custom` | `boolean` | 是否为自定义对象。`false` 表示标准对象，`true` 表示自定义对象 |
| `label` | `string` | 实体的显示名称，如"销售机会"、"客户" |
| `disabled` | `boolean` | 实体是否已被禁用 |
| `createable` | `boolean` | 当前用户是否有权在该实体上新建记录 |
| `deletable` | `boolean` | 当前用户是否有权删除该实体的记录 |
| `updateable` | `boolean` | 当前用户是否有权更新该实体的记录 |
| `queryable` | `boolean` | 当前用户是否有权查询该实体的记录 |
| `feedEnabled` | `boolean` | 该实体是否启用了动态（Feed）功能 |
| `fields` | `FieldItem[]` | 该实体的字段定义数组，描述每个字段的元信息 |

#### fields 数组元素（FieldItem）字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `apiKey` | `string` | 字段的 API Key，全局唯一标识 |
| `label` | `string` | 字段的显示名称 |
| `type` | `string` | 字段类型。可选值包括：`text`（单行文本）、`textarea`（多行文本）、`int`（整数）、`currency`（金额）、`picklist`（单选下拉）、`boolean`（布尔）、`date`（日期）、`datetime`（日期时间）、`reference`（引用关系）、`owner`（所属人）、`entitytype`（业务类型）、`dimension`（维度）、`formula_real`（公式-数值）、`email`（邮箱）、`phone`（电话）、`url`（网址）等 |
| `itemType` | `string` | 字段的 Java 数据类型，如 `String`、`Long`、`Integer`、`Double`、`Boolean` 等 |
| `defaultValue` | `any` | 默认值，无默认值时返回 `null` |
| `enabled` | `boolean` | 该字段是否启用 |
| `required` | `boolean` | 该字段是否为必填项 |
| `createable` | `boolean` | 新建记录时是否可填写该字段 |
| `updateable` | `boolean` | 更新记录时是否可修改该字段 |
| `sortable` | `boolean` | 该字段是否支持排序 |
| `minLength` | `number` \| `null` | 最小长度限制，无限制时为 `null` |
| `maxLength` | `number` \| `null` | 最大长度限制，无限制时为 `null` |
| `dependentPropertyName` | `string` \| `null` | 级联依赖的父字段 API Key，独立字段时为 `null` |
| `unique` | `boolean` | 该字段值是否唯一 |
| `encrypt` | `boolean` | 该字段值是否加密存储 |
| `nameField` | `boolean` | 该字段是否为实体的名称字段（Name Field） |
| `referTo` | `object` \| `null` | 引用关系的目标实体信息。引用字段（`type: "reference"`）时非 `null`，包含 `apiKey` 字段表示目标实体的 API Key。其他类型为 `null` |
| `selectitem` | `SelectItem[]` | 下拉选项列表，仅 `type: "picklist"` 时有值，否则为空数组 |
| `checkitem` | `CheckItem[]` | 复选选项列表，通常为空数组 |

### 7. 实体列表 `xObject.getEntityList`

```tsx
// 标准 + 自定义
const all = await xObject.getEntityList({ active: true });

// 仅标准
const std = await xObject.getEntityList({ custom: false, active: true });
// 仅自定义
const cus = await xObject.getEntityList({ custom: true, active: true });
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `custom`（可选） | 是否限定为自定义对象。`false` 仅标准对象，`true` 仅自定义对象；不传则返回全部实体 |
| `active`（可选） | 是否仅返回当前用户有权限的对象，默认 `true` |

**返回结构**

```typescript
{
  status: boolean;       // true 表示成功
  code: number;          // 返回码
  msg: string;           // 提示信息
  totalSize: number;     // 总条数
  data: Array<EntityDesc>; // 实体描述列表
}
```

### 8. 业务类型列表 `xObject.getEntityTypeList`

```tsx
const res = await xObject.getEntityTypeList('xObjectApiKey', {
  // 其他请求选项
});
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |
| `options`（可选） | 可选请求配置 |

**返回结构**

```typescript
{
  status: boolean;   // true 表示成功
  code: number;      // 返回码
  msg: string;       // 提示信息
  totalSize: number; // 总条数
  data: any[];       // 业务类型列表
}
```

### 9. 获取业务对象字段列表 `xObject.getFileds`

获取指定业务对象的字段列表，仅返回字段定义数组。

```tsx
const fields = await xObject.getFileds('xObjectApiKey', {
  // 其他请求选项
});
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `xObjectApiKey` | 业务对象的 API Key |
| `options`（可选） | 可选请求配置 |

**返回结构**

```typescript
{
  status: boolean;    // true 表示成功
  code: number;       // 返回码
  msg: string;        // 提示信息
  data: FieldItem[];  // 字段定义数组（同 getDesc 的 fields）
}
```

## 二、`customApi`：平台自定义 API

### 1. 调用自定义 API `customApi.run`

```tsx
const result = await customApi.run({
  apiUrl: '/rest/custom/api/endpoint',
  methodType: 'POST', // 可选，默认 POST
  data: {
    key1: 'value1',
    key2: 'value2',
  },
});
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `apiUrl` | 自定义 API 的 URL 路径 |
| `methodType`（可选） | HTTP 方法，默认 `POST` |
| `data`（可选） | 请求体数据，根据 `methodType` 决定序列化方式 |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息，失败时含具体错误原因
  data: any;        // 接口返回数据，格式由自定义 API 发布者定义
}
```

### 2. 获取自定义 API 列表 `customApi.getList`

```tsx
const list = await customApi.getList({ pageNo: 1, pageSize: 1000 });
```

**参数说明**

| 参数 | 说明 |
|------|------|
| `pageNo`（可选） | 页码，默认 `1` |
| `pageSize`（可选） | 每页条数，默认 `1000` |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息
  data: Array<{
    methodName: string;   // API 名称
    methodType: string;   // HTTP 方法（GET / POST 等）
    URL: string;          // API URL 路径
    // ... 其他自定义 API 元数据字段
  }>;
}
```

**配合 `propsSchema` 的 `customApi` 类型**：

```tsx
// model.ts
propsSchema = [
  { type: 'customApi', name: 'fetchConfig', label: '接口绑定' },
];

// 组件里
const { fetchConfig } = this.props;
const result = await customApi.run(fetchConfig);
```

## 三、`request`：通用请求封装

axios 封装，**仅允许访问白名单路径**：

- `/rest/data/v2.0/scripts` — 自定义 API
- `/rest/metadata/v2.0/dx/logic/extpoints/openapi` — 自定义 API 列表
- `/rest/data/v2.0/xobjects` — 实体 Open API
- `/rest/metadata/v2.0/xobjects/filter` — 实体列表（元数据过滤）
- `/rest/data/v2/query` — 通用查询
- `/rest/neobi/v2.0` — BI
- `/rest/ai/v2.0/agent` — AI Agent

```tsx
const res = await request({
  url: 'https://third-party.example.com/api/v1/query',
  method: 'GET',
  headers: { 'Custom-Header': 'value' },
  data: { q: 'keyword', page: 1 },
  timeout: 30000,
});
```

**参数说明**

| 参数 | 类型 | 说明 |
|------|------|------|
| `url` | `string` | 请求 URL（须在白名单路径内） |
| `method`（可选） | `string` | HTTP 方法，默认 `GET` |
| `headers`（可选） | `object` | 自定义请求头 |
| `data`（可选） | `any` | 请求数据。GET 时序列化为查询参数（`params`），非 GET 以 JSON body 发送 |
| `timeout`（可选） | `number` | 超时时间（毫秒） |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息
  data: any;        // 响应数据
}
```

- GET 时 `data` 会转为 `params`；非 GET 以 JSON body 发送。
- 访问非白名单外部 API 需用「通用代理」。

## 四、通用代理：访问不支持 CORS 的外部 API

### 部署代理

1. 下载 [`forward.zip`](https://neo-cmp-docs.netlify.app/forward.zip)（来自 neo-cmp-docs 在线文档；如链接失效请联系平台支持获取）。
2. Admin → 开发 / 业务逻辑代码 → 代码包 → 新建：
   - 代码名称：通用代理接口
   - Package：`other.xsy.proxy`（与 ZIP 内 Java 包名一致）
3. 上传 ZIP 并发布。

### 调用

**外层**固定 `POST`，**内层** `data` 携带真正要访问的第三方 URL、方法、参数：

```tsx
const result = await customApi.run({
  apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward',
  methodType: 'POST',
  data: {
    url: 'https://third-party.example.com/api/v1/query',
    method: 'GET',
    data: { q: 'keyword', page: 1 },
  },
});
```

**外层请求参数说明**

| 参数 | 说明 |
|------|------|
| `apiUrl` | 固定为 `/rest/data/v2.0/scripts/api/proxy/forward` |
| `methodType` | 固定为 `POST` |
| `data.url`（内层） | 第三方外部 API 的完整 URL |
| `data.method`（内层） | 第三方外部 API 的 HTTP 方法（GET / POST / PUT / PATCH 等） |
| `data.data`（内层） | 第三方外部 API 的请求参数。GET 时序列化为查询参数（`null` 的项忽略），非 GET 以 JSON body 发送 |

**返回结构**

```typescript
{
  status: boolean;  // true 表示成功
  code: number;     // 返回码
  msg: string;      // 提示信息
  data: any;        // 第三方接口的响应数据（可解析为 JSON 则返回对象，否则返回原始字符串）
}
```

**内层 `data` 的行为**：

- **`GET`**：`data` 序列化为查询参数拼到 `url`（`null` 的项忽略）。
- **POST / PUT / PATCH 等**：`data` 作为 JSON body，`Content-Type: application/json`。

**返回**：
- 成功：第三方接口响应（可解析为 JSON 则返回对象，否则原始字符串）。
- 失败：`Result.resultFailWrapper` 封装（错误码如 `5000001` / `5000002`）。

## 五、最小实战示例

### 场景 1：表格组件按实体数据源拉取数据

```tsx
// @ts-ignore
import { BaseCmp, NeoEvent } from 'neo-ui-common';
// @ts-ignore
import { xObject } from 'neo-open-api';

interface Props { xObjectDataApi?: any; className?: string; }
interface State { data: any[]; total: number; loading: boolean; error: string | null }

export default class EntityTableC extends BaseCmp<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { data: [], total: 0, loading: false, error: null };
    this.refreshListData = this.refreshListData.bind(this);
  }

  componentDidMount() { this.refreshListData(); }

  @NeoEvent.function
  async refreshListData(page = 1, pageSize = 10) {
    const { xObjectDataApi } = this.props;
    if (!xObjectDataApi?.xObjectApiKey) return;

    this.setState({ loading: true, error: null });
    try {
      const r = await xObject.query({ ...xObjectDataApi, page, pageSize });
      if (r?.status) {
        this.setState({ data: r.data || [], total: r.totalSize || 0, loading: false });
      } else {
        this.setState({ error: r?.msg || '加载失败', loading: false });
      }
    } catch (e: any) {
      this.setState({ error: e?.message || '加载失败', loading: false });
    }
  }

  render() { return <div className={`entityTable__c ${this.props.className ?? ''}`}>{/* ... */}</div>; }
}
```

### 场景 2：通过自定义 API 请求外部数据

```tsx
// @ts-ignore
import { customApi } from 'neo-open-api';

interface Props { fetchConfig?: any; }

async function loadExternal(fetchConfig: any) {
  if (!fetchConfig?.apiUrl) return null;
  const res = await customApi.run(fetchConfig);
  if (!res?.status) throw new Error(res?.msg || '接口调用失败');
  return res.data;
}
```

## 六、常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 本地预览报 `Cannot find module 'neo-ui-component-*'` | 虚拟模块，本地预览模式下没有这些模块 | 改用 `neo linkDebug` |
| `xObject.query` 对字段排序失败 | 平台**仅支持对 `id` 排序** | 其他字段排序在客户端做 |
| `where` 里对多选字段用 `=` 报错 | 多选不支持取值条件 | 只能用 `is null` / `is not null` |
| `request` 请求 401 / 被拦截 | URL 不在白名单 | 走通用代理 `/rest/data/v2.0/scripts/api/proxy/forward` |
| `customApi.run` 返回 `status: false` | `msg` 里有具体原因 | 按 `msg` 处理；自定义 API 的错误码以发布者实现为准 |
| 返回的字段是 `{ id, name }` 对象 | 关联字段（Lookup）返回结构 | 关联字段需传入 `{ id, name }` 形式的对象（见 `openCreateForm` 注释） |
| 分页查询 `totalSize` 和 `data.length` 对不上 | `totalSize` 是总数 | 客户端分页只看 `totalSize`，`data.length` 是当前页条数 |

## 七、参考

- [平台实体数据源](https://neo-cmp-docs.netlify.app/datasource/平台实体数据源)
- [平台自定义API](https://neo-cmp-docs.netlify.app/datasource/平台自定义API)
- [数据源类配置项](https://neo-cmp-docs.netlify.app/config/数据源类配置项)（`propsSchema` 里的实体 / 字段 / 自定义 API 类型）
- 代理代码包 ZIP：[forward.zip](https://neo-cmp-docs.netlify.app/forward.zip)（如链接失效请联系平台支持获取）

:::
# 组件运行时上下文（`props.data` / `props.env.ctx`）

自定义组件运行时，平台会把页面级数据、用户数据、环境工具与接口能力等注入到 props。本文档说明怎么用。

::: v-pre

## 快速定位

| 能力 | 在 `props` 上的位置 |
|---|---|
| 当前用户 / 租户 / 页面元信息 | `this.props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` |
| 平台全局对象（系统 / 用户 / UI / 工具 / API） | `this.props.env.ctx`（即 `CTX`） |
| 组件实例唯一 ID | 运行时 / 画布：`this.props.keyIdentifier`；设计时属性区：`this.props.$com.keyIdentifier` |
| 当前组件 Schema | `this.props.$schema` |

### 类组件 vs 函数组件

- **类组件**：`this.props.data` / `this.props.env.ctx`。
- **函数组件**：入参解构 `const { data, env } = props`；放入 `useEffect` 依赖时注意 `env.ctx` 的引用稳定性。

## 一、页面数据 `__Neo*`

```tsx
// 当前用户
const currentUser = this.props.data?.__NeoCurrentUser;
if (currentUser) {
  console.log(currentUser.id, currentUser.name);
}

// 系统 / 租户信息
const systemInfo = this.props.data?.__NeoSystemInfo;

// 页面元数据（含 pageId 等）
const pageInfo = this.props.data?.__NeoPageInfo;
```

## 二、`props.env.ctx`（全局对象 `CTX`）

### 2.1 system（系统）

| 名称 | 类型 | 说明 |
|---|---|---|
| `language` | 属性 | 当前用户语言 |
| `timeZone` | 属性 | 当前时区 |
| `clientType` | 属性 | `Web` / `App` / `WeCom` / `DingTalk` |
| `tenantId` | 属性 | 当前租户 ID |
| `tenantName` | 属性 | 当前租户名称 |
| `currencies` | 属性 | 租户已启用的货币 |
| `systemType` | 属性 | 业务系统类型（crm / prm 等） |
| `logout()` | 函数 | 登出并回登录页 |
| `getCurrentDate(format?)` | 函数 | 获取当前系统时间，可指定格式 |

```tsx
const ctx = this.props.env?.ctx;
if (!ctx) return;

const { language, tenantId, tenantName } = ctx.system;
ctx.system.logout(); // 自定义退出按钮
```

### 2.2 user（当前用户）

| 名称 | 类型 | 说明 |
|---|---|---|
| `id` / `name` / `email` / `phoneNumber` / `currency` | 属性 | 基本信息 |
| `primaryFunctionalId` | 属性 | 主职能 ID |
| `functionals` | 属性 | 所有职能 `[{ id, name, isMain }]` |
| `departmentId` / `departmentName` | 属性 | 部门 |

```tsx
const user = this.props.env?.ctx?.user;
const mainFunctional = user?.functionals?.find((f: any) => f.isMain);
```

### 2.3 ui（界面）

| 名称 | 说明 |
|---|---|
| `showToast(type, msg, time?)` | 轻提示。`type`: `success` / `warning` / `error`；`time` 默认 1s |
| `confirm({ title, msg, width?, onOk, onCancel })` | 确认弹窗 |
| `openIframe({ url, title, height?, width?, showFooter?, onOk?, onCancel?, showCloseButton? })` | iframe 弹层 |
| `showLoading()` / `hideLoading()` | 全页遮罩 loading |
| `openPickerList({ objectApiKey, listView, selectionMode?, conditions?, orderBy?, title? })` | 打开实体 Picker |
| `navigatePageTo({ url, isNewWindow? })` | 页面跳转 |

```tsx
const ui = this.props.env?.ctx?.ui;
ui?.showToast('success', '保存成功', 2);

ui?.confirm({
  title: '确认删除',
  msg: '删除后不可恢复，是否继续？',
  onOk: () => { /* 执行删除 */ },
  onCancel: () => {},
});

ui?.openPickerList({
  objectApiKey: 'account',
  listView: 'account_view_1',
  selectionMode: 'single',
  title: '选择客户',
});
```

### 2.4 util（工具）

| 名称 | 说明 |
|---|---|
| `log` / `warn` / `info` / `error` | console 代理 |
| `setTimeout(fn, time)` / `setInterval(fn, time)` | 标准计时器 |
| `isEmpty(any)` | 判空（`{}` 与 `[]` 视为空） |
| `urlParams` | 当前页 URL 查询参数，解析后的对象 |
| `openAIChat({ query?, agentApiKey? })` | 打开 AI 对话框 |

```tsx
const util = this.props.env?.ctx?.util;
const orderId = util?.urlParams?.orderId; // ?orderId=123
if (!util?.isEmpty(orderId)) util?.log('orderId', orderId);

// 打开 AI 对话框
util?.openAIChat({
  query: '请总结一下本周数据变化',
  agentApiKey: 'sales_assistant_agent',
});
```

### 2.5 api（接口）

```tsx
const ctx = this.props.env?.ctx;

// 新建表单
ctx?.api?.openCreateForm({
  objectApiKey: 'account',
  busiType: 'defaultBusiType',
  defaultValues: {
    name: 'AME',
    parent__c: { id: '记录ID', name: '显示名称' }, // 关联字段传 { id, name }
  },
});

// 编辑 / 复制表单
ctx?.api?.openEditForm({ objectApiKey: 'zhu__c', busiType: 'defaultBusiType', recordId: 3710606526529990 });
ctx?.api?.openCloneForm({ objectApiKey: 'zhu__c', busiType: 'defaultBusiType', recordId: 3710606526529990 });

// 打开列表页（新 tab）
ctx?.api?.openListPage({
  objectApiKey: 'customEntity111__c',
  listView: 'customEntity111__c_view_all',
  config: { isNewTab: true },
});

// 通用 request（仅允许白名单路径，见 open-api.md）
const res = await ctx?.api?.request({
  url: '/rest/data/v2.0/xobjects/account/...',
  method: 'GET',
});
```

> `ctx.api.request` 与 `neo-open-api` 的 `request` 是同一类能力；业务代码里通常直接用 `neo-open-api` 的封装（`xObject` / `customApi` / `request`），更语义化。

## 三、`keyIdentifier`：组件实例 ID

**运行时 / 画布区**：

```tsx
const cmpKey = this.props.keyIdentifier;
// 或从 $schema 解析
const cmpKey2 = this.props.$schema?.keyIdentifier;
```

**设计时属性面板**：

```tsx
const cmpKey = this.props.$com?.keyIdentifier;
```

> 注意：**设计时属性面板的 `keyIdentifier` 在 `$com` 上**，不是直接在 `props` 上；运行时/画布则相反。

## 四、打开 AI 对话框（示例）

```tsx
// @ts-ignore
import { BaseCmp } from 'neo-ui-common';

export default class OpenChatPageBtn extends BaseCmp<{ aiQuery?: string; agentApiKey?: string; env?: any; className?: string; placeholder?: string }, {}> {
  openChatPage = () => {
    const { env, aiQuery, agentApiKey } = this.props;
    const openAIChat = env?.ctx?.util?.openAIChat;
    if (!openAIChat) return;
    openAIChat({
      query: aiQuery || '请总结一下本周数据变化',
      agentApiKey: agentApiKey || 'sales_assistant_agent',
    });
  };

  render() {
    const { className, placeholder } = this.props;
    return (
      <div className={`openChatPageBtn__c ${className || ''}`}>
        <button type="button" onClick={this.openChatPage}>
          {placeholder || '打开 AI 对话页'}
        </button>
      </div>
    );
  }
}
```

## 五、最佳实践

- **始终判空**：`this.props.env?.ctx?.ui?.showToast?.('success', 'ok')`。设计器预览、本地调试等场景 `env.ctx` 可能不存在。
- **不要缓存 `ctx` 到模块作用域**：`ctx` 会随页面 / 租户切换变化；每次使用时从 `this.props.env` 取。
- **TS 类型**：可以在 `@types/` 补一份声明：

```ts
// @types/neo-ctx.d.ts
export interface NeoCtx {
  system: {
    language: string; timeZone: string; clientType: string;
    tenantId: string; tenantName: string;
    logout: () => void;
    getCurrentDate: (format?: string) => string;
  };
  user: { id: string; name: string; email?: string; functionals?: Array<{id:string;name:string;isMain:boolean}> };
  ui: {
    showToast: (type: 'success'|'warning'|'error', msg: string, time?: number) => void;
    confirm: (opt: { title: string; msg: string; width?: string; onOk: () => void; onCancel: () => void }) => void;
    showLoading: () => void; hideLoading: () => void;
    navigatePageTo: (opt: { url: string; isNewWindow?: boolean }) => void;
  };
  util: {
    log: (...a: any[]) => void; warn: (...a: any[]) => void; info: (...a: any[]) => void; error: (...a: any[]) => void;
    isEmpty: (v: any) => boolean;
    urlParams: Record<string, string>;
    openAIChat: (opt: { query?: string; agentApiKey?: string }) => void;
  };
  api: {
    request: (opt: { url: string; method?: string; headers?: Record<string,string>; data?: any }) => Promise<any>;
    openCreateForm: (opt: any) => void;
    openEditForm: (opt: any) => void;
    openCloneForm: (opt: any) => void;
    openListPage: (opt: any) => void;
  };
}

export interface NeoBaseProps {
  data?: { __NeoCurrentUser?: any; __NeoSystemInfo?: any; __NeoPageInfo?: any; [key: string]: any };
  env?: { ctx?: NeoCtx };
  keyIdentifier?: string;
  $schema?: any;
  $com?: { keyIdentifier?: string };
  className?: string;
  render?: (name: string, schema: any) => React.ReactNode;
}
```

```ts
interface MyProps extends NeoBaseProps { /* 业务字段 */ }
```

## 六、常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 本地预览 `this.props.env.ctx` 是 undefined | `neo preview` 不注入真实平台运行时 | 用 `neo linkDebug` 走真实平台调试 |
| `this.props.data.__NeoPageInfo` 为空 | 当前页面类型未注入对应上下文 | 确认组件 `targetPage` 与运行页面匹配；必要时从 `env.ctx` 读取替代信息 |
| 设计时属性区拿不到 `keyIdentifier` | 读错了字段 | 设计时 `this.props.$com?.keyIdentifier`，运行时 `this.props.keyIdentifier` |
| `ctx.system.getCurrentDate` 输出时区不对 | 没传 format 或平台默认行为变更 | 显式传 format；必要时结合 `ctx.system.timeZone` 转换 |

:::

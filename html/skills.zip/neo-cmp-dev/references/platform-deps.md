# 平台预置依赖与 externals

neo-cmp-cli 构建时会把**平台侧已有的依赖**作为 **external** 从 bundle 中剔除。组件产物只包含业务代码，运行时从平台全局拿到真实实现。

好处：

- 组件体积更小、首次加载更快
- 避免同一依赖在运行时出现多份（React 多实例会直接报错）
- 所有组件共享平台侧的同一份库，版本一致

::: v-pre

## 预置依赖清单

**通用（全端）**：

| 包 | 版本 |
|---|---|
| `react` | `^16.13.1` |
| `react-dom` | `^16.13.1` |
| `mobx` | `^6.3.0` |
| `mobx-react` | `^7.0.0` |
| `mobx-state-tree` | `^5.4.0` |
| `axios` | `^0.27.2` |
| `classnames` | `^2.3.2` |
| `qs` | `^6.11.0` |
| `lodash` | `^4.17.21` |
| `amis` | `^1.1.5` |
| `neo-ui-common` | - |

**PC / Web 端**：

| 包 | 版本 |
|---|---|
| `antd` | `4.9.4` |
| `@ant-design/icons` | `^4.8.0` |
| `neo-ui-component-web` | - |

**H5 端**：

| 包 | 版本 |
|---|---|
| `antd-mobile` | `2.3.4` |
| `neo-ui-component-h5` | - |

**平台 OpenAPI SDK**：

| 包 | 版本 |
|---|---|
| `neo-open-api` | - |

### 虚拟模块（不要装 npm）

以下都是**运行时注入**的虚拟模块，**不要**写进 `package.json`：

- `neo-ui-common`（`BaseCmp` / `NeoEvent`）
- `neo-ui-component-web`（PC 平台业务组件，如 `NeoEntityGrid`）
- `neo-ui-component-h5`（H5 平台业务组件，如 `NeoEntityList` / `GlobalSearchInput`）

> `neo-open-api` 是平台 SDK（真实 NPM 包），可按需在 `package.json` 中添加依赖。

**约定写法**：

```tsx
// @ts-ignore 平台注入，虚拟模块无需安装
import { BaseCmp, NeoEvent } from 'neo-ui-common';
// @ts-ignore
import { NeoEntityList } from 'neo-ui-component-h5';
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

// @ts-ignore 平台 SDK（真实 NPM 包，需要在 package.json 的 dependencies 中添加依赖）
import { xObject, customApi, request } from 'neo-open-api';
```

> **重要区分**：
> - `neo-ui-common` / `neo-ui-component-web` / `neo-ui-component-h5` 是**平台虚拟模块**（运行时注入），**不要**写进 `package.json`，import 时加 `// @ts-ignore`
> - `neo-open-api` 是**真实 NPM 包**（平台 OpenAPI SDK），**必须**写入 `package.json` 的 `dependencies`（如 `"neo-open-api": "^1.2.13"`），import 时也建议加 `// @ts-ignore` 作为类型兜底

可选：在 `@types/` 里补一份类型声明，避免 `@ts-ignore`。

> **端不同，UI 库不同**。`model.ts` 里 `targetDevice` 要和用到的 UI 库对齐（用 `antd` 就 `'web'`，用 `antd-mobile` 就 `'mobile'`）。

## externals 机制

- 开发时可以在 `package.json` 里装这些包（用于 TypeScript 类型和本地预览），**虚拟模块除外**
- 构建时 webpack 会把它们从打包中剔除，产物里变成对平台全局的引用（或运行时注入）
- 业务代码里**正常 import 使用**：

```tsx
import React, { useState } from 'react';
import { Button, Modal, message } from 'antd';
import axios from 'axios';
import classnames from 'classnames';
import { makeAutoObservable } from 'mobx';
import { observer } from 'mobx-react';
```

## 使用约束

- **版本必须与平台一致**：平台 `react@16.13.1`，组件就必须 `react@^16.13.1`；否则运行时可能报错（尤其 React 16 + 18 混用会直接炸）。
- **不要 alias / shadow**：不要在 webpack / tsconfig 里把 `react` 重定向到其他包。
- **不要内联打包**：不要用 `ncc` / 自定义 rollup 配置把这些依赖打进产物。
- **antd 和 antd-mobile 不要同时用**：PC 端用 antd、H5 端用 antd-mobile；混用会导致 bundle 里有未剔除的那一份。

## 版本不一致会怎样

| 现象 | 可能原因 | 处理 |
|---|---|---|
| `Invalid hook call` | `react` 出现多份实例 | 对齐 `react@^16.13.1`；删 `node_modules` 重装 |
| antd 组件样式异常 | antd 版本和平台不一致（4.x vs 5.x） | 对齐 `antd@4.9.4` |
| `Cannot read properties of undefined` | `lodash` / `axios` 用了新版 API | 对齐预置版本 |
| MobX action 不生效 | `mobx` 从 5.x 升 6.x API 变了 | 使用 `makeAutoObservable` / `makeObservable` |
| 发布报「找不到 neo-ui-common」 | 虚拟模块未正确 externals（非 neo-cmp-cli 工程） | 用 neo-cmp-cli；或自建 webpack 把虚拟模块映射成 `neoRequire(...)` |

## 引入清单外的依赖

可以 `npm install <pkg> --registry=https://registry.npmmirror.com` 并直接 import（默认走淘宝源；若工程已配置企业私服，沿用即可。淘宝源策略见 `neo-cmp-cli` 技能）。它会被**打进组件产物**。代价是：

- 每个用到该依赖的组件都有一份副本
- 组件产物体积变大
- 页面上多个自定义组件用不同版本同一依赖会各带一份

**策略**：

- **轻量工具**（如 `dayjs` 代替 `moment`）→ 放心用
- **重型依赖**（echarts、monaco-editor、pdf.js）→ **动态 import + 懒加载**，或在多组件间走 **`neoCommonModule` 模块联邦**（见 `module-sharing.md`）

### 懒加载示例（echarts）

```tsx
import { useEffect, useRef } from 'react';

interface Props { option: any }
const Chart: React.FC<Props> = ({ option }) => {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let instance: any;
    (async () => {
      const echarts = await import(/* webpackChunkName: "echarts" */ 'echarts');
      if (!ref.current) return;
      instance = echarts.init(ref.current);
      instance.setOption(option);
    })();
    return () => instance?.dispose();
  }, [option]);

  return <div ref={ref} style={{ width: '100%', height: 320 }} />;
};
```

## 检查产物体积

构建完成后查看 `dist/` 或 CLI 输出的产物大小。**异常信号**：

- 单个组件 bundle > 1MB → 一般是外部依赖被打进去了
- bundle 里出现 `react` / `antd` → externals 没生效，检查 `neo.config.js`

可用工具：`webpack-bundle-analyzer`、`build2lib.bundleAnalyzerReport: true`。

## 常用外部依赖的 import 片段

```tsx
// React
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import ReactDOM from 'react-dom';

// antd（PC）
import { Button, Modal, Form, Input, Select, Table, message } from 'antd';
import { PlusOutlined, EditOutlined } from '@ant-design/icons';

// antd-mobile（H5）
import { Button, Modal, List, Toast } from 'antd-mobile';

// MobX
import { makeAutoObservable, observable, action, computed } from 'mobx';
import { observer, useLocalObservable } from 'mobx-react';

// HTTP / utils
import axios from 'axios';
import qs from 'qs';
import _ from 'lodash';
import classnames from 'classnames';

// 平台能力（注意：虚拟模块 与 平台 SDK 区分）
// @ts-ignore 平台虚拟模块（无需安装）
import { BaseCmp, NeoEvent } from 'neo-ui-common';
// @ts-ignore 平台 SDK（真实 NPM 包，需在 package.json 中添加依赖）
import { xObject, customApi, request } from 'neo-open-api';
```

## 自建 Webpack 的 externals 示例

若工程不是 neo-cmp-cli（自建 Webpack），需要手动处理虚拟模块：

```js
// webpack.config.js（Webpack 5）
module.exports = {
  entry: './src/index.js',
  externals: [
    // 1. 对象形：通用 react / antd 等
    {
      react: 'React',
      'react-dom': 'ReactDOM',
    },
    // 2. 函数形兜底：剔除掉平台虚拟模块
    function (context, request, callback) {
      const neoModules = ['neo-ui-common', 'neo-ui-component-web', 'neo-ui-component-h5'];
      if (neoModules.includes(request)) {
        return callback(null, `neoRequire("${request}")`, 'commonjs');
      }
      callback();
    },
  ],
};
```

Webpack 4 及以下不支持数组混写；请把对象规则并入函数内。

## 参考

- [组件开发规范 · 10-复用平台预置依赖](https://neo-cmp-docs.netlify.app/guide/组件开发规范#10-复用平台预置依赖)
- [常见问题 · publish](https://neo-cmp-docs.netlify.app/常见问题#publish)（发布相关问题）

:::

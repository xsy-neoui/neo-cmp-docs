# 平台预置业务组件（import 代码方式复用）

> **本文档是 [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/) 对应主题的本地摘要，以本地内容为准，在线文档作补充参考。**

Neo 平台在 `neo-ui-component-h5` 与 `neo-ui-component-web` 中暴露了几个高价值业务组件。自定义组件内可**直接 `import`** 使用，平台运行时会自动注入，开发工程不用装。

::: v-pre

## 通用规则

- **H5 端**：从 `neo-ui-component-h5` 导入（`NeoEntityList` / `GlobalSearchInput`）。
- **PC / Web 端**：从 `neo-ui-component-web` 导入（`NeoEntityGrid`）。
- **`targetDevice` 对齐**：创建组件时 `neo create cmp -d <mobile|web|all>`；模型里 `targetDevice` 与 UI 库一致。
- **`render` 必传**：部分组件依赖 amis 子节点渲染，需传 `render={this.props.render}`（类组件）或 `render={props.render}`（函数组件）；否则内部 Schema 无法渲染。
- **依赖不要装**：这些包和 `neo-ui-common` 一样是平台虚拟模块。`package.json` 里**不要**写；`import` 前加 `// @ts-ignore`。自建 webpack 的工程需在 `externals` 里把它们映射到 `neoRequire('...')`。

## 一、`NeoEntityList`（H5 端列表）

基于 `EntityList` 的二次封装，卡片式列表，支持 SmartView 切换、搜索、筛选、排序、批量操作、下拉刷新与上拉加载。

```tsx
import * as React from 'react';
// @ts-ignore
import { NeoEntityList } from 'neo-ui-component-h5';

interface Props { render: (name: string, schema: object) => React.ReactNode }

export default class ContactList extends React.Component<Props> {
  render() {
    return (
      <NeoEntityList
        render={this.props.render}        /* 必传：透传 amis render */
        entityApiKey="contact"             /* 必传：实体 apiKey */
        disableTitleView                   /* 隐藏标题区 */
        isShowTitlePicker={false}          /* 不展示视图 Picker */
        disableSearch={false}              /* 是否显示搜索 */
        disabledSort={false}               /* 是否显示排序 */
        disabledFilter={false}             /* 是否显示筛选 */
        disabledOperationBtn={false}       /* 隐藏操作按钮区 */
        disabledShortcutBtn={false}        /* 隐藏快捷按钮区 */
        pageSize={20}                      /* 每页条数 */
        isNoRefresh={false}                /* 禁用下拉刷新 / 上拉加载 */
        autoHeight={false}                 /* true 则使用 body 滚动 */
        onItemClickIntercept={(data, entity) => {
          // 返回 truthy 会阻止默认打开详情逻辑
          return false;
        }}
        onSearchDataComplete={(payload) => {
          // 数据加载完回调
        }}
      />
    );
  }
}
```

**可用 props**（常用）：

| 属性 | 类型 | 说明 |
|---|---|---|
| `entityApiKey` | string | **必填**，实体 apiKey |
| `render` | function | **必填**，通常 `this.props.render` |
| `disableTitleView` | boolean | 是否隐藏标题区 |
| `isShowTitlePicker` | boolean | 是否展示视图 Picker |
| `disableSearch` | boolean | 是否隐藏搜索 |
| `disabledSort` / `disabledFilter` | boolean | 是否隐藏排序 / 筛选 |
| `disabledOperationBtn` / `disabledShortcutBtn` | boolean | 隐藏操作按钮区 / 快捷按钮区 |
| `pageSize` | number | 每页条数 |
| `isNoRefresh` | boolean | 禁用下拉刷新与上拉加载 |
| `autoHeight` | boolean | 使用 body 滚动 |
| `onItemClickIntercept` | function | 点击列表项前拦截（返回 truthy 阻止默认打开详情） |
| `onSearchDataComplete` | function | 数据请求完成回调 |
| `style` | object | 外层样式 |

> 需要 `requestParams` / `referConditions` / `ListItemSchema` / `expandSchemas` 等未透传属性时，改用完整 `EntityList` Schema（见平台文档）。

## 二、`GlobalSearchInput`（H5 端全局搜索入口）

只读样式的搜索条，点击后跳转到全局搜索页面。

```tsx
// @ts-ignore
import { GlobalSearchInput } from 'neo-ui-component-h5';

<GlobalSearchInput
  render={this.props.render}        /* 必传 */
  placeholder="搜索客户、商机..."      /* 可选，默认「全局搜索」 */
  backgroundColor="#F5F5F5"          /* 可选，默认 #FFFFFF */
/>
```

## 三、`NeoEntityGrid`（PC / Web 端大列表）

基于 AG-Grid，实体数据列表组件。支持表格 / 分屏 / 地图 / BI 看板 / Picker 等多种展示模式。

```tsx
// @ts-ignore
import { NeoEntityGrid } from 'neo-ui-component-web';

export default class AccountGrid extends React.Component<{ render: any }> {
  render() {
    return (
      <NeoEntityGrid
        render={this.props.render}  /* 必传 */
        name="accountList"            /* 必传：amis 通信 */
        objectApiKey="account"        /* 必传：实体 apiKey（即使用 agGridDataSource 也不可省） */
        pattern="entityView"          /* entityView / pickView / simpleListView / globalSearchPage / secondaryList */
        defaultViewId=""              /* 默认视图 ID */
        hiddenHeader={false}          /* 隐藏头部（视图切换栏 + 工具栏） */
        disableSearch={false}
        showView
        enableChangeView
        canCreate
        canImport={false}
        editable
        withOrder
        withCheck
        enableToolbar
        disableExport={false}
        disableBatchEdit={false}
        disableFieldSetup={false}
        disableFullScreen={false}
        disableBiView={false}
        disablePagination={false}
        paginationPageSize={20}
        autoHeight={false}
        height="500px"
        additionalConditions={[{ apiKey: 'accountName', type: 3, value: '测试客户' }]} /* 静态筛选 */
        customEmptyMsg="暂无数据，请点击「新建」按钮创建"
        onRowSelected={(data) => console.log('选中', data)}
        onSinglerClick={(row) => {
          // 返回 true 则阻止默认打开详情
          return false;
        }}
        onDataLoaded={(data) => console.log('数据加载完成', data)}
        onGridReady={(gridModel) => {
          // gridModel.reloadGrid / setCustomCondition
        }}
        customToolbarButtons={{
          header: [
            { id: 'approve-btn', label: '批量审批', icon: 'CheckOne', onClick: () => {} },
          ],
          footer: [
            { id: 'export-pdf', label: '导出 PDF', icon: 'FilePdf', onClick: () => {} },
          ],
        }}
      />
    );
  }
}
```

### 关键属性

| 属性 | 说明 |
|---|---|
| `objectApiKey` | **必填**，实体 apiKey；即便使用 `agGridDataSource` 自定义行数据，仍需传 |
| `name` | **必填**，amis 通信 key |
| `render` | **必填**，`this.props.render` |
| `pattern` | `entityView`（默认） / `pickView`（选择器） / `simpleListView` / `globalSearchPage` / `secondaryList` |
| `autoHeight` / `height` | 布局；`autoHeight=true` 时 `height` 失效 |
| `dataLoadType` | `serverSide` / `clientSide` / `auto` / `pagination` |
| `agGridDataSource` | `{ getRows(params) }` 接管服务端行数据加载 |
| `defaultViewId` | 默认显示的列表视图 ID |
| `additionalConditions` | 静态筛选条件 `[{ apiKey, type, value }]`；`type` 取值见下表 |
| `hiddenHeader` / `showView` / `canCreate` / `canImport` / `disableSearch` / `disablePagination` / `editable` / `withOrder` / `withCheck` | 显隐与能力开关 |
| `selectionMode` | `single` / `multiple`（Picker 默认 single） |
| `enableToolbar` / `disableExport` / `disableBatchEdit` / `disableFieldSetup` / `disableBiView` / `disableFullScreen` / `disableAutoSizeColumns` | 工具栏开关 |
| `customToolbarButtons` | `{ header?: [], footer?: [] }` 自定义工具栏按钮；每项 `{ id, label, icon?, tooltip?, visible?, disabled?, onClick?, customRender? }` |
| `onRowSelected(data, event)` | 选中变化回调；`data: [{ data: { ...row, id, name } }]` |
| `onSinglerClick(clickData)` | 行单击拦截；返回 `true` 阻止默认打开详情 |
| `onGridReady(gridModel)` | 表格就绪；`gridModel.reloadGrid()` / `setCustomCondition()` |
| `onDataLoaded` / `onDataRequest` / `onFirstDataRendered` / `onLayoutLoaded` / `onSmartViewChanged` | 数据与视图回调 |
| `searchPlaceholder` | 搜索框占位 |
| `customEmptyMsg` | 自定义空状态文案 |
| `pageInfo` | `{ pageKey, scope: { objectApiKey } }`，注册 `reloadPage` 等到页面 Com |
| `scene` | 场景标识（如 `'standard'`） |
| `busiTypeApiKey` | 业务类型 apiKey |

### `additionalConditions` 的 `type` 常用取值

| 值 | 含义 |
|---|---|
| 1 | 等于 |
| 2 | 不等于 |
| 3 | 包含 |
| 4 | 不包含 |
| 5 | 开始于 |
| 6 | 大于 |
| 7 | 大于等于 |
| 8 | 小于 |
| 9 | 小于等于 |
| 10 | 在列表中（IN） |
| 13 | 为空 |
| 14 | 不为空 |
| 21 | 不在列表中 |

### Picker 模式（选择器）

```tsx
<NeoEntityGrid
  render={this.props.render}
  name="accountPicker"
  objectApiKey="account"
  pattern="pickView"
  selectionMode="multiple"
  referData={{ referObjectApiKey: 'opportunity', referItemApiKey: 'accountId' }}
  onSelectedCall={(selectedData) => { /* 确认选中 */ }}
  onCancel={() => { /* 取消 */ }}
  shouldCloseDialog
/>
```

### 自定义数据源（agGridDataSource）

```tsx
private agGridDataSource = {
  getRows: (params: any) => {
    const { startRow, endRow, sortModel, filterModel } = params.request;
    const pageSize = endRow - startRow;
    const pageNo = Math.floor(startRow / pageSize) + 1;
    fetchCustomPage({ pageNo, pageSize, sortModel, filterModel })
      .then(({ records, totalSize }) => params.successCallback(records, totalSize))
      .catch(() => params.fail());
  },
};

<NeoEntityGrid
  render={this.props.render}
  name="accountListCustom"
  objectApiKey="account" /* 即便自定义行数据，也要传（布局、权限、缓存 key 都依赖它） */
  pattern="entityView"
  dataLoadType="serverSide"
  agGridDataSource={this.agGridDataSource}
  paginationPageSize={20}
/>
```

### 刷新列表

- 在 `onGridReady(gridModel)` 里拿到 `gridModel`：`gridModel.reloadGrid(false)`；
- 或用 amis 指令：`target: 'listviewx?cmd=refresh_grid'`。

## 四、函数组件的 `render` 透传

若上层是函数组件：

```tsx
function MyWrapper(props: { render: any }) {
  return <NeoEntityGrid render={props.render} name="xxList" objectApiKey="account" pattern="entityView" />;
}
```

## 五、常见陷阱

| 现象 | 原因 | 处理 |
|---|---|---|
| 列表不渲染 / 只有空白 | `render` 没传 | `render={this.props.render}` / `render={props.render}` 必传 |
| `Cannot find module 'neo-ui-component-web'` | 本地预览用 | 改用 `neo linkDebug` |
| Picker 选了没反应 | 没传 `onSelectedCall` | Picker 模式必须传，且通常配合 `shouldCloseDialog` |
| 自定义数据源列不对 | 行字段 apiKey 与列配置不匹配 | 行对象字段要与当前列表列的字段 apiKey 对齐 |
| 切换工具栏按钮显隐卡顿 | `visible=false` 时完全不渲染（预期行为） | — |
| `onSinglerClick` 双击也触发 | 双击打开详情前也会先调 `onSinglerClick` | 按需要在回调内判断；返回 `true` 即可阻止默认 |
| 筛选条件不生效 | `additionalConditions.apiKey` 与实体字段对不上 | 对齐字段 apiKey；`type` 使用上表取值 |

## 六、参考

- [使用平台组件](https://neo-cmp-docs.netlify.app/使用平台组件)
- [H5版列表组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/H5版列表组件使用说明)
- [H5版全局搜索组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/H5版全局搜索组件使用说明)
- [PC版列表组件使用说明](https://neo-cmp-docs.netlify.app/cmpDocs/PC版列表组件使用说明)
- 模板参考：`neo-h5-cmps` / `neo-web-entity-grid`

:::

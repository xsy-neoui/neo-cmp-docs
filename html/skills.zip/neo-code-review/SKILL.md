---
name: neo-code-review
description: 对 neo-cmp-dev 开发的 Neo 平台自定义组件进行**代码审查与规范校验**。当 neo-cmp-dev 完成组件开发（步骤 9 之后）、用户要求 review / 检查 / 审查 / 规范对齐组件代码、或发现组件出现异常行为（样式不生效、事件动作不响应、设计器看不到配置项等）时，必须走本技能。本技能逐项检查组件入口文件（`index.tsx`）、模型文件（`model.ts`）、样式文件（`index.scss`/`common.scss`）、目录结构、事件动作声明、数据源使用方式、字段名合法性、依赖配置等是否满足 neo-cmp-dev 的全部约束与规范，输出整改清单后转交 neo-cmp-dev 修复，再重新 review 直至全部通过。本技能不修改任何组件代码，只检查并生成报告。
---

# Neo 平台自定义组件代码审查技能

本技能对 `neo-cmp-dev` 开发完成的 Neo 平台自定义组件进行**代码审查与规范校验**，确保组件满足平台所有约束、限制和开发规范。

## 技能边界

本技能与 `neo-cmp-dev` 的关系：

| 场景 | 技能 |
|---|---|
| **开发组件**（写代码、模型、样式） | `neo-cmp-dev` |
| **审查组件**（检查是否符合规范） | **`neo-code-review`（本技能）** |
| **修复问题**（按审查结果调整代码） | 返回 `neo-cmp-dev` |
| **执行命令**（预览/调试/发布） | `neo-cmp-cli` |

**工作流程**：
```
neo-cmp-dev 开发完成（步骤 9 后）
    → 转交 neo-code-review 审查
        → 发现问题 → 返回 neo-cmp-dev 修复 → 再次转交 neo-code-review 审查（循环）
        → 全部通过 → 继续 neo-cmp-dev 步骤 10/11
```

## 审查范围

本技能按以下 7 个维度逐项检查：

1. **目录与命名规范**
2. **入口文件（index.tsx）规范**
3. **模型文件（model.ts）规范**
4. **事件动作规范**
5. **样式规范**
6. **数据源与平台能力规范**
7. **依赖与构建规范**

各维度详细检查项见 `references/checklist.md`。

## 审查流程

### 步骤 1：定位被审查组件

明确当前要审查的组件目录路径，格式应为 `src/components/<cmpName>__c/`。从该目录读取以下文件：

- `index.tsx`（必有）
- `model.ts`（必有）
- `index.scss`（若有）
- `common.scss`（若有）
- `types.ts`（若有）
- 目录中的其他文件

同时检查 `src/utils/`、`src/common/` 中是否有多余的工具函数或组件未被迁移。

### 步骤 2：逐项检查（7 个维度）

读取 `references/checklist.md`，按 7 个维度的检查项逐一检查。每个检查项的结果标记为：

- ✅ **通过** — 完全符合规范
- ❌ **未通过** — 不符合规范，记录具体原因和文件位置
- ⏭️ **跳过** — 当前组件不适用此项（如无事件动作则跳过事件动作检查）

每个 ❌ 项需记录：
- **文件**：哪个文件的问题
- **行/段**：大致位置
- **问题描述**：违反哪条规范
- **修复建议**：如何修复（引用 neo-cmp-dev 对应文档）

### 步骤 3：生成审查报告

将所有 ❌ 项汇总为清晰的整改清单，格式如下：

```
## 代码审查报告 — <组件名>

### 审查结果：❌ <未通过数>/<总数> 项未通过（或 ✅ 全部通过）

### ❌ 问题清单

| # | 维度 | 文件 | 问题描述 | 修复建议 |
|---|------|------|----------|----------|
| 1 | 目录与命名 | model.ts | ... | ... |

### 📋 需整改明细
...
```

### 步骤 4：根据审查结果决定后续操作

- **全部通过**（没有 ❌ 项）→ 告知用户组件代码已通过规范审查，可继续 `neo-cmp-dev` 的后续步骤（步骤 10 安装依赖+格式化、步骤 11 询问预览/linkDebug/发布）。
- **存在问题**（有 ❌ 项）→ 将审查报告交给用户，**转交 `neo-cmp-dev` 技能**按修复建议调整代码。调整完成后，再次转交本技能重新审查，循环直至全部通过。

## 审查重点速览

### 重点关注（最常见问题）

| 检查项 | 违反后果 |
|--------|---------|
| 根节点 className ≠ 目录名 | 样式隔离失效 |
| 未合并 `props.className` | 设计器「是否显示」失效 |
| `propsSchema[].type` 用泛名（`input`/`select`） | 属性面板找不到控件 |
| 未 `extends BaseCmp` 但有事件动作 | 事件动作不生效 |
| `@NeoEvent.function` 方法未 `bind(this)` | 运行时 `this` 为 undefined |
| `model.events`/`functions` 未声明 | 设计器看不到配置项 |
| SCSS 使用 `&-xx` 语法 | 构建后样式不匹配 |
| 虚拟模块在 `package.json` 里 | 发布报错 |
| 弹层样式放进 `index.scss` | 弹层样式不生效 |
| 字段名凭直觉杜撰（未按优先级获取：需求→`xObjectDataApi.fields`→`xObject.getFileds`） | 运行时查询失败 |
| 在 `xObject.getFileds` 返回列表之外擅自添加字段（约束 8） | 运行时查询报错，字段不存在 |
| 用 `axios` 代替 `xObject` 操作实体 | 丢失登录态/权限/审计 |
| **`neo-open-api` 未在 `package.json.dependencies` 中** | 构建后运行时找不到模块 |
| **`xObject.query` 返回后错误取 `result.list`/`result.records` 而非 `result.data`** | 列表数据为空 |
| **用 `code === 0`/`code === 200` 判断成功而非 `status === true`** | 网关语义不一致导致误判 |
| **直接手写 `axios`/`fetch` 调平台实体接口** | 丢失登录态、权限、审计 |
| 列表展示用 `antd Table` + `xObject.query` | 失去平台列表能力 |
| `defaultComProps` 漏了 `propsSchema` 条目 | 首次拖入字段为 undefined |
| `defaultComProps` 包含数据源对象类型字段（`xObjectDataApi`/`xObjectDetailApi`/`customApi`） | 无意义默认值引发生命周期误判 |
| **组件状态数据超过 2 个但使用函数组件而非类组件** | 状态管理混乱，无法利用 `BaseCmp` 的能力 |
| **`componentDidUpdate` 未响应 props 变化（约束 5）** | 属性面板配置变化后组件不刷新、数据不重新加载 |
| **`@NeoEvent.function` 方法使用类属性箭头函数而非类方法定义** | 装饰器不生效，事件动作不响应 |
| **所有异步 `neo-open-api` 调用未用 `try-catch` 包裹** | 运行时错误无兜底，白屏 |
| **`xObjectDataApi` 与 `selectFieldDescApi` / `selectFieldsApi` 并存（约束 10）** | 属性面板两个字段选择入口，功能重复、业务方困惑 |
| **`xObjectDataApi` 的 `value.fields` 为 `string[]` 格式，应直接作为 `xObject.query` 的 `fields` 参数传入** | 未正确使用字符串数组格式，导致查询字段不生效或多余转换 |
| **`xObject.query` 的 `orderBy` 使用非 `id` 字段** | 排序不生效 |
| **实体详情页跳转 URL 格式错误** | 跳转不生效 |
| **`where` 中对多值字段做取值条件** | 查询报错 |
| **字段名/实体 apiKey 大小写不一致** | 查询不到数据 |
| **`@NeoEvent.function` 方法使用类属性箭头函数而非普通方法** | 装饰器对箭头函数不生效 |
| **使用了第三方工具方法（如 `lodash.get`/`moment`/`dayjs`/`numeral`/`uuid`/`qs` 等）但未在文件头 `import` 对应模块** | 运行时 `TypeError`：模块未定义，组件白屏 |
| **代码中 `import` 的第三方 npm 包未在 `package.json.dependencies` 中声明** | 构建后运行时找不到模块，报错 `Module not found` |
| **本地模块 import 路径不存在或错误（如 `./components/xxx` 文件缺失、`../../utils/xxx` 目录深度计算错误、裸写 `components/xxx` 而非 `./components/xxx`）** | 构建失败或运行时找不到模块，报错 `Module not found` |

## 参考文件

- `references/checklist.md` — 完整的 7 维度检查清单（~100+ 项，覆盖 neo-cmp-dev 全部约束）
- [`neo-cmp-dev/`](../neo-cmp-dev/SKILL.md) — Neo 平台自定义组件开发技能（约束源头）
- [`neo-cmp-dev/references/common-pitfalls.md`](../neo-cmp-dev/references/common-pitfalls.md) — 常见陷阱大全
- [`neo-cmp-dev/references/spec-checklist.md`](../neo-cmp-dev/references/spec-checklist.md) — 组件开发规范速查
- [`neo-cmp-dev/references/styling.md`](../neo-cmp-dev/references/styling.md) — 样式规范
- [`neo-cmp-dev/references/component-form.md`](../neo-cmp-dev/references/component-form.md) — 类组件 vs 函数组件规范
- [`neo-cmp-dev/references/model-file.md`](../neo-cmp-dev/references/model-file.md) — model.ts 规范
- [`neo-cmp-dev/references/props-schema.md`](../neo-cmp-dev/references/props-schema.md) — propsSchema 类型规范
- [`neo-cmp-dev/references/event-action.md`](../neo-cmp-dev/references/event-action.md) — 事件动作规范
- [`neo-cmp-dev/references/open-api.md`](../neo-cmp-dev/references/open-api.md) — xObject/customApi 规范
- [`neo-cmp-dev/references/platform-deps.md`](../neo-cmp-dev/references/platform-deps.md) — 依赖与 externals 规范

## 审查规则说明

本技能检查的是**代码是否符合 neo-cmp-dev 中定义的约束与规范**，而非代码的功能正确性或业务逻辑。具体的约束来源是 `neo-cmp-dev/SKILL.md` 的以下部分：

- **硬性约束**（约束 1-10，含约束 5 响应式约束、约束 6 字段获取统一规则、约束 8 字段获取禁止擅自加字段、约束 10 `xObjectDataApi` 与 `selectFieldDescApi` / `selectFieldsApi` 互斥）
- **组件目录约定**
- **步骤 2 的字段兜底规则与数据接入决策**
- **步骤 4 的 model 约束**（含 `defaultComProps` 跳过数据源对象类型字段约束）
- **步骤 6-10 的开发约束**（含步骤 6 响应式约束、步骤 10 样式约束、步骤 9 实体详情页跳转）
- **实体识别的硬性规则**（含字段获取统一使用 `xObject.getFileds`、apiKey 大小写、自定义实体获取）
- **常见陷阱**
- **所有 `references/` 文件中的约束细则**（含 `open-api.md` 返回值规范、`component-form.md` 类函数组件决策、`styling.md` 样式隔离原理、`platform-deps.md` 虚拟模块 vs 平台 SDK 区分）

当发现违规项时，按 `neo-cmp-dev` 中的规范说明给出修复建议，**不要自行发明检查规则**。不确定某项是否违规时，返回 ✅ 通过。

# 组件代码审查清单（7 维度 ~100+ 项）

> 本清单是 `neo-cmp-dev/SKILL.md` 及所有 `references/` 文件中约束与规范的逐项可检查映射。
>
> **审查方式**：阅读组件目录下的 `index.tsx`、`model.ts`、`index.scss`、`common.scss`、`package.json` 等文件，对照以下条目逐一检查。
>
> **标记**：✅ 通过 / ❌ 未通过 / ⏭️ 跳过

---

## 维度 1：目录与命名规范

### 1.1 组件目录名
- [ ] 目录位于 `src/components/` 下
- [ ] 目录名使用 `<cmpName>__c` 后缀（`__c` 是平台约定）
- [ ] 目录名 = `cmpType`（CLI 按目录名自动生成）
- [ ] 目录内不存在与 `cmpType` 不一致的残余文件

### 1.2 必须文件
- [ ] 存在 `index.tsx`（或 `.ts`/`.js`/`.jsx`）作为入口
- [ ] 存在 `model.ts`（或 `.js`）作为模型文件
- [ ] 入口文件名只能为 `index.*`（CLI 扫描入口的依据）

### 1.3 工具与公共组件
- [ ] 不依赖 `this`/`state`/`props` 的独立纯函数已下沉到 `src/utils/`（按领域分文件，如 `date.ts`/`number.ts`/`entity.ts`）
- [ ] `index.tsx` 中不存在不依赖 `this`/`state`/`props` 的独立函数
- [ ] 自研功能子组件（非 antd/antd-mobile 替代品）放 `src/common/`，README 说明自研原因
- [ ] 组件私有子组件放 `src/components/<cmpName>__c/components/`
- [ ] 不将 UI 子组件零散放在组件目录顶层

### 1.4 自研 UI 兜底说明
- [ ] 若使用了非 antd/antd-mobile 的自研 UI 子组件，有 README 说明原因
- [ ] 未引入 Element/MUI/Semi/Arco/Vant/NutUI 等其他 UI 库

---

## 维度 2：入口文件（index.tsx）规范

### 2.1 根节点 className
- [ ] 根节点 `className` 包含组件目录名（如 `infoCard__c`）
- [ ] 根节点使用 `classnames` 合并了 `props.className`（格式：`classnames('目录名', this.props.className)`）

### 2.2 import 规范
- [ ] 平台虚拟模块（`neo-ui-common` / `neo-ui-component-*`）导入前有 `// @ts-ignore` 注释
- [ ] 虚拟模块的 import 语句格式正确：
  ```tsx
  // @ts-ignore 平台虚拟模块（无需安装）
  import { BaseCmp, NeoEvent } from 'neo-ui-common';
  // @ts-ignore
  import { NeoEntityGrid } from 'neo-ui-component-web';
  ```
- [ ] `neo-open-api`（平台 SDK）的 import 语句格式正确，注释写明是平台 SDK（**非虚拟模块**）：
  ```tsx
  // @ts-ignore 平台 SDK（真实 NPM 包，需在 package.json 中添加依赖）
  import { xObject, customApi, request } from 'neo-open-api';
  ```
- [ ] `neo-open-api` 的 import 注释**未**误写为"虚拟模块/无需安装"等误导性描述（必须写"平台 SDK"或类似标注）
- [ ] 不直接从 `axios`/`request` 调用平台实体数据（应使用 `xObject`）
- [ ] PC 端 `import` 来自 `antd`（非 `antd-mobile`），H5 端 `import` 来自 `antd-mobile`（非 `antd`）
- [ ] `classnames` 库正常导入（`import classnames from 'classnames'`）
- [ ] 组件样式文件被正确导入（`import './index.scss'` / `import './common.scss'`）

### 2.3 组件形态选择
- [ ] 若有事件动作需求（`@NeoEvent.dispatch`/`@NeoEvent.function`），组件为类组件 `extends BaseCmp`
- [ ] 若需要组件控制/组件可见性能力，组件为类组件 `extends BaseCmp`
- [ ] 纯展示且无事件动作需求 → 可为函数组件 + Hooks
- [ ] 函数组件未使用 `@NeoEvent.dispatch`/`@NeoEvent.function` 装饰器

### 2.4 类组件规范
- [ ] 类 `extends BaseCmp<Props, State>`
- [ ] 构造函数首行：`super(props)`
- [ ] `tsconfig.json` 已开启 `experimentalDecorators: true`
- [ ] 所有 `@NeoEvent.function` 方法在构造函数里做了 `this.xxx = this.xxx.bind(this)`
- [ ] **`@NeoEvent.function`/`@NeoEvent.dispatch` 使用类方法定义（`methodName() {}`），非类属性箭头函数（`methodName = () => {}`）**——装饰器只对类方法生效
- [ ] 类属性箭头函数（自动绑定 this）仅用于事件回调，不用于 `@NeoEvent.function` 装饰方法

### 2.5 数据访问规范
- [ ] 读/写平台实体数据使用 `xObject.query`/`get`/`create`/`update`/`delete`，未手写 `axios`
- [ ] 调平台自定义 API 使用 `customApi.run`
- [ ] 外部 API → 检查是否用通用代理：`customApi.run({ apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', ... })`
- [ ] 错误处理以 `status === true` 判断成功（不依赖 `code === 0` 或 `code === 200`）
- [ ] 所有 `neo-open-api` 异步调用（`xObject.query`/`get`/`create`/`update`/`delete`、`customApi.run`/`getList`）都包裹了 `try-catch`，`catch` 中提供兜底错误文案
- [ ] **`xObject.query` 的返回值使用正确：`result.data` 为列表数组（`any[]`），取值 `result.data || []`，未误用 `result.list` / `result.records` / `result.items`**
- [ ] **`xObject.get` 的返回值使用正确：`result.data` 为详情对象，未将 `result` 直接当详情对象使用**
- [ ] **`xObject.create` / `xObject.update` 的返回值使用正确：`result.data` 为操作后的记录对象**
- [ ] **`xObject.delete` 的返回值使用正确：仅有 `status`/`code`/`msg`，无 `data`**
- [ ] **`xObject.getFileds` 的返回值使用正确：`result.data` 为字段定义数组（`FieldItem[]`），从中取 `apiKey` 作为字段 key**
- [ ] **直接手写 `axios`/`fetch` 调平台实体接口（禁用手写 HTTP 调用平台实体数据）**

### 2.6 列表类组件规范
- [ ] 平台实体列表优先使用了 `NeoEntityList`（H5）/ `NeoEntityGrid`（PC），传了 `render={this.props.render}`
- [ ] 未因规避学习成本而用 `antd Table` + `xObject.query` 自研列表
- [ ] 若用了 `antd Table`/`antd-mobile List`，确为显著偏离列表语义的场景（卡片墙/看板/日历/地图等），且有 README 说明原因

### 2.7 字段使用规范（约束 6 + 约束 8）
- [ ] `xObject.query`/`xObject.get` 的 `fields` 参数未凭直觉杜撰
- [ ] `fields` 来源符合登录状态约束：未登录时使用 `xObject.getFileds`，已登录时使用 `fetchEntityDesc.js`/`xObject.getFileds`，均取前 10 个字段（`data` 中的 `apiKey` 为字段 key 值）
- [ ] 未指定字段时，组件通过 `xObject.getFileds` 获取字段列表，使用返回结果中的 `apiKey` 作为字段 key
- [ ] **`xObject.getFileds` 返回的字段列表即为组件可使用的字段全集，禁止在代码中凭经验添加列表之外的字段**（约束 8）
- [ ] **仅在用户需求明确要求某个实体字段且该字段不在 `xObject.getFileds` 返回的前 10 个时，才可将该字段追加到使用清单中**（约束 8 例外）
- [ ] 若用户未指定具体字段，则只能使用 `xObject.getFileds` 返回的字段，不得自行补充任何字段
- [ ] 字段名与实体 apiKey 的大小写严格一致

### 2.8 响应式约束（约束 5）— 依赖 props 属性的方法必须支持响应式
- [ ] **类组件**：所有依赖 `this.props` 特定字段的方法（如属性面板配置变化后重新查询数据、切换展示模式、重置本地状态等），在 `componentDidUpdate` 中监听了对应 props 字段的变化
- [ ] `componentDidUpdate` 正确比较 `prevProps` 与 `this.props` 中的相关字段，并在变化时触发对应操作（典型模式见下方）
- [ ] `propsSchema` 中所有可配置项（通过属性面板可改的字段）对应的组件 props，考虑了运行时变化的场景，**非仅 `componentDidMount` 一次性执行**
- [ ] 挂载时首次执行的初始化逻辑与 props 变化后的响应逻辑已解耦，优先从 `componentDidUpdate` 统一收口，避免在多个方法中分散判断条件
- [ ] 仅在挂载时执行一次、与 props 无关的逻辑（如注册全局事件监听）放在 `componentDidMount`，未误放进 `componentDidUpdate`
- [ ] **函数组件**：使用 `useEffect` + 正确依赖数组实现 props 响应（禁止忽略依赖数组或使用空数组 `[]` 跳过 prop 响应）

### 2.9 实体详情页跳转 URL
- [ ] 若组件需要点击实体名跳转到详情页，URL 格式为：
  ```
  /bff/neoweb#/entityDetail/{objectApiKey}/{recordId}?objectApiKey={...}&recordId={...}
  ```
- [ ] 未写死 URL 中的 `objectApiKey`/`recordId`（从运行时上下文中获取）

---

## 维度 3：模型文件（model.ts）规范

### 3.1 必填字段
- [ ] 包含 `label`（设计器面板显示的名称）
- [ ] 包含 `description`（设计器面板显示的描述）
- [ ] 包含 `defaultComProps`（首次拖入默认 props）
- [ ] 包含 `propsSchema`（属性面板配置，至少一个条目或为空数组）

### 3.2 targetDevice 对齐
- [ ] `targetDevice` 与实际使用的 UI 库对齐：
  - 使用 `antd` → `'web'`
  - 使用 `antd-mobile` → `'mobile'`
  - 纯展示无 UI 库或跨端 → `'all'`

### 3.3 propsSchema 类型检查
- [ ] 所有 `type` 均为平台真实类型（表单类或数据源类）
- [ ] **表单类可用 type**：`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `neoCheckbox` / `neoCascader` / `neoTreeSelect` / `neoDatePicker` / `neoTimePicker` / `neoRate` / `neoSlider` / `neoUpload` / `neoTransfer`
- [ ] **数据源类可用 type**：`xObjectEntityList` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `selectFieldDescApi` / `dataViewIdSelect` / `customApi`
- [ ] 未使用泛名（`input` / `select` / `radio` / `color` / `switch` 等）作为 `type`
- [ ] 未使用平台清单之外且未注册的 `type`
- [ ] 若用了自定义 `type`，已按 `custom-props-item.md` 完成 `@FormItem` 注册 + `model.ts` side-effect 引入

### 3.4 propsSchema 名称与类型对齐
- [ ] 每个 `propsSchema[].name` 与组件 `props` 字段名严格一致（大小写也一致）
- [ ] `options[].value` 类型与组件 props TS literal union 类型对齐
- [ ] **`type` 与 props 数据类型匹配**（布尔→`panelSwitch`、枚举→`panelSelect`/`neoRadio`、数字→`panelNumber`、颜色→`panelColor`、文本→`panelInput`），未误用（如布尔用 `panelInput`、枚举用 `panelInput`）
- [ ] `visibleOn`/`hiddenOn` 表达式引用了正确的 props 字段名

### 3.5 defaultComProps
- [ ] 每个 `propsSchema` 条目在 `defaultComProps` 中都有对应的默认值
- [ ] `defaultComProps` 的默认值与 `propsSchema` 的 `value`/`defaultValue` 一致
- [ ] 除有意留空外，不存在 propsSchema 有但 defaultComProps 没有的字段
- [ ] **`defaultComProps` 中不包含值为对象类型的数据源类配置项**（`xObjectDataApi` / `xObjectDetailApi` / `customApi` 等不应出现在 `defaultComProps` 中，因其值由设计器绑定产生，预设空对象 `{}` 无意义）
- [ ] 对于 `xObjectEntityList`（值为 `string`）、`selectFieldsApi`（值为 `string[]`）、`dataViewIdSelect`（值为 `string`）等非对象数值的数据源类配置项，可正常添加默认值

### 3.6 分类与标签
- [ ] 未自行添加 `tags` 字段（如需分类应提示用户在 model.ts 自行添加）
- [ ] 若用户已自行添加了 `tags`，格式应为字符串数组，建议包含 `'自定义组件'`

### 3.7 事件与函数声明
- [ ] 组件内使用了 `@NeoEvent.dispatch` → `model.events` 中有对应声明（`apiKey` 与方法名一致）
- [ ] 组件内使用了 `@NeoEvent.function` → `model.functions` 中有对应声明（`apiKey` 与方法名一致）
- [ ] 事件只声明在 `model.events`，未写在 `propsSchema` 中
- [ ] `events` 声明格式：`{ apiKey, label, helpText? }`
- [ ] `functions` 声明格式：`{ apiKey, label, helpTextKey? }`

### 3.8 其他模型字段
- [ ] 若 `targetPage` 非 `['all']`，有明确的理由（只特定页面有意义）
- [ ] 组件需要设计器可见 → `exposedToDesigner` 未设为 `false`
- [ ] `targetDevice` 与实际使用的 UI 库对齐（`antd`→`'web'`、`antd-mobile`→`'mobile'`、纯展示/跨端→`'all'`）
- [ ] 若用户已添加 `tags`，格式为字符串数组，建议包含 `'自定义组件'`

---

## 维度 4：事件动作规范

### 4.1 事件动作基础
- [ ] 涉及事件动作 → `extends BaseCmp`
- [ ] 构造函数调用了 `super(props)`
- [ ] `@NeoEvent.function` 方法有 `bind(this)`
- [ ] 方法 `apiKey` 与模型声明严格一致

### 4.2 dispatch 事件
- [ ] `@NeoEvent.dispatch` 标记的方法返回有意义的值（透传给事件绑定目标）
- [ ] dispatch 触发：通过方法调用语法 `this.methodName(args)`，非作为回调直接传递

### 4.3 function 动作
- [ ] `@NeoEvent.function` 方法使用了类方法定义（非类属性箭头函数）
- [ ] 使用 `this` 的 method 在构造函数有 `bind(this)`

### 4.4 广播（若有使用）
- [ ] `NeoEvent.listen` 有对应的 `componentWillUnmount` 清理（unsub 句柄）
- [ ] 广播仅用于全局通知场景（非主方案，主方案为 dispatch + function）

---

## 维度 5：样式规范

### 5.1 根节点样式
- [ ] 根节点 className = 组件目录名（与样式隔离 `[data-scope]` 一致）
- [ ] 根节点合并了 `props.className`（设计器注入 `design-hide`）
- [ ] 使用了 `classnames` 库拼接 className

### 5.2 SCSS 与 BEM
- [ ] 未使用 `&-xx` 语法拼接 BEM 子元素/修饰符（如 `&__header`、`&--primary`）
- [ ] BEM 子元素和修饰符写成独立完整选择器：`.cmpName__c__header`、`.cmpName__c--primary`
- [ ] 伪类选择器（`&:hover`、`&:focus` 等）允许使用

### 5.3 样式隔离
- [ ] 组件主体样式放在 `index.scss`（会被 CLI 隔离）
- [ ] 弹层/浮层（Modal/Popover/Tooltip/Dropdown/Select 等 body 挂载组件）的样式放在 `common.scss` 或 `reset.scss`（不会被隔离）
- [ ] `common.scss` 被正确 import（`import './common.scss'`）
- [ ] 未将弹层样式写入 `index.scss`

### 5.4 stylelint 常见规范
- [ ] 颜色值小写（`#fff` 非 `#FFF`）
- [ ] 颜色值简写（`#fff` 非 `#ffffff`）
- [ ] `0px` → `0`（`margin: 0` 非 `margin: 0px`）
- [ ] `margin: 8px 16px` 无冗余值
- [ ] 字符串使用单引号
- [ ] 属性声明冒号后有一个空格
- [ ] `@include`/`@mixin` 等 at-rule 前有空行
- [ ] 类名使用 kebab-case（BEM 形式也满足）
- [ ] 未滥用 `!important`（若使用，有充分理由且提高选择器特异性无法替代）

### 5.5 嵌套
- [ ] 嵌套层级未超过 3 层
- [ ] 没有过度嵌套的深层选择器

---

## 维度 6：数据源与平台能力规范

### 6.1 数据接入决策
- [ ] 能用 `xObject` 的未手写 `axios`
- [ ] `propsSchema` 优先暴露数据源类配置项（`xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `customApi`），而非写死 apiKey
- [ ] 外部 API 场景已提示用户部署通用代理（`forward.zip`）
- [ ] 通用代理调用时外层固定 `POST`，真正方法放内层 `data.method`
- [ ] **组件代码中读/写实体数据全部使用 `neo-open-api` 提供的 `xObject` 方法，未自行使用 `axios`/`fetch` 调用平台实体接口**
- [ ] **`props.env.ctx` 使用时始终判空**（如 `this.props.env?.ctx?.ui?.showToast`），未假设运行时一定存在

### 6.2 xObject 使用
- [ ] `xObject.query` 的 `fields` 参数不为空，且字段名正确
- [ ] 错误判断使用 `status === true`（非 `code === 0`）
- [ ] `orderBy` 仅支持 `id asc` / `id desc`，其他字段排序在客户端做
- [ ] `where` 语法：未对多值字段做取值条件（多值字段只能 `is null` / `is not null`）
- [ ] `where` 中 `like` 使用了正确语法（`'xxx%'` 开头匹配，非 `'%xxx'`）

### 6.3 customApi 使用
- [ ] 调自定义 API 时传了 `apiUrl` 和 `methodType`
- [ ] 通用代理的 `apiUrl` = `'/rest/data/v2.0/scripts/api/proxy/forward'`

### 6.4 平台预置组件
- [ ] H5 端列表 → `NeoEntityList`（传 `render={this.props.render}`）
- [ ] PC 端列表 → `NeoEntityGrid`（传 `render={this.props.render}`）
- [ ] H5 搜索 → `GlobalSearchInput`（若有搜索需求）
- [ ] 数据源类 propsSchema 的 `xObjectApiKey` 路径正确（如 `'entityApiKey.xObjectApiKey'` 或 `'dataSource.xObjectApiKey'`）

### 6.5 运行时上下文
- [ ] 使用 `this.props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` 时做了空值判断（非空再使用）
- [ ] 使用 `this.props.env.ctx` 时做了空值判断（如 `this.props.env?.ctx?.ui`），未假设运行时一定存在
- [ ] 未将 `ctx` 缓存到模块作用域（`ctx` 会随页面/租户切换变化，应每次从 `this.props.env` 取）
- [ ] 设计时属性面板取 `keyIdentifier`：使用 `this.props.$com?.keyIdentifier`；运行时/画布：使用 `this.props.keyIdentifier`

---

## 维度 7：依赖与构建规范

### 7.1 包版本（对照 `package.json`）
- [ ] `react` 版本为 `^16.13.1`
- [ ] `react-dom` 版本为 `^16.13.1`
- [ ] PC 端 `antd` 版本为 `4.9.4`
- [ ] PC 端 `@ant-design/icons` 版本（若有）为 `^4.8.0`
- [ ] H5 端 `antd-mobile` 版本为 `2.3.4`
- [ ] `classnames` 版本为 `^2.3.2`（若有）
- [ ] `mobx` 版本（若有）为 `^6.3.0`
- [ ] `axios` 版本为 `^0.27.2`（若有）
- [ ] `lodash` 版本为 `^4.17.21`（若有）

### 7.2 虚拟模块 与 平台 SDK
- [ ] `neo-ui-common` 不在 `package.json` 的 `dependencies` 或 `devDependencies` 中（虚拟模块）
- [ ] `neo-ui-component-web` / `neo-ui-component-h5` 不在 `package.json` 的 `dependencies` 或 `devDependencies` 中（虚拟模块）
- [ ] **`neo-open-api` 在 `package.json` 的 `dependencies` 中**（真实 NPM 包，必须安装；确认是否存在如 `"neo-open-api": "^1.2.13"`）
- [ ] `neo-open-api` 的 import 注释中**未**误写为"虚拟模块"或"无需安装"（应写"平台 SDK"）

### 7.3 避免 bundle 问题
- [ ] 未使用 `ncc` / 自定义 rollup 配置打包预置依赖
- [ ] webpack/tsconfig 未将 `react` 重定向到其他包
- [ ] antd 和 antd-mobile 未同时使用（仅使用当前端对应的一种）

### 7.4 重型依赖
- [ ] 若引入重型依赖（echarts / monaco-editor / pdf.js 等），使用了动态 import + 懒加载
- [ ] 若多组件共用重型依赖，配置了 `neoCommonModule` 模块共享

### 7.5 package.json 完整性
- [ ] `name` 在租户内唯一
- [ ] `version` 符合语义化版本规范
- [ ] `framework` 字段为 `react-ts`（若存在）
- [ ] 存在 `preview` / `linkDebug` / `pushCmp` 脚本（或等同 CLI 配置）

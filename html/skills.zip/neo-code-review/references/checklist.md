# 组件代码审查清单（7 维度 ~80+ 项）

> 本清单是 `neo-cmp-dev/SKILL.md` 及所有 `references/` 文件中约束与规范的逐项可检查映射。
>
> **审查方式**：阅读组件目录下的 `index.tsx`、`model.ts`、`index.scss`、`common.scss`、`package.json` 等文件，对照以下条目逐一检查。
>
> **标记**：✅ 通过 / ❌ 未通过 / ⏭️ 跳过

---

## 维度 1：目录与命名规范

### 1.1 组件目录名
- [ ] 目录位于 `src/components/` 下
- [ ] 目录名使用 `<cmpName>__c` 后缀（`__c` 是平台约定）
- [ ] 目录名 = `cmpType`（CLI 按目录名自动生成）
- [ ] 目录内不存在与 `cmpType` 不一致的残余文件

### 1.2 必须文件
- [ ] 存在 `index.tsx`（或 `.ts`/`.js`/`.jsx`）作为入口
- [ ] 存在 `model.ts`（或 `.js`）作为模型文件
- [ ] 入口文件名只能为 `index.*`（CLI 扫描入口的依据）

### 1.3 工具与公共组件
- [ ] 不依赖 `this`/`state`/`props` 的独立纯函数已下沉到 `src/utils/`（按领域分文件，如 `date.ts`/`number.ts`/`entity.ts`）
- [ ] `index.tsx` 中不存在不依赖 `this`/`state`/`props` 的独立函数
- [ ] 自研功能子组件（非 antd/antd-mobile 替代品）放 `src/common/`，README 说明自研原因
- [ ] 组件私有子组件放 `src/components/<cmpName>__c/components/`
- [ ] 不将 UI 子组件零散放在组件目录顶层

### 1.4 自研 UI 兜底说明
- [ ] 若使用了非 antd/antd-mobile 的自研 UI 子组件，有 README 说明原因
- [ ] 未引入 Element/MUI/Semi/Arco/Vant/NutUI 等其他 UI 库

---

## 维度 2：入口文件（index.tsx）规范

### 2.1 根节点 className
- [ ] 根节点 `className` 包含组件目录名（如 `infoCard__c`）
- [ ] 根节点使用 `classnames` 合并了 `props.className`（格式：`classnames('目录名', this.props.className)`）

### 2.2 import 规范
- [ ] 平台虚拟模块（`neo-ui-common` / `neo-ui-component-*`）导入前有 `// @ts-ignore` 注释
- [ ] 虚拟模块的 import 语句格式正确：
  ```tsx
  // @ts-ignore 平台注入，无需安装
  import { BaseCmp, NeoEvent } from 'neo-ui-common';
  // @ts-ignore
  import { xObject, customApi, request } from 'neo-open-api';
  ```
- [ ] 不直接从 `axios`/`request` 调用平台实体数据（应使用 `xObject`）
- [ ] PC 端 `import` 来自 `antd`（非 `antd-mobile`），H5 端 `import` 来自 `antd-mobile`（非 `antd`）
- [ ] `classnames` 库正常导入（`import classnames from 'classnames'`）
- [ ] 组件样式文件被正确导入（`import './index.scss'` / `import './common.scss'`）

### 2.3 组件形态选择
- [ ] 若有事件动作需求（`@NeoEvent.dispatch`/`@NeoEvent.function`），组件为类组件 `extends BaseCmp`
- [ ] 若需要组件控制/组件可见性能力，组件为类组件 `extends BaseCmp`
- [ ] 纯展示且无事件动作需求 → 可为函数组件 + Hooks
- [ ] 函数组件未使用 `@NeoEvent.dispatch`/`@NeoEvent.function` 装饰器

### 2.4 类组件规范
- [ ] 类 `extends BaseCmp<Props, State>`
- [ ] 构造函数首行：`super(props)`
- [ ] `tsconfig.json` 已开启 `experimentalDecorators: true`
- [ ] 所有 `@NeoEvent.function` 方法在构造函数里做了 `this.xxx = this.xxx.bind(this)`

### 2.5 数据访问规范
- [ ] 读/写平台实体数据使用 `xObject.query`/`get`/`create`/`update`/`delete`，未手写 `axios`
- [ ] 调平台自定义 API 使用 `customApi.run`
- [ ] 外部 API → 检查是否用通用代理：`customApi.run({ apiUrl: '/rest/data/v2.0/scripts/api/proxy/forward', ... })`
- [ ] 错误处理以 `status === true` 判断成功（不依赖 `code === 0`）
- [ ] try-catch 包裹异步调用，`error` 有兜底文案

### 2.6 列表类组件规范
- [ ] 平台实体列表优先使用了 `NeoEntityList`（H5）/ `NeoEntityGrid`（PC），传了 `render={this.props.render}`
- [ ] 未因规避学习成本而用 `antd Table` + `xObject.query` 自研列表
- [ ] 若用了 `antd Table`/`antd-mobile List`，确为显著偏离列表语义的场景（卡片墙/看板/日历/地图等），且有 README 说明原因

### 2.7 字段使用规范
- [ ] `xObject.query`/`xObject.get` 的 `fields` 参数未凭直觉杜撰
- [ ] `fields` 来源遵循优先级：用户需求字段 → `references/standard-entities.md` 前 10 个 → `fetchEntityDesc.js`/`xObject.getDesc` 前 10 个

---

## 维度 3：模型文件（model.ts）规范

### 3.1 必填字段
- [ ] 包含 `label`（设计器面板显示的名称）
- [ ] 包含 `description`（设计器面板显示的描述）
- [ ] 包含 `defaultComProps`（首次拖入默认 props）
- [ ] 包含 `propsSchema`（属性面板配置，至少一个条目或为空数组）

### 3.2 targetDevice 对齐
- [ ] `targetDevice` 与实际使用的 UI 库对齐：
  - 使用 `antd` → `'web'`
  - 使用 `antd-mobile` → `'mobile'`
  - 纯展示无 UI 库或跨端 → `'all'`

### 3.3 propsSchema 类型检查
- [ ] 所有 `type` 均为平台真实类型（表单类或数据源类）
- [ ] **表单类可用 type**：`panelInput` / `panelSelect` / `panelSwitch` / `panelNumber` / `panelColor` / `neoRadio` / `neoCheckbox` / `neoCascader` / `neoTreeSelect` / `neoDatePicker` / `neoTimePicker` / `neoRate` / `neoSlider` / `neoUpload` / `neoTransfer`
- [ ] **数据源类可用 type**：`xObjectEntityList` / `xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `selectFieldDescApi` / `dataViewIdSelect` / `customApi`
- [ ] 未使用泛名（`input` / `select` / `radio` / `color` / `switch` 等）作为 `type`
- [ ] 未使用平台清单之外且未注册的 `type`
- [ ] 若用了自定义 `type`，已按 `custom-props-item.md` 完成 `@FormItem` 注册 + `model.ts` side-effect 引入

### 3.4 propsSchema 名称对齐
- [ ] 每个 `propsSchema[].name` 与组件 `props` 字段名严格一致（大小写也一致）
- [ ] `options[].value` 类型与组件 props TS literal union 类型对齐

### 3.5 defaultComProps
- [ ] 每个 `propsSchema` 条目在 `defaultComProps` 中都有对应的默认值
- [ ] `defaultComProps` 的默认值与 `propsSchema` 的 `value`/`defaultValue` 一致
- [ ] 除有意留空外，不存在 propsSchema 有但 defaultComProps 没有的字段
- [ ] **`defaultComProps` 中不包含值为对象类型的数据源类配置项**（`xObjectDataApi` / `xObjectDetailApi` / `customApi` 等不应出现在 `defaultComProps` 中，因其值由设计器绑定产生，预设空对象 `{}` 无意义）
- [ ] 对于 `xObjectEntityList`（值为 `string`）、`selectFieldsApi`（值为 `string[]`）、`dataViewIdSelect`（值为 `string`）等非对象数值的数据源类配置项，可正常添加默认值

### 3.6 分类与标签
- [ ] 未自行添加 `tags` 字段（如需分类应提示用户在 model.ts 自行添加）
- [ ] 若用户已自行添加了 `tags`，格式应为字符串数组，建议包含 `'自定义组件'`

### 3.7 事件与函数声明
- [ ] 组件内使用了 `@NeoEvent.dispatch` → `model.events` 中有对应声明（`apiKey` 与方法名一致）
- [ ] 组件内使用了 `@NeoEvent.function` → `model.functions` 中有对应声明（`apiKey` 与方法名一致）
- [ ] 事件只声明在 `model.events`，未写在 `propsSchema` 中
- [ ] `events` 声明格式：`{ apiKey, label, helpText? }`
- [ ] `functions` 声明格式：`{ apiKey, label, helpTextKey? }`

### 3.8 其他模型字段
- [ ] 若 `targetPage` 非 `['all']`，有明确的理由（只特定页面有意义）
- [ ] 组件需要设计器可见 → `exposedToDesigner` 未设为 `false`

---

## 维度 4：事件动作规范

### 4.1 事件动作基础
- [ ] 涉及事件动作 → `extends BaseCmp`
- [ ] 构造函数调用了 `super(props)`
- [ ] `@NeoEvent.function` 方法有 `bind(this)`
- [ ] 方法 `apiKey` 与模型声明严格一致

### 4.2 dispatch 事件
- [ ] `@NeoEvent.dispatch` 标记的方法返回有意义的值（透传给事件绑定目标）
- [ ] dispatch 触发：通过方法调用语法 `this.methodName(args)`，非作为回调直接传递

### 4.3 function 动作
- [ ] `@NeoEvent.function` 方法使用了类方法定义（非类属性箭头函数）
- [ ] 使用 `this` 的 method 在构造函数有 `bind(this)`

### 4.4 广播（若有使用）
- [ ] `NeoEvent.listen` 有对应的 `componentWillUnmount` 清理（unsub 句柄）
- [ ] 广播仅用于全局通知场景（非主方案，主方案为 dispatch + function）

---

## 维度 5：样式规范

### 5.1 根节点样式
- [ ] 根节点 className = 组件目录名（与样式隔离 `[data-scope]` 一致）
- [ ] 根节点合并了 `props.className`（设计器注入 `design-hide`）
- [ ] 使用了 `classnames` 库拼接 className

### 5.2 SCSS 与 BEM
- [ ] 未使用 `&-xx` 语法拼接 BEM 子元素/修饰符（如 `&__header`、`&--primary`）
- [ ] BEM 子元素和修饰符写成独立完整选择器：`.cmpName__c__header`、`.cmpName__c--primary`
- [ ] 伪类选择器（`&:hover`、`&:focus` 等）允许使用

### 5.3 样式隔离
- [ ] 组件主体样式放在 `index.scss`（会被 CLI 隔离）
- [ ] 弹层/浮层（Modal/Popover/Tooltip/Dropdown/Select 等 body 挂载组件）的样式放在 `common.scss` 或 `reset.scss`（不会被隔离）
- [ ] `common.scss` 被正确 import（`import './common.scss'`）
- [ ] 未将弹层样式写入 `index.scss`

### 5.4 stylelint 常见规范
- [ ] 颜色值小写（`#fff` 非 `#FFF`）
- [ ] 颜色值简写（`#fff` 非 `#ffffff`）
- [ ] `0px` → `0`（`margin: 0` 非 `margin: 0px`）
- [ ] `margin: 8px 16px` 无冗余值
- [ ] 字符串使用单引号
- [ ] 属性声明冒号后有一个空格
- [ ] `@include`/`@mixin` 等 at-rule 前有空行
- [ ] 类名使用 kebab-case（BEM 形式也满足）
- [ ] 未滥用 `!important`（若使用，有充分理由且提高选择器特异性无法替代）

### 5.5 嵌套
- [ ] 嵌套层级未超过 3 层
- [ ] 没有过度嵌套的深层选择器

---

## 维度 6：数据源与平台能力规范

### 6.1 数据接入决策
- [ ] 能用 `xObject` 的未手写 `axios`
- [ ] `propsSchema` 优先暴露数据源类配置项（`xObjectDataApi` / `xObjectDetailApi` / `selectFieldsApi` / `customApi`），而非写死 apiKey
- [ ] 外部 API 场景已提示用户部署通用代理（`forward.zip`）
- [ ] 通用代理调用时外层固定 `POST`，真正方法放内层 `data.method`

### 6.2 xObject 使用
- [ ] `xObject.query` 的 `fields` 参数不为空，且字段名正确
- [ ] 错误判断使用 `status === true`（非 `code === 0`）
- [ ] `orderBy` 仅支持 `id asc` / `id desc`，其他字段排序在客户端做
- [ ] `where` 语法：未对多值字段做取值条件

### 6.3 customApi 使用
- [ ] 调自定义 API 时传了 `apiUrl` 和 `methodType`
- [ ] 通用代理的 `apiUrl` = `'/rest/data/v2.0/scripts/api/proxy/forward'`

### 6.4 平台预置组件
- [ ] H5 端列表 → `NeoEntityList`（传 `render={this.props.render}`）
- [ ] PC 端列表 → `NeoEntityGrid`（传 `render={this.props.render}`）
- [ ] H5 搜索 → `GlobalSearchInput`（若有搜索需求）
- [ ] 数据源类 propsSchema 的 `xObjectApiKey` 路径正确（如 `'entityApiKey.xObjectApiKey'` 或 `'dataSource.xObjectApiKey'`）

### 6.5 运行时上下文
- [ ] 使用 `this.props.data.__NeoCurrentUser` / `__NeoSystemInfo` / `__NeoPageInfo` 时做了空值判断（非空再使用）

---

## 维度 7：依赖与构建规范

### 7.1 包版本（对照 `package.json`）
- [ ] `react` 版本为 `^16.13.1`
- [ ] `react-dom` 版本为 `^16.13.1`
- [ ] PC 端 `antd` 版本为 `4.9.4`
- [ ] H5 端 `antd-mobile` 版本为 `2.3.4`

### 7.2 虚拟模块
- [ ] `neo-ui-common` 不在 `package.json` 的 `dependencies` 或 `devDependencies` 中
- [ ] `neo-ui-component-web` / `neo-ui-component-h5` 不在 `package.json` 的 `dependencies` 或 `devDependencies` 中

### 7.3 避免 bundle 问题
- [ ] 未使用 `ncc` / 自定义 rollup 配置打包预置依赖
- [ ] webpack/tsconfig 未将 `react` 重定向到其他包
- [ ] antd 和 antd-mobile 未同时使用（仅使用当前端对应的一种）

### 7.4 重型依赖
- [ ] 若引入重型依赖（echarts / monaco-editor / pdf.js 等），使用了动态 import + 懒加载
- [ ] 若多组件共用重型依赖，配置了 `neoCommonModule` 模块共享

### 7.5 package.json 完整性
- [ ] `name` 在租户内唯一
- [ ] `version` 符合语义化版本规范
- [ ] `framework` 字段为 `react-ts`（若存在）
- [ ] 存在 `preview` / `linkDebug` / `pushCmp` 脚本（或等同 CLI 配置）

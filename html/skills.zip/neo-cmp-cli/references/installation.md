# 安装与版本

**Node 版本要求**：v16+（推荐 v20+）。

## 安装 neo-cmp-cli

```bash
# npm（推荐）
npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com

# 或 yarn
yarn global add neo-cmp-cli --registry https://registry.npmmirror.com

# 或 pnpm
pnpm add -g neo-cmp-cli --registry=https://registry.npmmirror.com

# 验证
neo -h
neo --version

# 升级
npm update -g neo-cmp-cli --registry=https://registry.npmmirror.com
yarn global upgrade --latest neo-cmp-cli --registry https://registry.npmmirror.com
```

## Windows 安装常见问题

- **「禁止运行脚本」**：`Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser`
- **「无法将 neo 项识别为 cmdlet」**（PATH 问题）：
  ```powershell
  $npmPath = npm config get prefix
  $env:PATH += ";$npmPath"
  [Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";$npmPath", "User")
  ```

## 淘宝源策略

`registry.npmmirror.com` 是默认镜像源（`registry.npm.taobao.org` 已于 2024 年停用，禁止再使用）。

### 允许注入淘宝源（仅两类场景）

1. **全局安装 / 升级 neo-cmp-cli 本身**：
   ```bash
   npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com
   yarn global add neo-cmp-cli --registry https://registry.npmmirror.com
   pnpm add -g neo-cmp-cli --registry=https://registry.npmmirror.com
   ```
2. **在项目根目录安装工程全量依赖**（`package.json` + lock 文件一次性安装）：
   ```bash
   npm install --registry=https://registry.npmmirror.com
   yarn --registry https://registry.npmmirror.com
   pnpm install --registry=https://registry.npmmirror.com
   ```

### 禁止注入淘宝源的场景
- 发布/构建类：`npm publish` / `npm run build` / `neo build*` / `neo push cmp`
- 任何与"安装 neo-cmp-cli"或"安装工程全量依赖"无关的命令

### 例外（让行于工程配置）
- 工程已有 `.npmrc` / `.yarnrc` / `.yarnrc.yml` 指向私服，或安装 scope 包（如 `@your-scope/xxx`），沿用工程配置，不追加 `--registry`
- **用户显式要求其它源**时以用户为准

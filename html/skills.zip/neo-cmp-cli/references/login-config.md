# 登录 / 环境配置

## OAuth2（推荐，默认）

```bash
neo login -e cd        # 开发环境
neo login -e production # 生产
neo login -e custom    # 自定义：需在 neo.config.js 配置
```

### 可选环境（env）

| 值 | 说明 |
|---|---|
| `production` | 线上生产环境（crm.xiaoshouyi.com） |
| `p20` | P20 环境（crm-p20.xiaoshouyi.com） |
| `sandbox` | 沙盒环境（crm-sandbox.xiaoshouyi.com） |
| `cd` | 开发环境（crm-cd.xiaoshouyi.com） |
| `tencentuat` | tencentuat 环境（crm-tencentuat.xiaoshouyi.com） |
| `custom` | 自定义环境（在 `neo.config.js` → `neoConfig` 中配置 `neoBaseURL` / `loginURL` / `tokenAPI`） |

### 自定义环境配置（`neo.config.js`）

```js
module.exports = {
  neoConfig: {
    neoBaseURL: 'https://crm-xx.xiaoshouyi.com',        // 平台根地址
    loginURL:   'https://login-xx.xiaoshouyi.com/auc/oauth2/auth',  // 授权页
    tokenAPI:   'https://login-xx.xiaoshouyi.com/auc/oauth2/token', // 换 Token
  },
};
```

### Token 说明

- 登录成功后 token 写入**项目根目录**下的 `.neo-cli/token.json`（`{projectRoot}/.neo-cli/token.json`），不是用户 home 目录或全局配置
- `access_token` 约 2 小时，`refresh_token` 约 30 天，过期前 5 分钟自动刷新
- `neo login` 会拉起系统默认浏览器访问授权页，完成后回调本地接收 code。终端会打印授权 URL，**若浏览器未自动打开**，提示用户手动复制 URL 到浏览器打开

## 密码模式（备选，不推荐）

仅当 OAuth2 不可用（如 CI 环境）时使用。密码需与 8 位安全令牌拼接，获取方式见 [销售易文档中心](https://doc.xiaoshouyi.com) 的 OAuth 章节。

```js
// neo.config.js
module.exports = {
  neoConfig: {
    neoBaseURL: 'https://crm-cd.xiaoshouyi.com',
    tokenAPI:   'https://login-cd.xiaoshouyi.com/auc/oauth2/token',
    authType:   'password',
    auth: {
      client_id:     'xxx',
      client_secret: 'xxx',
      username:      'xxx',
      // 「登录密码 + 8 位安全令牌」直接拼接（无空格）
      password:      'xxx',
    },
  },
};
```

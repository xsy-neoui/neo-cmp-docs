# 平台对接脚本（Node.js）详细说明

`scripts/` 目录下的 Node 脚本专门处理「需要对接平台接口 / 需要先列出再选」的场景，**所有脚本执行前自动做登录态预检**（未登录时调用 `neo login -e <env>` 走 OAuth2 授权），**Agent 无需在 bash 处理 neo 的交互式列表**。

## 脚本总览

| 脚本 | 作用 | 关键参数 |
|---|---|---|
| `scripts/login.js` | 登录态预检 / 主动登录 | `--env` / `--force` / `--project` |
| `scripts/fetchEntityList.js` | 拉取平台实体列表（`xObject.getEntityList`） | `--custom` / `--all` / `--format json` / `--out` |
| `scripts/fetchEntityDesc.js` | 按 apiKey 获取实体字段详情（`xObject.getDesc`） | `--apiKey` / `--format fields\|json` / `--out` |
| `scripts/fetchCustomCmpList.js` | 从 `.neo-cli/env.json` 拼接 `queryAll` 接口地址，拉取自定义组件列表 | `--framework` / `--format json` / `--out` |
| `scripts/pullCustomCmp.js` | **交互式选择 + 批量 `neo pull cmp -n <name>`**（含「拉取全部」选项） | `--all` / `--name a,b` / `--list-only` / `--dry-run` |
| `scripts/buildEntityDetailUrl.js` | **构建实体详情页 URL + 生成列表组件点击跳转代码片段**（原则 8） | `--apiKey` / `--code` / `--recordId` / `--format` |
| `scripts/validateEntityFields.js` | **验证组件使用的字段是否在实体中已存在**（发布前校验，原则 9） | `--apiKey` / `--fields` / `--verbose` / `--out` |

## 共享底座

### `scripts/lib/ensureDeps.js`（依赖自动预检）

所有脚本在最顶部 `require('./lib/ensureDeps')`。如果 `skills/neo-cmp-cli/` 下尚未安装 `node_modules`，会自动在 skill 根目录执行 `npm i --registry=https://registry.npmmirror.com` 再继续；已安装则为一次快速存在性检查（幂等）。**用户/Agent 首次运行脚本时无需手动 `npm install`，脚本会自己搞定。**

### `scripts/lib/neoClient.js`（核心工具函数）

- `ensureLogin({ env, cwd, forceLogin })`：读取 `.neo-cli/token.json`，判断 `access_token` / `instance_uri` / `expiresAt`；失效时 `spawnSync('neo', ['login', '-e', env])` 拉起授权流程，授权成功后重新读取 token
- `configureAxiosWithToken(axios, token)`：设置 `baseURL = token.instance_uri` / `Authorization: Bearer <token>` / `xsy-inner-source: bff` 到 axios defaults
- `getEnvConfig(projectDir)` + `buildFullUrl(envConfig, apiPath)`：从 `.neo-cli/env.json` 拼全量接口地址
- `prepareOpenApiEnv()`：在 `require('neo-open-api')` 之前伪造 `window.location.origin`，让 SDK 白名单走浏览器分支
- `parseArgs(argv, aliases)`：轻量 CLI 解析，所有脚本共享统一参数风格

## 典型场景

### 场景 A：拉取自定义组件

对应原则 1「先列再选」。

1. 登录态预检 & 列出线上组件：
   ```bash
   # 只看列表
   node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js --format json
   # 或使用 pullCustomCmp 的 --list-only
   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --list-only
   ```
2. 列表以**编号形式**交给用户挑选，额外提供「0/all = 拉取全部」选项
3. 拿到选择后非交互式执行：
   ```bash
   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --all                  # 拉全部
   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --name orderCard__c,userCard__c  # 拉指定
   ```
4. 执行前提醒：会覆盖 `src/components/<cmpType>/` 目录，先备份

### 场景 B：实体详情页跳转

对应原则 8「生成列表组件时，点击实体名称跳转详情页」。

1. 确定实体 apiKey（如 `account` / `opportunity` / `contact` 等）
2. 使用 buildEntityDetailUrl.js 获取跳转代码：
   ```bash
   node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js --apiKey <apiKey> --code
   ```
3. 若内置映射无该实体，先用 `fetchEntityDesc.js` 获取字段列表找到名称字段：
   ```bash
   node skills/neo-cmp-cli/scripts/fetchEntityDesc.js --apiKey <apiKey>
   ```
4. 将输出的 `buildEntityDetailUrl` 函数和 `render` 跳转逻辑嵌入组件代码

### 场景 C：发布前验证字段存在性

对应原则 9「组件使用平台实体数据时必须验证字段存在性」。

1. 汇总组件代码中所有实体字段 apiKey（来自 `xObject.query({ fields })`、`xObject.create/update` 的 `data` 等）
2. 按实体逐个验证：
   ```bash
   node skills/neo-cmp-cli/scripts/validateEntityFields.js -k <apiKey> -f field1,field2,field3
   ```
3. 检查输出中是否存在 ❌ 无效字段；若有，提示用户并协助从 `fields` 列表、`data` 对象等位置剔除，用户确认后进入发布流程

## 前置依赖

仓库根 `package.json` 已声明 `axios` / `neo-open-api` / `neo-cmp-cli`。所有脚本启动时自动做依赖预检：若 `skills/neo-cmp-cli/` 下无 `node_modules`，自动执行 `npm i --registry=https://registry.npmmirror.com`（幂等）。也可手动安装：

```bash
npm install --registry=https://registry.npmmirror.com
```

若系统 PATH 没有 `neo` 命令，脚本提示：`未找到 neo 命令，请先全局安装：npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com`

## 与原则的对齐

- **原则 1**：`pullCustomCmp.js` 默认编号选择模式（`1,3,5` / `1-3` / `0/all`），也可 `--list-only` 只列不跑，用户选定后再 `--name`/`--all` 非交互式执行
- **原则 3**：`lib/ensureDeps.js` 安装脚本运行时依赖，属于"工程全量依赖安装"，默认追加淘宝源
- **原则 5**：所有脚本的 `ensureLogin` 以**当前工作目录下 `.neo-cli/token.json`** 为唯一判定标准
- **原则 6**：`fetchEntityList` / `fetchEntityDesc` / `fetchCustomCmpList` 只要 `.neo-cli/` 存在即可；`pullCustomCmp.js` 仍需在有 `neo.config.js` 的项目根运行
- **原则 7**：脚本本身不涉及预览/调试命令，但引用脚本的开发流程须遵循预览走 `neo preview`、调试走 `neo linkDebug`
- **原则 8**：`buildEntityDetailUrl.js` 输出 URL 模式和代码片段，直接落地原则 8
- **原则 9**：`validateEntityFields.js` 直接落地原则 9，发布前验证所有字段存在性

详细使用说明见 [`scripts/README.md`](../scripts/README.md)。

# 命令详细交互流程

> 以下每条命令的「询问话术」是 Agent 与用户交互的推荐措辞，可根据对话上下文灵活调整。核心不变：**先把交互选项列给用户 → 用户选择后再用非交互参数一次执行**。

## 1. `neo create project` — 创建空项目（默认路径）

**交互点**：缺 `-n` 弹出项目名输入框。

**询问话术**：
> 准备用 `neo create project` 新建一个空的自定义组件项目（不含任何组件，推荐的首次创建路径）。请提供项目名称（建议小驼峰 `xxxCmpProject`）。

**非交互式执行**：
```bash
neo create project --name=<name>
```

## 2. `neo init` — 按模板创建（仅用户指定模板时）

**交互点**：缺 `-t` 弹出模板列表；缺 `-n` 弹出项目名输入框。

**模板列表**：

| 值 | 说明 |
|---|---|
| `neo-web-entity-grid` | Web 端列表组件（基础大列表、Picker 列表等示例） |
| `neo-h5-cmps` | H5 端业务组件（全局搜索、数据列表、Tabs、AI 对话等示例） |
| `neo` | 自定义业务组件（实体表单、实体详情、实体数据表格等示例） |
| `neo-bi-cmps` | 数值指标组件（实体数据源中的关键数值指标） |
| `antd` | antd 组件（数据仪表板、搜索组件等示例） |
| `echarts` | ECharts 组件（图表示例） |
| `amap` | 地图组件（基于高德地图 API） |
| `vue2` | Vue2 组件（基于 Vue2 的示例） |

**询问话术**：
> 准备用 `neo init` 基于模板新建项目。请提供：
> 1. 模板类型：1) neo-web-entity-grid（PC 列表）/ 2) neo-h5-cmps（H5 业务）/ 3) neo（实体业务）/ 4) neo-bi-cmps（指标）/ 5) antd / 6) echarts / 7) amap / 8) vue2
> 2. 项目名称（目录名，建议小驼峰，以 `CmpProject` 结尾）

**非交互式执行**：
```bash
neo init -t <type> -n <name>
```

> `neo init` 不会覆盖已有 neo 项目目录；若当前目录已是自定义组件项目会直接退出报错。

## 3. `neo create cmp` — 新增组件

**交互点**：缺 `-n` 弹出组件名输入框；缺 `-d` 弹出设备类型列表。

**询问话术**：
> 准备用 `neo create cmp` 新增一个自定义组件。请提供：
> 1. 组件名（建议小驼峰 + `__c` 后缀，如 `infoCard__c`；目录名 = 根类名 = 组件名）
> 2. 目标端：1) all（所有端）/ 2) web（网页端 PC）/ 3) mobile（移动端 H5）

**非交互式执行**：
```bash
neo create cmp -n <name> -d <all|web|mobile>
```

## 4. `neo login` — 登录

**交互点**：缺 `-e` 弹出环境列表。

**询问话术**：
> 准备用 `neo login` 登录 NeoCRM。请选择环境：1) production / 2) p20 / 3) sandbox / 4) cd / 5) tencentuat / 6) custom（需在 `neo.config.js` 的 `neoConfig` 中配置域名）。

**非交互式执行**：
```bash
neo login -e <env>
```

> 登录成功后 token 写入 `{projectRoot}/.neo-cli/token.json`。access_token 约 2 小时，refresh_token 约 30 天。`neo login` 会拉起浏览器，若未自动打开，提示用户手动复制 URL。

## 5. `neo logout` — 登出

无参数，无交互点。`neo logout`

## 6. `neo preview` — 预览

**交互点**：缺 `-n` 时扫描 `src/components/` 列出目录；缺 `-m` 时让用户选 local/online。

**场景限制**：
- `-m local`：纯本地预览，**不依赖平台运行时**。若组件 import 了 `neo-ui-common` / `neo-ui-component-*`（平台虚拟模块），local 模式无法运行，必须走 `neo linkDebug` 或 `neo preview -m online`
- `-m online`：在线预览（等同 linkPreview），**需登录**，适用于依赖平台运行时的场景

**询问话术**：
> 准备用 `neo preview` 预览。请确认：
> 1. 要预览哪个组件？（从 `src/components/` 下选）
> 2. 模式：1) `local` 本地预览（纯展示，不依赖平台运行时）/ 2) `online` 在线预览（需登录）
>
> 若组件依赖 `neo-ui-common` / `neo-ui-component-*` / 平台事件动作，请选 `online` 或改用 `neo linkDebug`。

**非交互式执行（长时运行，走后台进程）**：
```bash
neo preview -n <name> -m local
neo preview -n <name> -m online
```

## 7. `neo linkDebug` — 外链调试

**交互点**：缺 `-p` 弹出列表，默认 `pc`。

**预检要求**：需项目结构预检（`neo.config.js`）+ 登录态预检（`.neo-cli/token.json`）

**询问话术**：
> 准备用 `neo linkDebug` 开启外链调试。请选择调试设备类型：1) `pc`（网页端，默认）/ 2) `h5`（移动端）。

**非交互式执行（长时运行，走后台进程）**：
```bash
neo linkDebug -p <pc|h5>
```

**启动后操作**：
1. 从后台进程输出提取 `http://localhost:<port>/index.js` 脚本地址
2. 在 NeoCRM 页面设计器 URL 末尾追加 `?debug=true`（或 `&debug=true`）并访问
3. 在设计器左侧「外部链接」面板添加脚本地址，物料面板即可看到自定义组件

## 8. `neo push cmp` — 发布

**交互点**：缺 `-n` 时扫描 `src/components/` 列出组件目录（含 ALL 批量选项）。

**预检要求**：需项目结构预检 + 登录态预检

**询问话术**：
> 准备 `neo push cmp` 构建并发布到 NeoCRM。请确认：
> 1. 当前登录环境是否正确（见 `.neo-cli/token.json`）
> 2. 要发布哪个组件？1) 指定组件名（单个）/ 2) ALL（所有组件）
> 3. `package.json` 的 `version` 已递增且未与线上冲突

**非交互式执行**：
```bash
# 单个
neo push cmp -n <cmpName>

# 批量（遍历 src/components/，逐条执行，失败不中断，完成后汇总）
neo push cmp -n cmpA__c
neo push cmp -n cmpB__c
```

**Agent 批量发布流程**：
1. `ls src/components/` 或 `fs.readdirSync` 过滤 `__c` 后缀目录作为组件清单
2. 展示给用户确认或剔除
3. 逐条执行，每条检查输出含 `success`/`发布成功` 信号；失败记录日志不中断
4. 全部执行完毕后汇总成功/失败清单

## 9. `neo pull cmp` — 拉取线上组件

**交互点**：缺 `-n` 时调用服务端接口拉线上组件列表（含 ALL 全量拉取）。

**预检要求**：需项目结构预检 + 登录态预检。**会覆盖本地同名目录**，拉取前必须提醒用户备份。

**询问话术**：
> 准备 `neo pull cmp` 拉取线上组件到本地。请确认：
> 1. 当前登录环境是否正确
> 2. 要拉取的组件名（若不知道，可通过 NeoCRM 管理后台查看，或本地跑一次交互式 `neo pull cmp` 查看列表）
> 3. 请备份本地 `src/components/<cmpName>/` 目录（或确认允许覆盖）

**非交互式执行**：
```bash
neo pull cmp -n <cmpName>
```

### 如何获取线上组件列表（用户不知组件名时）

CLI 只支持交互式列表（`NeoService.getCustomCmpList()` → inquirer），Agent 直接跑会卡住。推荐方式（按优先级）：
1. **最佳**：让用户在 NeoCRM 管理后台查看（页面设计器 → 自定义组件管理页），告知 Agent 组件名
2. **次选**：用户自己在终端跑一次 `neo pull cmp`（不带参数），交互式列表展示组件名后退出
3. **备选**：从本地 `src/components/` 下已有的 `__c` 目录推测名称，`-n` 尝试执行

## 10. `neo delete cmp` — 删除线上组件（不可恢复）

**交互点**：缺 `-n` 拉线上列表让用户选。

**预检要求**：需项目结构预检 + 登录态预检。**高风险**：删除后设计器无法选用，已引用页面/表单会失效。

**询问话术（必须显式二次确认）**：
> ⚠️ 准备 `neo delete cmp` 删除线上组件。**此操作不可恢复**，且会影响已引用的页面/表单。请确认：
> 1. 当前登录环境正确（别误删 production）
> 2. 要删除的组件名：`<cmpName>`（再确认一次）
> 3. 建议先用 `neo pull cmp -n <cmpName>` 备份源码
>
> 请回复「确认删除 `<cmpName>`」后再执行

**非交互式执行**：
```bash
neo delete cmp -n <cmpName>
```

## 11. `neo open` — 打开编辑器

**参数**：`-e, --editor <cursor|vscode|code|auto>`（默认 `auto`）；`-n, --name <项目名>`（默认当前目录）

**非交互式执行**：
```bash
neo open
neo open -e cursor
neo open -e vscode -n myCmpProject
```

## 12. 其它无交互命令

| 命令 | 说明 |
|---|---|
| `neo config init` | 生成 `neo.config.js` 配置文件 |
| `neo dev` | 本地开发模式（历史命令，一般用 `neo preview` / `neo linkDebug`） |
| `neo build` | 构建生产代码 |
| `neo build2lib` | 构建 UMD 模块 |
| `neo build2esm` | 构建 ESM 模块 |
| `neo inspect [-t build\|dev\|lib]` | 输出当前工程的构建配置 |

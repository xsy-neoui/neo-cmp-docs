# 常见报错 & 排查

| 症状 | 可能原因 | 处置 |
|---|---|---|
| `neo -h` 报 `command not found` | PATH 问题 / 未全局安装 / Windows 未更新 PATH | 重新全局安装 `npm i -g neo-cmp-cli --registry=...` |
| `neo push cmp` / `pull cmp` / `linkDebug` / `delete cmp` 报"找不到配置" / 无组件可发 | 未做项目结构预检，当前目录不存在 `neo.config.js` | 先 `neo create project --name=<name>`（默认）或 `neo init -t <type> -n <name>`（指定模板时）创建项目后再执行（原则 6） |
| `neo push cmp` / `pull cmp` / `linkDebug` / `delete cmp` 卡住 / 401 | 未做登录态预检，当前目录不存在 `.neo-cli/token.json` | 先 `neo login -e <env>` 登录后再执行（原则 5） |
| `neo preview` 报「找不到 `neo-ui-common`」 | 组件依赖平台虚拟模块，`local` 模式无法提供 | 改用 `neo linkDebug` 或 `neo preview -m online` |
| `neo linkDebug` 外链在设计器里不可用 | 未追加 `?debug=true`；未把脚本地址加到「外部链接」面板 | 按流程补两步；确认 localhost 可被设计器访问 |
| `neo push cmp` 报鉴权错 / 401 | token 失效 / 登录环境不对 | `neo logout` → `neo login -e <对应环境>` |
| `neo push cmp` 报 `version` 冲突 | `package.json` 未递增 `version` | 递增 `version` 再发 |
| `neo push cmp` 报"找不到 model" | 组件缺 `model.ts` / `model.js` | 按 `neo-cmp-dev` 硬约束补齐 model |
| `neo pull cmp` 把本地修改覆盖 | 未备份 | 用 Git stash / 分支保留现场；或先手动重命名本地目录 |
| `neo login` 浏览器未自动打开 | 系统默认浏览器未注册 / 无头环境 | 复制终端里的授权 URL 手动打开 |
| `neo login` 授权跳转失败 | 浏览器扩展冲突（例如 Neo UI Extension） | 临时禁用相关扩展再登录 |
| 发布后组件"是否显示"设置无效 | 根节点 DOM 未合并 `props.className`（平台会注入 `design-hide`） | 按 `neo-cmp-dev` 样式硬约束修正 |
| 发布后根节点样式失效 | 根 className 不是组件目录名，样式隔离作用域不匹配 | 根节点 className 必须等于目录名（= cmpType） |
| 安装超时 / EAI_AGAIN | 未走淘宝源 | 追加 `--registry=https://registry.npmmirror.com` 重试 |

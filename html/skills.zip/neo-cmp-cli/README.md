# neo-cmp-cli Skill 说明

为 Agent 提供 **neo-cmp-cli（`neo` 命令）** 的执行层规范：何时用哪条子命令、应传什么参数、怎么把 CLI 的 `inquirer` 交互式列表转换成"先在对话里问用户 → 再以 `-x` 参数非交互执行"的工作流，避免在 Agent bash 中卡住。

## 技能边界（三技能路由）

本技能只处理**命令操作**本身，不写组件代码、不做 Vue 语法迁移：

| 用户意图 | 应使用的技能 |
|---|---|
| 创建 / 发布（上传） / 拉取（下载） / 删除 / 预览 / 外链调试 / 登录 / 登出 / 打开编辑器 **自定义组件或组件项目**（纯命令操作） | **`neo-cmp-cli`（本技能）** |
| 实现 / 开发 / 改造某个自定义组件的**内部功能**（写 `index.tsx` / `model.ts` / `propsSchema` / 事件动作 / 数据对接 / 样式） | `neo-cmp-dev` |
| 把 Vue 组件或项目**改造 / 转换 / 迁移**成自定义组件（有 Vue 源码输入） | `vue-to-react` → 再由 `neo-cmp-dev` 做平台规范落地 |

当用户同时提"创建 + 实现"时，本技能只负责创建骨架（`neo create cmp`），其余 11 步交给 `neo-cmp-dev`。

## 结构

- `scripts/` — **平台对接脚本（Node.js）**，用于 Agent 对接 NeoCRM 平台；**所有脚本启动时会自动做依赖预检**（缺 `node_modules` 时自动 `npm i --registry=https://registry.npmmirror.com`），然后再做登录态预检（未登录则调用 `neo login -e <env>`）：
  - `lib/ensureDeps.js`：依赖预检（自动 `npm i --registry=...`，幂等）
  - `lib/neoClient.js`：共享底座（token/env 读取、登录预检、axios 配置、`neo-open-api` 浏览器环境伪装）
  - `login.js`：登录态预检 / 主动登录
  - `fetchEntityList.js`：拉取平台实体列表（标准 / 自定义 / 全部）
  - `fetchEntityDesc.js`：按 apiKey 获取实体字段详情
  - `fetchCustomCmpList.js`：拉取当前租户的自定义组件列表（从 `.neo-cli/env.json` 拼接 API 地址）
  - `pullCustomCmp.js`：交互式选择 + 批量 `neo pull cmp -n <cmpType>`（含「拉取全部」选项）
  - `README.md`：脚本使用说明
- `SKILL.md` — 主文档，含 frontmatter（name + description，带触发关键词），覆盖：
  - 10 条核心原则（规避交互式卡顿 / 长时运行走后台+任务完成通知 / 安装前 `neo -v` 预检 / 默认走淘宝源 / 执行前告知风险 / 需登录类命令的登录态预检 / 需项目环境类命令的项目结构预检 / 预览≠调试 / 跳转详情页 / 字段验证）
  - 安装与 Windows 常见问题
  - **每条命令的「交互点 → 询问话术 → 非交互式参数」映射**（`init` / `create project` / `create cmp` / `login` / `logout` / `preview` / `linkDebug` / `push cmp` / `pull cmp` / `delete cmp` / `open` / 其它无交互命令）
  - 标准开发流程（从 0 到发布的最短链路）
  - 与 `neo-cmp-dev` 等上层技能的协作矩阵
  - 登录 / 环境配置（OAuth2 + 密码模式）
  - 常见报错 & 排查表
  - 交互式命令全景速查表

## 主要使用方

- [`neo-cmp-dev`](../neo-cmp-dev/SKILL.md) — 在其 11 步开发关键步骤中的第 3 / 10 / 11 步调用本技能命令（第 10 步委托本技能执行安装依赖与格式化；第 11 步由 `neo-cmp-dev` 向用户询问「预览 / linkDebug / 发布」三选项，选定后整体转交本技能执行）。
- 其他需要走 `neo` 命令的技能（如迁移、发布、拉取回本地等场景）。

## 关键约定

1. **永远先把 `inquirer` 选项列给用户，拿到选择后再用 `-t/-n/-e/-d/-m/-p` 等参数一次性执行**，禁止让 Agent 在 bash 中直接触发交互式列表。
2. **长时运行命令**（`neo preview` / `neo linkDebug` / `neo dev`）走**后台进程**工具启动，从输出里抓 URL 或端口后**立即通知用户任务完成**，不阻塞等待进程结束。
3. **安装前预检**：执行 `npm i -g neo-cmp-cli` 前必须先 `neo -v` 检测，已安装则跳过。
4. **淘宝源策略**：仅两类场景自动注入（全局装 `neo-cmp-cli`、工程根 `npm install`），其余走默认源；工程已有 `.npmrc` 指向私服时沿用。
5. **高风险命令**（`neo delete cmp` / `neo pull cmp` / `neo push cmp`）执行前显式告知风险并二次确认。
6. **需登录类命令**（`neo push cmp` / `neo pull cmp` / `neo linkDebug` / `neo delete cmp`）执行前**必须**先检查当前目录下是否存在 `.neo-cli/token.json`；不存在则立刻中止并提示用户 `neo login -e <env>` 完成授权登录。
7. **需项目环境类命令**（`neo push cmp` / `neo pull cmp` / `neo linkDebug` / `neo delete cmp`）执行前**必须**先检查当前目录下是否存在 `neo.config.js`；不存在则立刻中止并提示用户先 `neo init -t <type> -n <name>` 或 `neo create project --name=<name>` 创建自定义组件项目。预检顺序：需项目 → 需登录 → 非交互式参数解析 → 执行。
8. **预览 ≠ 调试**：用户说"预览/在线预览/本地预览" → `neo preview`；用户说"调试/调试组件/联调/exlinkDebug" → `neo linkDebug`，不可混用。
9. **列表组件需添加实体名称跳转详情页**：生成列表组件时，点击实体名称（`label`/`name`/`xxName`）必须跳转到对应的详情页，使用 `scripts/buildEntityDetailUrl.js` 生成跳转代码。
10. **字段验证**：组件使用到平台实体数据时，发布前必须用 `scripts/validateEntityFields.js` 验证所用字段是否存在于实体中；若发现不存在的字段，提示用户并协助从组件代码中剔除。

## 资料来源
- [neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/)

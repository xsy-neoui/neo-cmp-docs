---
name: neo-cmp-cli
description: 用于代用户执行 neo-cmp-cli（neo 命令）的命令层技能，覆盖"命令执行"与"安装运维"两类操作（不写组件内部实现，也不做 Vue 迁移）。**命令类**：创建 / 初始化 / 新建 / 发布 / 上传 / 拉取 / 下载 / 删除 / 预览 / 本地调试 / 外链调试 / 登录 / 登出 / 打开编辑器 **自定义组件或组件项目**；**安装类**：全局安装/升级 `neo-cmp-cli`、工程全量依赖安装（`npm install`/`yarn`/`pnpm install`）、`npm run format`。此技能负责把 neo 命令的 inquirer 交互式列表在对话中先问清用户，再用非交互式参数（-t / -n / -e / -d / -m / -p 等）一次性执行，避免 agent bash 卡住，并做登录态与项目结构预检。**安装前必先 `neo -v` 检测是否已安装**，已安装则跳过安装步骤。**首次创建自定义组件项目时，默认走 `neo create project`（空项目），只有当用户显式要求要用某个内置模板（如 echarts / antd / neo-h5-cmps 等）时才改用 `neo init -t <type>`**。**淘宝源（https://registry.npmmirror.com）仅在两种场景自动注入**：① 全局安装 / 升级 `neo-cmp-cli` 本身；② 在项目根目录安装工程全量依赖（`npm install` / `yarn` / `pnpm install`）。其它 npm / yarn / pnpm 操作（单包增删升级、`npx`、发布构建等）一律走用户环境 / 工程默认源，不再追加 `--registry`。**不用于**：在自定义组件内部实现某项具体业务功能 / 属性面板 / 事件动作 / 数据接入 / 样式（→ neo-cmp-dev）；把 Vue 组件或整个 Vue 项目改造 / 转换 / 迁移成自定义组件（→ vue-to-react）。触发关键词：neo init、neo create project、neo create cmp、neo preview、neo linkDebug、neo push cmp、neo pull cmp、neo delete cmp、neo login、neo logout、neo open、创建自定义组件项目、发布自定义组件、上传自定义组件、拉取自定义组件、下载自定义组件、删除自定义组件、预览自定义组件、在线预览自定义组件、本地预览自定义组件、调试自定义组件、外链调试自定义组件、实体详情页跳转、字段验证、登录 Neo 平台、登出 Neo 平台、安装 neo-cmp-cli、安装依赖、全局格式化。
---

# Neo CLI 技能

为 `neo-cmp-dev` 提供**命令执行层**规范：**什么场景用什么命令/参数、如何避免交互式卡住**。

> 不覆盖：组件内部实现（→ `neo-cmp-dev`）、vue→react 迁移（→ `vue-to-react`）、UI 设计（→ `frontend-design`）。

::: v-pre

## 技能边界

| 用户意图 | 应使用的技能 |
|---|---|
| **命令操作**：创建项目/新建组件/预览/外链调试/登录/登出/发布/拉取/删除/打开编辑器 | **本技能** |
| **组件内部实现**：写 `index.tsx`/`model.ts`/`propsSchema`/事件动作/数据源/样式 | → `neo-cmp-dev` |
| **Vue→React 迁移**：把 Vue 项目改造成自定义组件 | → `vue-to-react` |

**同时表达"创建+实现"时**：命令层走本技能，实现层走 `neo-cmp-dev`，不在本技能写组件代码。

## 何时使用

- Agent 代执行 `neo` 命令（`init`/`create`/`preview`/`linkDebug`/`push`/`pull`/`delete`/`login` 等）。
- Agent 代执行 `npm install` / `npm run format` 安装和格式化命令。
- **安装预检**：执行安装前先 `neo -v` 检测是否已安装 neo-cmp-cli，避免重复安装。
- 被 `neo-cmp-dev` 第 3 步（`neo create cmp`）、第 10 步（`npm install` + `npm run format`）、第 11 步（开发完成后的预览/调试/发布）调用。

## 核心原则

### 原则 1：永远不让 `neo` 走 inquirer 交互

Agent bash 无法输入 inquirer 弹窗，会**卡住**。流程：识别交互点（见命令参考）→ 对话中列编号问用户 → 用非交互参数（`-t`/`-n`/`-e`/`-d`/`-m`/`-p`）执行。需拉线上列表的场景（`neo pull/delete cmp` 无 `--name`）先做只读操作拿到列表再问。**禁止**把 `neo` 命令放到后台进程启动（读不到 stdin 会静默失败）。

### 原则 2：长时命令走后台进程 + 通知用户完成

`neo preview`/`neo linkDebug`/`neo dev` → 后台进程启动，从输出提取 URL 或端口信息，**然后立即通知用户命令已启动**（例如"预览已启动，访问地址：http://localhost:xxx"），**不要阻塞等待进程结束**。Agent 应在提取到关键信息后结束该步骤。

### 原则 3：淘宝源仅两类场景注入

`registry.npmmirror.com` 仅用于：① 全局装/升级 `neo-cmp-cli`；② 项目根安装全量依赖。**其它**走默认源。工程已有 `.npmrc` 指向私服时沿用，不覆盖。详见 [`references/installation.md`](references/installation.md)。

### 原则 4：安装前预检（`neo -v`）

执行 `npm i -g neo-cmp-cli` **之前必须先运行 `neo -v`** 检测当前电脑是否已安装：
- `neo -v` 成功（已安装）→ **跳过安装，直接进入下一步**
- `neo -v` 失败（未安装）→ 按淘宝源策略执行 `npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com`
- 升级场景同理：先 `neo -v` 检查，再 `npm update -g neo-cmp-cli`

安装完成后再次 `neo -v` 确认安装成功。

### 原则 5：执行前说明操作

每条命令前说明做什么、改什么、是否可逆。`neo delete cmp` **不可恢复**，`neo pull cmp` **会覆盖本地**，`neo push cmp` **会发布到线上**。

### 原则 6：需登录命令必做预检（强制执行）

**检查 `.neo-cli/token.json`** 的命令：`neo push cmp`/`pull cmp`/`linkDebug`/`delete cmp`。存在→继续；不存在→中断，提示 `neo login -e <env>`。**预检优先于参数解析**。例外（不检）：`neo login`/`logout`/`-h`/`--version`/`open`/`create project`/`init`/`create cmp`/`preview -m local`/`config init`/`build*`/`inspect`。

**检查方式（强制）**：Agent 必须显式执行登录态检查，并在回复中输出检查结果：

1. 使用 `read_file` 或 `cat` 读取 `{cwd}/.neo-cli/token.json`
2. 文件存在且内容有效 → 回复中输出 `✅ 登录态检查通过`
3. 文件不存在 → 回复中输出 `❌ 未登录，请先执行 neo login -e <env>`，**中断后续命令执行**
4. Agent 在回复中**未输出上述任一结果**的，视为 **未执行预检**，属于违规操作

路径约定：以当前工作目录下的 `.neo-cli/token.json` 为准。

### 原则 7：需项目命令必做项目预检

**检查 `neo.config.js`** 的命令：`neo push cmp`/`pull cmp`/`linkDebug`/`delete cmp`。存在→继续；不存在→中断，提示先 `neo create project -n <name>`（默认）或（指定模板时）`neo init -t <type> -n <name>`。**预检顺序：项目结构(原则7)→登录态(原则6)→参数解析(原则1)→执行**。路径约定：以当前工作目录下的 `neo.config.js` 为准。

### 原则 8：预览 ≠ 调试

| 意图 | 命令 |
|---|---|
| **预览**（看效果/本地运行） | `neo preview -m local\|online` |
| **调试**（联调/在设计器里测/linkDebug） | `neo linkDebug -p pc\|h5`（需预检+登录） |

两条都走后台进程。`-m local` 不依赖平台运行时；`-m online` 等同 linkPreview（需登录）。

## 命令参考（先问用户 → 非交互式执行）

每条命令的详细"询问话术"见 [`references/command-details.md`](references/command-details.md)，此处仅列命令形式和参数。

### 创建与新增

| # | 命令 | 参数 | 说明 |
|---|---|---|---|
| 1 | `neo create project` | `-n <name>` | 创建空项目（**首次创建的默认路径**） |
| 2 | `neo init` | `-t <type> -n <name>` | 按模板创建（**仅用户指定模板时**）。模板：`neo-web-entity-grid`/`neo-h5-cmps`/`neo`/`neo-bi-cmps`/`antd`/`echarts`/`amap`/`vue2` |
| 3 | `neo create cmp` | `-n <name> -d <all\|web\|mobile>` | 当前项目新增组件。组件名建议 `xxx__c`（小驼峰+`__c`） |

### 授权与登出

| # | 命令 | 参数 | 说明 |
|---|---|---|---|
| 4 | `neo login` | `-e <env>` | 登录。env：`production`/`p20`/`sandbox`/`cd`/`tencentuat`/`custom`。token 写入 `{projectRoot}/.neo-cli/token.json` |
| 5 | `neo logout` | 无 | 登出 |

### 预览与调试（长时运行，走后台进程）

| # | 命令 | 参数 | 预检 |
|---|---|---|---|
| 6 | `neo preview` | `-n <name> -m <local\|online>` | — |
| 7 | `neo linkDebug` | `-p <pc\|h5>` | ✅ 项目 + ✅ 登录。提取 `http://localhost:<port>/index.js`，设计器 URL 加 `?debug=true`，在「外部链接」面板添加 |

### 发布、拉取、删除（需预检）

| # | 命令 | 参数 | 说明 |
|---|---|---|---|
| 8 | `neo push cmp` | `-n <name>` | 发布。批量：`ls src/components/` → 用户确认 → 逐条执行，失败不中断，完成后汇总 |
| 9 | `neo pull cmp` | `-n <name>` | 拉取线上组件。**会覆盖本地同名目录**，先提醒备份。不知组件名时让用户人工提供 |
| 10 | `neo delete cmp` | `-n <name>` | 删除线上组件。**不可恢复，强二次确认** |

### 其它

| # | 命令 | 参数 | 说明 |
|---|---|---|---|
| 11 | `neo open` | `-e <cursor\|vscode\|code\|auto> -n <name>` | 编辑器打开项目 |
| 12 | `neo config init` | 无 | 生成 `neo.config.js` |
| 12 | `neo dev` | 无 | 本地开发模式（历史命令） |
| 12 | `neo build` / `neo build2lib` / `neo build2esm` | 无 | 构建命令 |
| 12 | `neo inspect` | `[-t build\|dev\|lib]` | 输出构建配置 |

### 工程维护

| # | 命令 | 参数 | 说明 |
|---|---|---|---|
| A | `npm install` / `yarn` / `pnpm install` | 识别 lock 文件选包管理器 | 安装工程全量依赖（淘宝源策略） |
| B | `npm run format` | — | 全局格式化，不存在时提示补 `"format": "prettier --write ..."` |
| C | `neo -v` | — | 安装预检：检测 neo-cmp-cli 是否已安装 |

## 标准开发流程

```
0. 🔍 neo -v (预检：已安装则跳过安装，未安装则执行一步)
1. npm i -g neo-cmp-cli (先 neo -v 检测，未安装再执行：淘宝源策略见参考文献 installation.md)
2. ⚠️ neo create project --name=<name>          # 默认空项目
   # 或（用户指定模板时）：neo init -t <type> -n <name>
3. cd <project> && npm install (识别 lock 选包管理器)
4. ⚠️ neo create cmp -n <name> -d <all|web|mobile>
5. 本地调试（二选一）：
   5a. neo preview -n <name> -m <local|online>   # 预览，后台进程，提取 URL 后通知用户完成
   5b. 📂+🔐 neo linkDebug -p <pc|h5>            # 调试，后台进程，需预检，提取端口后通知用户完成
6. ⚠️ neo login -e <env>
7. 🔍 node skills/.../validateEntityFields.js -k <apiKey> -f f1,f2  # 字段验证（参考 neo-cmp-dev 原则）
8. 📂+🔐 neo push cmp -n <name>                  # 发布
```

## 与 `neo-cmp-dev` 协作

| `neo-cmp-dev` 步骤 | 本技能命令 | 说明 |
|---|---|---|
| 3. 初始化组件目录 | `neo create cmp` | 问组件名、targetDevice |
| 10. 安装依赖 + 全局格式化 | `npm install` + `npm run format` | ① 先 `neo -v` 预检neo-cmp-cli是否已安装（原则4）→ ② 识别包管理器（`npm install`/`yarn`/`pnpm install`）→ ③ 安装工程全量依赖（淘宝源策略，工程有`.npmrc`沿用时复用）→ ④ `npm run format`（不存在时提示补 `"format": "prettier --write ..."`）→ ⑤ 汇总结果，失败不阻塞 |
| 11. 开发完成后 | `neo preview` / `neo linkDebug` / `neo login` + `neo push cmp` | 用户选预览/调试/发布后，本技能逐一执行（预检+后台进程→提取URL/端口后通知完成+失败汇总） |

`neo-cmp-dev` 第 11 步以多选形式抛出「① 预览 ② linkDebug ③ 发布」，本技能负责逐一执行。对于 `preview` 和 `linkDebug` 等后台进程命令，提取到 URL/端口后即**通知用户任务已完成**，不阻塞等待进程结束。

## 全景速查表

> 预检顺序：需项目(原则7) → 需登录(原则6) → 参数解析(原则1) → 执行

| 命令 | 需项目 | 需登录 | 交互点 | 非交互式参数 |
|---|---|---|---|---|
| `neo create project` | — | — | 缺 `-n` | `-n <name>` |
| `neo init` | — | — | 缺 `-t`/`-n` | `-t <type> -n <name>` |
| `neo create cmp` | — | — | 缺 `-n`/`-d` | `-n <name> -d <all\|web\|mobile>` |
| `neo login` | — | — | 缺 `-e` | `-e <env>` |
| `neo preview` | — | —² | 缺 `-n`/`-m` | `-n <name> -m <local\|online>` |
| `neo linkDebug` | ✅ | ✅ | 缺 `-p` | `-p <pc\|h5>` |
| `neo push cmp` | ✅ | ✅ | 缺 `-n`(含ALL) | `-n <name>` |
| `neo pull cmp` | ✅ | ✅ | 缺 `-n`(线上列表) | `-n <name>` |
| `neo delete cmp` | ✅ | ✅ | 缺 `-n`(线上列表) | `-n <name>` |

> ² `online` 模式需登录，`local` 模式无需

## 平台对接脚本

`scripts/` 下的 Node 脚本**自动做登录态预检**，Agent 无需在 bash 处理 neo 交互式列表。

| 脚本 | 作用 |
|---|---|
| `scripts/login.js` | 登录态预检/主动登录 |
| `scripts/fetchEntityList.js` | 拉取平台实体列表 |
| `scripts/fetchEntityDesc.js` | 按 apiKey 获取实体字段详情 |
| `scripts/fetchCustomCmpList.js` | 拉取线上自定义组件列表 |
| `scripts/pullCustomCmp.js` | 交互选择+批量拉取（`--all`/`--name a,b`/`--list-only`） |
| `scripts/buildEntityDetailUrl.js` | 生成实体详情页跳转 URL 和代码片段 |
| `scripts/validateEntityFields.js` | 验证字段是否存在于实体中 |

详细说明（共享底座、典型场景、前置依赖、与原则对齐）见 [`references/scripts-detail.md`](references/scripts-detail.md)。

## 参考资料

以下文件包含更详细的背景信息，按需查阅：

- [`references/installation.md`](references/installation.md) — 安装命令、淘宝源策略、Windows 问题
- [`references/login-config.md`](references/login-config.md) — OAuth2/密码模式配置、环境表、token 说明
- [`references/troubleshooting.md`](references/troubleshooting.md) — 常见错误排查表
- [`references/command-details.md`](references/command-details.md) — 每条命令的详细"询问话术"和交互流程
- [`references/scripts-detail.md`](references/scripts-detail.md) — 脚本共享底座、典型场景（拉组件/跳转/验证）、与原则对齐
- [`scripts/README.md`](./scripts/README.md) — 脚本详细使用说明
- 在线文档：[neo-cmp-docs.netlify.app](https://neo-cmp-docs.netlify.app/)

:::
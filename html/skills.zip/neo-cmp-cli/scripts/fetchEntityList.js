#!/usr/bin/env node
/*
 * 拉取平台实体列表（基于 neo-open-api 的 xObject.getEntityList）。
 *
 * 执行前会做登录态预检：如未登录则自动调用 `neo login -e <env>`。
 *
 * 用法：
 *   node skills/neo-cmp-cli/scripts/fetchEntityList.js
 *   node skills/neo-cmp-cli/scripts/fetchEntityList.js --custom      # 只看自定义实体
 *   node skills/neo-cmp-cli/scripts/fetchEntityList.js --all          # 标准 + 自定义
 *   node skills/neo-cmp-cli/scripts/fetchEntityList.js --format json  # 输出 JSON
 *
 * 参数：
 *   --custom                          只拉自定义实体（custom=true）
 *   --all                             标准 + 自定义都拉（调两次接口合并）
 *   --active <true|false>             active 过滤，默认 true
 *   --format <table|json>             输出格式，默认 table
 *   --out <path>                      将结果额外写入文件（json 格式）
 *   --env <env>                       未登录时使用的登录环境（默认 cd）
 *   --project <dir>                   项目根目录（默认 process.cwd()）
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const fs = require('fs');
const path = require('path');

const {
  ensureLogin,
  configureAxiosWithToken,
  prepareOpenApiEnv,
  parseArgs,
  DEFAULT_ENV,
  resolveProjectDir,
} = require('./lib/neoClient');

// 必须在 require('neo-open-api') / axios 之前完成"浏览器环境伪装"
prepareOpenApiEnv();

const axios = require('axios');
const { xObject } = require('neo-open-api');

function buildParams(args) {
  const active = args.active === 'false' ? false : true;
  // 三种模式：
  //   --all            → 同时拉 custom=true/false
  //   --custom         → 只拉 custom=true
  //   默认             → 只拉 custom=false（标准实体）
  if (args.all) {
    return [
      { custom: false, active },
      { custom: true, active },
    ];
  }
  if (args.custom) {
    return [{ custom: true, active }];
  }
  return [{ custom: false, active }];
}

function printTable(entities) {
  if (entities.length === 0) {
    console.log('（空）');
    return;
  }
  const rows = entities.map((e, i) => ({
    '#': i + 1,
    apiKey: e.apiKey || '-',
    label: e.label || '-',
    custom: e.custom === true ? '是' : '否',
    active: e.active === false ? '否' : '是',
  }));
  console.table(rows);
}

async function main() {
  const args = parseArgs(process.argv, { e: 'env', p: 'project' });
  const env = args.env || DEFAULT_ENV;
  const projectDir = resolveProjectDir(args.project);

  const token = await ensureLogin({ env, cwd: projectDir });
  configureAxiosWithToken(axios, token);

  const paramList = buildParams(args);
  const results = [];
  for (const params of paramList) {
    console.log(`[info] 拉取实体列表: custom=${params.custom}, active=${params.active}`);
    const res = await xObject.getEntityList(params);
    if (!res || res.status !== true) {
      throw new Error(
        `获取实体列表失败（custom=${params.custom}）: ${(res && (res.msg || res.code)) || '未知错误'}`,
      );
    }
    const list = Array.isArray(res.data) ? res.data : [];
    results.push(...list);
  }

  // 去重 + 排序
  const unique = new Map();
  for (const e of results) {
    if (e && e.apiKey && !unique.has(e.apiKey)) unique.set(e.apiKey, e);
  }
  const entities = [...unique.values()].sort((a, b) =>
    String(a.apiKey || '').localeCompare(String(b.apiKey || '')),
  );

  console.log(`[info] 共 ${entities.length} 个实体`);

  if ((args.format || 'table') === 'json') {
    console.log(JSON.stringify(entities, null, 2));
  } else {
    printTable(entities);
  }

  if (args.out) {
    const outPath = path.resolve(args.out);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(entities, null, 2), 'utf8');
    console.log(`[done] 已写入: ${outPath}`);
  }
}

main().catch((err) => {
  console.error('[error]', err && (err.stack || err.message || err));
  process.exit(1);
});

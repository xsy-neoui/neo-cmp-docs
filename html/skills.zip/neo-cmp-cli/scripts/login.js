#!/usr/bin/env node
/*
 * 登录态预检脚本。
 *
 * 作用：
 *   - 读取当前项目根目录下的 .neo-cli/token.json
 *   - 如果不存在 / 过期，则调用 `neo login -e <env>` 触发 OAuth2 授权登录
 *   - 否则直接打印当前登录信息
 *
 * 用法：
 *   node skills/neo-cmp-cli/scripts/login.js
 *   node skills/neo-cmp-cli/scripts/login.js --env production
 *   node skills/neo-cmp-cli/scripts/login.js --force
 *   node skills/neo-cmp-cli/scripts/login.js --project /path/to/cmp-project
 *
 * 参数：
 *   --env <production|p20|sandbox|cd|tencentuat|custom>   未登录时使用的环境（默认 cd）
 *   --force                                               强制重新登录
 *   --project <dir>                                       项目根目录（默认 process.cwd()）
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const {
  ensureLogin,
  readToken,
  tokenPath,
  resolveProjectDir,
  parseArgs,
  DEFAULT_ENV,
} = require('./lib/neoClient');

async function main() {
  const args = parseArgs(process.argv, { e: 'env', p: 'project', f: 'force' });
  const env = args.env || DEFAULT_ENV;
  const projectDir = resolveProjectDir(args.project);
  const forceLogin = Boolean(args.force);

  const token = await ensureLogin({ env, cwd: projectDir, forceLogin });

  const userInfo = token.userInfo || {};
  console.log('[done] 已登录 NeoCRM:');
  console.log(`  tokenPath    : ${tokenPath(projectDir)}`);
  console.log(`  instance_uri : ${token.instance_uri}`);
  console.log(`  tenant_id    : ${token.tenant_id || '-'}`);
  console.log(`  tenantName   : ${userInfo.tenantName || '-'}`);
  console.log(`  user         : ${userInfo.name || '-'}${userInfo.email ? ` <${userInfo.email}>` : ''}`);
  if (token.expiresAt) {
    console.log(`  expiresAt    : ${new Date(token.expiresAt).toISOString()}`);
  }
}

main().catch((err) => {
  console.error('[error]', err && (err.stack || err.message || err));
  process.exit(1);
});

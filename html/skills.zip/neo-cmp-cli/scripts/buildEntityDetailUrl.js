#!/usr/bin/env node
/*
 * 构建实体详情页 URL 并生成列表组件中"点击实体名称跳转详情页"的代码片段。
 *
 * 当生成列表组件时，点击实体名称（实体名称通常记录在 label、name 或 xxName 字段中）
 * 应跳转到对应的详情页。本脚本帮助快速生成 URL 和嵌入组件的点击跳转逻辑。
 *
 * 用法：
 *   # 生成实体的详情页 URL
 *   node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js --apiKey opportunity
 *
 *   # 生成 URL + React 点击跳转代码片段
 *   node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k account --code
 *
 *   # 指定记录 ID 生成完整 URL
 *   node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k contact -i record123
 *
 * 参数：
 *   --apiKey, -k <apiKey>             实体 apiKey（必填）
 *   --recordId, -i <id>               记录 ID（可选，默认占位符 {recordId}）
 *   --code                            同时输出 React 代码片段（供嵌入列表组件）
 *   --format <url|snippet|both>       输出内容：仅 URL / 仅代码片段 / 两者。默认 url
 *   --env <env>                       未登录时使用的登录环境（默认 cd）
 *   --project <dir>                   项目根目录（默认 process.cwd()）
 */

'use strict';

require('./lib/ensureDeps');

const {
  parseArgs,
  DEFAULT_ENV,
  resolveProjectDir,
} = require('./lib/neoClient');

/**
 * 构建实体详情页 URL。
 *
 * @param {string} objectApiKey  实体 apiKey，如 'account'、'opportunity'
 * @param {string} recordId      记录 ID
 * @returns {string}             完整详情页 URL
 */
function buildEntityDetailUrl(objectApiKey, recordId) {
  const q = new URLSearchParams({
    objectApiKey,
    recordId: recordId,
  });
  return `/bff/neoweb#/entityDetail/${objectApiKey}/${recordId}?${q.toString()}`;
}

/**
 * 生成代码片段：列表组件中点击实体名称跳转详情页。
 *
 * @param {string} objectApiKey       实体 apiKey
 * @param {string} nameField          实体名称字段的 apiKey（如 accountName、contactName）
 * @returns {string}                  React TSX 代码片段
 */
function generateClickSnippet(objectApiKey, nameField) {
  const snippet = `// 列表组件中的"实体名称"列点击跳转逻辑
// ${objectApiKey} 实体名称字段: ${nameField}

import { useHistory } from 'react-router-dom';

// 构建详情页 URL
function buildEntityDetailUrl(objectApiKey, recordId) {
  const q = new URLSearchParams({ objectApiKey, recordId });
  return \`/bff/neoweb#/entityDetail/\${objectApiKey}/\${recordId}?\${q.toString()}\`;
}

// 在列表组件中使用（antd Table columns 示例）：
const columns = [
  {
    title: '实体名称',
    dataIndex: '${nameField}',
    key: '${nameField}',
    render: (text, record) => (
      <a
        href={buildEntityDetailUrl('${objectApiKey}', record.id || record.recordId)}
        onClick={(e) => {
          e.preventDefault();
          // 方式 1：使用 react-router 跳转
          // history.push(buildEntityDetailUrl('${objectApiKey}', record.id || record.recordId));
          // 方式 2：使用平台运行时 ctx 跳转
          // props.env.ctx.ui.openUrl(buildEntityDetailUrl('${objectApiKey}', record.id || record.recordId));
        }}
        style={{ color: '#1890ff', cursor: 'pointer' }}
      >
        {text}
      </a>
    ),
  },
];

// 若使用平台 NeoEntityGrid / NeoEntityList 组件，可在 columnConfig 中配置：
// {
//   field: '${nameField}',
//   enableHyperlink: true,
//   hyperlinkUrl: buildEntityDetailUrl('${objectApiKey}', '{recordId}'),
// }
`;

  return snippet;
}

/**
 * 生成字段映射表：对于常见实体，给出适合作为"实体名称"点击跳转的字段名。
 */
function getNameFieldForEntity(apiKey) {
  const fieldMap = {
    account: 'accountName',
    contact: 'contactName',
    opportunity: 'opportunityName',
    order: 'orderName',
    contract: 'contractName',
    lead: 'leadName',
    product: 'productName',
    task: 'taskName',
    serviceCase: 'caseName',
    expenseaccount: 'expenseName',
    visitRecord: 'visitName',
    user: 'userName',
    department: 'departmentName',
    activityrecord: 'activityName',
    schedule: 'scheduleName',
    announcement: 'title',
    goods: 'goodsName',
    payment: 'paymentName',
    receipt: 'receiptName',
    purchaseOrder: 'purchaseName',
    campaign: 'campaignName',
    apply: 'applyName',
    project: 'projectName',
  };
  return fieldMap[apiKey] || null;
}

function main() {
  const args = parseArgs(process.argv, {
    k: 'apiKey',
    i: 'recordId',
    e: 'env',
    p: 'project',
  });

  const apiKey = args.apiKey || (args._ && args._[0]);
  if (!apiKey || typeof apiKey !== 'string') {
    console.error('[error] 缺少必填参数 --apiKey <apiKey>');
    console.error('');
    console.error('用法:');
    console.error('  node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k opportunity');
    console.error('  node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k account --code');
    process.exit(1);
  }

  const recordId = args.recordId || '{recordId}';
  const format = args.format || 'url';
  const showCode = args.code || format === 'snippet' || format === 'both';
  const showUrl = format === 'url' || format === 'both';

  // 构建详情页 URL
  const detailUrl = buildEntityDetailUrl(apiKey, recordId);
  const nameField = getNameFieldForEntity(apiKey);

  console.log('');
  console.log('========================================');
  console.log(`  实体 apiKey : ${apiKey}`);
  console.log(`  名称字段建议: ${nameField || '（未知，请参考 xObject.getDesc 结果）'}`);
  console.log('========================================');
  console.log('');

  if (showUrl) {
    console.log('【详情页 URL】');
    console.log(detailUrl);
    console.log('');
  }

  if (showCode && nameField) {
    console.log('【React 点击跳转代码片段】');
    console.log(generateClickSnippet(apiKey, nameField));
  } else if (showCode && !nameField) {
    console.log('[warn] 未找到该实体的名称字段映射，无法生成精确代码片段。');
    console.log('[warn] 请先用以下命令获取实体字段列表，找到名称字段的 apiKey：');
    console.log(`  node skills/neo-cmp-cli/scripts/fetchEntityDesc.js --apiKey ${apiKey}`);
    console.log('');
    console.log('【通用详情页 URL】');
    console.log(detailUrl);
    console.log('');
    console.log('【通用跳转逻辑片段】');
    console.log(generateClickSnippet(apiKey, '<nameFieldApiKey>'));
  }

  // URL 构建函数（可直接复制到组件代码中使用）
  console.log('【可直接嵌入组件的函数】');
  console.log(`function buildEntityDetailUrl(objectApiKey, recordId) {
  const q = new URLSearchParams({ objectApiKey, recordId });
  return \`/bff/neoweb#/entityDetail/\${objectApiKey}/\${recordId}?\${q.toString()}\`;
}`);
  console.log('');
}

main();

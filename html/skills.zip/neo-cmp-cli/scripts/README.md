# neo-cmp-cli skill · 平台对接脚本

这些脚本在 `neo-cmp-cli` skill 内部辅助 Agent 对接 Neo 平台：拉实体、拉自定义组件列表、按用户选择拉取组件等。所有脚本都用 Node 实现，执行前**先做登录态预检**；未登录时自动调用 `neo login -e <env>` 走 OAuth2 授权流程。

```
scripts/
├── lib/
│   ├── ensureDeps.js          依赖预检：`skills/neo-cmp-cli/node_modules` 不存在时自动 `npm i --registry=...`
│   └── neoClient.js           共享底座：token/env 读取 + 登录预检 + axios 配置 + neo-open-api 浏览器伪装
├── login.js                   登录态预检（未登录则 neo login -e <env>）
├── fetchEntityList.js         拉取平台实体列表（xObject.getEntityList）
├── fetchEntityDesc.js         按 apiKey 拉取实体详情（xObject.getDesc）
├── fetchCustomCmpList.js      从 .neo-cli/env.json 拼接 queryAll 接口地址，拉取自定义组件列表
├── pullCustomCmp.js           交互式选择 / 批量拉取线上自定义组件（额外提供「拉取全部」选项）
├── buildEntityDetailUrl.js    构建实体详情页 URL + 生成列表组件点击跳转代码片段
└── validateEntityFields.js    验证组件使用的字段是否在实体中已存在（发布前校验）
```

## 前置依赖

所有脚本在启动时都会 `require('./lib/ensureDeps')`，**自动做依赖预检**：如果 `skills/neo-cmp-cli/` 下尚不存在 `node_modules`，会先在该目录执行：

```bash
npm i --registry=https://registry.npmmirror.com
```

完成安装后再继续执行原脚本。已安装的情况下仅做一次快速的存在性检查，幂等。所以通常 **不需要手动安装**；若你想提前安装 / 遇到企业网络环境的代理问题，也可以手动执行：

```bash
npm install --registry=https://registry.npmmirror.com
# 或
yarn --registry https://registry.npmmirror.com
```

依赖：

- `axios` — HTTP 客户端
- `neo-open-api` — 对接平台业务对象 / 实体描述 SDK
- `neo-cmp-cli` — 全局或本地都可，脚本会通过系统 PATH 调用 `neo login` / `neo pull cmp`

> **neo 命令未安装时**，脚本会给出明确提示：
> ```
> 未找到 neo 命令，请先全局安装：npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com
> ```

## 登录态预检（所有脚本共享的入口逻辑）

- 当前工作目录下的 `.neo-cli/token.json` 是唯一判定依据（与 `neo login` 的写入位置保持一致）。
- `token` 视为有效的条件：存在 `access_token` + 存在 `instance_uri` + `expiresAt` 未过期。
- 失效时自动执行 `neo login -e <env>`（默认 `cd`），命令会拉起系统浏览器完成 OAuth2 授权；授权成功后 CLI 将 token 写回 `.neo-cli/token.json`，脚本再重新读入继续执行。
- 若全局没有 `neo` 命令，终止并提示用户先安装 `neo-cmp-cli`。

所有脚本都支持下面两个通用参数：

- `--env <production|p20|sandbox|cd|tencentuat|custom>` 未登录时用哪个环境登录，默认 `cd`
- `--project <dir>` 项目根目录（`.neo-cli/` 的父目录），默认 `process.cwd()`

## 1. `login.js` — 登录态预检 / 主动登录

```bash
node skills/neo-cmp-cli/scripts/login.js               # 未登录则触发 neo login -e cd
node skills/neo-cmp-cli/scripts/login.js --env production
node skills/neo-cmp-cli/scripts/login.js --force        # 强制重登
```

## 2. `fetchEntityList.js` — 拉取平台实体列表

参考 `scripts/fetchStandardEntities.js` 的思路，基于 `neo-open-api` 的 `xObject.getEntityList({ custom, active })`。

```bash
# 默认：标准实体
node skills/neo-cmp-cli/scripts/fetchEntityList.js

# 只看自定义实体
node skills/neo-cmp-cli/scripts/fetchEntityList.js --custom

# 标准 + 自定义
node skills/neo-cmp-cli/scripts/fetchEntityList.js --all

# 输出 JSON 并落盘
node skills/neo-cmp-cli/scripts/fetchEntityList.js --all --format json --out scripts/output/entities.json
```

## 3. `fetchEntityDesc.js` — 按 apiKey 获取实体详情

```bash
node skills/neo-cmp-cli/scripts/fetchEntityDesc.js --apiKey account
node skills/neo-cmp-cli/scripts/fetchEntityDesc.js -k customContact__c --format json
node skills/neo-cmp-cli/scripts/fetchEntityDesc.js -k account -o scripts/output/account.json
```

默认以表格展示字段清单（apiKey / label / dataType / required / custom）；`--format json` 会输出接口原始响应。

## 4. `fetchCustomCmpList.js` — 拉取自定义组件列表

从当前项目 `.neo-cli/env.json` 读 `neoBaseURL` + `queryAll`（默认 `/rest/metadata/v3.0/ui/customComponents/actions/queryCustomComponents`）拼出完整接口地址，带着 token 直接 POST：

```bash
node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js

# 只看 React 组件
node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js --framework react

# 写 JSON 到文件
node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js --format json --out scripts/output/custom-cmps.json
```

该脚本同时以 `fetchCustomCmpList({ projectDir, env, framework, pageSize })` 形式导出，供 `pullCustomCmp.js` 等上层脚本复用。

## 5. `pullCustomCmp.js` — 交互式选择 + 批量拉取自定义组件

原生 `neo pull cmp`（不带 `-n`）会弹出交互式列表，在 Agent 的 bash 环境里会卡住。本脚本的流程：

1. 登录态预检 → 必要时 `neo login`
2. 拉取线上自定义组件列表，展示给用户
3. **提供「拉取全部」选项**：用户输入 `0` 或 `all` 即全选；也支持 `1,3,5`、`1-3` 等编号 / 范围
4. 逐个调用 `neo pull cmp -n <cmpType>`（非交互式，不会卡住）
5. 汇总成功 / 失败清单

常用方式：

```bash
# 默认：交互式选择
node skills/neo-cmp-cli/scripts/pullCustomCmp.js

# 非交互式：拉全部
node skills/neo-cmp-cli/scripts/pullCustomCmp.js --all

# 非交互式：直接指定（逗号分隔多个）
node skills/neo-cmp-cli/scripts/pullCustomCmp.js --name orderCard__c,userCard__c

# 仅列出可选组件（JSON），不执行 pull —— 便于 Agent 先在对话里给用户选
node skills/neo-cmp-cli/scripts/pullCustomCmp.js --list-only

# 只打印将要执行的 neo 命令，不实际执行
node skills/neo-cmp-cli/scripts/pullCustomCmp.js --name orderCard__c --dry-run
```

> ⚠️ `neo pull cmp` 会覆盖本地 `src/components/<cmpType>/` 同名目录，请先备份或切到干净分支。

## 6. `buildEntityDetailUrl.js` — 构建实体详情页 URL + 生成跳转代码

当生成列表组件时，点击实体名称（实体名称通常记录在 `label`、`name` 或 `xxName` 字段中）应跳转到对应的详情页。本脚本帮助快速生成 URL 和嵌入组件的点击跳转逻辑。

```bash
# 生成实体的详情页 URL
node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js --apiKey opportunity

# 生成 URL + React 点击跳转代码片段（推荐）
node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k account --code

# 指定记录 ID 生成完整 URL
node skills/neo-cmp-cli/scripts/buildEntityDetailUrl.js -k contact -i record123
```

URL 格式：
```
/bff/neoweb#/entityDetail/{objectApiKey}/{recordId}?objectApiKey={objectApiKey}&recordId={recordId}
```

输出的代码片段包含：
- `buildEntityDetailUrl` 函数（可直接嵌入组件）
- antd Table `columns` 中实体名称列的 `render` 跳转实现
- 使用平台 `NeoEntityGrid`/`NeoEntityList` 时的 `columnConfig` 配置方式

**内置的实体名称字段映射**（常见实体自动识别名称字段）：

| 实体 apiKey | 名称字段 |
|---|---|
| `account` | `accountName` |
| `contact` | `contactName` |
| `opportunity` | `opportunityName` |
| `order` | `orderName` |
| `contract` | `contractName` |
| `lead` | `leadName` |
| `product` | `productName` |
| 其它 | 未映射的实体会在输出中提示先用 `fetchEntityDesc.js` 获取字段列表 |

## 7. `validateEntityFields.js` — 验证字段是否存在于实体中

当组件开发完成且使用到平台实体数据时，**必须**验证使用的字段是否是该实体中已经存在的字段，避免因字段名拼写错误或使用了不存在的字段导致组件运行时报错。脚本仅报告验证结果，不会自动剔除字段——由上游 SKILL 根据结果提示用户处理。

```bash
# 验证一组字段是否存在于实体中
node skills/neo-cmp-cli/scripts/validateEntityFields.js -k account -f accountName,phone,email

# 详细输出（含字段类型信息）
node skills/neo-cmp-cli/scripts/validateEntityFields.js -k contact -f contactName,mobilePhone,email --verbose

# 输出结果到 JSON 文件
node skills/neo-cmp-cli/scripts/validateEntityFields.js -k opportunity -f opportunityName,amount,stage --out result.json
```

输出内容：
- 总计验证字段数、有效/无效数
- ❌ 无效字段清单（不存在的字段名）
- ✅ 有效字段详情（`--verbose` 时显示 apiKey、label、dataType、required、custom）
- 存在无效字段时以非零退出码退出

**使用时机（推荐）**：
1. 组件开发完成准备发布前
2. `propsSchema` 中使用 `selectFieldsApi`/`selectFieldDescApi` 选择了字段后
3. 组件代码中 `xObject.query({ fields: [...] })` 的字段列表确定后

## Agent 使用建议

- **先"列出 → 选择 → 执行"**：对于拉取 / 删除这类需要用户决策的命令，先用 `fetchCustomCmpList.js --format json` 或 `pullCustomCmp.js --list-only` 拿到列表，在对话里让用户选好，再走 `--name` / `--all` 的非交互式执行。
- **登录态预检**：`ensureLogin` 会自动兜底，Agent 可直接跑业务脚本；仅当 `neo login` 需要用户手动在浏览器点"同意"时会短暂弹窗。
- **环境**：脚本默认走 `cd`；如果用户当前组件项目对接的是 production，请显式加 `--env production`。

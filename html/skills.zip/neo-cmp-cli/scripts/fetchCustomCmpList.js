#!/usr/bin/env node
/*
 * 从 .neo-cli/env.json 拼接接口地址，调用「查询自定义组件列表」的管理端接口：
 *   POST  {neoBaseURL}{queryAll}      // 默认 /rest/metadata/v3.0/ui/customComponents/actions/queryCustomComponents
 *   body  { pageNo: 1, pageSize: 1000 }
 *
 * 执行前会做登录态预检：如未登录则自动调用 `neo login -e <env>`。
 *
 * 用法：
 *   node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js
 *   node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js --framework react
 *   node skills/neo-cmp-cli/scripts/fetchCustomCmpList.js --format json --out scripts/output/custom-cmps.json
 *
 * 参数：
 *   --framework <react|vue2|...>     按框架过滤（可选）
 *   --pageSize <n>                   分页大小，默认 1000
 *   --format <table|json>            输出格式，默认 table
 *   --out, -o <path>                 写入文件（json 格式，完整响应数据）
 *   --env <env>                      未登录时使用的登录环境（默认 cd）
 *   --project <dir>                  项目根目录（默认 process.cwd()）
 *
 * 该模块同时以函数形式导出给其它脚本复用：
 *   const { fetchCustomCmpList } = require('./fetchCustomCmpList');
 *   const cmpList = await fetchCustomCmpList({ projectDir, env, framework });
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const fs = require('fs');
const path = require('path');
const axios = require('axios');

const {
  ensureLogin,
  getEnvConfig,
  buildFullUrl,
  parseArgs,
  DEFAULT_ENV,
  resolveProjectDir,
} = require('./lib/neoClient');

const DEFAULT_QUERY_API = '/rest/metadata/v3.0/ui/customComponents/actions/queryCustomComponents';

/**
 * 拉取自定义组件列表。
 *
 * @param {object} [options]
 * @param {string} [options.projectDir]    项目根目录，默认 process.cwd()
 * @param {string} [options.env]           未登录时用于 `neo login -e` 的环境，默认 cd
 * @param {string} [options.framework]     按 framework 过滤（react / vue2 / ...）
 * @param {number} [options.pageSize]      分页大小，默认 1000
 * @returns {Promise<{list: Array, raw: object, url: string}>}
 */
async function fetchCustomCmpList(options = {}) {
  const {
    projectDir: rawProjectDir,
    env = DEFAULT_ENV,
    framework,
    pageSize = 1000,
  } = options;
  const projectDir = resolveProjectDir(rawProjectDir);

  const token = await ensureLogin({ env, cwd: projectDir });

  let envConfig;
  try {
    envConfig = getEnvConfig(projectDir);
  } catch (err) {
    // 若用户过去未通过 neo login 写入 env.json，回退到 token.instance_uri + 默认 API 路径
    if (!token.instance_uri) throw err;
    envConfig = {
      neoBaseURL: token.instance_uri,
      queryAll: DEFAULT_QUERY_API,
    };
  }

  const queryAllPath = envConfig.queryAll || DEFAULT_QUERY_API;
  const url = buildFullUrl(envConfig, queryAllPath);

  console.log(`[info] POST ${url}  (pageSize=${pageSize})`);
  const response = await axios.post(
    url,
    { pageNo: 1, pageSize },
    {
      headers: {
        Authorization: `Bearer ${token.access_token}`,
        'xsy-inner-source': 'bff',
        'Content-Type': 'application/json',
      },
    },
  );

  const { code, message, msg, data } = response.data || {};
  if (code && code !== 200) {
    throw new Error(`获取自定义组件列表失败: ${message || msg || '未知错误'}`);
  }

  let list = Array.isArray(data) ? data : Array.isArray(data && data.data) ? data.data : [];
  if (framework) {
    list = list.filter(
      (c) => String(c.framework || '').toLowerCase() === String(framework).toLowerCase(),
    );
  }
  list = list.sort((a, b) =>
    String(a.cmpType || '').localeCompare(String(b.cmpType || '')),
  );

  return { list, raw: response.data, url };
}

function printTable(list) {
  if (list.length === 0) {
    console.log('（当前租户暂无自定义组件）');
    return;
  }
  const rows = list.map((c, i) => ({
    '#': i + 1,
    cmpType: c.cmpType || '-',
    label: c.label || '-',
    framework: c.framework || '-',
    version: c.version || '-',
    category: c.componentCategory || '-',
  }));
  console.table(rows);
}

async function main() {
  const args = parseArgs(process.argv, { o: 'out', e: 'env', p: 'project' });
  const { list, raw } = await fetchCustomCmpList({
    projectDir: args.project,
    env: args.env,
    framework: args.framework,
    pageSize: args.pageSize ? Number(args.pageSize) : undefined,
  });

  console.log(`[info] 共 ${list.length} 个自定义组件`);
  if ((args.format || 'table') === 'json') {
    console.log(JSON.stringify(list, null, 2));
  } else {
    printTable(list);
  }

  if (args.out) {
    const outPath = path.resolve(args.out);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(raw, null, 2), 'utf8');
    console.log(`[done] 已写入: ${outPath}`);
  }
}

module.exports = { fetchCustomCmpList, DEFAULT_QUERY_API };

if (require.main === module) {
  main().catch((err) => {
    console.error('[error]', err && (err.stack || err.message || err));
    process.exit(1);
  });
}

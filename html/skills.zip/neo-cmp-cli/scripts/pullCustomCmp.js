#!/usr/bin/env node
/*
 * 拉取（下载）自定义组件到本地：
 *   1. 登录态预检（未登录 → neo login -e <env>）
 *   2. 从平台拉取「当前租户」的自定义组件列表（复用 fetchCustomCmpList）
 *   3. 把列表以编号形式展示给用户，**额外提供「拉取全部」选项**，让用户选择
 *   4. 根据选择逐个执行 `neo pull cmp -n <cmpType>`
 *
 * 本脚本自身不是交互式 neo 命令的替代品，而是"先在对话 / 终端里选好，再走非交互式 -n"的工作流载体。
 *
 * 用法：
 *   # 默认：进入交互式选择（单个 / 全部）
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js
 *
 *   # 非交互式：直接指定 cmpType（多个用逗号分隔）
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --name orderCard__c
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --name orderCard__c,userCard__c
 *
 *   # 非交互式：直接拉取全部
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --all
 *
 *   # 只列出线上组件供选择（不执行 pull），配合 Agent / 上层技能收集用户选择
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --list-only
 *
 *   # 不真正执行 neo pull cmp，仅打印命令（方便检查）
 *   node skills/neo-cmp-cli/scripts/pullCustomCmp.js --dry-run
 *
 * 参数：
 *   --name, -n <cmpType[,cmpType...]>   指定要拉取的组件（多个用逗号分隔）
 *   --all                                拉取全部线上自定义组件
 *   --list-only                          只展示列表，不执行 pull（输出 JSON + 表格）
 *   --dry-run                            只打印将要执行的 neo 命令，不真正执行
 *   --framework <react|vue2>             按 framework 过滤待选列表
 *   --env <env>                          未登录时 neo login 的环境（默认 cd）
 *   --project <dir>                      项目根目录（默认 process.cwd()）
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const readline = require('readline');
const { spawnSync } = require('child_process');

const {
  parseArgs,
  resolveProjectDir,
  DEFAULT_ENV,
} = require('./lib/neoClient');
const { fetchCustomCmpList } = require('./fetchCustomCmpList');

function printTable(list) {
  const rows = list.map((c, i) => ({
    '#': i + 1,
    cmpType: c.cmpType || '-',
    label: c.label || '-',
    framework: c.framework || '-',
    version: c.version || '-',
  }));
  console.table(rows);
}

function ask(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => {
      rl.close();
      resolve(String(answer || '').trim());
    });
  });
}

// 解析用户输入（编号列表），支持：
//   "0"          → 拉取全部
//   "1"          → 第 1 个
//   "1,3,5"      → 多个
//   "1-3"        → 范围
//   "all"/"a"    → 全部
function parseSelection(input, total) {
  const raw = input.toLowerCase();
  if (!raw) return [];
  if (raw === 'all' || raw === 'a' || raw === '0') {
    return Array.from({ length: total }, (_, i) => i);
  }
  const set = new Set();
  const parts = raw.split(/[\s,]+/).filter(Boolean);
  for (const part of parts) {
    const rangeMatch = part.match(/^(\d+)-(\d+)$/);
    if (rangeMatch) {
      const start = Number(rangeMatch[1]);
      const end = Number(rangeMatch[2]);
      if (Number.isFinite(start) && Number.isFinite(end)) {
        const [s, e] = start <= end ? [start, end] : [end, start];
        for (let i = s; i <= e; i += 1) {
          if (i >= 1 && i <= total) set.add(i - 1);
        }
      }
      continue;
    }
    const n = Number(part);
    if (Number.isFinite(n) && n >= 1 && n <= total) set.add(n - 1);
  }
  return [...set].sort((a, b) => a - b);
}

function runPullCmd({ cmpType, cwd, dryRun }) {
  const cmd = 'neo';
  const cmdArgs = ['pull', 'cmp', '-n', cmpType];
  const display = `${cmd} ${cmdArgs.join(' ')}`;
  console.log(`\n[exec] ${display}`);
  if (dryRun) {
    console.log('[dry-run] 跳过实际执行');
    return { status: 0 };
  }
  const result = spawnSync(cmd, cmdArgs, {
    stdio: 'inherit',
    cwd,
    shell: process.platform === 'win32',
    env: process.env,
  });
  if (result.error) {
    if (result.error.code === 'ENOENT') {
      throw new Error(
        '未找到 neo 命令，请先全局安装：npm i -g neo-cmp-cli --registry=https://registry.npmmirror.com',
      );
    }
    throw new Error(`执行 ${display} 失败: ${result.error.message}`);
  }
  return result;
}

async function main() {
  const args = parseArgs(process.argv, {
    n: 'name',
    p: 'project',
    e: 'env',
  });
  const projectDir = resolveProjectDir(args.project);
  const env = args.env || DEFAULT_ENV;
  const dryRun = Boolean(args['dry-run']);

  // 1. 拉平台列表（顺带登录态预检）
  const { list } = await fetchCustomCmpList({
    projectDir,
    env,
    framework: args.framework,
  });

  if (list.length === 0) {
    console.log('[info] 当前租户暂无任何自定义组件，无需拉取。');
    return;
  }

  console.log(`[info] 当前租户共有 ${list.length} 个自定义组件：`);
  printTable(list);

  if (args['list-only']) {
    console.log(JSON.stringify(list.map((c) => ({
      cmpType: c.cmpType,
      label: c.label,
      framework: c.framework,
      version: c.version,
    })), null, 2));
    return;
  }

  // 2. 决定要拉取的目标
  let targets = [];
  if (args.all) {
    targets = list.map((c) => c.cmpType).filter(Boolean);
  } else if (args.name) {
    const requested = String(args.name).split(',').map((s) => s.trim()).filter(Boolean);
    const missing = requested.filter((n) => !list.some((c) => c.cmpType === n));
    if (missing.length > 0) {
      console.warn(`[warn] 线上未找到以下组件：${missing.join(', ')}，将跳过。`);
    }
    targets = requested.filter((n) => list.some((c) => c.cmpType === n));
  } else {
    // 交互式选择
    console.log('\n请选择要拉取的组件：');
    console.log('  0  或  all     → 拉取全部');
    console.log('  1              → 第 1 个');
    console.log('  1,3,5          → 多个');
    console.log('  1-3            → 范围');
    console.log('  回车直接退出');
    const answer = await ask('> ');
    if (!answer) {
      console.log('[info] 未选择任何组件，已退出。');
      return;
    }
    const idxs = parseSelection(answer, list.length);
    if (idxs.length === 0) {
      console.log('[info] 无有效选择，已退出。');
      return;
    }
    targets = idxs.map((i) => list[i].cmpType).filter(Boolean);
  }

  if (targets.length === 0) {
    console.log('[info] 没有可拉取的目标，已退出。');
    return;
  }

  // 3. 批量执行 neo pull cmp -n <cmpType>
  console.log(`\n[info] 将依次拉取 ${targets.length} 个组件：${targets.join(', ')}`);
  console.log('[warn] neo pull cmp 会覆盖本地 src/components/<cmpType>/ 同名目录，请确认已备份。');

  const success = [];
  const failed = [];
  for (const cmpType of targets) {
    try {
      const result = runPullCmd({ cmpType, cwd: projectDir, dryRun });
      if (result.status === 0) {
        success.push(cmpType);
      } else {
        failed.push({ cmpType, status: result.status });
      }
    } catch (err) {
      failed.push({ cmpType, error: err.message });
    }
  }

  console.log('\n===== 拉取结果 =====');
  console.log(`成功 (${success.length}): ${success.join(', ') || '-'}`);
  if (failed.length > 0) {
    console.log(`失败 (${failed.length}):`);
    failed.forEach((f) => {
      console.log(`  - ${f.cmpType}${f.error ? `（${f.error}）` : `（退出码 ${f.status}）`}`);
    });
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('[error]', err && (err.stack || err.message || err));
  process.exit(1);
});

#!/usr/bin/env node
/*
 * 验证组件中使用的字段是否在平台实体中已存在。
 *
 * 当组件使用到平台实体数据时，必须验证使用的字段是否是该实体中已经存在的字段，
 * 避免因字段名拼写错误或使用了不存在的字段导致组件运行时报错。
 * 脚本仅报告验证结果，不自动剔除——由 SKILL 层提示用户处理无效字段。
 *
 * 用法：
 *   # 验证一组字段是否存在于实体中
 *   node skills/neo-cmp-cli/scripts/validateEntityFields.js -k account -f accountName,phone,email
 *
 *   # 详细输出（含字段类型信息）
 *   node skills/neo-cmp-cli/scripts/validateEntityFields.js -k contact -f contactName,mobilePhone,email --verbose
 *
 *   # 输出结果到 JSON 文件
 *   node skills/neo-cmp-cli/scripts/validateEntityFields.js -k opportunity -f opportunityName,amount,stage --out result.json
 *
 * 参数：
 *   --apiKey, -k <apiKey>             实体 apiKey（必填）
 *   --fields, -f <field1,field2,...>  待验证的字段 apiKey 列表，逗号分隔（必填）
 *   --verbose                          详细输出：验证通过的字段也显示类型信息
 *   --out, -o <path>                  将验证结果写入 JSON 文件
 *   --env <env>                       未登录时使用的登录环境（默认 cd）
 *   --project <dir>                   项目根目录（默认 process.cwd()）
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const fs = require('fs');
const path = require('path');

const {
  ensureLogin,
  configureAxiosWithToken,
  prepareOpenApiEnv,
  parseArgs,
  DEFAULT_ENV,
  resolveProjectDir,
} = require('./lib/neoClient');

prepareOpenApiEnv();

const axios = require('axios');
const { xObject } = require('neo-open-api');

/**
 * 验证字段列表是否存在于实体的字段集合中。
 *
 * @param {string} apiKey         实体 apiKey
 * @param {string[]} fields       待验证的字段 apiKey 列表
 * @returns {Promise<{valid: object[], invalid: string[]}>}
 *   valid: 有效字段详情数组
 *   invalid: 不存在的字段名列表
 */
async function validateEntityFields(apiKey, fields) {
  const res = await xObject.getDesc(apiKey);
  if (!res || res.status !== true) {
    throw new Error(`获取实体详情失败: ${(res && (res.msg || res.code)) || '未知错误'}`);
  }

  const detail = res.data || {};
  const entityFields = Array.isArray(detail.fields) ? detail.fields : [];

  // 构建 field apiKey -> field meta 的映射
  const fieldMap = {};
  for (const f of entityFields) {
    const key = (f.apiKey || f.name || '').toLowerCase();
    fieldMap[key] = f;
  }

  // 分别记录有效和无效字段
  const valid = [];
  const invalid = [];

  for (const field of fields) {
    const trimmed = field.trim();
    if (!trimmed) continue;

    const lowerKey = trimmed.toLowerCase();
    if (fieldMap[lowerKey]) {
      valid.push({
        apiKey: fieldMap[lowerKey].apiKey || fieldMap[lowerKey].name,
        label: fieldMap[lowerKey].label || fieldMap[lowerKey].displayName || '-',
        dataType: fieldMap[lowerKey].dataType || fieldMap[lowerKey].type || '-',
        required: fieldMap[lowerKey].required === true || fieldMap[lowerKey].isRequired === true,
        custom: fieldMap[lowerKey].custom === true || fieldMap[lowerKey].isCustom === true,
      });
    } else {
      invalid.push(trimmed);
    }
  }

  return { valid, invalid };
}

function printValidationResult(result, verbose) {
  const { valid, invalid } = result;

  console.log('');
  console.log('======= 字段验证结果 =======');
  console.log(`  总计验证 : ${valid.length + invalid.length} 个字段`);
  console.log(`  有效     : ${valid.length} 个字段`);
  console.log(`  无效     : ${invalid.length} 个字段`);

  if (invalid.length > 0) {
    console.log('');
    console.log('❌ 以下字段在实体中不存在：');
    invalid.forEach((f) => console.log(`   - ${f}`));
  }

  if (verbose && valid.length > 0) {
    console.log('');
    console.log('有效字段详情：');
    const rows = valid.map((f, i) => ({
      '#': i + 1,
      apiKey: f.apiKey,
      label: f.label,
      dataType: f.dataType,
      required: f.required ? '是' : '否',
      custom: f.custom ? '是' : '否',
    }));
    console.table(rows);
  }

  console.log('');
}

async function main() {
  const args = parseArgs(process.argv, {
    k: 'apiKey',
    f: 'fields',
    o: 'out',
    e: 'env',
    p: 'project',
  });

  const apiKey = args.apiKey || (args._ && args._[0]);
  if (!apiKey || typeof apiKey !== 'string') {
    console.error('[error] 缺少必填参数 --apiKey <apiKey>');
    process.exit(1);
  }

  const fieldsRaw = args.fields || (args._ && args._[1]);
  if (!fieldsRaw || typeof fieldsRaw !== 'string') {
    console.error('[error] 缺少必填参数 --fields <field1,field2,...>');
    process.exit(1);
  }

  const fields = fieldsRaw.split(',').map((s) => s.trim()).filter(Boolean);
  if (fields.length === 0) {
    console.error('[error] --fields 中未包含任何有效字段名');
    process.exit(1);
  }

  const env = args.env || DEFAULT_ENV;
  const projectDir = resolveProjectDir(args.project);
  const verbose = Boolean(args.verbose);

  // 登录态预检
  const token = await ensureLogin({ env, cwd: projectDir });
  configureAxiosWithToken(axios, token);

  console.log(`[info] 验证实体 ${apiKey} 的字段：${fields.join(', ')}`);
  const result = await validateEntityFields(apiKey, fields);

  printValidationResult(result, verbose);

  // 输出到文件
  if (args.out) {
    const outPath = path.resolve(args.out);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(result, null, 2), 'utf8');
    console.log(`[done] 验证结果已写入: ${outPath}`);
  }

  // 如果存在无效字段，以非零退出码退出
  if (result.invalid.length > 0) {
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('[error]', err && (err.stack || err.message || err));
  process.exit(1);
});

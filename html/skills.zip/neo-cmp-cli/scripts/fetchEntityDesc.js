#!/usr/bin/env node
/*
 * 根据 apiKey 获取单个实体的详情（基于 neo-open-api 的 xObject.getDesc）。
 *
 * 执行前会做登录态预检：如未登录则自动调用 `neo login -e <env>`。
 *
 * 用法：
 *   node skills/neo-cmp-cli/scripts/fetchEntityDesc.js --apiKey account
 *   node skills/neo-cmp-cli/scripts/fetchEntityDesc.js --apiKey customContact__c --format fields
 *   node skills/neo-cmp-cli/scripts/fetchEntityDesc.js -k account -o scripts/output/account.json
 *
 * 参数：
 *   --apiKey, -k <apiKey>             实体 apiKey（必填）
 *   --format <json|fields>            输出格式；json：原始 JSON；fields：字段表格。默认 fields
 *   --out, -o <path>                  将结果写入文件（始终是原始 JSON）
 *   --env <env>                       未登录时使用的登录环境（默认 cd）
 *   --project <dir>                   项目根目录（默认 process.cwd()）
 */

'use strict';

// 必须放在任何第三方 require 之前：未安装依赖时先 `npm i --registry=...`。
require('./lib/ensureDeps');

const fs = require('fs');
const path = require('path');

const {
  ensureLogin,
  configureAxiosWithToken,
  prepareOpenApiEnv,
  parseArgs,
  DEFAULT_ENV,
  resolveProjectDir,
} = require('./lib/neoClient');

prepareOpenApiEnv();

const axios = require('axios');
const { xObject } = require('neo-open-api');

function printFieldTable(detail) {
  const fields = Array.isArray(detail.fields) ? detail.fields : [];
  if (fields.length === 0) {
    console.log('（该实体未返回字段信息）');
    return;
  }
  const rows = fields.map((f, i) => ({
    '#': i + 1,
    apiKey: f.apiKey || f.name || '-',
    label: f.label || f.displayName || '-',
    dataType: f.dataType || f.type || '-',
    required: f.required === true || f.isRequired === true ? '是' : '否',
    custom: f.custom === true || f.isCustom === true ? '是' : '否',
  }));
  console.table(rows);
}

async function main() {
  const args = parseArgs(process.argv, { k: 'apiKey', o: 'out', e: 'env', p: 'project' });
  const apiKey = args.apiKey || (args._ && args._[0]);
  if (!apiKey || typeof apiKey !== 'string') {
    console.error('[error] 缺少必填参数 --apiKey <apiKey>');
    process.exit(1);
  }

  const env = args.env || DEFAULT_ENV;
  const projectDir = resolveProjectDir(args.project);

  const token = await ensureLogin({ env, cwd: projectDir });
  configureAxiosWithToken(axios, token);

  console.log(`[info] 获取实体详情: ${apiKey}`);
  const res = await xObject.getDesc(apiKey);
  if (!res || res.status !== true) {
    throw new Error(`获取实体详情失败: ${(res && (res.msg || res.code)) || '未知错误'}`);
  }
  const detail = res.data || {};

  const format = args.format || 'fields';
  if (format === 'json') {
    console.log(JSON.stringify(res, null, 2));
  } else {
    console.log('');
    console.log(`apiKey     : ${detail.apiKey || apiKey}`);
    console.log(`label      : ${detail.label || '-'}`);
    console.log(`pluralLabel: ${detail.pluralLabel || '-'}`);
    console.log(`custom     : ${detail.custom === true ? '是' : '否'}`);
    if (detail.description) console.log(`description: ${detail.description}`);
    console.log('');
    console.log('【字段】');
    printFieldTable(detail);
  }

  if (args.out) {
    const outPath = path.resolve(args.out);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, JSON.stringify(res, null, 2), 'utf8');
    console.log(`[done] 已写入: ${outPath}`);
  }
}

main().catch((err) => {
  console.error('[error]', err && (err.stack || err.message || err));
  process.exit(1);
});
